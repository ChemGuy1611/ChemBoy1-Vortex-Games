# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.0] - 2026-04-02

- Initial release
