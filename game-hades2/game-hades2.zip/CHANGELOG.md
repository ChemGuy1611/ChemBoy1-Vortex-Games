# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.1.3] - 2025-09-26

- Added Epic version ID and full support.
