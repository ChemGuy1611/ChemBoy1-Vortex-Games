# Changelog

## Planned Improvements (Not Yet Released)

- None

## [1.2.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.2.1] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [1.2.0] - 2026-10-11

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.4] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [1.1.3] - 2026-08-30

- Fixed: Plugins are now installed into a folder named after the plugin itself, so plugins that depend on each other load correctly. Plugins installed before this update use a placeholder folder name and need to be reinstalled.
- Fixed: Mod loader, plugin, and tool downloads are now saved under their real file name instead of a temporary one.

## [1.1.2] - 2026-08-17

- Changed: The Browse Thunderstore page asks you to confirm opening an external site once per Vortex session, instead of every time the page is opened.
- Fixed: After a download is started from the Browse Thunderstore page, the Back button no longer returns to the download link.
- Fixed: The Browse Thunderstore page no longer registers a keyboard shortcut that was already in use elsewhere in Vortex.

## [1.1.1] - 2026-08-17

- Fixed: On the Xbox version, the mod loader, plugins, and Binaries mods now install beside the game executable in the game's main folder, instead of the Ship folder used by the other versions.

## [1.1.0] - 2026-08-16

- Added: "Browse Thunderstore" page, which opens the Hades II Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [1.0.0] - 2026-08-15

- Added: Support for the Hell2Modding mod loader, the current Hades II modding route.
- Added: The mod loader, ModUtil, and everything ModUtil needs are downloaded and installed automatically from Thunderstore, with notifications when a new version is available.
- Added: Mod type for ReturnOfModding plugins, so plugins install to the correct folder.
- Note: The older Mod Importer route still works and is unchanged.

## [0.2.0] - 2026-08-03

- Fixed: Readme and changelog files inside mods no longer show up as file conflicts.
- Fixed: Paths are now built safely on all systems.
- Added: Buttons to open the game's PCGamingWiki page, view the changelog, submit a bug report, and open the downloads folder.

## [0.1.3] - 2025-09-26

- Added Epic version ID and full support.
