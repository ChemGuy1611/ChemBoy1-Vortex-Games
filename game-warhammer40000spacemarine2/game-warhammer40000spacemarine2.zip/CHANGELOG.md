# Changelog

## [0.3.3] - 2025-05-14
- Added tool and installer for Integration Studio. Thanks to Pickysaurus.

## [0.3.2] - 2025-04-17
- Disabled symlinks as they don't work with the game after Patch 7.0

## [0.3.1] - 2025-04-16
- Corrected crash reports folder path

## [0.3.0] - 2025-04-15
- Updated for Patch 7.0 - paks go to "client_pc/root/mods" folder and loose files go to "client_pc/root/local"
- Set pak mods folder as default mod install directory. Binaries folder added as a fallback installer. This will ensure FOMOD installers install to mods folder.
- Added button to open folders - paks folder, local mods folder, local appdata folder, and crash reports folder. - folder icon in Mods toolbar.