# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.8.4] - 2026-09-06

- Fixed: Locked load order entries could be moved out of position when using "Move to Top", "Move to Bottom" or the position number box on another entry. Locked entries now keep their place.
- Fixed: The load order position number box now accepts low numbers even when a locked entry is further down the list.

## [0.8.3] - 2026-09-04

- Added: Right-click menu on the load order: enable or disable an entry, lock or unlock it, move it to the top or bottom, and open its staging folder or mod page. Works on one entry or several at once.
- Added: Lock button on each load order row, plus ctrl/shift multi-select.
- Added: Load order filter by status (enabled, disabled, locked, unlocked, unmanaged) with a matched/total count.
- Added: Load order entries for mods Vortex does not manage are now marked "Not managed by Vortex".
- Fixed: A locked load order entry no longer unlocks itself after deploying or reopening the load order page.

## [0.8.2] - 2026-07-29

- Fixed: The load order could disappear after deploying while a mod update was in progress, and only came back after deploying a second time.
- Added: A message now appears if you change the load order while a mod update is still finishing, so it is clear the change was not applied and needs to be made again.
- Fixed: After a mod update finished, the load order page could keep showing out-of-date information until another deployment was run.

## [0.8.1] - 2026-07-25

- Fixed: Using "Update all" to update several mods at once could move them in the load order or uncheck them.

## [0.8.0] - 2026-07-22

- Fixed: Updating a mod could uncheck it or move it in the load order, especially on profiles other than the one you were using.

## [0.7.1] - 2026-05-23

- Added: Function to clear folders from "local" on purge (avoid MODS DETECTED from stray folders after purge)

## [0.7.0] - 2026-04-28

- Improved: Upgraded pak installer dialogue to show full paths
- Improved: Added defensive code in load order deserialization

## [0.6.0] - 2026-04-22

- Improved: Load Order rendering using React - show mod image thumbnails

## [0.5.2] - 2026-02-08

- Improved: Load Order deserialization and serialization now uses js-yaml for proper formatting
- Added: Toggle buttons to Load Order to enable/disable mods (thanks to above improvement)

## [0.5.1] - 2026-02-04

- Added: Automatic save (profile) backup on mod purge
- Added: Button to restore save (profile) from the most recent backup
- Improved: Error handling for function to copy Custom Stratagems Paks to mods folder

## [0.5.0] - 2026-02-02

- Added: Xbox (Game Pass) version support

## [0.4.1] - 2026-01-29

- Added: Buttons to open Custom Stratagems paks folder and copy newest Custom Strat to Pak Mods folder
- Added: Button to open PCGamingWiki page
- Added: Launch tool to launch game without EAC (Offline play only!)

## [0.4.0] - 2026-01-28

- Added: Load Order support for pak mods!
- Added: Handling of multiple pak files in one mod (file selection dialogue)
- Added: Button to open Saves (Profiles) folder - Steam only
- Added: Launch tool and download button for Custom Stratagems
- Added: Launch tool and download button for Index V2
- Fixed: Updated deprecated fsPromises.rmdir() to fsPromises.rm()
- Fixed: Corrected path strings
- Fixed: Always get latest version of IS when downloading

## [0.3.6] - 2025-12-04

- Improved IS installer to remove unnecessary files and folders from the staging folder.
- Updated IS download button to download directly from Nexus Mods.

## [0.3.5] - 2025-09-16

- IS mod installer now extracts both the "client" and "server" default_other.pak files to "mods_source" and copies the "tools" folder to "root" during installation.
- Updated IS notification to reflect that it is now available on Nexus Mods.

## [0.3.4] - 2025-07-08

- Added notification if user has installed Integration Studio mod toolkit with important usage information.
- Added button to open IS download page (folder icon in Mods toolbar).

## [0.3.3] - 2025-05-14

- Added tool and installer for Integration Studio. Thanks to Pickysaurus.

## [0.3.2] - 2025-04-17

- Disabled symlinks as they don't work with the game after Patch 7.0

## [0.3.1] - 2025-04-16

- Corrected crash reports folder path

## [0.3.0] - 2025-04-15

- Updated for Patch 7.0 - paks go to "client_pc/root/mods" folder and loose files go to "client_pc/root/local"
- Set pak mods folder as default mod install directory. Binaries folder added as a fallback installer. This will ensure FOMOD installers install to mods folder.
- Added button to open folders - paks folder, local mods folder, local appdata folder, and crash reports folder. - folder icon in Mods toolbar.
