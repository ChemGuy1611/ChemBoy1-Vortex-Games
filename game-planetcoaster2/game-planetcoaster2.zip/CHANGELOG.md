# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.4.0] - 2026-06-06

- Fixed: ACSE Mods always installed with a top level folder

## [0.3.1] - 2026-04-09

- Added: Xbox (Game Pass) version support.

## [0.3.0] - 2025-10-22

- Added Root modtype and installer for known folders.
- Improved ACSE downloader function.
- Several technical improvements.

## [0.2.0] - 2024-12-13

- Added mod types and installer for saves folder.
- Added Epic Games ID (thanks to user Coppertine).

## [0.1.0] - 2024-11-25

- Initial release
