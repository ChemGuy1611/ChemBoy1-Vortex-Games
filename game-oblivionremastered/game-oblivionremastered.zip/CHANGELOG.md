# Changelog

## Future Improvements (Not Yet Released)
- Load order support for pak mods
- ?Gamebryo extension integration?

## [0.2.0] - 2025-04-23
- Added load order support for plugin mods 
- Removed load order support for pak mods
- Added automatic installer and updater for UE4SS

## [0.1.2] - 2025-04-22
- Added installer for config mods - only available if the game, staging folder, and user folders are on the same drive partition.
- Several more small fixes

## [0.1.1] - 2025-04-22
- Included changelog file
- Several small fixes

## [0.1.0] - 2025-04-22
- Initial release