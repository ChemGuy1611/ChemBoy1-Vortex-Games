# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.2.2] - 2025-05-28

- Fixed profile test when checking for new versions of shadPS4

## [0.2.1] - 2025-03-31

- Fixed shadPS4 re-downloading on every Vortex launch due to file name case-sensitivity

## [0.2.0] - 2025-03-30

- Added download and update functionality for shadPS4 sot that the user will always get the latest verison when managing the game
