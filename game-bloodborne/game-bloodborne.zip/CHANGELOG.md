# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.2.5] - 2025-10-24

- Vortex now passes launch parameters to start Bloodborne automatically using the launch button, and NOT when launching via the shadPS4 tool. This lets the user get to the shadPS4 main menu using the tool without automatically launching Bloodborne.

## [0.2.4] - 2025-10-23

- Fixed shadPS4 update check not running on mod update check.

## [0.2.3] - 2025-07-30

- Version bump to fix mod page.

## [0.2.2] - 2025-05-28

- Fixed profile test when checking for new versions of shadPS4

## [0.2.1] - 2025-03-31

- Fixed shadPS4 re-downloading on every Vortex launch due to file name case-sensitivity

## [0.2.0] - 2025-03-30

- Added download and update functionality for shadPS4 sot that the user will always get the latest verison when managing the game
