/*////////////////////////////////////////////////////
Name: Bloodborne Vortex Extension
Structure: Emulation Game
Author: ChemBoy1
Version: 1.0.1
Date: 2026-10-16
////////////////////////////////////////////////////*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const { actions, fs: vfs, util, selectors, log, VortexError } = require("vortex-api");
const path = require("path");
const template = require("string-template");
const {
  download,
  findModByFile,
  findDownloadIdByFile,
  resolveVersionByPattern,
  testRequirementVersion,
} = require("./downloader");

//Specify all the information about the game
const GAME_ID = "bloodborne";
const PS_ID = "CUSA03173"; // <--- CHANGE THIS IF YOU ARE USING A DIFFERENT VERSION OF THE GAME
const GAME_FILE = path.join(PS_ID, "eboot.bin");
const GAME_NAME = "Bloodborne";
const GAME_NAME_SHORT = "Bloodborne";
const MOD_PATH = "."; //Set default mod path
const EXTENSION_URL = "https://www.nexusmods.com/bloodborne/mods/64"; //Nexus link to this extension. Used for links

let GAME_PATH = "";
let GAME_VERSION = ""; //Game version
let STAGING_FOLDER = ""; //Vortex staging folder path
let DOWNLOAD_FOLDER = ""; //Vortex download folder path

//Info for mod types and installers
const DVDROOTPS4_ID = `${GAME_ID}-dvdroot_ps4`;
const DVDROOTPS4_NAME = `Game Data (dvdroot_ps4)`;
const DVDROOTPS4_PATH = path.join(PS_ID, "dvdroot_ps4");
const DVDROOTPS4_FOLDERS = [
  "action",
  "chr",
  "event",
  "facegen",
  "map",
  "menu",
  "movie",
  "msg",
  "mtd",
  "obj",
  "other",
  "param",
  "paramdef",
  "parts",
  "remo",
  "script",
  "sfx",
  "shader",
  "sound",
];

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Folder";

// Information for shadPS4 downloader and updater
const SHADPS4_ID = `${GAME_ID}-shadps4`;
const SHADPS4_NAME = "shadPS4";
const SHADPS4_EXEC = "shadps4.exe";
const SHADPS4_VERSION = "0.16.0";
const SHADPS4_ARC_NAME = `shadps4-win64-sdl-${SHADPS4_VERSION}.zip`;
const SHADPS4_URL = `https://github.com/shadps4-emu/shadPS4/releases/download/v.${SHADPS4_VERSION}/${SHADPS4_ARC_NAME}`;
const SHADPS4_URL_MAIN = `https://api.github.com/repos/shadps4-emu/shadPS4`;
const SHADPS4_FILE = "shadPS4.exe"; // <-- CASE SENSITIVE! Must match name exactly or downloader will download the file again.

const SHADLAUNCHER_ID = `${GAME_ID}-shadps4qtlauncher`;
const SHADLAUNCHER_NAME = "shadPS4QtLauncher";
const SHADLAUNCHER_EXEC = "shadps4qtlauncher.exe";
const SHADLAUNCHER_VERSION = "2026-06-20-cead95c";
const SHADLAUNCHER_ARC_NAME = `shadPS4QtLauncher-win64-qt-${SHADLAUNCHER_VERSION}.zip`;
const SHADLAUNCHER_URL = `https://github.com/shadps4-emu/shadPS4/releases/download/v.${SHADLAUNCHER_VERSION}/${SHADLAUNCHER_ARC_NAME}`;
const SHADLAUNCHER_URL_MAIN = `https://api.github.com/repos/shadps4-emu/shadps4-qtlauncher`;
const SHADLAUNCHER_FILE = "shadPS4QtLauncher.exe"; // <-- CASE SENSITIVE! Must match name exactly or downloader will download the file again.

const SHADLAUNCHER_URL_REL = `https://github.com/shadps4-emu/shadps4-qtlauncher/releases`;
const SHADLAUNCHER_DL_STRING = "shadPS4QtLauncher-win64-qt-";

const REQUIREMENTS = [
  {
    //shadPS4
    archiveFileName: SHADPS4_ARC_NAME,
    modType: SHADPS4_ID,
    assemblyFileName: SHADPS4_FILE,
    userFacingName: SHADPS4_NAME,
    githubUrl: SHADPS4_URL_MAIN,
    findMod: (api) => findModByFile(api, SHADPS4_ID, SHADPS4_FILE),
    findDownloadId: (api) => findDownloadIdByFile(api, SHADPS4_ARC_NAME),
    fileArchivePattern: new RegExp(/^shadps4-win64-sdl-(\d+\.\d+\.\d+)/, "i"),
    resolveVersion: (api) => resolveVersionByPattern(api, REQUIREMENTS[0]),
  },
  /*{ //QtLauncher
    archiveFileName: SHADLAUNCHER_ARC_NAME,
    modType: SHADLAUNCHER_ID,
    assemblyFileName: SHADLAUNCHER_FILE,
    userFacingName: SHADLAUNCHER_NAME,
    githubUrl: SHADLAUNCHER_URL_MAIN,
    findMod: (api) => findModByFile(api, SHADLAUNCHER_ID, SHADLAUNCHER_FILE),
    findDownloadId: (api) => findDownloadIdByFile(api, SHADLAUNCHER_ARC_NAME),
    fileArchivePattern: new RegExp(/^shadPS4QtLauncher-win64-qt-(\d+-\d+-\d+)/, 'i'),
    resolveVersion: (api) => resolveVersionByPattern(api, REQUIREMENTS[1]),
  }, //*/
];

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = "Save";
const SAVE_PATH = path.join("user", "savedata", "1", PS_ID, "SPRJ0005");
const SAVE_FILE = "userdata0000";

const SMITHBOX_EXEC = "smithbox.exe";
const FLVER_EXEC = "flver_editor.exe";

const PARAMETERS = [GAME_FILE];

//Filled in from info above
const PCGAMINGWIKI_URL = "XXX";
const IGNORE_CONFLICTS = [
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];
const IGNORE_DEPLOY = [
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];
const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    shortName: GAME_NAME_SHORT,
    executable: SHADPS4_EXEC,
    parameters: PARAMETERS,
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    modPath: MOD_PATH,
    modPathIsRelative: true,
    requiredFiles: [GAME_FILE],
    details: { ignoreConflicts: IGNORE_CONFLICTS, ignoreDeploy: IGNORE_DEPLOY },
    environment: {},
  },
  modTypes: [
    {
      id: DVDROOTPS4_ID,
      name: DVDROOTPS4_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", DVDROOTPS4_PATH),
    },
    {
      id: SAVE_ID,
      name: SAVE_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", SAVE_PATH),
    },
    {
      id: ROOT_ID,
      name: ROOT_NAME,
      priority: "high",
      targetPath: `{gamePath}`,
    },
    {
      id: SHADPS4_ID,
      name: SHADPS4_NAME,
      priority: "low",
      targetPath: `{gamePath}`,
    },
    {
      id: SHADLAUNCHER_ID,
      name: SHADLAUNCHER_NAME,
      priority: "low",
      targetPath: `{gamePath}`,
    },
  ],
  discovery: {
    ids: [],
    names: [],
  },
};

//3rd party tools and launchers
const tools = [
  /*{
    id: "shadPS4",
    name: "shadPS4 (No-GUI)",
    logo: `shadps4.png`,
    executable: () => SHADPS4_EXEC,
    requiredFiles: [SHADPS4_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    //shell: true,
    //defaultPrimary: true,
    //parameters: PARAMETERS,
  }, //*/
  {
    id: `${GAME_ID}-shadps4qtlauncher`,
    name: "shadPS4QtLauncher",
    logo: `shadps4.png`,
    executable: () => SHADLAUNCHER_EXEC,
    requiredFiles: [SHADLAUNCHER_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    //shell: true,
    //defaultPrimary: true,
    //parameters: PARAMETERS,
  },
  {
    id: "Smithbox",
    name: "Smithbox",
    logo: `smithbox.png`,
    executable: () => SMITHBOX_EXEC,
    requiredFiles: [SMITHBOX_EXEC],
    detach: true,
    relative: true,
    exclusive: false,
    //shell: true,
    //parameters: []
  },
  {
    id: "FlverEditor",
    name: "Flver Editor",
    logo: `flver.png`,
    executable: () => FLVER_EXEC,
    requiredFiles: [FLVER_EXEC],
    detach: true,
    relative: true,
    exclusive: false,
    //shell: true,
    //parameters: []
  },
];

//Set mod type priorities
function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  var _a;
  return template(pattern, {
    gamePath:
      (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
        ? void 0
        : _a.path,
    documents: util.getVortexPath("documents"),
    localAppData: util.getVortexPath("localAppData"),
    appData: util.getVortexPath("appData"),
  });
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () =>
    util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher() {
  return Promise.resolve(undefined);
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? {};
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}
async function deploy(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for ShadPS4 files
function testShadPs4(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === SHADPS4_EXEC);
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install ShadPS4 files
function installShadPs4(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SHADPS4_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: SHADPS4_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for ShadPS4 Qt Launcherfiles
function testShadLauncher(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === SHADLAUNCHER_EXEC);
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install ShadPS4 Qt Launcher files
function installShadLauncher(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SHADLAUNCHER_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: SHADLAUNCHER_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Smithbox files
function testSmithbox(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === SMITHBOX_EXEC);
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Smithbox files
function installSmithbox(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SMITHBOX_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  //const setModTypeInstruction = { type: 'setmodtype', value: SHADPS4_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join("Smithbox", file.substr(idx)),
    };
  });
  //instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Flver Editor files
function testFlver(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === FLVER_EXEC);
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Flver Editor files
function installFlver(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === FLVER_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  //const setModTypeInstruction = { type: 'setmodtype', value: SHADPS4_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join("Flver Editor", file.substr(idx)),
    };
  });
  //instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for game data files
function testDvdRootPs4(files, gameId) {
  const isMod = files.some((file) => DVDROOTPS4_FOLDERS.includes(path.basename(file)));
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install game data files
function installDvdRootPs4(files) {
  const modFile = files.find((file) => DVDROOTPS4_FOLDERS.includes(path.basename(file)));
  const idx = modFile.lastIndexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: DVDROOTPS4_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for save files
function testSave(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === SAVE_FILE);
  let supported = gameId === spec.game.id && isMod;

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install save files
function installSave(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SAVE_FILE);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: SAVE_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

// GITHUB AUTOMATIC DOWNLOAD FUNCTIONS /////////////////////////////////////////////////

async function asyncForEachTestVersion(api, requirements) {
  for (let index = 0; index < requirements.length; index++) {
    await testRequirementVersion(api, requirements[index]);
  }
}

async function asyncForEachCheck(api, requirements) {
  let mod = [];
  for (let index = 0; index < requirements.length; index++) {
    mod[index] = await requirements[index].findMod(api);
  }
  let checker = mod.every((entry) => entry !== undefined); //findMod resolves to a mod object or undefined, never a boolean
  return checker;
}

async function onCheckModVersion(api, gameId, mods, forced) {
  try {
    await asyncForEachTestVersion(api, REQUIREMENTS);
    log("warn", "Checked requirements versions");
  } catch (err) {
    log("warn", `failed to test requirements versions: ${err}`);
  }
}

async function checkForRequirements(api) {
  const CHECK = await asyncForEachCheck(api, REQUIREMENTS);
  return CHECK;
}

//* Old shadPS4 download method
async function isShadPS4Installed(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  let check = Object.keys(mods).some((id) => mods[id]?.type === SHADPS4_ID);
  if (!check) {
    try {
      GAME_PATH = getDiscoveryPath(api);
      await fsp.stat(path.join(GAME_PATH, SHADPS4_EXEC));
      check = true;
    } catch {
      //do nothing
    }
  }
  return check;
}
//Function to auto-download shadPS4 from Github
async function downloadShadPS4(api, gameSpec) {
  let modLoaderInstalled = await isShadPS4Installed(api, gameSpec);
  if (!modLoaderInstalled) {
    //notification indicating install process
    const NOTIF_ID = "bloodborne-shadps4-installing";
    api.sendNotification({
      id: NOTIF_ID,
      message: "Installing shadPS4",
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });

    try {
      //Download the mod
      const dlInfo = {
        game: gameSpec.game.id,
        name: `shadPS4 v${SHADPS4_VERSION}`,
      };
      const URL = SHADPS4_URL;
      const dlId = await new Promise((resolve, reject) =>
        api.events.emit(
          "start-download",
          [URL],
          dlInfo,
          undefined,
          (err, result) => (err ? reject(err) : resolve(result)),
          undefined,
          {
            allowInstall: false,
          },
        ),
      );
      const modId = await new Promise((resolve, reject) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, (err, result) =>
          err ? reject(err) : resolve(result),
        ),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, SHADPS4_ID), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions.
      //Show the user the download page if the download, install process fails
    } catch (err) {
      const errPage = `https://github.com/shadps4-emu/shadPS4/releases`;
      api.showErrorNotification("Failed to download/install shadPS4", err);
      try {
        window.api.shell.openUrl(errPage);
      } catch (openErr) {
        api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
      }
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

async function isShadLauncherInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  let check = Object.keys(mods).some((id) => mods[id]?.type === SHADLAUNCHER_ID);
  if (!check) {
    GAME_PATH = getDiscoveryPath(api);
    try {
      GAME_PATH = getDiscoveryPath(api);
      await fsp.stat(path.join(GAME_PATH, SHADLAUNCHER_EXEC));
      check = true;
    } catch {
      //do nothing
    }
  }
  return check;
}

//* Download ShadPS4 Launcher from GitHub page (user browse for download - necessary for now until stable release)
async function downloadShadLauncher(api, gameSpec, check) {
  let isInstalled = await isShadLauncherInstalled(api, gameSpec);
  const URL = SHADLAUNCHER_URL_REL;
  const MOD_NAME = SHADLAUNCHER_NAME;
  const MOD_TYPE = SHADLAUNCHER_ID;
  const ARCHIVE_NAME = SHADLAUNCHER_DL_STRING;
  const instructions = api.translate(
    `Click on Continue below to open the browser. - ` +
      `Navigate to the latest experimental version of ${MOD_NAME} on the GitHub releases page and ` +
      `click on the appropriate file to download and install the mod.`,
  );

  if (!isInstalled || !check) {
    return new Promise((resolve, reject) => {
      //Browse and download the mod
      return api
        .emitAndAwait("browse-for-download", URL, instructions)
        .then((result) => {
          //result is an array with the URL to the downloaded file as the only element
          if (!result || !result.length) {
            //user clicks outside the window without downloading
            return reject(
              new VortexError("User canceled", { kind: "user-canceled", skipped: false }),
            );
          }
          if (!result[0].includes(ARCHIVE_NAME)) {
            //if user downloads the wrong file
            return reject(
              new VortexError("Selected wrong download", { kind: "user-canceled", skipped: true }),
            );
          } //*/
          return Promise.resolve(result);
        })
        .catch((error) => {
          return reject(error);
        })
        .then((result) => {
          const dlInfo = { game: gameSpec.game.id, name: MOD_NAME };
          api.events.emit(
            "start-download",
            result,
            {},
            undefined,
            async (error, id) => {
              //callback function to check for errors and pass id to and call 'start-install-download' event
              if (error !== null && error.name !== "AlreadyDownloaded") {
                return reject(error);
              }
              api.events.emit(
                "start-install-download",
                id,
                { allowAutoEnable: true },
                async (error) => {
                  //callback function to complete the installation
                  if (error !== null) {
                    return reject(error);
                  }
                  const profileId = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
                  const batched = [
                    actions.setModsEnabled(api, profileId, result, true, {
                      allowAutoDeploy: true,
                      installed: true,
                    }),
                    actions.setModType(GAME_ID, result[0], MOD_TYPE), // Set the mod type
                  ];
                  util.batchDispatch(api.store, batched); // Will dispatch both actions.
                  return resolve();
                },
              );
            },
            "never",
            { allowInstall: false },
          );
        });
    }).catch((err) => {
      if (err?.data?.kind === "user-canceled") {
        api.showErrorNotification(
          `User cancelled download/install of ${MOD_NAME}. Please re-launch Vortex and try again.`,
          err,
          { allowReport: false },
        );
        //window.api.shell.openUrl(URL);
        return Promise.resolve();
      } else if (err?.data?.kind === "process-canceled") {
        api.showErrorNotification(
          `Failed to download/install ${MOD_NAME}. Please re-launch Vortex and try again or download manually from modDB at the opened paged and install the zip in Vortex.`,
          err,
          { allowReport: false },
        );
        try {
          window.api.shell.openUrl(URL);
        } catch (openErr) {
          api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
        }
        return Promise.reject(err);
      } else {
        return Promise.reject(err);
      }
    });
  }
} //*/

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

//Notify User of Setup instructions
function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup`;
  const MESSAGE = "Bloodborne Game Files Required";
  api.sendNotification({
    id: "setup-notification-bloodborne",
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                "Neither the extension developer nor Nexus Mods endorse piracy. You must own a legitimate copy of Bloodborne to use this extension.\n" +
                "You must have the extracted Bloodorne game (CUSA03173) files installed from your PS4 or a .pkg file for the extension to work.\n",
            },
            [
              { label: "Acknowledge", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

//Setup function
async function setup(discovery, api, gameSpec) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  setupNotify(api);
  GAME_PATH = discovery.path;
  //await downloadShadPS4(api, gameSpec);
  const requirementsInstalled = await checkForRequirements(api);
  if (!requirementsInstalled) {
    await download(api, REQUIREMENTS);
  }
  await downloadShadLauncher(api, gameSpec, true);
  await vfs.ensureDirWritableAsync(path.join(discovery.path, SAVE_PATH));
  return vfs.ensureDirWritableAsync(path.join(discovery.path, DVDROOTPS4_PATH));
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    executable: () => gameSpec.game.executable,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //register mod installers
  context.registerInstaller(`${GAME_ID}-shadps4`, 25, testShadPs4, installShadPs4);
  context.registerInstaller(`${GAME_ID}-shadlauncher`, 27, testShadLauncher, installShadLauncher);
  context.registerInstaller(`${GAME_ID}-smithbox`, 29, testSmithbox, installSmithbox);
  context.registerInstaller(`${GAME_ID}-flver`, 31, testFlver, installFlver);
  context.registerInstaller(`${GAME_ID}-dvdroot_ps4`, 33, testDvdRootPs4, installDvdRootPs4);
  context.registerInstaller(`${GAME_ID}-save`, 35, testSave, installSave);

  //register actions
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    `Download ${SHADLAUNCHER_NAME}`,
    () => {
      downloadShadLauncher(context.api, spec, false);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      try {
        window.api.shell.openFile(path.join(__dirname, "CHANGELOG.md"));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      try {
        window.api.shell.openUrl(`${EXTENSION_URL}?tab=bugs`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      try {
        window.api.shell.openFile(DOWNLOAD_FOLDER);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    try {
      window.api.shell.openFile(CONFIG_PATH);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', () => {
    try {
      window.api.shell.openFile(SAVE_PATH);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
}

//main function
function main(context) {
  applyGame(context, spec);
  context.once(() => {
    // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    context.api.onAsync("check-mods-version", (gameId, mods, forced) => {
      if (gameId !== GAME_ID) return;
      return onCheckModVersion(context.api, gameId, mods, forced);
    }); //*/
  });
  return true;
}

//export to Vortex
module.exports = {
  default: main,
};
