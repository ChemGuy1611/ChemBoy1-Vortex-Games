# Changelog

## [0.5.1]
- Tweak TFC Installer mod installer criteria

## [0.5.0]
- Improved support for TFC Installer and mods that use it
- Moved TFC mods to "TFC Installer\Mods" folder
- Added installer for root folders (ContentBaked)
- Added a tool for UPK Explorer if the user installs it to the game folder
- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including TFC Installer, to fail with wrong URL