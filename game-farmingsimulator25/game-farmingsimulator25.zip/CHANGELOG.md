# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2026-01-27

- Added Xbox Game Pass version support
