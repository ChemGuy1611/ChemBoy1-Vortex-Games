# Changelog

## [1.1.2] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.1.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [1.1.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [1.0.6] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.0.5] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.4] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.3] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: The "Open LogicMods Folder" button now opens the LogicMods folder instead of the Paks folder.
- Fixed: Installing a ModKit mod whose mod.json has no mod name no longer causes an error.

## [1.0.2] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.0.1] - 2026-09-21

- Improved: Pak mods still carrying the old shared mod type are now retagged automatically instead of prompting you to reinstall them.

## [1.0.0] - 2026-09-21

- Migrated to file-based load order (FBLO); added a lock button, multi-select, and a right-click context menu to the Paks load order page.
- Added a UE4SS Load Order page and a LogicMods Load Order page for Blueprint pak mods.
- Added UE4SS load order support to Collections.
- Added: UE4SS now downloads automatically and checks for updates.
- Added a status filter to the load order pages.
- Added buttons to open the UE4SS settings file, the UE4SS mods.txt file, and the Vortex downloads folder.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Fixed: Updating a mod no longer moved it in the load order.
- Fixed: Mod files with no file extension were skipped during installation.

## [0.6.1] - 2026-04-22

- Fixed: Several minor technical fixes

## [0.6.0] - 2026-02-03

- Removed: Automatic download of Mod Enabler - users can still install it from a new Vortex button or the mod page
- Fixed: Mod installs are properly cancelled if the modType is not deployable - This avoids confusion about if the mod will work
- Fixed: Proper installer handling for all Documents folder mods (Creations, AIGenerated, Canvas, My3DPrinter, MyAppearances, Animations, Textures)
- Fixed: Path checker reliablity
- Added: Tool to launch inZOIMODKit, if installed.
- Fixed: Path strings
- Added: Buttons to open several files/folders/URLs

## [0.5.1] - 2025-12-04

- Added compatibility flags to remove built-in Vortex modTypes. Users should now be able to deploy mods when the game folder is not on the C drive. Note that you still won't be able to install mods to the game folder if it is not on C drive.

## [0.5.0] - 2025-12-03

- Added missing directory check for legacy pak mod types. This could prevent deployment if the game folder was on a secondary drive. Note that you still won't be able to deploy if the game is on a secondary drive due to a Vortex limitation (<https://github.com/Nexus-Mods/Vortex/issues/18945>).
- Fixed issue with Load Order sorting of legacy pak mods not working if certain other UE game extensions were installed. You will need to reinstall all legacy pak mods to be able to sort them properly. A notification will be sent reminding you to do this.
- Added notification indicating deployment is required after changing the load order.
- Fixed missing FOMOD installer check for pak mods.
- Technical fixes and improvements.

## [0.4.0] - 2025-10-07

- Added functions to automatically set the "bEnable" flag to "true" in mod_manifest.json file for all MODKit mods on deployment.

## [0.3.2] - 2025-09-25

- Updated MODKit mod installer so that mods with invalid mod_manifest.json files will still be installed, with a warning notification to the user.

## [0.3.1] - 2025-06-29

- Updated installer notification to reflect the new requirements of the mod folder being moved to User Documents. Partition checks are now for mods that install to the game folder and Local AppData.

## [0.3.0] - 2025-06-26

- Updated Pak mod installer to handle new MODKit mod format. Moved to correct install directory "Document/inZOI/Mods".
- Changed partion checks and installer error messages to target mod types that go into the game folder (since the default install path is in Documents now).

## [0.2.1] - 2025-04-22

- Added installer for UE4SS DLL Mods
- Improved code for partition-checked modtypes
- Fixed incorrect path for button to open LogicMods folder
- Minor code improvements

## [0.2.0] - 2025-04-08

- Added multiple modtypes and installers for Documents folders: Canvas and AIGenerated folders, MyAppearances (appearance.dat), MyTextures (albedo.jpg), and MyAnimations (motion.dat)
- Corrected Saves install path
- Removed unnecessary logging

## [0.1.5] - 2025-03-30

- Corrected Saves install path.
- Added multiple modtypes and installers for Documents folders: Canvas and AIGenerated folders, MyAppearances (appearance.dat), MyTextures (albedo.jpg), and MyAnimations (motion.dat).
- Removed unnecessary logging.

## [0.1.4] - 2025-03-30

- Fixed undefined variable error for setting modtypes if the game had not been discovered yet.

## [0.1.3] - 2025-03-30

- Fixed partition checks for enabling modtypes for Config, Saves, and Creations mods.
- Added error messages if the user tries to install Config, Save, or Creations mods when those modtypes are not enabled.
- Fixed a ReferenceError for incorrect "CHECK_AI" variable name.

## [0.1.2] - 2025-03-29

- Added installers for My3DPrinter and Creations mods (to Documents folder). Note that the game, staging folder, and user folder must ALL be on the same drive for this to work since this game cannot use symlinks.
- Added buttons to open inZOI My3DPrinter and Creations (Documents) folders and to view the Changelog (folder icon in Mods toolbar)
- Added a tool to launch the game with custom arguments (arguments provided by the user)

## [0.1.1] - 2025-03-28

- Fixed Save games path
- Added automatic install of Mod Enabler
- Removed .sig extension files from pak mod installer as they are not required

## [0.1.0] - 2025-03-27

- Initial release
