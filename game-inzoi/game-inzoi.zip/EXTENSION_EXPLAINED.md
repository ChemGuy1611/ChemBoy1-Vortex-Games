# inZOI — Vortex Extension Explained

## Overview

| Property | Value |
| --- | --- |
| Name | inZOI Vortex Extension |
| Engine / Structure | UE5 |
| Author | ChemBoy1 |

## Key Identifiers

| Property | Value |
| --- | --- |
| Game ID | `inzoi` |
| Executable | `inZOI.exe` |

## Supported Stores

- **Steam** — `2456740`

## Feature Flags

| Flag | Value | Description |
| --- | --- | --- |
| `CHECK_CONFIG` | `false` |  |
| `CHECK_DOCS` | `false` |  |
| `IO_STORE` | `true` | true if the Paks folder contains .ucas and .utoc files |
| `SYM_LINKS` | `true` | true if symlink deployment is enabled for this game |

## Mod Types

Mod types define where each category of mod gets deployed:

| Name | ID | Priority | Target Path |
| --- | --- | --- | --- |
| UE5KITMOD_NAME | `UE5KITMOD_ID` | high | `UE5KITMOD_PATH` |
| Save | `inzoi-save` | high | `SAVE_PATH` |
| CREATIONS_NAME | `CREATIONS_ID` | high | `CREATIONS_PATH` |
| AIGENERATED_NAME | `AIGENERATED_ID` | high | `AIGENERATED_PATH` |
| CANVAS_NAME | `CANVAS_ID` | high | `CANVAS_PATH` |
| MY3DPRINTER_NAME | `MY3DPRINTER_ID` | high | `MY3DPRINTER_PATH` |
| MYAPPEARANCES_NAME | `MYAPPEARANCES_ID` | high | `MYAPPEARANCES_PATH` |
| ANIMATIONS_NAME | `ANIMATIONS_ID` | high | `ANIMATIONS_PATH` |
| TEXTURES_NAME | `TEXTURES_ID` | high | `TEXTURES_PATH` |

## Mod Installers

Installers run in priority order (lower number = tested first). The first installer whose test returns `supported: true` handles the archive.

| Installer ID | Priority |
| --- | --- |
| `ue5-pak-installer` | 28 |

## Auto-Downloaded Dependencies

| Dependency | Version | Details |
| --- | --- | --- |
| UE4SS | — | — |

## Special Features

- **Deploy Hook** (`did-deploy`) — runs custom logic (e.g., notifications, metadata patching) every time mods are deployed.
- **Auto-Downloader** — can automatically download required tools (mod loader, managers, etc.).
- **FOMOD Awareness** — installers check for and skip `fomod/ModuleConfig.xml` to avoid conflicts with the built-in FOMOD installer.
- **Registry Lookup** — uses Windows registry for game detection or configuration paths.

## How Mod Installation Works

```
User drops archive into Vortex
  └── Each installer's test() runs in priority order
       └── First supported=true wins
            └── install() returns copy instructions + setmodtype
                 └── Vortex stages files
                      └── User deploys
                           └── Vortex links/copies to game folder
                                └── did-deploy fires → post-deploy logic runs
```

## Entry Point

The extension is registered via `module.exports = { default: main }`. The `main(context)` function calls `applyGame(context, spec)` which registers the game, mod types, installers, and actions with Vortex.
