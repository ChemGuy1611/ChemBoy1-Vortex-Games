## [0.5.0]
- Updated Chairloader mod installer to rezip the mods so that they can be manually added in Chairloader (automated installer doesn't work)
