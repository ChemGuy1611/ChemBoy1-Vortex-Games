# Changelog

## FUTURE CHANGES (NOT IMPLEMENTED YET)

- None Planned

## [0.2.0] - 2026-01-30

- Added: Installer for Script Loader mods - indexed on "lua" folder
- Added: Find .texpack and .lodpack files in the "wad" directory, in addition to "patch" directory
- Fixed: path strings
- Added: Buttons to open Script Loader config file, PCGamingWiki page, view changelog, and submit bug reports

## [0.1.3] - 2025-04-10

- Corrected text string when writing texpack and lodpack mods to boot-options.json (`../../patch/pc_le/${fileName}`).

## [0.1.2] - 2025-04-10

- Updated info.json

## [0.1.1] - 2025-04-02

- Added button to open Settings INI file and boot-options.json file - folder icon in Mods toolbar.
- Reset boot-option.json file on mod purge.

## [0.1.0] - 2025-04-01

- Initial release
