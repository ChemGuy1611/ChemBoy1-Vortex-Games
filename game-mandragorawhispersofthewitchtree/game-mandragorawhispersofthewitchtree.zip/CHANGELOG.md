# Changelog

Future Changes (NOT IMPLEMENTED YET):
- 

## [0.1.0] - 2025-04-22
- Initial release
