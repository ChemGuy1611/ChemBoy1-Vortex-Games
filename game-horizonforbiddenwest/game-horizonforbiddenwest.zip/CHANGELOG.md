# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.2.3] - 2026-01-25

- Changed HFW MM to launch directly from Vortex (fixed in v0.9.3 of HFW MM)

## [0.2.2] - 2026-01-22

- Disabled all ModForge support. All users should use HFW MM instead. ModForge is not capable of handling mod variants, and is closed-source.

## [0.2.1] - 2026-01-14

- Changed HFW Mod Manager to instruct the user to launch it from the game folder. This is due to some strange behavior in the app that I am still trying to sort out.
- Added preliminary support for ModForge (alternative mod packer). Auto-download choice is deactivated for now.
- Fixed issues with downloaded HFW MM executable not being downloaded properly.

## [0.2.0] - 2026-01-07

- Added support for HFW Mod Manager and its mods.
- Automatically downloads HFW Mod Manager and copies the executable to the game folder.
- Send notification to run HFW Mod Manager after deployment.
