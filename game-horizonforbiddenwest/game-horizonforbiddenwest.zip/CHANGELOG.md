# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.2.0] - 2026-01-07

- Added support for HFW Mod Manager and its mods.
- Automatically downloads HFW Mod Manager and copies the executable to the game folder.
- Send notification to run HFW Mod Manager after deployment.
