# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.1.2] - 2025-06-05

- Set Vortex to launch the Steam version through Steam launcher.

## [0.1.1] - 2025-06-05

- Added Steam demo app id to discovery.
- Fixed text in Config/Save modtype notification.

## [0.1.0] - 2025-06-02

- Initial release
