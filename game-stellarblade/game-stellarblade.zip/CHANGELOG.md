# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.7] - 2025-07-26

- UE4SS downloader function now points to the custom version for Stellar Blade (<https://github.com/Chrisr0/RE-UE4SS/releases>). This function can be run with the button located in the folder icon on the Mods tab toolbar.

## [0.1.6] - 2025-07-24

- Added .json files to pak mod installer. Fixes CNS (Custom NanoSuit System) compatibility.

## [0.1.5] - 2025-06-21

- Added Epic Games ID and full support.

## [0.1.4] - 2025-06-16

- Fixed config/save installers notification text.
- Added installer for splash screen mods (splash.bmp file).

## [0.1.3] - 2025-06-15

- Added installer for title screen mods (.bk2 files to "SB/Content/Movies").

## [0.1.2] - 2025-06-12

- Set Vortex to launch the Steam version through Steam launcher.
- Corrected save game folder path for release version.

## [0.1.1] - 2025-06-05

- Added Steam demo app id to discovery.
- Fixed text in Config/Save modtype notification.

## [0.1.0] - 2025-06-02

- Initial release
