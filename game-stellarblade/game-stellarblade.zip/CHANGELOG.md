# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.1.6] - 2025-07-24

- Added .json files to pak mod installer.

## [0.1.5] - 2025-06-21

- Added Epic Games ID and full support.


## [0.1.4] - 2025-06-16

- Fixed config/save installers notification text.
- Added installer for splash screen mods (splash.bmp file).

## [0.1.3] - 2025-06-15

- Added installer for title screen mods (.bk2 files to "SB/Content/Movies").

## [0.1.2] - 2025-06-12

- Set Vortex to launch the Steam version through Steam launcher.
- Corrected save game folder path for release version.

## [0.1.1] - 2025-06-05

- Added Steam demo app id to discovery.
- Fixed text in Config/Save modtype notification.

## [0.1.0] - 2025-06-02

- Initial release
