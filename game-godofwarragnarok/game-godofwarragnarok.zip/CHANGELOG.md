# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):
- 

## [0.2.2] - 2025-04-10
- Corrected text string when writing texpack and lodpack mods to boot-options.json (`../../patch/pc_le/${fileName}`).

## [0.2.1] - 2025-04-07
- Added button to open Settings INI file and boot-options.json file - folder icon in Mods toolbar.
- Reset boot-option.json file on mod purge. 

## [0.2.0] - 2025-04-01
- Added installers for texpacks and lodpacks, which update the game's boot-options.json file with a filename list.
