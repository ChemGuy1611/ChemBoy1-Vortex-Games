# Changelog

Future Changes (NOT IMPLEMENTED YET):

- NONE

## [0.1.2] - 2025-05-28

- Changed lovely-injector download URL to always get latest release
- Added a button to manually trigger the lovely-injector downloader (folder icon in Mods toolbar)

## [0.1.1] - 2025-05-28

- Changed required file to executable
- Made game launch through Steam
- Removed lovely-injector version check since it doesn't work properly
- Fixed SteamModded installer

## [0.1.0] - 2025-05-27

- Initial release
