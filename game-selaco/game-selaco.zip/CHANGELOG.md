# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2025-10-06

- Changed default mod install path to "Mods" folder and added a fallback installer to the root folder. This improves compatibility with FOMOD installers for .pk3 mods.
- Added '+g_skipintro 1' to the default command line arguments (skips intro videos).

## [0.1.0] - 2025-10-05

- Inital Release
