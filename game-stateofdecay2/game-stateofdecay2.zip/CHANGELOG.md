# Changelog

## [3.1.7] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [3.1.6] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [3.1.5] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [3.1.4] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [3.1.3] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [3.1.2] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.

## [3.1.1] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [3.1.0] - 2026-09-19

- Removed the dependency on the Unreal Engine Mod Installer extension. Pak mods are now installed and managed directly by this extension; existing installs are migrated automatically, no action needed.

## [3.0.0] - 2026-09-14

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Migrated the pak load order page to Vortex's newer file-based system, adding a lock button, multi-select, and a right-click context menu.

## [2.2.1] - 2026-09-08

- Fixed: The Binaries mod folder is now created correctly during setup.

## [2.2.0] - 2026-01-31

- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, and submit bug reports

## [2.1.1] - 2025-05-28

- Removed unnecessary error logging
- Fixed technical issues with executable discovery
- Fixed game version detection for Xbox version

## [2.1.0] - 2025-04-13

- Added installer to detect "Cooked" folder for poorly packaged Cooked mods.
- Added installer for mods intended for the root game directory (contain "StateOfDecay2" folder).
- Added fallback installer for binaries folder.
- Added a tool for Community Editor (save editor).
- Improved reliability of game discovery and launcher setup.
- Added buttons to open the following items within the folder icon in Mods toolbar: Vortex Downloads folder, Paks folder, Config folder, changelog.
- Added setup notification informing the user of some nuances when installing "INTEGRATION" pak mods with SoD2 MM.
- Other technical fixes.
