# Changelog

## Planned Improvements (Not Yet Released)

- None

## [2.2.1] - 2026-09-08

- Fixed: The Binaries mod folder is now created correctly during setup.

## [2.2.0] - 2026-01-31

- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, and submit bug reports

## [2.1.1] - 2025-05-28

- Removed unnecessary error logging
- Fixed technical issues with executable discovery
- Fixed game version detection for Xbox version

## [2.1.0] - 2025-04-13

- Added installer to detect "Cooked" folder for poorly packaged Cooked mods.
- Added installer for mods intended for the root game directory (contain "StateOfDecay2" folder).
- Added fallback installer for binaries folder.
- Added a tool for Community Editor (save editor).
- Improved reliability of game discovery and launcher setup.
- Added buttons to open the following items within the folder icon in Mods toolbar: Vortex Downloads folder, Paks folder, Config folder, changelog.
- Added setup notification informing the user of some nuances when installing "INTEGRATION" pak mods with SoD2 MM.
- Other technical fixes.
