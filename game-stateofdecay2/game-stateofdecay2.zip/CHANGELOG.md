# Changelog

## Planned Improvements (Not Yet Released)

- None

## [3.1.1] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [3.1.0] - 2026-09-19

- Removed the dependency on the Unreal Engine Mod Installer extension. Pak mods are now installed and managed directly by this extension; existing installs are migrated automatically, no action needed.

## [3.0.0] - 2026-09-14

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Migrated the pak load order page to Vortex's newer file-based system, adding a lock button, multi-select, and a right-click context menu.

## [2.2.1] - 2026-09-08

- Fixed: The Binaries mod folder is now created correctly during setup.

## [2.2.0] - 2026-01-31

- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, and submit bug reports

## [2.1.1] - 2025-05-28

- Removed unnecessary error logging
- Fixed technical issues with executable discovery
- Fixed game version detection for Xbox version

## [2.1.0] - 2025-04-13

- Added installer to detect "Cooked" folder for poorly packaged Cooked mods.
- Added installer for mods intended for the root game directory (contain "StateOfDecay2" folder).
- Added fallback installer for binaries folder.
- Added a tool for Community Editor (save editor).
- Improved reliability of game discovery and launcher setup.
- Added buttons to open the following items within the folder icon in Mods toolbar: Vortex Downloads folder, Paks folder, Config folder, changelog.
- Added setup notification informing the user of some nuances when installing "INTEGRATION" pak mods with SoD2 MM.
- Other technical fixes.
