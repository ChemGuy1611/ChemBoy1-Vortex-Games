# Changelog

## Future Improvements (Not Yet Released)
- 

## [0.2.0] - 2025-04-25
- Added support IO Store pak mods (pak/ucas/utoc)
- Updated signature bypass download to new mod page
- Added buttons to open multiple folders - folder icon on Mods toolbar
- Several other technical improvements