# Changelog

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.
- Fixed: A mod archive containing another archive with an upper-case extension (.ZIP, .RAR, .7Z) is now installed as it is instead of being packed into another zip.

## [0.3.1] - 2026-09-08

- Fixed: The loose file loader folder is now created correctly during setup.
- Changed: Removed the unused load order code. The load order page was never registered for this game, so mod installation and deployment are unchanged.

## [0.3.0] - 2026-03-10

- Added: Integrated Nioh3ModManager for Loose File mods installation
- Added: Support for Loose file loader
- Added: Loose File mods are now installed to the "ModArchives" folder to be installed with ModManager
- Added: Notification to run ModManager after deployment

## [0.2.3] - 2026-03-04

- Changed: Launch game directly through Steam

## [0.2.2] - 2026-02-25

- Added: Installer for .g1t and .g1m files to "package\RDBExplorer_Mods" folder

## [0.2.1] - 2026-02-22

- Added: Basic support for RDBExplorer - installer, download button, launch tool

## [0.2.0] - 2026-02-20

- Added: Automatic install and support for DLL Loader and .dll/.asi mods
- Added: Automatic install and support for Yumia fdata Tools and .fdata package mods - Yumia merge runs on deploy - Vanilla files restored on purge - Credit to eArmada8 for Yumia (<https://github.com/eArmada8/yumia_fdata_tools>)

## [0.1.0] - 2026-02-04

- Inital Release
