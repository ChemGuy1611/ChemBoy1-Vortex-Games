# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2026-02-20

- Added: Automatic install and support for DLL Loader and .dll/.asi mods
- Added: Automatic install and support for Yumia fdata Tools and .fdata package mods

## [0.1.0] - 2026-02-04

- Inital Release
