# Changelog

Future Changes (NOT IMPLEMENTED YET):

- Find out how to change modtype for falloutlondon mod automatically (? set from registerModType ?)
- Add working check for if INI files already updated (existing check doesnt seem to work)

## [0.1.1] - 2025-06-24

- Added partition check to ensure all 3 folders of interest are on the same drive partition (FO4 game, FOLON, FO4 Staging).
- Added some additional logging for debugging.
- Fixed error that would occur when installing other mods for FO4.

## [0.1.0] - 2025-06-23

- Initial release
