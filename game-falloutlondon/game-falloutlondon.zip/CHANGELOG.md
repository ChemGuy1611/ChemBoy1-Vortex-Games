# Changelog

Future Changes (NOT IMPLEMENTED YET):

- Find out how to change modtype for falloutlondon mod automatically (? set from modtype ?)
- Test INI code
- Add check for if INI files already updated

## [0.1.0] - 2025-06-24

- Initial release
