# Changelog

Future Changes (NOT IMPLEMENTED YET):

- Find out how to change modtype for falloutlondon mod automatically (? set from registerModType ?)
- Add working check for if INI files already updated (existing doesnt seem to work)

## [0.1.0] - 2025-06-24

- Initial release
