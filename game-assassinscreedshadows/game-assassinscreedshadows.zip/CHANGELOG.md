# Changelog

## [0.1.1]
- Added mod installer tests for .forge files to put files in the correct dlc folder, if necessary. 
- Removed some unused mod installers.

## [0.1.0]
- Intial release