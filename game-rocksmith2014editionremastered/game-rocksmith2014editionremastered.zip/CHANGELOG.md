# Changelog

## Planned Improvements (Not Yet Released)

- Change CDLC Song Downloader to open a free-roam browser window so that domain switching to file hosting sites for the .psarc files does not cause exit errors and allows downloading multiple files in one session.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.3.1] - 2026-04-19

- Fixed: Corrected CDLC Enabler URL string.

## [0.3.0] - 2026-04-01

- Fixed: ASIO4ALL install function causing a crash due to hardcoded version in exe filename.
- Fixed: DLC Builder installer not running due to hardcoded version in exe filename.
- Improved: The download buttons in the folder icon on the Mods page toolbar now execute the non-Nexus downloads even if they are already installed. This allows the buttons to be used to update those mods and tools.
- Improved: All executables now launch using api.runExecutable()
- Added: Buttons to open PCGamingWiki page and make bug reports.

## [0.2.1] - 2025-10-21

- Corrected a logic issue in the Root modtype installer.

## [0.2.0] - 2025-10-20

- Added Root modtype and installer for known .psarc files and folders (i.e. cache.psarc).
- Added tool to launch Unpack-Repack tool.

## [0.1.2] - 2025-03-29

- Fixed ASIO4ALL installer not running because it requires elevation.

## [0.1.1] - 2025-03-28

- Added ASIO4ALL installer to Optional Mods notification (required for RS_ASIO to work)
- Moved CFSM to Optional mods notification (not truly a requirement)
- Removed unnecessary modtypes for mods that are installed by executables, not as mods in Vortex (RSMods, CDLC Enabler, DLC Builder)
- Running CFSM no longer blocks the user from launching the game
- Added tool to launch the game with custom arguments (arguments provided by the user)
- Condensed browse-to-download functions into a repeatable function
- Added button to open Vortex downloads folder for the game

## [0.1.0]

- Initial release
