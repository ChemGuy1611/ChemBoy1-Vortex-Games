# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2026-01-19

- Fixed: More reliable folder deletion operations - revised deprecated fsPromises.rmdir function to fsPromises.rm

## [0.1.0] - 2025-XX-XX

- Inital Release
