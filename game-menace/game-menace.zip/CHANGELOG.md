# Changelog

## Planned Improvements (Not Yet Released)

## [1.0.2] - 2026-09-28

- Game version now shows the real game build instead of the Unity engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.0.1] - 2026-09-18

- Fixed: Some mods could install using a garbled folder name after Nexus changed its download archive filenames.

## [1.0.0] - 2026-09-17

- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Added: Two mods that each add a MelonLoader plugin with a same-named file (a README, an icon, a shared dependency) no longer conflict with each other — each mod now installs into its own folder.

## [0.8.3] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.8.2] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [0.8.1] - 2026-09-05

- Added: Right-click menu on load order entries - lock or unlock a position, move to top or bottom, open the mod folder, staging folder or mod page, and disable the Vortex mod. Works on a single entry or a multi-selection.
- Added: Lock button on each load order row, and ctrl/shift multi-select.
- Added: Enable/Disable button on each load order row that turns the Vortex mod on or off.
- Added: Load order status filter (enabled, disabled, locked, unlocked, unmanaged) with a matched/total count.
- Added: Load order rows for mods Vortex does not manage are now marked "Not managed by Vortex".
- Fixed: Locked load order positions now survive a deployment.
- Fixed: The load order page no longer fails to open on a fresh install before the mods folder exists.

## [0.8.0] - 2026-09-05

- Added: ModpackLoader is downloaded and kept up to date automatically again, from the Menace Mod Manager release on GitHub.

## [0.7.1] - 2026-08-30

- Changed: Jiangyu now appears in your mod list with its version, and can be disabled or removed from there like any other mod. An existing copy is replaced automatically.

## [0.7.0] - 2026-08-29

- Added: Support for Jiangyu, the mod loader that replaced ModpackLoader. It is downloaded and installed for you, and kept up to date.
- Added: Installer for Jiangyu mods. They install to their own folder under "Mods" and appear on the load order page.
- Changed: The load order page now covers both Jiangyu and ModpackLoader mods together.
- Changed: ModpackLoader is no longer downloaded on its own. It now comes with the Menace ModKit, which places the loader files where the game needs them.
- Changed: The Menace ModKit now downloads from its current home, and is kept up to date.
- Fixed: The .NET 10 notification no longer appears unless ModpackLoader is actually installed.

## [0.6.2] - 2026-07-29

- Fixed: The load order could disappear after deploying while a mod update was in progress, and only came back after deploying a second time.
- Added: A message now appears if you change the load order while a mod update is still finishing, so it is clear the change was not applied and needs to be made again.
- Fixed: After a mod update finished, the load order page could keep showing out-of-date information until another deployment was run.

## [0.6.1] - 2026-07-25

- Fixed: Using "Update all" to update several mods at once could move them in the load order or uncheck them.

## [0.6.0] - 2026-07-22

- Fixed: Updating a mod could uncheck it or move it in the load order, especially on profiles other than the one you were using.

## [0.5.0] - 2026-04-22

- Improved: Load Order rendering using React - show mod image thumbnails

## [0.4.2] - 2026-03-22

- Added: Installer for Custom Leaders mods

## [0.4.1] - 2026-02-24

- Added: Checks and notifications for .NET 6/10 installations required by MelonLoader/ModpackLoader

## [0.4.0] - 2026-02-24

- Changed: ModpackLoader now downloads from a Nexus Mods page, and is no longer bundled with the extension

## [0.3.2] - 2026-02-16

- Updated: DLL file package
- Improved: ModpackLoader dlls are copied with overwrite at setup to ensure they are updated

## [0.3.1] - 2026-02-13

- Fixed: Added error handling for reading/writing failures in modpack.json files
- Fixed: Prevented adding non-ModpackLoader mod entries to load order

## [0.3.0] - 2026-02-12

- Added: Load Order support for ModPackLoader mods
- Added: Installer and launch tool for Menace ModKit app (<https://github.com/p0ss/MenaceAssetPacker>)

## [0.2.0] - 2026-02-12

- Added: support for ModPackLoader mods not packaged with loader dll
- Added: Auto-copy of ModPackLoader dlls to game folder

## [0.1.0] - 2026-02-10

- Initial release
