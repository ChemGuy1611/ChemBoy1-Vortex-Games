/*//////////////////////////////////////////
Name: MENACE Vortex Extension
Structure: Unity BepinEx/MelonLoader Hybrid
Author: ChemBoy1
Version: 0.8.1
Date: 2026-09-05
//////////////////////////////////////////*/

//Import libraries
const { actions, fs, util, selectors, log } = require('vortex-api');
const path = require('path');
const template = require('string-template');
const fsExtra = require('fs-extra');
const { parseStringPromise } = require('xml2js');
const winapi = require('winapi-bindings');
const React = require('react');
//Auto-downloader module
const { download, findModByFile, findDownloadIdByFile, resolveVersionByModVersion } = require('./downloader');

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const USER_HOME = util.getVortexPath("home");
const LOCALLOW = path.join(USER_HOME, 'AppData', 'LocalLow');
//const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath("appData");
const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all the information about the game
const GAME_ID = "menace";
const STEAMAPP_ID = "2432860";
const STEAMAPP_ID_DEMO = "2432870";
const EPICAPP_ID = "15fe5928df2c4d45bc92d01d24bd230a"; //from egdata.app
const GOGAPP_ID = "1812373738";
const XBOXAPP_ID = "HoodedHorse.MENACE";
const XBOXEXECNAME = "Game";
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, GOGAPP_ID, XBOXAPP_ID, STEAMAPP_ID_DEMO, EPICAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const GAME_NAME = "MENACE";
const GAME_NAME_SHORT = "MENACE";
const GAME_STRING = "Menace"; //string for exe and data folder (seem to always match)
const GAME_STRING_ALT = "Menace"; // matches Steam
const EXEC = `${GAME_STRING}.exe`;
const EXEC_EGS = EXEC;
const EXEC_GOG = EXEC;
const EXEC_XBOX = 'gamelaunchhelper.exe';
const EXEC_ALT = EXEC_XBOX; //or `${GAME_STRING_ALT}.exe`
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Menace";
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1686"; //Nexus link to this extension. Used for links

//feature toggles
const enableLoadOrder = true; //true if you want to use load order sorting
const allowSymlinks = true; //true if game can use symlinks without issues. Typically needs to be false if files have internal references (i.e. pak/ucas/utoc or ba2/esp)
const multiExe = false; //set to true if there are multiple executables (typically for Xbox/EGS)
const fallbackInstaller = true; //enable fallback installer. Set false if you need to avoid installer collisions
const preventPluginInstall = true; //set to true if you want to prevent plugins not for the current mod loader from installing. Disable if using cross-compatibility plugins.
const loaderSwitchRestart = false; //set to true if you need to restart the extension after switching mod loaders
const enableSaveInstaller = false; //set to true if you want to enable the save installer (only recommended if saves are stored in the game's folder)
const hasCustomMods = false; //set to true if there are modTypes with folder paths dependent on which mod loader is installed
const hasCustomLoader = false; //set to true if there is a custom mod loader
const customLoaderInstaller = false; //set true if the custom loader uses an installer

const DATA_FOLDER_DEFAULT = `${GAME_STRING}_Data`;
let DATA_FOLDER = DATA_FOLDER_DEFAULT;
const ALT_VERSION = 'xbox';
const DATA_FOLDER_ALT = `${GAME_STRING_ALT}_Data`; //don't always match
const ROOT_FOLDERS = [DATA_FOLDER, DATA_FOLDER_ALT];
const VERSION_FILE = 'app.info';
let VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);

const DEV_REGSTRING = "Overhype Studios"; //developer name
const GAME_REGSTRING = "Menace"; //game name
const XBOX_SAVE_STRING = 'znaey1dw2bdpr'; //string after "ID_"

//Data to determine BepinEx/MelonLoader versions and URLs
const recommendedLoader = 'melon'; // bepinex/melon/'' - loader shows as "(Recommended)" in selector. '' if no recommendation.
const BEPINEX_BUILD = 'il2cpp'; // 'mono' or 'il2cpp' - check for "il2cpp_data" folder
const ARCH = 'x64'; //'x64' or 'x86' game architecture (64-bit or 32-bit)
const BEP_VER = '5.4.23.5'; //set BepInEx version for mono URLs
const BEP_BE_VER = '755'; //set BepInEx build for BE URLs
const BEP_BE_COMMIT = '3fab71a'; //git commit number for BE builds
const allowBepCfgMan = false; //should BepInExConfigManager be downloaded?
const allowMelPrefMan = false; //should MelonPreferencesManager be downloaded? False until figure out UniverseLib dependency
const allowBepinexNexus = false; //set false until bugs are fixed
const allowMelonNexus = false; //set false until bugs are fixed

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

let GAME_PATH = '';
let STAGING_FOLDER = '';
let DOWNLOAD_FOLDER = '';
let GAME_VERSION = '';
let bepinexInstalled = false;
let melonInstalled = false;
let customInstalled = false;
const APPMANIFEST_FILE = 'appxmanifest.xml';

//Config and save paths
const CONFIG_PATH = path.join(LOCALLOW, DEV_REGSTRING, GAME_REGSTRING);
const CONFIG_FILES = ['settings.json'];
const SAVE_PATH_DEFAULT = path.join(USER_HOME, 'AppData', 'LocalLow', DEV_REGSTRING, GAME_REGSTRING);
const SAVE_PATH_XBOX = path.join(LOCALAPPDATA, "Packages", `${XBOXAPP_ID}_${XBOX_SAVE_STRING}`, "SystemAppData", "wgs"); //XBOX Version
let SAVE_PATH = SAVE_PATH_DEFAULT;
const SAVE_FILES = ['XXX.XXX'];
const SAVE_EXTS = [".XXX"];

//info for modtypes, installers, and tools
const BEPINEX_ID = `${GAME_ID}-bepinex`;
const BEPINEX_NAME = "BepInEx Injector";
let BEPINEX_FILE = 'BepInEx.Core.dll';
let BEP_INDICATOR_FILE = path.join('BepInEx', 'core', BEPINEX_FILE);
if (BEPINEX_BUILD === 'mono') {
  BEPINEX_FILE = 'BepInEx.dll';
  BEP_INDICATOR_FILE = path.join('BepInEx', 'core', BEPINEX_FILE);
}
const BEPINEX_FOLDER = 'BepInEx';
const BEP_STRING = 'BepInEx';
const BEP_PATCHER_STRING = 'BaseUnityPlugin';

let BEPINEX_ZIP = `BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.${BEP_BE_VER}+${BEP_BE_COMMIT}.zip`;
let BEPINEX_URL = `https://builds.bepinex.dev/projects/bepinex_be/${BEP_BE_VER}/BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.${BEP_BE_VER}%2B${BEP_BE_COMMIT}.zip`;
let BEPINEX_URL_ERR = `https://builds.bepinex.dev/projects/bepinex_be`;
if (BEPINEX_BUILD === 'mono') {
  BEPINEX_ZIP = `BepInEx_win_${ARCH}_${BEP_VER}.zip`;
  BEPINEX_URL = `https://github.com/BepInEx/BepInEx/releases/download/v${BEP_VER}/${BEPINEX_ZIP}`;
  BEPINEX_URL_ERR = `https://github.com/BepInEx/BepInEx/releases`;
}

let MELON_STRING = 'IL2CPP';
if ( BEPINEX_BUILD === 'mono') {
  MELON_STRING = 'Mono';
}
const MELON_ID = `${GAME_ID}-melonloader`;
const MELON_NAME = "MelonLoader";
const MELON_ZIP = `MelonLoader.${ARCH}.zip`;
//const MELON_URL = `https://github.com/LavaGang/MelonLoader/releases/latest/download/${MELON_ZIP}`;
const MELON_URL = `https://nightly.link/LavaGang/MelonLoader/workflows/build/alpha-development/MelonLoader.Windows.x64.CI.Release.zip`;
const MELON_URL_ERR = `https://github.com/LavaGang/MelonLoader/releases`;
const MELON_PAGE_NO = 9;
const MELON_FILE_NO = 34;
const MELON_DOMAIN = GAME_ID;
const MELON_FILE = 'MelonLoader.dll';
const MELON_FOLDER = 'MelonLoader';
const MEL_STRING = 'MelonLoader';
const MEL_PLUGIN_STRING = 'MelonPlugin';
const MELON_INDICATOR_FILE = path.join('MelonLoader', 'net6', MELON_FILE);
const MELON_DOTNET_VER = '6';
const MELON_DOTNET_URL = `https://dotnet.microsoft.com/download/dotnet/${MELON_DOTNET_VER}.0`;
const DOTNET_REG_HIVE = 'HKEY_LOCAL_MACHINE';
const DOTNET_REG_KEY = `SOFTWARE\\WOW6432Node\\dotnet\\Setup\\InstalledVersions\\x64\\sharedfx\\Microsoft.WindowsDesktop.App`;

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Game Folder";

const ASSEMBLY_ID = `${GAME_ID}-assemblydll`;
const ASSEMBLY_NAME = "Assembly DLL Mod";
let ASSEMBLY_PATH = '.';
let ASSEMBLY_FILES = ["GameAssembly.dll"];
if (BEPINEX_BUILD === 'mono') {
  ASSEMBLY_PATH = path.join(DATA_FOLDER, 'Managed');
  ASSEMBLY_FILES = ["Assembly-CSharp.dll", "Assembly-CSharp-firstpass.dll"];
}

const ASSETS_ID = `${GAME_ID}-assets`;
const ASSETS_NAME = "Assets/Resources File";
let ASSETS_PATH = DATA_FOLDER;
const ASSETS_EXTS = ['.assets', '.resource', '.ress'];

const PLUGIN_EXTS = ['.dll'];

const BEPINEX_MOD_ID = `${GAME_ID}-bepinexmod`;
const BEPINEX_MOD_NAME = "BepInEx Mod";
const BEPINEX_MOD_PATH = BEPINEX_FOLDER;
const BEPINEX_MOD_FOLDERS = ['plugins', 'patchers', 'config'];

const MELON_MOD_ID = `${GAME_ID}-melonmod`;
const MELON_MOD_NAME = "MelonLoader Mod";
const MELON_MOD_PATH = '.';
const MELON_MOD_FOLDERS = ['mods', 'plugins', 'userdata', 'userlibs'];

const BEPINEX_PLUGINS_ID = `${GAME_ID}-bepinex-plugins`;
const BEPINEX_PLUGINS_NAME = "BepInEx Plugins";
const BEPINEX_PLUGINS_FOLDER = 'plugins';
const BEPINEX_PLUGINS_PATH = path.join(BEPINEX_FOLDER, BEPINEX_PLUGINS_FOLDER);

const BEPINEX_PATCHERS_ID = `${GAME_ID}-bepinex-patchers`;
const BEPINEX_PATCHERS_NAME = "BepInEx Patchers";
const BEPINEX_PATCHERS_FOLDER = 'patchers';
const BEPINEX_PATCHERS_PATH = path.join(BEPINEX_FOLDER, BEPINEX_PATCHERS_FOLDER);

const BEPINEX_CONFIG_ID = `${GAME_ID}-bepinex-config`;
const BEPINEX_CONFIG_NAME = "BepInEx Config";
const BEPINEX_CONFIG_FOLDER = 'config';
const BEPINEX_CONFIG_PATH = path.join(BEPINEX_FOLDER, BEPINEX_CONFIG_FOLDER);

const MELON_MODS_ID = `${GAME_ID}-melonloader-mods`;
const MELON_MODS_NAME = "MelonLoader Mods";
const MELON_MODS_FOLDER = 'Mods';
const MELON_MODS_PATH = MELON_MODS_FOLDER;

const MELON_PLUGINS_ID = `${GAME_ID}-melonloader-plugins`;
const MELON_PLUGINS_NAME = "MelonLoader Plugins";
const MELON_PLUGINS_FOLDER = 'Plugins';
const MELON_PLUGINS_PATH = MELON_PLUGINS_FOLDER;

const MELON_CONFIG_ID = `${GAME_ID}-melonloader-config`;
const MELON_CONFIG_NAME = "MelonLoader Config";
const MELON_CONFIG_FOLDER = 'UserData';
const MELON_CONFIG_PATH = MELON_CONFIG_FOLDER;

const BEPCFGMAN_ID = `${GAME_ID}-bepcfgman`;
const BEPCFGMAN_NAME = "BepInExConfigManager";
const BEPCFGMAN_PATH = BEPINEX_MOD_PATH;
const BEPCFGMAN_URL = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases/download/v18.4.1/BepInEx.ConfigurationManager_IL2CPP_v18.4.1.zip`;
const BEPCFGMAN_URL_ERR = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases`;
const BEPCFGMAN_FILE = `configurationmanager.dll`; //lowercased

const MELONPREFMAN_ID = `${GAME_ID}-melonprefman`;
const MELONPREFMAN_NAME = "MelonPreferencesManager";
const MELONPREFMAN_PATH = MELON_MODS_PATH;
const MELONPREFMAN_URL = `https://github.com/Bluscream/MelonPreferencesManager/releases/latest/download/MelonPrefManager.${MELON_STRING}.dll`;
const MELONPREFMAN_URL_ERR = `https://github.com/Bluscream/MelonPreferencesManager/releases`;
const MELONPREFMAN_FILE = `melonprefmanager.${BEPINEX_BUILD}.dll`; //lowercased

const BEP_CONFIG_FILE = 'BepInEx.cfg';
const BEP_CONFIG_FILEPATH = path.join(BEPINEX_CONFIG_PATH, BEP_CONFIG_FILE);
const MEL_CONFIG_FILE = 'Loader.cfg';
const MEL_CONFIG_FILEPATH = path.join(MELON_CONFIG_PATH, MEL_CONFIG_FILE);

const BEP_LOG_FILE = 'LogOutput.log';
const BEP_LOG_FILEPATH = path.join(BEPINEX_FOLDER, BEP_LOG_FILE);
const MEL_LOG_FILE = 'Latest.log';
const MEL_LOG_FILEPATH = path.join(MELON_FOLDER, MEL_LOG_FILE);

//custom mods (that change directory based on loader)
const CUSTOM_ID = `${GAME_ID}-custommod`;
const CUSTOM_NAME = "XXX";
const CUSTOM_FOLDER = 'XXX';
const CUSTOM_PATH_BEPINEX = path.join(BEPINEX_PLUGINS_PATH, CUSTOM_FOLDER);
const CUSTOM_PATH_MELON = path.join(MELON_MODS_PATH, CUSTOM_FOLDER);
let CUSTOM_PATH = '';
/*const CUSTOM_PATH_BEPINEX = path.join(BEPINEX_PLUGINS_PATH);
const CUSTOM_PATH_MELON = path.join(MELON_MODS_PATH); //*/
const CUSTOM_STRING = '.custom.json';
const CUSTOM_EXTS = ['.json'];

const DEPLOY_FILE = `vortex.deployment.${CUSTOM_ID}.json`;
const CUSTOM_DEPLOYFILE_BEPINEX = path.join(CUSTOM_PATH_BEPINEX, DEPLOY_FILE);
const CUSTOM_DEPLOYFILE_MELON = path.join(CUSTOM_PATH_MELON, DEPLOY_FILE);

//Save Editor
const SAVEEDITOR_ID = `${GAME_ID}-saveeditor`;
const SAVEEDITOR_NAME = "Save Editor";
const SAVEEDITOR_EXEC = 'XXX.exe';

//Custom mod loader
const CUSTOMLOADER_ID = `${GAME_ID}-customloader`;
const CUSTOMLOADER_NAME = "XXX";
const CUSTOMLOADER_EXEC = 'XXX.exe';
const CUSTOMLOADER_FILE = 'XXX.dll';
const CUSTOMLOADER_MARKER_FILE = 'XXX.dll';
const CUSTOMLOADER_MARKER_PATH = path.join(DATA_FOLDER, 'Managed', CUSTOMLOADER_MARKER_FILE);
const CUSTOMLOADER_FOLDER = 'XXX';
const CUSTOMLOADER_PAGE_NO = 0;
const CUSTOMLOADER_FILE_NO = 0;
const CUSTOMLOADER_DOMAIN = GAME_ID;
const CUSTOMLOADER_FILES_ARRAY = [
  'winhttp.dll',
  CUSTOMLOADER_MARKER_PATH,
];

const CUSTOMLOADER_MOD_ID = `${GAME_ID}-customloadermod`;
const CUSTOMLOADER_MOD_NAME = "XXX Mod";
const CUSTOMLOADER_MOD_PATH = '.';
const CUSTOMLOADER_MOD_FOLDERS = ['mods'];

const CUSTOMLOADER_PLUGIN_ID = `${GAME_ID}-customloaderplugin`;
const CUSTOMLOADER_PLUGIN_NAME = "XXX Plugin";
const CUSTOMLOADER_PLUGIN_PATH = path.join('XXX');
const CUSTOMLOADER_PLUGIN_FOLDERS = ['XXX'];
const CUSTOM_PLUGIN_STRING = 'XXX'; //string to ID Custom plugin file

//Jiangyu is the current mod loader for the game and replaced ModpackLoader. The release asset is a
//naked .dll dropped into the MelonLoader "Mods" folder, so it is fetched in direct-copy mode.
const JIANGYU_ID = `${GAME_ID}-jiangyu`;
const JIANGYU_NAME = "Jiangyu Loader";
const JIANGYU_PATH = MELON_MODS_PATH;
const JIANGYU_FILE = 'Jiangyu.Loader.dll';
const JIANGYU_FILES = [JIANGYU_FILE];
const JIANGYU_ARC_NAME = JIANGYU_FILE;
const JIANGYU_URL_API = `https://api.github.com/repos/antistrategie/jiangyu`;

const JIANGYUMOD_ID = `${GAME_ID}-jiangyumod`;
const JIANGYUMOD_NAME = "Jiangyu Mod";
const JIANGYUMOD_PATH = MELON_MODS_PATH;
const JIANGYUMOD_FILE = 'jiangyu.json';
const JIANGYUMOD_FILES = [JIANGYUMOD_FILE];

const MODPACKLOADER_ID = `${GAME_ID}-modpackloader`;
const MODPACKLOADER_NAME = "ModpackLoader";
const MODPACKLOADER_PATH = '.';
const MODPACKLOADER_FILE = "Menace.ModpackLoader.dll";
const MODPACKLOADER_FOLDER = "UserLibs";
//ModpackLoader is installed on its own (see MODPACKLOADER_REQUIREMENTS): the loader assembly to
//"Mods", its dependencies to "UserLibs". Kept as a list so identical copies - a mod bundling its
//own, or a hand-installed ModpackLoader package - are excluded from conflict reporting.
const MODPACKLOADER_DLLS = [
  MODPACKLOADER_FILE,
  'Microsoft.CodeAnalysis.CSharp.dll',
  'Microsoft.CodeAnalysis.dll',
  'MoonSharp.Interpreter.dll',
  'Newtonsoft.Json.dll',
  'SharpGLTF.Core.dll',
  'System.Collections.Immutable.dll',
  'System.Reflection.Metadata.dll'
];
const MPL_DOTNET_VER = '10';
const MPL_DOTNET_URL = `https://dotnet.microsoft.com/download/dotnet/${MPL_DOTNET_VER}.0`;

const MODPACKMOD_ID = `${GAME_ID}-modpackmod`;
const MODPACKMOD_NAME = "Modpack Mod";
const MODPACKMOD_PATH = MELON_MODS_PATH;
const MODPACKMOD_FILE = "modpack.json";

const CUSTOMLEADERS_ID = `${GAME_ID}-customleaders`;
const CUSTOMLEADERS_NAME = "Custom Leaders Mod";
const CUSTOMLEADERS_FOLDER = "customleaders";
const CUSTOMLEADERS_PATH = path.join(MELON_MODS_PATH, CUSTOMLEADERS_FOLDER);
const CUSTOMLEADERS_STRING_CLONE = "_clone.json";
const CUSTOMLEADERS_STRING_REPL = "_replace.json";

const MODKIT_ID = `${GAME_ID}-modkit`;
const MODKIT_NAME = "Menace ModKit";
const MODKIT_EXEC = 'Menace.Modkit.App.exe';
const MODKIT_PATH = '.';
const MODKIT_ARC_NAME = 'menace-modkit-win-x64.zip';
//Folder inside the Menace Mod Manager (and ModKit) archive holding the bundled ModpackLoader
//runtime - installModpackLoader extracts the loader from here.
const MODKIT_LOADER_FOLDER = path.join('third_party', 'bundled', 'ModpackLoader');
const MODKIT_URL_API = 'https://api.github.com/repos/antistrategie/MenaceModkit';
//The Menace Mod Manager ships in the same repo and release as the ModKit and carries the same
//bundled ModpackLoader runtime. It is the ModpackLoader download source (see
//MODPACKLOADER_REQUIREMENTS); the ~120 MB manager app in the archive is not deployed.
const MODMANAGER_ARC_NAME = 'menace-mod-manager-win-x64.zip';

//Jiangyu ships a naked .dll, which Vortex's archive install pipeline cannot handle. directCopyAsMod
//puts the file in a managed mod's staging folder instead, so it deploys to the MelonLoader "Mods"
//folder through JIANGYU_ID and shows up in the mod list like any other mod - with its version, and
//removable from there.
const JIANGYU_REQUIREMENTS = [
  {
    archiveFileName: JIANGYU_ARC_NAME,
    userFacingName: JIANGYU_NAME,
    githubUrl: JIANGYU_URL_API,
    directCopyAsMod: true,
    modType: JIANGYU_ID, //required in this mode - the mod type is what decides where the file deploys
    assemblyFileName: JIANGYU_FILE,
    findMod: (api) => findModByFile(api, JIANGYU_ID, JIANGYU_FILE),
    //the release also carries jiangyu-cli and jiangyu-studio archives - anchor both ends
    fileArchivePattern: /^Jiangyu\.Loader\.dll$/i,
    resolveVersion: (api) => resolveVersionByModVersion(api, JIANGYU_REQUIREMENTS[0]),
    //legacy loose copy written by the old direct-copy mode - deleted once, when the managed mod is
    //created. Placeholder only: GAME_PATH is '' at module load, so setup() reassigns it.
    directCopyPath: path.join(GAME_PATH, JIANGYU_PATH, JIANGYU_FILE),
    autoInstall: true, //this is the game's current loader, so a missing copy is installed for the user
  },
];

//ModpackLoader ships bundled inside the Menace Mod Manager release on GitHub (same repo as the
//ModKit), under MODKIT_LOADER_FOLDER. The downloader fetches menace-mod-manager-win-x64.zip and
//hands it to installModpackLoader, which extracts only the bundled loader - the assembly to "Mods",
//its dependencies to "UserLibs" - and drops the ~120 MB manager app. Some published mods still need
//ModpackLoader alongside Jiangyu, so setup() keeps installing it automatically.
const MODPACKLOADER_REQUIREMENTS = [
  {
    archiveFileName: MODMANAGER_ARC_NAME,
    userFacingName: MODPACKLOADER_NAME,
    githubUrl: MODKIT_URL_API,
    modType: MODPACKLOADER_ID,
    assemblyFileName: MODPACKLOADER_FILE,
    findMod: (api) => findModByFile(api, MODPACKLOADER_ID, MODPACKLOADER_FILE),
    findDownloadId: (api) => findDownloadIdByFile(api, MODMANAGER_ARC_NAME),
    //the release also ships menace-modkit-win-x64.zip and linux tarballs - anchor both ends
    fileArchivePattern: /^menace-mod-manager-win-x64\.zip$/i,
    resolveVersion: (api) => resolveVersionByModVersion(api, MODPACKLOADER_REQUIREMENTS[0]),
    autoInstall: true,
  },
];

//The ModKit is an optional authoring tool, never a play requirement, so only the toolbar button
//installs it. The asset name carries no version, so the installed mod's version is the marker.
const MODKIT_REQUIREMENTS = [
  {
    archiveFileName: MODKIT_ARC_NAME,
    modType: MODKIT_ID,
    assemblyFileName: MODKIT_EXEC,
    userFacingName: MODKIT_NAME,
    githubUrl: MODKIT_URL_API,
    findMod: (api) => findModByFile(api, MODKIT_ID, MODKIT_EXEC),
    findDownloadId: (api) => findDownloadIdByFile(api, MODKIT_ARC_NAME),
    //the same release ships menace-mod-manager-win-x64.zip - anchor both ends so it cannot match
    fileArchivePattern: /^menace-modkit-win-x64\.zip$/i,
    resolveVersion: (api) => resolveVersionByModVersion(api, MODKIT_REQUIREMENTS[0]),
    autoInstall: false, //the toolbar action installs this - never setup() and never a deploy
  },
];

//Both loaders share the "Mods" folder, so one page covers both. Jiangyu has no load order field of
//its own and sorts lexically by folder name, so its position is written as a numeric folder prefix
//at deploy time, while ModpackLoader mods keep the number inside their own modpack.json.
const LO_JSON_KEY = "loadOrder";
const LO_INCREMENT = 10;
const LO_ATTRIBUTE = "modName";
const LO_PREFIX_PAD = 3; //zero-padded so "010-" cannot sort above "009-"; good for 999 mods
const LO_UNSORTED_PREFIX = 'ZZZ';
const LO_UNSORTED_POS = 9999; //sort key for a mod with no recorded position - always last
// for mod update to keep them in the load order and not uncheck them
let mod_update_all_profile = false;
let updateModIds = new Map(); // Nexus mod id -> {firstSeen, targetFileId} (Map, not scalar, so batch updates don't clobber each other)
const MAX_UPDATE_WAIT_MS = 5 * 60 * 1000; // release the guard for an update that never lands (cancelled or failed install)
let updating_mod = false; // used to see if it's a mod update or not
let mod_install_name = ""; // used to display the name of the currently installed mod

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const MOD_PATH_DEFAULT = ".";
let REQ_FILE = EXEC;
if (multiExe && (BEPINEX_BUILD === 'il2cpp')) {
  REQ_FILE = ASSEMBLY_FILES[0];
}
if (multiExe && (BEPINEX_BUILD === 'mono')) {
  REQ_FILE = ''; //find something that works in this case
}
const PARAMETERS_STRING = '';
const PARAMETERS = [PARAMETERS_STRING];

//The ModKit and the ModpackLoader mod on Nexus both supply the loader runtime, so those files are
//expected to be identical duplicates rather than a conflict the user has to resolve.
const IGNORE_CONFLICTS = [...MODPACKLOADER_DLLS.map(dll => path.join('**', dll)), path.join('**', JIANGYU_FILE), path.join('**', 'manifest.json'), path.join('**', 'icon.png'), path.join('**', 'CHANGELOG.md'), path.join('**', 'readme.txt'), path.join('**', 'README.txt'), path.join('**', 'ReadMe.txt'), path.join('**', 'Readme.txt')];
const IGNORE_DEPLOY = [path.join('**', 'manifest.json'), path.join('**', 'icon.png'), path.join('**', 'CHANGELOG.md'), path.join('**', 'readme.txt'), path.join('**', 'README.txt'), path.join('**', 'ReadMe.txt'), path.join('**', 'Readme.txt')];
let MODTYPE_FOLDERS = [BEPINEX_PATCHERS_PATH, BEPINEX_PLUGINS_PATH, BEPINEX_CONFIG_PATH, MELON_PLUGINS_PATH, MELON_MODS_PATH, MELON_CONFIG_PATH, CUSTOMLEADERS_PATH];
if (hasCustomMods) {
  MODTYPE_FOLDERS.push(CUSTOM_PATH_BEPINEX, CUSTOM_PATH_MELON);
}
if (hasCustomLoader) {
  MODTYPE_FOLDERS.push(CUSTOMLOADER_PLUGIN_PATH);
}

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const LO_IMAGE_WIDTH = 96; //Width of the load order thumbnail image
const LO_IMAGE_HEIGHT = LO_IMAGE_WIDTH * 0.5625;

//Filled in from info above
const spec = {
  "game": {
    "id": GAME_ID,
    "name": GAME_NAME,
    "shortName": GAME_NAME_SHORT,
    //"parameters": PARAMETERS,
    "logo": `${GAME_ID}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPath": MOD_PATH_DEFAULT,
    "modPathIsRelative": true,
    "requiredFiles": [
      REQ_FILE
    ],
    "compatible": {
      "dinput": false,
      "enb": false,
    },
    "details": {
      "steamAppId": +STEAMAPP_ID,
      "gogAppId": GOGAPP_ID,
      "epicAppId": EPICAPP_ID,
      "xboxAppId": XBOXAPP_ID,
      "supportsSymlinks": allowSymlinks,
      "ignoreConflicts": IGNORE_CONFLICTS,
      "ignoreDeploy": IGNORE_DEPLOY,
    },
    "environment": {
      "SteamAPPId": STEAMAPP_ID,
      "GogAPPId": GOGAPP_ID,
      "EpicAPPId": EPICAPP_ID,
      "XboxAPPId": XBOXAPP_ID
    }
  },
  "modTypes": [
    {
      "id": MODPACKLOADER_ID,
      "name": MODPACKLOADER_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', MODPACKLOADER_PATH)
    },
    {
      "id": MODPACKMOD_ID,
      "name": MODPACKMOD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MODPACKMOD_PATH)
    }, //*/
    {
      "id": CUSTOMLEADERS_ID,
      "name": CUSTOMLEADERS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', CUSTOMLEADERS_PATH)
    }, //*/
    {
      "id": MODKIT_ID,
      "name": MODKIT_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', MODKIT_PATH)
    },
    {
      "id": BEPINEX_MOD_ID,
      "name": BEPINEX_MOD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_MOD_PATH)
    },
    {
      "id": MELON_MOD_ID,
      "name": MELON_MOD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_MOD_PATH)
    }, //*/
    {
      "id": BEPINEX_PLUGINS_ID,
      "name": BEPINEX_PLUGINS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_PLUGINS_PATH)
    },
    {
      "id": BEPINEX_PATCHERS_ID,
      "name": BEPINEX_PATCHERS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_PATCHERS_PATH)
    },
    {
      "id": BEPINEX_CONFIG_ID,
      "name": BEPINEX_CONFIG_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_CONFIG_PATH)
    },
    {
      "id": MELON_MODS_ID,
      "name": MELON_MODS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_MODS_PATH)
    },
    {
      "id": MELON_PLUGINS_ID,
      "name": MELON_PLUGINS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_PLUGINS_PATH)
    },
    {
      "id": MELON_CONFIG_ID,
      "name": MELON_CONFIG_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_CONFIG_PATH)
    },
    {
      "id": BEPCFGMAN_ID,
      "name": BEPCFGMAN_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPCFGMAN_PATH)
    },
    {
      "id": MELONPREFMAN_ID,
      "name": MELONPREFMAN_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELONPREFMAN_PATH)
    },
    {
      "id": ROOT_ID,
      "name": ROOT_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": BEPINEX_ID,
      "name": BEPINEX_NAME,
      "priority": "low",
      "targetPath": '{gamePath}'
    },
    {
      "id": MELON_ID,
      "name": MELON_NAME,
      "priority": "low",
      "targetPath": '{gamePath}'
    },
    //appended last on purpose: the loop below derives each priority from the array index, so
    //inserting anywhere else renumbers every mod type after it
    {
      "id": JIANGYU_ID,
      "name": JIANGYU_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', JIANGYU_PATH)
    },
  ],
  "discovery": {
    "ids": DISCOVERY_IDS_ACTIVE,
    "names": []
  }
};

//3rd party tools and launchers
const tools = [
  {
    id: `${GAME_ID}-customlaunch`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC,
    requiredFiles: [EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  {
    id: MODKIT_ID,
    name: MODKIT_NAME,
    logo: `modkit.png`,
    executable: () => MODKIT_EXEC,
    requiredFiles: [MODKIT_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    //shell: true,
    //defaultPrimary: true,
    //parameters: PARAMETERS,
  }, //*/
  /*{
    id: `${GAME_ID}-customlaunchalt`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC_ALT,
    requiredFiles: [EXEC_ALT],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  /*{
    id: SAVEEDITOR_ID,
    name: SAVEEDITOR_NAME,
    logo: `saveeditor.png`,
    executable: () => SAVEEDITOR_EXEC,
    requiredFiles: [SAVEEDITOR_EXEC],
    detach: true,
    relative: true,
    exclusive: false,
    //shell: true,
    //parameters: [],
  }, //*/
  /*{
    id: CUSTOMLOADER_ID,
    name: `${CUSTOMLOADER_NAME} Installer`,
    logo: `customloader.png`,
    executable: () => path.join(CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC),
    requiredFiles: [path.join(CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC)],
    detach: true,
    relative: true,
    exclusive: true,
    //shell: true,
    //parameters: [],
  }, //*/
];

// BASIC FUNCTIONS //////////////////////////////////////////////////////////////

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fs.statAsync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}

//Set mod type priorities
function modTypePriority(priority) {
  return {
    high: 30,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath: (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0 ? void 0 : _a.path,
      documents: util.getVortexPath('documents'),
      localAppData: util.getVortexPath('localAppData'),
      appData: util.getVortexPath('appData'),
    });
  }
  catch (err) { //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification('Failed to locate executable. Please launch the game at least once.', err);
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () => gameSpec.game.modPathIsRelative !== false
    ? gameSpec.game.modPath || '.'
    : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () => util.GameStoreHelper.findByAppId(gameSpec.discovery.ids)
    .then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher(gamePath, store) {
  if (store === 'xbox' && (DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID))) {
      return Promise.resolve({
          launcher: 'xbox',
          addInfo: {
              appId: XBOXAPP_ID,
              parameters: [{ appExecName: XBOXEXECNAME }],
          },
      });
  } //*/
  if (store === 'epic' && (DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID))) {
    return Promise.resolve({
        launcher: 'epic',
        addInfo: {
            appId: EPICAPP_ID,
        },
    });
  } //*/
  /*
  if (store === 'steam') {
    return Promise.resolve({
        launcher: 'steam',
    });
  } //*/
  return Promise.resolve(undefined);
}

//Get correct save folder for game version
async function getSavePath(api) {
  GAME_PATH = getDiscoveryPath(api);
  if (await statCheckAsync(GAME_PATH, EXEC_XBOX)) {
    SAVE_PATH = SAVE_PATH_XBOX;
    return SAVE_PATH;
  }
  else {
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return SAVE_PATH;
  };
} //*/

//Get correct executable for game version
function getExecutable(discoveryPath) {
  if (statCheckSync(discoveryPath, EXEC_XBOX)) {
    SAVE_PATH = SAVE_PATH_XBOX;
    return EXEC_XBOX;
  }
  /*if (!multiExe) { //return immediately if only one exe filename for all versions
    return EXEC;
  }
  if (statCheckSync(discoveryPath, EXEC_ALT)) {
    DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    }
    return EXEC_ALT;
  }; //*/
  return EXEC;
}

//Get correct game version
async function setGameVersion(gamePath) {
  const CHECK = await statCheckAsync(gamePath, EXEC_XBOX);
  if (CHECK) {
    GAME_VERSION = 'xbox';
    SAVE_PATH = SAVE_PATH_XBOX;
    /*DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    } //*/
    return GAME_VERSION;
  } else {
    GAME_VERSION = 'default';
    return GAME_VERSION;
  }
}

//Get correct custom folder for installed mod loader
function getCustomFolder(api, game) {
  GAME_PATH = getDiscoveryPath(api);
  if (GAME_PATH === undefined) {
    return '.';
  }
  bepinexInstalled = isBepinexInstalled(api, spec);
  melonInstalled = isMelonInstalled(api, spec);
  if (bepinexInstalled) {
    CUSTOM_PATH = CUSTOM_PATH_BEPINEX;
    try {
      fs.statSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_MELON));
      fsExtra.unlinkSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_MELON));
    } catch (err) {
      //log('warn', `Failed to remove ${CUSTOMCHAR_DEPLOYFILE_MELON}: ${err.message}`);
    }
  };
  if (melonInstalled) {
    CUSTOM_PATH = CUSTOM_PATH_MELON;
    try {
      fs.statSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_BEPINEX));
      fsExtra.unlinkSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_BEPINEX));
    } catch {
      //log('warn', `Failed to remove ${CUSTOMCHAR_DEPLOYFILE_BEPINEX}: ${err.message}`);
    }
  };
  const folderPath = path.join(GAME_PATH, CUSTOM_PATH);
  return folderPath;
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fs.readdirAsync(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fs.statAsync(fullPath);
      if (stats.isDirectory()) { // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else { // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log('warn', `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api) => { //get the game's discovered path
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, GAME_ID], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) { //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) => api.events.emit('purge-mods', true, (err) => err ? reject(err) : resolve()));
}
async function deploy(api) { //useful to deploy mods after doing some action
  return new Promise((resolve, reject) => api.events.emit('deploy-mods', (err) => err ? reject(err) : resolve()));
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Test for BepinEx files
function testBepinex(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === BEPINEX_FILE));
  const isFolder = files.some(file => (path.basename(file) === BEPINEX_FOLDER));
  let supported = (gameId === spec.game.id) && isMod && isFolder;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install BepInEx files
function installBepinex(files) {
  const MOD_TYPE = BEPINEX_ID;
  const modFile = files.find(file => (path.basename(file) === BEPINEX_FOLDER));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for MelonLoader files
function testMelon(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === MELON_FILE));
  const isFolder = files.some(file => (path.basename(file) === MELON_FOLDER));
  let supported = (gameId === spec.game.id) && isMod && isFolder;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install MelonLoader files
function installMelon(files) {
  const MOD_TYPE = MELON_ID;
  const modFile = files.find(file => (path.basename(file) === MELON_FOLDER));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for ModpackLoader files
function testModkit(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === MODKIT_EXEC));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install ModKit files
function installModkit(files) {
  const MOD_TYPE = MODKIT_ID;
  const modFile = files.find(file => (path.basename(file) === MODKIT_EXEC));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });

  //ModpackLoader is installed separately now (see MODPACKLOADER_REQUIREMENTS / installModpackLoader),
  //so the ModKit's bundled copy under third_party/ is left as-is - not re-placed into "Mods"/"UserLibs".
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Jiangyu Loader files. The loader is normally fetched straight to the game folder by the
//auto-downloader; this covers the archived copy attached to a mod page on Nexus.
function testJiangyu(files, gameId) {
  const isMod = files.some(file => JIANGYU_FILES.some(loaderFile =>
    (loaderFile.toLowerCase() === path.basename(file).toLowerCase())));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Jiangyu Loader files
function installJiangyu(files) {
  const MOD_TYPE = JIANGYU_ID;
  const modFile = files.find(file => JIANGYU_FILES.some(loaderFile =>
    (loaderFile.toLowerCase() === path.basename(file).toLowerCase())));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Jiangyu mod files
function testJiangyuMod(files, gameId) {
  const isMod = files.some(file => JIANGYUMOD_FILES.includes(path.basename(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install Jiangyu mod files
async function installJiangyuMod(files, destinationPath) {
  const MOD_TYPE = JIANGYUMOD_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };
  const modFile = files.find(file => (path.basename(file).toLowerCase() === JIANGYUMOD_FILE));
  const rootPath = path.dirname(modFile);
  const idx = modFile.indexOf(path.basename(modFile));

  //Folder the mod deploys into. The manifest's "name" is the loader's own identity for the mod -
  //what other mods declare as a dependency - so it wins over anything derived from the archive.
  let folder = path.basename(destinationPath).split('-')[0];
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== '.') {
    folder = ROOT_PATH;
  }
  try {
    const contents = await fs.readFileAsync(path.join(destinationPath, modFile), 'utf8');
    const manifestName = JSON.parse(contents).name;
    if ((typeof manifestName === 'string') && (manifestName.trim() !== '')) {
      folder = manifestName.trim();
    }
  } catch (err) {
    log('warn', `Failed to read "${JIANGYUMOD_FILE}", using "${folder}" as the mod folder instead: ${err}`);
  }
  folder = folder.replace(/[<>:"/\\|?*]/g, '_'); //a manifest name is not limited to valid folder characters

  const MOD_ATTRIBUTE = { //attribute for use in load order
    type: 'attribute',
    key: LO_ATTRIBUTE,
    value: folder,
  };

  //Files install at the mod root. The folder they deploy into is applied by the mod type's
  //mergeMods callback, which is what lets the load order page reorder them.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file.substr(idx),
    };
  });
  instructions.push(setModTypeInstruction);
  instructions.push(MOD_ATTRIBUTE);
  return Promise.resolve({ instructions });
}

//Test for ModpackLoader files. Two archive shapes install here: the standalone ModpackLoader package
//(the loader dll beside a "UserLibs" folder) and the Menace Mod Manager release, which carries the
//same loader bundled under MODKIT_LOADER_FOLDER.
function testModpackLoader(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === MODPACKLOADER_FILE));
  const hasUserLibs = files.some(file => (path.basename(file) === MODPACKLOADER_FOLDER));
  const loaderSuffix = `${path.sep}${MODKIT_LOADER_FOLDER.toLowerCase()}`;
  const isBundled = files.some(file => path.dirname(file).toLowerCase().endsWith(loaderSuffix));
  let supported = (gameId === spec.game.id) && isMod && (hasUserLibs || isBundled);

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install ModpackLoader files
function installModpackLoader(files) {
  const MOD_TYPE = MODPACKLOADER_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  //Menace Mod Manager archive: take only the bundled loader, dropping the ~120 MB manager app and
  //everything else. The loader assembly goes to "Mods" and its dependencies to "UserLibs" - the
  //paths the game loads them from, which is not how the archive stores them. Same split that
  //installModkit does for the ModKit archive.
  const loaderSuffix = `${path.sep}${MODKIT_LOADER_FOLDER.toLowerCase()}`;
  const bundleFiles = files.filter(file =>
    (!file.endsWith(path.sep)) && (path.dirname(file).toLowerCase().endsWith(loaderSuffix)));
  if (bundleFiles.length > 0) {
    const instructions = bundleFiles.map(file => {
      const fileName = path.basename(file);
      const destFolder = (fileName.toLowerCase() === MODPACKLOADER_FILE.toLowerCase())
        ? MELON_MODS_PATH
        : MODPACKLOADER_FOLDER;
      return { type: 'copy', source: file, destination: path.join(destFolder, fileName) };
    });
    instructions.push(setModTypeInstruction);
    return Promise.resolve({ instructions });
  }

  //Standalone ModpackLoader package: copy it through as authored, anchored on its "UserLibs" folder.
  const modFile = files.find(file => (path.basename(file) === MODPACKLOADER_FOLDER));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Custom Mod Loader files
function testCustomLoader(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === CUSTOMLOADER_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Custom Mod Loader files
function installCustomLoader(files) {
  const MOD_TYPE = CUSTOMLOADER_ID;
  const modFile = files.find(file => (path.basename(file) === CUSTOMLOADER_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

if (customLoaderInstaller) {
  //Test for Custom Mod Loader files (installer exe)
  function testCustomLoader(files, gameId) {
    const isMod = files.some(file => (path.basename(file) === CUSTOMLOADER_EXEC));
    let supported = (gameId === spec.game.id) && isMod;

    // Test for a mod installer.
    if (supported && files.find(file =>
        (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
        (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
      supported = false;
    }

    return Promise.resolve({
        supported,
        requiredFiles: [],
    });
  }
  //Install Custom Mod Loader files (installer exe)
  function installCustomLoader(files) {
    const MOD_TYPE = CUSTOMLOADER_ID;
    const modFile = files.find(file => (path.basename(file) === CUSTOMLOADER_EXEC));
    const idx = modFile.indexOf(path.basename(modFile));
    const rootPath = path.dirname(modFile);
    const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

    // Remove directories and anything that isn't in the rootPath.
    const filtered = files.filter(file => (
      (file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep))
    ));
    const instructions = filtered.map(file => {
      return {
        type: 'copy',
        source: file,
        destination: path.join(CUSTOMLOADER_FOLDER, file.substr(idx)),
      };
    });
    instructions.push(setModTypeInstruction);
    return Promise.resolve({ instructions });
  }
}

//Test for BepinExConfigManager mod files
function testBepCfgMan(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === BEPCFGMAN_FILE));
  const isFolder = files.some(file => (path.basename(file).toLowerCase() === 'plugins'));
  let supported = (gameId === spec.game.id) && isMod && isFolder;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install BepinExConfigManager mod files
function installBepCfgMan(files) {
  const MOD_TYPE = BEPCFGMAN_ID;
  const modFile = files.find(file => (path.basename(file).toLowerCase() === 'plugins'));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for MelonPreferencesManager mod files
function testMelonPrefMan(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === MELONPREFMAN_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install MelonPreferencesManager mod files
function installMelonPrefMan(files) {
  const MOD_TYPE = MELONPREFMAN_ID;
  const modFile = files.find(file => (path.basename(file).toLowerCase() === MELONPREFMAN_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Assembly mod files
function testAssembly(files, gameId) {
  const isMod = files.some(file => ASSEMBLY_FILES.includes(path.basename(file)));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Assembly mod files
function installAssembly(files) {
  const MOD_TYPE = ASSEMBLY_ID;
  const modFile = files.find(file => ASSEMBLY_FILES.includes(path.basename(file)));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const isMod = files.some(file => ROOT_FOLDERS.includes(path.basename(file)));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
async function installRoot(files, workingDir) {
  const modFile = files.find(file => ROOT_FOLDERS.includes(path.basename(file)));
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`
  const idx = modFile.indexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: ROOT_ID };

  /*if (GAME_VERSION === ALT_VERSION) {
    try {
      await fs.statAsync(path.join(workingDir, modFile));
      if (path.basename(modFile) === DATA_FOLDER_DEFAULT) {
        await fs.renameAsync(path.join(workingDir, modFile), path.join(workingDir, rootPath, DATA_FOLDER_ALT));
      }
      const paths = await getAllFiles(workingDir);
      files = [...paths.map(p => p.replace(`${workingDir}${path.sep}`, ''))];
    } catch (err) {
      log('warn', `Failed to rename "${DATA_FOLDER_DEFAULT}" folder to "${DATA_FOLDER_ALT}" for root mod ${workingDir} (or "${DATA_FOLDER_DEFAULT}" folder is not present): ${err}`);
    }
  } //*/

  // Don't use rootPath filter since it removes files without extensions
  const filtered = files.filter(file =>
    ((!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer Test for assets files
function testAssets(files, gameId) {
  const isMod = files.some(file => ASSETS_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install assets files
function installAssets(files) {
  const modFile = files.find(file => ASSETS_EXTS.includes(path.extname(file).toLowerCase()));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: ASSETS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Assembly mod files
function testCustom(files, gameId) {
  const isMod = files.some(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
  const isString = files.some(file => (path.basename(file).toLowerCase().includes(CUSTOM_STRING)));
  let supported = (gameId === spec.game.id) && isMod && isString;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Assembly mod files
function installCustom(files) {
  const MOD_TYPE = CUSTOM_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };
  const modFile = files.find(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
  /*let modFile = files.find(file => (path.basename(file) === CUSTOM_FOLDER)); //check for folder and use to index if it's there.
  let folder  = '.';
  if (modFile === undefined) {
    modFile = files.find(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
    folder =  CUSTOM_FOLDER;
  } //*/
  const DATA_FILE = path.basename(modFile, '.custom.json');
  const idx = modFile.indexOf(DATA_FILE);
  const rootPath = path.dirname(modFile);
 
  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) 
    && (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file.substr(idx),
      //destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for ModpackLoader mod files
function testModpackMod(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === MODPACKMOD_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install ModpackLoader mod files
function installModpackMod(files, fileName) {
  const MOD_TYPE = MODPACKMOD_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };
  let modFile = files.find(file => path.basename(file).toLowerCase() === MODPACKMOD_FILE);
  let rootPath = path.dirname(modFile);
  //*
  let folder = path.basename(fileName).split('-')[0];
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== '.') {
    folder = ROOT_PATH;
    //modFile = rootPath; //make the folder the targeted modFile so we can grab any other folders also in its directory
    //rootPath = path.dirname(modFile);
    //const indexFolder = path.basename(modFile);
    //idx = modFile.indexOf(`${indexFolder}${path.sep}`);  //index on the folder with path separator
  } //*/
  const idx = modFile.indexOf(path.basename(modFile));
  const MOD_ATTRIBUTE = { //attribute for use in load order
    type: 'attribute',
    key: LO_ATTRIBUTE,
    value: folder,
  };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(folder, file.substr(idx)),
      //destination: file.substr(idx),
    };
  });
  instructions.push(setModTypeInstruction);
  instructions.push(MOD_ATTRIBUTE);
  return Promise.resolve({ instructions });
}

//Test for Custom Leaders mod files
function testCustomLeaders(files, gameId) {
  const isClone = files.some(file => (path.basename(file).toLowerCase().includes(CUSTOMLEADERS_STRING_CLONE)));
  const isReplace = files.some(file => (path.basename(file).toLowerCase().includes(CUSTOMLEADERS_STRING_REPL)));
  let supported = (gameId === spec.game.id) && ( isClone || isReplace );

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install Custom Leaders mod files
function installCustomLeaders(files, fileName) {
  const MOD_TYPE = CUSTOMLEADERS_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };
  let modFile = files.find(file => (path.basename(file).toLowerCase().includes(CUSTOMLEADERS_STRING_CLONE)));
  if (modFile === undefined) {
    modFile = files.find(file => (path.basename(file).toLowerCase().includes(CUSTOMLEADERS_STRING_REPL)));
  }
  let rootPath = path.dirname(modFile);
  //*
  let folder = path.basename(modFile).replace(CUSTOMLEADERS_STRING_CLONE, '');
  if (folder.includes('.json')) {
    folder = path.basename(modFile).replace(CUSTOMLEADERS_STRING_REPL, '');
  }
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== '.') {
    folder = '';
    modFile = rootPath; //make the folder the targeted modFile so we can grab any other folders also in its directory
    rootPath = path.dirname(modFile);
    //const indexFolder = path.basename(modFile);
    //idx = modFile.indexOf(`${indexFolder}${path.sep}`);  //index on the folder with path separator
  } //*/
  const idx = modFile.indexOf(path.basename(modFile));

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(folder, file.substr(idx)),
      //destination: file.substr(idx),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer Test for plugin files
function testPlugin(files, gameId) {
  const isMod = files.some(file => PLUGIN_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install plugin files
async function installPlugin(api, gameSpec, files, workingDir) {
  const modFile = files.find(file => PLUGIN_EXTS.includes(path.extname(file).toLowerCase()));
  let idx = modFile.indexOf(path.basename(modFile));
  let rootPath = path.dirname(modFile);
  let setModTypeInstruction = {};
  const MOD_NAME = path.basename(workingDir).replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*/gi, '');

  // logic to parse dll files to determine if they are Custom/Melon/BepInEx plugins
  let isBepinex = false;
  let isBepinexPatcher = false;
  let isMelon = false;
  let isMelonPlugin = false;
  let isCustom = false;
  let unknown = false;
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = isCustomInstalled(api, gameSpec);
  }

  // STEP 1 - Detect plugin types by reading DLL contents //////////////////////////////////////////

  await Promise.all(files.map(async file => {
    if (PLUGIN_EXTS.includes(path.extname(file).toLowerCase())) {
      try {
        const content = await fs.readFileAsync(path.join(workingDir, file), 'utf8');
        if (hasCustomLoader && content.includes(CUSTOM_PLUGIN_STRING)) {
          isCustom = true;
        } 
        else if (content.includes(BEP_STRING)) {
          isBepinex = true;
          isBepinexPatcher = false; //temporary, find reliable string to id patchers
          //isBepinexPatcher = !content.includes(BEP_PATCHER_STRING) && !files.find(file => path.extname(file).toLowerCase() = BEPINEX_PLUGINS_FOLDER);
        } 
        else if (content.includes(MEL_STRING)) {
          isMelon = true;
          isMelonPlugin = content.includes(MEL_PLUGIN_STRING);
        }
        else {
          unknown = true;
        }
      } catch (err) {
        api.showErrorNotification(`Failed to read plugin file "${file}" to determine which mod loader it requires. Plugin is likely corrupted.`, err, { allowReport: false });
      }
    }
  }));

  // STEP 2 - CANCEL/WARN INSTALL CONDITIONS //////////////////////////////////////////

  if (hasCustomLoader) {
    if (isCustom && ( bepinexInstalled || melonInstalled )) {
      const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
          bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has ${CUSTOMLOADER_NAME} plugins, but you have installed BepInEx or MelonLoader.[br][/br][br][/br]`
              + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
              + `${preventPluginInstall ? `The installation will be cancelled to avoid issues.[br][/br][br][/br]` : `The mod will not be loaded unless the correct mod loader is installed.[br][/br][br][/br]`}`
              + `Check the mod's page to see if there is a ${CUSTOMLOADER_NAME} version of the mod, or change your mod loader to MelonLoader.[br][/br][br][/br]`),
          options: { order: ['bbcode'], wrap: true },
      }, [
          { label: 'Ok' }
      ]);
      if (wrongLoader.action === 'Ok') {
        if (preventPluginInstall) {
          throw new util.UserCanceled();
        } else {
          //do nothing, proceed with install
        }
      }
    }
    if ((isBepinex || isMelon) && customInstalled) {
      const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
          bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has BepInEx/MelonLoader plugins, but you have installed ${CUSTOMLOADER_NAME}.[br][/br][br][/br]`
              + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
              + `Check the mod's page to see if there is a ${CUSTOMLOADER_NAME} version of the mod, or change your mod loader to BepInEx/MelonLoader.[br][/br][br][/br]`),
          options: { order: ['bbcode'], wrap: true },
      }, [
          { label: 'Ok' }
      ]);
      if (wrongLoader.action === 'Ok') {
        if (preventPluginInstall) {
          throw new util.UserCanceled();
        } else {
          //do nothing, proceed with install
        }
      }
    }
  }
  // If both BepInEx and MelonLoader plugins are detected, cancel install
  if (isBepinex && isMelon) {
    const mixedModHandling = await api.showDialog('error', 'Mixed Mod Detected', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has both BepInEx and MelonLoader plugins in the same archive.[br][/br][br][/br]`
            + `Mixed mods are not supported by the game extension and the mod author will need to repackage their mod.[br][/br][br][/br]`
            + `You can manually extract the correct plugin from the archive and install it to Vortex.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (mixedModHandling.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }
  //if BepInEx plugin is installed while using MelonLoader, cancel install
  if (isBepinex && melonInstalled) {
    const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has BepInEx plugins, but you have installed MelonLoader.[br][/br][br][/br]`
            + `The installation will be cancelled to avoid issues.[br][/br][br][/br]`
            + `Check the mod's page to see if there is a MelonLoader version of the mod, or change your mod loader to BepInEx.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (wrongLoader.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }
  //if MelonLoader plugin is installed while using BepInEx, cancel install
  if (isMelon && bepinexInstalled) {
    const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has MelonLoader plugins, but you have installed BepInEx.[br][/br][br][/br]`
            + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
            + `Check the mod's page to see if there is a BepInEx version of the mod, or change your mod loader to MelonLoader.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (wrongLoader.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }

  // STEP 3 - INSTALL THE PLUGINS //////////////////////////////////////////

  // Install method that attempts to index on folders, then dll files
  if (hasCustomLoader) {
    if (isCustom) {
      setModTypeInstruction = { type: 'setmodtype', value: CUSTOMLOADER_MOD_ID };
      const folder = files.find(file => CUSTOMLOADER_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
      if (folder !== undefined) {
        idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
        rootPath = path.dirname(folder);
      }
      if (folder === undefined) {
        setModTypeInstruction = { type: 'setmodtype', value: CUSTOMLOADER_PLUGIN_ID };
      }
    }
  }

  if (isBepinex && !isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_MOD_ID };
    const folder = files.find(file => BEPINEX_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    }
    if (folder === undefined) {
      setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PLUGINS_ID };
    }
  }

  if (isBepinex && isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_MOD_ID };
    const folder = files.find(file => BEPINEX_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    }
    if (folder === undefined) {
      setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PATCHERS_ID };
    }
  }

  if (isMelon && !isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MOD_ID };
    const folder = files.find(file => MELON_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    }
    if (folder === undefined) {
      setModTypeInstruction = { type: 'setmodtype', value: MELON_MODS_ID };
    }
  }

  if (isMelon && isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MOD_ID };
    const folder = files.find(file => MELON_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    }
    if (folder === undefined) {
      setModTypeInstruction = { type: 'setmodtype', value: MELON_PLUGINS_ID };
    }
  } //*/

  /* NORMAL INSTALL - Assign mod types
  if (isBepinex && !isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PLUGINS_ID };
  }
  if (isBepinex && isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PATCHERS_ID };
  }
  if (isMelon && !isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MODS_ID };
  }
  if (isMelon && isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_PLUGINS_ID };
  } //*/

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Fallback installer to root folder
function testFallback(files, gameId) {
  let supported = (gameId === spec.game.id);

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to root folder
function installFallback(api, files, destinationPath) {
  fallbackInstallerNotify(api, destinationPath);
  
  const filtered = files.filter(file =>
    (!file.endsWith(path.sep))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file,
    };
  });
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  const NOTIF_ID = `${GAME_ID}-fallbackinstaller`;
  modName = path.basename(modName, '.installing');
  const MESSAGE = 'Fallback installer reached for ' + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'info',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `The mod you just installed reached the fallback installer. This means Vortex could not determine where to place these mod files.\n`
                + `Please check the mod page description and review the files in the mod staging folder to determine if manual file manipulation is required.\n`
                + `\n`
                + `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n`
                + `\n`
                + `Mod Name: ${modName}.\n`
                + `\n`             
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Contact Ext. Developer', action: () => {
                util.opn(`${EXTENSION_URL}?tab=posts`).catch(() => null);
                dismiss();
              }
            }, //*/
            {
              label: 'Open Staging Folder', action: () => {
                util.opn(path.join(STAGING_FOLDER, modName)).catch(() => null);
                dismiss();
              }
            }, //*/
            //*
            { label: `Open Mod Page`, action: () => {
              const mods = util.getSafe(api.store.getState(), ['persistent', 'mods', spec.game.id], {});
              const modMatch = Object.values(mods).find(mod => mod.installationPath === modName);
              log('warn', `Found ${modMatch?.id} for ${modName}`);
              let PAGE = ``;
              if (modMatch) {
                const MOD_ID = modMatch.attributes.modId;
                if (MOD_ID !== undefined) {
                  PAGE = `${MOD_ID}?tab=description`; 
                }
              }
              const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
              util.opn(MOD_PAGE_URL).catch(err => undefined);
              //dismiss();
            }}, //*/
          ]);
        },
      },
    ],
  });
}

// LOAD ORDER FUNCTIONS /////////////////////////////////////////////////////////

function getIndex(number) {
  if (number === 10) {
    return 1;
  }
  return ( (number - LO_INCREMENT) / 10 ) + 1;
}

//Matches only a complete load order prefix, so a mod folder that merely starts with digits is left
//alone.
const LO_PREFIX_REGEX = new RegExp(`^(?:[0-9]{${LO_PREFIX_PAD}}|${LO_UNSORTED_PREFIX})-`);

//The folder name without its load order prefix. Load order entries are identified by this, so an
//entry keeps the same id when the mod is moved to a different position.
function stripLoadOrderPrefix(folder) {
  return folder.replace(LO_PREFIX_REGEX, '');
}

//Folder a Jiangyu mod deploys into, before the load order prefix is added. The installer records it
//as an attribute; the mod id is a fallback for anything installed without one.
function modFolderName(mod) {
  const folder = util.getSafe(mod, ['attributes', LO_ATTRIBUTE], '');
  return ((typeof folder === 'string') && (folder !== '')) ? folder : mod.id;
}

//Position of a mod folder in the load order, on one scale for both loaders: a Jiangyu mod carries
//it in its folder prefix, a ModpackLoader mod inside its own modpack.json. Returns undefined for a
//folder belonging to neither loader, which the load order page does not list.
async function readLoadOrderPosition(modFolderPath, folder) {
  if (await statCheckAsync(path.join(modFolderPath, folder), JIANGYUMOD_FILE)) {
    const prefix = folder.match(LO_PREFIX_REGEX);
    if (prefix === null) { //installed by hand, or deployed before this extension sorted them
      return LO_UNSORTED_POS;
    }
    const pos = Number.parseInt(prefix[0], 10);
    return Number.isNaN(pos) ? LO_UNSORTED_POS : pos + 1; //prefixes count from 0, positions from 1
  }
  if (await statCheckAsync(path.join(modFolderPath, folder), MODPACKMOD_FILE)) {
    const filePath = path.join(modFolderPath, folder, MODPACKMOD_FILE);
    let number;
    try {
      number = JSON.parse(await fs.readFileAsync(filePath, 'utf8'))[LO_JSON_KEY];
    } catch (err) {
      log('error', `Failed to read load order file ${filePath}: ${err}`);
      return LO_UNSORTED_POS;
    }
    if (number === undefined) { //if loadOrder is undefined, put it at the end
      log('warn', `Mod "${folder}" ${LO_JSON_KEY} is undefined. Placing it last.`);
      return LO_UNSORTED_POS;
    }
    return getIndex(number);
  }
  return undefined;
}

//Reordering is ignored while a mod update is in flight: the deserializers below freeze the stored
//order and the serializers skip writing, so tell the user their change was not applied.
function notifyLoadOrderPaused(api, gameId) {
  api.sendNotification({
    id: `${gameId}-loadorder-update-paused`,
    type: 'warning',
    message: 'Load order changes are paused while a mod update finishes. Reorder again once it completes.',
    displayMS: 6000,
  });
}

async function deserializeLoadOrder(context) {
  //* on mod update for all profile it would cause the mod if it was selected to be unselected
  if (mod_update_all_profile) {
    //A mod update briefly removes and reinstalls mods, so rebuilding the order from disk right now
    //would drop their entries. Return the stored order untouched instead: positions are preserved
    //and the page keeps showing the real load order rather than a placeholder row.
    const updateState = context.api.getState();
    const updateProfileId = selectors.lastActiveProfileForGame(updateState, GAME_ID);
    return util.getSafe(updateState, ['persistent', 'loadOrder', updateProfileId], []);
  } //*/

  //Set basic information for load order paths and data
  const mods = util.getSafe(context.api.store.getState(), ['persistent', 'mods', spec.game.id], {});
  GAME_PATH = getDiscoveryPath(context.api);
  if (GAME_PATH === undefined) {
    return [];
  }
  const modFolderPath = path.join(GAME_PATH, MODPACKMOD_PATH);

  //Seed lock state from the stored load order. Neither loader's manifest has a lock field, so
  //without this a locked entry would silently unlock on the next deploy or page mount.
  const prevState = context.api.getState();
  const prevLO = util.getSafe(prevState, ['persistent', 'loadOrder', selectors.lastActiveProfileForGame(prevState, GAME_ID)], []);
  const prevById = new Map((Array.isArray(prevLO) ? prevLO : []).map((entry) => [entry.id, entry]));

  //Get all mod folders from MelonLoader "Mods" folder
  let modFolders = [];
  try {
    await fs.ensureDirWritableAsync(modFolderPath); //may not exist yet on a fresh install
    modFolders = await fs.readdirAsync(modFolderPath);
    modFolders = modFolders.filter((file) => isDir(modFolderPath, file));
    modFolders = modFolders.filter((file) => (file.toLowerCase() !== CUSTOMLEADERS_FOLDER.toLowerCase()));
    modFolders = modFolders.sort((a,b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  } catch (err) {
    if (err.code !== 'ENOENT') {
      log('warn', `Could not read the "Mods" folder: ${err}`);
    }
    return [];
  }

  //One entry per folder holding either loader's manifest. "folder" is the folder as it is on disk,
  //which for a Jiangyu mod carries the load order prefix, while "id" is that name without it.
  const entries = [];
  for (const folder of modFolders) {
    const pos = await readLoadOrderPosition(modFolderPath, folder);
    if (pos === undefined) { //not a mod for either loader
      continue;
    }
    entries.push({ pos, folder, id: stripLoadOrderPrefix(folder) });
  }
  entries.sort((lhs, rhs) => (lhs.pos - rhs.pos) || lhs.id.toLowerCase().localeCompare(rhs.id.toLowerCase()));

  //Determine if mod is managed by Vortex - keyed on the folder as deployed, prefix included
  const isVortexManaged = async (folder) => {
    return fs.statAsync(path.join(modFolderPath, folder, `__folder_managed_by_vortex`))
      .then(() => true)
      .catch(() => false)
  };

  // Get readable mod name using attribute from mod installer
  function getModName(id) {
    try {//Mod installed by Vortex, find mod where atrribute (from installer) matches folder in the load order
      const modMatch = Object.values(mods).find(mod => (util.getSafe(mods[mod.id]?.attributes, [LO_ATTRIBUTE], '') === id));
      if (modMatch) {
        return modMatch.attributes.customFileName ?? modMatch.attributes.logicalFileName ?? modMatch.attributes.name;
      }
      return id;
    } catch {
      return id;
    }
  }

  // Get Vortex mod id using attribute from mod installer
  function getModId(id) {
    try {//find mod where atrribute (from installer) matches file in the load order
      const modMatch = Object.values(mods).find(mod => (util.getSafe(mods[mod.id]?.attributes, [LO_ATTRIBUTE], '') === id)); //find mod by folder name attribute
      if (modMatch) {
        return modMatch.id;
      }
      return undefined;
    } catch {
      return undefined;
    }
  }

  //Set load order
  const loadOrder = [];
  for (const entry of entries) {
    const managed = await isVortexManaged(entry.folder);
    loadOrder.push({
      id: entry.id,
      name: managed ? getModName(entry.id) : 'Manual Mod',
      modId: managed ? getModId(entry.id) : undefined,
      enabled: true,
      locked: prevById.get(entry.id)?.locked ?? false,
    });
  }

  return loadOrder;
}

function setNumber(index) {
  if (index === 0) {
    return LO_INCREMENT;
  }
  return (index * 10) + LO_INCREMENT;
}

//entries: [{ filePath, position }] - position is the mod's index in the whole load order, so that
//both loaders' mods end up on the same scale and the page's order survives a round trip.
async function writeToFiles(entries) {
  for (const entry of entries) {
    let contents;
    try {
      await fs.statAsync(entry.filePath);
      contents = await fs.readFileAsync(entry.filePath, 'utf8');
    } catch (err) {
      log('error', `Failed to write load order file or it does not exist: ${entry.filePath}: ${err}`);
      continue;
    }
    const json = JSON.parse(contents);
    json[LO_JSON_KEY] = setNumber(entry.position);
    const loadOrderOutput = JSON.stringify(json, null, 2);
    await fs.writeFileAsync(
      entry.filePath,
      loadOrderOutput,
      { encoding: "utf8" },
  );
  }
}

//Write load order to files
async function serializeLoadOrder(context, loadOrder) {
  //* don't write if all profiles are being updated
  if (mod_update_all_profile) {
    notifyLoadOrderPaused(context.api, GAME_ID);
    return;
  } //*/
  GAME_PATH = getDiscoveryPath(context.api);
  if (GAME_PATH === undefined) {
    return;
  }
  const modFolderPath = path.join(GAME_PATH, MODPACKMOD_PATH);

  //Entry ids have no load order prefix, so map them back to the folders as they stand on disk -
  //those still carry whatever prefix the last deployment gave them.
  let modFolders = [];
  try {
    await fs.ensureDirWritableAsync(modFolderPath); //may not exist yet on a fresh install
    modFolders = (await fs.readdirAsync(modFolderPath)).filter((file) => isDir(modFolderPath, file));
  } catch (err) {
    if (err.code !== 'ENOENT') {
      log('error', `Failed to read "Mods" folder: ${err}`);
    }
    return;
  }
  const folderById = new Map(modFolders.map((folder) => [stripLoadOrderPrefix(folder).toLowerCase(), folder]));

  //Only ModpackLoader mods are written here. A Jiangyu mod has nowhere on disk to record its
  //position - it gets the numbered folder from mergeMods on the next deployment instead.
  const entries = [];
  for (let index = 0; index < loadOrder.length; index++) {
    const folder = folderById.get(String(loadOrder[index].id).toLowerCase());
    if (folder === undefined) {
      continue;
    }
    if (await statCheckAsync(path.join(modFolderPath, folder), MODPACKMOD_FILE)) {
      entries.push({ filePath: path.join(modFolderPath, folder, MODPACKMOD_FILE), position: index });
    }
  }
  //must write to each mod's json file
  await writeToFiles(entries);
  return;
}

//Numbered folder prefix that puts a Jiangyu mod's load order position onto disk. Zero-padded
//because the loader sorts mod folders lexically, where "10-" would otherwise come before "9-".
function loadOrderPrefix(api, mod) {
  const state = api.getState();
  const profile = selectors.lastActiveProfileForGame(state, GAME_ID);
  const loadOrder = util.getSafe(state, ['persistent', 'loadOrder', profile], []);
  //The load order is an array of entries, where "id" is the mod's folder name and "modId" is the
  //Vortex mod id - the latter is what identifies the mod being deployed here.
  const pos = Array.isArray(loadOrder)
    ? loadOrder.findIndex((entry) => (entry.modId === mod.id))
    : -1;
  if (pos === -1) { //not on the page yet - sorts last until the next deserialize picks it up
    return `${LO_UNSORTED_PREFIX}-`;
  }
  return `${String(pos).padStart(LO_PREFIX_PAD, '0')}-`;
}

//Absolute path of a load order entry's folder on disk. The entry id has the numbered prefix
//stripped; a Jiangyu mod's folder on disk still carries it while a ModpackLoader mod's does not,
//so match on the prefix-stripped name rather than joining the id directly. Returns undefined if
//the folder is not found (e.g. the mod is not deployed).
async function resolveModFolder(api, id) {
  const gamePath = getDiscoveryPath(api);
  if (gamePath === undefined) {
    return undefined;
  }
  const modFolderPath = path.join(gamePath, MODPACKMOD_PATH);
  try {
    const folders = await fs.readdirAsync(modFolderPath);
    const match = folders.find((folder) =>
      stripLoadOrderPrefix(folder).toLowerCase() === String(id).toLowerCase());
    return match !== undefined ? path.join(modFolderPath, match) : undefined;
  } catch {
    return undefined;
  }
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

async function relaunchExt(api) {
  return api.showDialog('info', 'Restart Required', {
    text: '\n'
        + 'The extension requires a restart to complete the Mod Loader setup.\n'
        + '\n'
        + 'The extension will purge mods and then exit - please re-activate the game via the Games page or Dashboard page.\n'
        + '\n'
        + 'IMPORTANT: You may see an External Changes dialogue. Select "Revert change (use staging file)".\n'
        + '\n',
  }, [ { label: 'Restart Extension' } ])
  .then(async () => {
    try {
      await purge(api);
      const batched = [
        actions.setDeploymentNecessary(GAME_ID, true),
        actions.setNextProfile(undefined),
      ];
      util.batchDispatch(api.store, batched);
    } catch (err) {
      api.showErrorNotification('Failed to set up Mod Loader', err, { allowReport: false });
    }
  });
}
//Function to choose mod loader
async function chooseModLoader(api, gameSpec) {
  await downloadMelon(api, gameSpec);
  /*
  const CUSTOM_LABEL = `${CUSTOMLOADER_NAME} (Recommended)`;
  let BEP_LABEL = `BepInEx`;
  if (recommendedLoader === 'bepinex') {
    BEP_LABEL = `${BEPINEX_NAME} (Recommended)`;
  }
  let MEL_LABEL = `MelonLoader`;
  if (recommendedLoader === 'melon') {
    MEL_LABEL = `${MELON_NAME} (Recommended)`;
  }
  const t = api.translate;
  let choices = [
    //{ label: t(BEP_LABEL) },
    { label: t(MEL_LABEL) },
  ];
  if (hasCustomLoader) {
    choices = [
      { label: t(CUSTOM_LABEL) },
      { label: t(BEP_LABEL) },
      { label: t(MEL_LABEL) },
    ];
  }
  const replace = {
    game: gameSpec.game.name,
    bl: '[br][/br][br][/br]',
  };
  return api.showDialog('info', 'Mod Loader Selection', {
    bbcode: t('You must choose a mod loader to install mods.{{bl}}'
      + 'Only one mod loader can be installed at a time.{{bl}}'
      + 'Make your choice based on which mods you would like to install and which loader they support.{{bl}}'
      + 'You can change which mod loader you have installed by Uninstalling the current one from Vortex, which will bring up this dialog again.{{bl}}'
      + 'Which mod loader would you like to use for {{game}}?',
      { replace }
    ),
  }, choices)
  .then(async (result) => {
    if (result === undefined) {
      return;
    }
    if (hasCustomLoader && (result.action === CUSTOM_LABEL)) {
      await downloadCustom(api, gameSpec);
    }
    if (result.action === BEP_LABEL) {
      await downloadBepinex(api, gameSpec);
    } else if (result.action === MEL_LABEL) {
      await downloadMelon(api, gameSpec);
    }
    if (hasCustomMods || loaderSwitchRestart) { //Run this if need to change a modType path based on the mod loader installed
      await deploy(api);
      relaunchExt(api);
    } 
  }); //*/
}
//Deconflict mod loaders
async function deconflictModLoaders(api, gameSpec) {
  const CUSTOM_LABEL = `${CUSTOMLOADER_NAME} (Recommended)`;
  const BEP_LABEL = `BepInEx`;
  const MEL_LABEL = `MelonLoader`;
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = checkCustomInstalled(api, gameSpec);
  }
  const t = api.translate;
  let choices = [
    { label: t(BEP_LABEL) },
    { label: t(MEL_LABEL) },
  ];
  if (hasCustomLoader) {
    choices = [
      { label: t(CUSTOM_LABEL) },
      { label: t(BEP_LABEL) },
      { label: t(MEL_LABEL) },
    ];
  }
  const replace = {
    game: gameSpec.game.name,
    bl: '[br][/br][br][/br]',
  };
  return api.showDialog('info', 'Mod Loader Conflict', {
    bbcode: t('You have more than one mod loader installed.{{bl}}'
      + 'This will cause the game to crash at launch. Only one mod loader can be installed at a time.{{bl}}'
      + 'You must choose which mod loader you would like to use for {{game}}.',
      { replace }
    ),
  }, choices)
  .then(async (result) => {
    if (result === undefined) {
      return;
    }
    if (hasCustomLoader && (result.action === CUSTOM_LABEL)) {
      if (melonInstalled) {
        await removeMelon(api, gameSpec);
      }
      if (bepinexInstalled) {
        await removeBepinex(api, gameSpec);
      }
    }
    if (result.action === BEP_LABEL) {
      if (melonInstalled) {
        await removeMelon(api, gameSpec);
      }
      if (hasCustomLoader && customInstalled) {
        await removeCustom(api, gameSpec);
      }
    } else if (result.action === MEL_LABEL) {
      if (bepinexInstalled) {
        await removeBepinex(api, gameSpec);
      }
      if (hasCustomLoader && customInstalled) {
        await removeCustom(api, gameSpec);
      }
    }
    if (hasCustomMods || loaderSwitchRestart) { //Run this if need to change a modType path based on the mod loader installed
      await deploy(api);
      relaunchExt(api);
    }
  });
}
async function removeBepinex(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === BEPINEX_ID);
  const modId = mods[mod].id
  log('warn', `Found BepInEx mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
  } catch (err) {
    api.showErrorNotification('Failed to remove BepInEx', err, { allowReport: false });
  }
}
async function removeMelon(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === MELON_ID);
  const modId = mods[mod].id
  log('warn', `Found MelonLoader mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
  } catch (err) {
    api.showErrorNotification('Failed to remove MelonLoader', err, { allowReport: false });
  }
}
async function removeCustom(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === CUSTOMLOADER_ID);
  const modId = mods[mod].id
  log('warn', `Found ${CUSTOMLOADER_NAME} mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
    if (customLoaderInstaller) { //remove files from installer here if there are any
      await removeCustomFiles(api, gameSpec);
    }
  } catch (err) {
    api.showErrorNotification(`Failed to remove ${CUSTOMLOADER_NAME}`, err, { allowReport: false });
  }
}
async function removeCustomFiles(api, gameSpec) { //run on purge too
  GAME_PATH = getDiscoveryPath(api);
  let files = CUSTOMLOADER_FILES_ARRAY;
  log('warn', `Found ${CUSTOMLOADER_NAME} files to remove for deconfliction/purge: [${files.join(', ')}]`);
  await deleteFiles(GAME_PATH, files);
}
async function deleteFiles(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    try {
      await fs.unlinkAsync(path.join(gamePath, relPaths[index]));
    } catch (err) {
      log('warn', `Failed to remove ${path.join(gamePath, relPaths[index])}: ${err}`);
    }
  }
}

async function resolveGameVersion(gamePath) {
  GAME_VERSION = await setGameVersion(gamePath);
  VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
  let version = '0.0.0';
  if (GAME_VERSION === 'xbox') { // use appxmanifest.xml for Xbox version
    try {
      const appManifest = await fs.readFileAsync(path.join(gamePath, APPMANIFEST_FILE), 'utf8');
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log('error', `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  } 
  else { // use exe
    try {
      const exeVersion = require('exe-version');
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC));
      return Promise.resolve(version); 
    } catch (err) {
      log('error', `Could not read ${EXEC} file to get game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  /*else {
    const versionFilepath = path.join(gamePath, VERSION_FILE_PATH);
    try {
      const data = await fs.readFileAsync(versionFilepath, { encoding: 'utf8' });
      const segments = data.split('\n');
      return (segments[3]) 
        ? Promise.resolve(segments[3])
        : Promise.reject(new util.DataInvalid('Failed to resolve version'));
    } catch (err) {
      return Promise.reject(err);
    }
  } //*/
} //*/

//Notify User to ask if they want to download BepInExConfigManager
async function downloadBepCfgManNotify(api) {
  let isInstalled = isBepCfgManInstalled(api, spec);
  if (!isInstalled) {
    const NOTIF_ID = `${GAME_ID}-bepcfgman`;
    const MOD_NAME = BEPCFGMAN_NAME;
    const MESSAGE = `Would you like to download ${MOD_NAME}?`;
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      message: MESSAGE,
      allowSuppress: true,
      actions: [
        {
          title: 'Download BepCfgMan',
          action: (dismiss) => {
            downloadBepCfgMan(api, spec);
            dismiss();
          },
        },
        {
          title: 'More',
          action: (dismiss) => {
            api.showDialog('question', MESSAGE, {
              text: `${MOD_NAME} is a mod that allows you to configure BepInEx mods with and in-game GUI.\n`
                  + `Click the button below to download and install ${BEPCFGMAN_NAME}.\n`
                  + `Once installed, the default key to show the configuration menu is F5.\n`
            }, [
                {
                  label: `Download ${MOD_NAME}`, action: () => {
                    downloadBepCfgMan(api, spec);
                    dismiss();
                  }
                },
                { label: 'Not Now', action: () => dismiss() },
                {
                  label: 'Never Show Again', action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  }
                },
              ]);
          },
        },
      ],
    });  
  }
}

//Notify User to ask if they want to download MelonPreferencesManager
async function downloadMelonPrefManNotify(api) {
  let isInstalled = isMelonPrefManInstalled(api, spec);
  if (!isInstalled) {
    const NOTIF_ID = `${GAME_ID}-melonprefman`;
    const MOD_NAME = MELONPREFMAN_NAME;
    const MESSAGE = `Would you like to download ${MOD_NAME}?`;
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      message: MESSAGE,
      allowSuppress: true,
      actions: [
        {
          title: 'Download MelPrefMan',
          action: (dismiss) => {
            downloadMelonPrefMan(api, spec);
            dismiss();
          },
        },
        {
          title: 'More',
          action: (dismiss) => {
            api.showDialog('question', MESSAGE, {
              text: `${MOD_NAME} is a mod that allows you to configure BepInEx mods with and in-game GUI.\n`
                  + `Click the button below to download and install ${BEPCFGMAN_NAME}.\n`
                  + `Once installed, the default key to show the configuration menu is F5.\n`
                  + '\n'
                  + `Note that due to the way the file is packaged on GitHub, you will see a popup asking if you want to create a new mod with the file.\n`
                  + `Select the "Create Mod" option.\n`
            }, [
                {
                  label: `Download ${MOD_NAME}`, action: () => {
                    downloadMelonPrefMan(api, spec);
                    dismiss();
                  }
                },
                { label: 'Not Now', action: () => dismiss() },
                {
                  label: 'Never Show Again', action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  }
                },
              ]);
          },
        },
      ],
    });  
  }
}

async function modFoldersEnsureWritable(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    await fs.ensureDirWritableAsync(path.join(gamePath, relPaths[index]));
  }
}

function dotNetMelonNotify(api) {
  const NOTIF_ID = `${GAME_ID}-dotnetmelon-notify`;
  const MESSAGE = `.NET ${MELON_DOTNET_VER} Required`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Download .NET ${MELON_DOTNET_VER}`,
        action: (dismiss) => {
          util.opn(MELON_DOTNET_URL).catch(() => null);
          dismiss();
        }
      },
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `MelonLoader requires .NET ${MELON_DOTNET_VER} to be installed on your system for IL2CPP build Unity games, like this game.\n`
                + `\n`
                + `Please install .NET ${MELON_DOTNET_VER} so that MelonLoader can function. Your game may crash at launch if the correct version of .NET is not installed.\n`
                + `\n`
          }, [
            { label: `Download .NET ${MELON_DOTNET_VER}`, action: () => {
              util.opn(MELON_DOTNET_URL).catch(() => null);
              dismiss();
            }},
            { label: 'Not Now', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

function dotNetModpackNotify(api) {
  const NOTIF_ID = `${GAME_ID}-dotnetmodpack-notify`;
  const MESSAGE = `.NET ${MPL_DOTNET_VER} Required`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Download .NET ${MPL_DOTNET_VER}`,
        action: (dismiss) => {
          util.opn(MPL_DOTNET_URL).catch(() => null);
          dismiss();
        }
      },
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `The MENACE ModPackLoader requires .NET ${MPL_DOTNET_VER} to be installed on your system.\n`
                + `\n`
                + `Please install .NET ${MPL_DOTNET_VER} so that ModpackLoader can function. Your game may crash at launch if the correct version of .NET is not installed.\n`
                + `\n`
          }, [
            { label: `Download .NET ${MPL_DOTNET_VER}`, action: () => {
              util.opn(MPL_DOTNET_URL).catch(() => null);
              dismiss();
            }},
            { label: 'Not Now', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

async function checkDotNetMelon(api) {
  const version = MELON_DOTNET_VER;
  let values = undefined;
  try {
    const buffer = winapi.WithRegOpen( //array of objects with values.type and values.key
      DOTNET_REG_HIVE,
      DOTNET_REG_KEY,
      (hkey) => {
        values = winapi.RegEnumValues(hkey); //array of objects with values.type and values.key
      }
    );
    if (!values) {
      dotNetMelonNotify(api); //assume not installed if key not found
    }
    values = values.map(value => value.key); //map array to only keys
    const found = values.some(value => value.startsWith(version)); //find entry starting with correct version number
    if (found) {
      //log('warn', `Found .NET ${version} installation`);
    } else {
      dotNetMelonNotify(api); //assume not installed if key not found
    }
  } catch (err) { //*/
    log('warn', `Failed to read .NET registry key: ${err}`);
    dotNetMelonNotify(api)
  }
}

async function checkDotNetModpack(api) {
  const version = MPL_DOTNET_VER;
  let values = undefined;
  try {
    const buffer = winapi.WithRegOpen( //array of objects with values.type and values.key
      DOTNET_REG_HIVE,
      DOTNET_REG_KEY,
      (hkey) => {
        values = winapi.RegEnumValues(hkey); //array of objects with values.type and values.key
      }
    );
    if (!values) {
      dotNetModpackNotify(api); //assume not installed if key not found
    }
    values = values.map(value => value.key); //map array to only keys
    const found = values.some(value => value.startsWith(version)); //find entry starting with correct version number
    if (found) {
      //log('warn', `Found .NET ${version} installation`);
    } else {
      dotNetModpackNotify(api); //assume not installed if key not found
    }
  } catch (err) { //*/
    log('warn', `Failed to read .NET registry key: ${err}`);
    dotNetModpackNotify(api)
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  //SYNC CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = isCustomInstalled(api, spec);
  }
  // ASYNC CODE ///////////////////////////////////
  if (multiExe) {
    GAME_VERSION = await setGameVersion(GAME_PATH);
  }
  MODTYPE_FOLDERS.push(ASSEMBLY_PATH);
  MODTYPE_FOLDERS.push(ASSETS_PATH);
  await modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
  //REQUIRED while the legacy directCopyPath pointer is present: JIANGYU_REQUIREMENTS is built at
  //module load, when GAME_PATH is still '', so the baked-in path is relative and would never
  //resolve - the old loose copy would then never be cleaned up. setup() runs on every
  //gamemode-activated, so this reassignment precedes every path that reads the field.
  JIANGYU_REQUIREMENTS[0].directCopyPath = path.join(GAME_PATH, JIANGYU_PATH, JIANGYU_FILE);
  await downloadJiangyu(api, gameSpec);
  await downloadModpackLoader(api, gameSpec);
  if (!bepinexInstalled && !melonInstalled && !customInstalled) {
    await chooseModLoader(api, spec); //dialog to choose mod loader
  }
  if ( (bepinexInstalled && melonInstalled) || (bepinexInstalled && customInstalled) || (melonInstalled && customInstalled)) {
    await deconflictModLoaders(api, spec); //deconflict if multiple mod loaders are installed
  } //*/
  if (bepinexInstalled && allowBepCfgMan) {
    downloadBepCfgManNotify(api, gameSpec); //notification to download BepInExConfigManager
  } //*/
  if (melonInstalled && allowMelPrefMan) {
    downloadMelonPrefManNotify(api, gameSpec); //notification to download MelonPreferencesManager
  } //*/
  //Jiangyu needs .NET 6 too, so it shares MelonLoader's check rather than getting one of its own
  if (isMelonInstalled(api, gameSpec) || isJiangyuInstalled(api, gameSpec)) {
    checkDotNetMelon(api);
  }
  if (isModpackLoaderInstalled(api, gameSpec)) { //.NET 10 is a ModpackLoader requirement only
    checkDotNetModpack(api);
  }
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  const game = { //register game
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersion,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //register mod types explicitly
  //Jiangyu has no load order field of its own and loads mods in folder-name order, so the load
  //order position is written as a numbered folder here, at deploy time. Registered explicitly
  //rather than through the loop above because that loop cannot carry a mergeMods callback.
  context.registerModType(JIANGYUMOD_ID, 29,
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    },
    (game) => pathPattern(context.api, game, path.join('{gamePath}', JIANGYUMOD_PATH)),
    () => Promise.resolve(false),
    { name: JIANGYUMOD_NAME,
      mergeMods: (mod) => {
        if (enableLoadOrder) {
          return loadOrderPrefix(context.api, mod) + modFolderName(mod);
        } else { //If load order is disabled, don't use sorting folders
          return modFolderName(mod);
        }
      }
    }
  ); //*/
  if (hasCustomMods) {
    context.registerModType(CUSTOM_ID, 58, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => getCustomFolder(context.api, game),
      () => Promise.resolve(false), 
      { name: CUSTOM_NAME }
    ); //*/
    //add more if needed
  }
  if (hasCustomLoader) {
    context.registerModType(CUSTOMLOADER_MOD_ID, 25, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}', CUSTOMLOADER_MOD_PATH)),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_PLUGIN_NAME }
    ); //*/
    context.registerModType(CUSTOMLOADER_PLUGIN_ID, 27, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}', CUSTOMLOADER_PLUGIN_PATH)),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_MOD_NAME }
    ); //*/
    context.registerModType(CUSTOMLOADER_ID, 60, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}')),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_NAME }
    ); //*/
  }

  //register mod types explicitly (due to potentially dynamic DATA_FOLDER)
  context.registerModType(ASSEMBLY_ID, 60, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, 
    (game) => pathPattern(context.api, game, path.join('{gamePath}', ASSEMBLY_PATH)), 
    () => Promise.resolve(false), 
    { name: ASSEMBLY_NAME }
  );
  context.registerModType(ASSETS_ID, 62, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, 
    (game) => pathPattern(context.api, game, path.join('{gamePath}', ASSETS_PATH)), 
    () => Promise.resolve(false), 
    { name: ASSETS_NAME }
  );

  //register mod installers
  if (hasCustomLoader) {
    context.registerInstaller(CUSTOMLOADER_ID, 25, testCustomLoader, installCustomLoader);
  }
  context.registerInstaller(MELON_ID, 26, testMelon, installMelon);
  context.registerInstaller(BEPINEX_ID, 27, testBepinex, installBepinex);
  context.registerInstaller(MODKIT_ID, 28, testModkit, installModkit);
  //both Jiangyu installers sit above the generic .dll plugin installer, which would otherwise claim
  //the loader, and above the ModpackLoader pair so a mod carrying both manifests loads with Jiangyu
  context.registerInstaller(JIANGYU_ID, 29, testJiangyu, installJiangyu);
  context.registerInstaller(JIANGYUMOD_ID, 30, testJiangyuMod, installJiangyuMod);
  context.registerInstaller(MODPACKLOADER_ID, 31, testModpackLoader, installModpackLoader);
  context.registerInstaller(MODPACKMOD_ID, 32, testModpackMod, installModpackMod);
  context.registerInstaller(ROOT_ID, 33, testRoot, installRoot);
  context.registerInstaller(BEPCFGMAN_ID, 34, testBepCfgMan, installBepCfgMan);
  context.registerInstaller(MELONPREFMAN_ID, 35, testMelonPrefMan, installMelonPrefMan);
  context.registerInstaller(ASSEMBLY_ID, 36, testAssembly, installAssembly);
  context.registerInstaller(`${GAME_ID}-plugin`, 37, testPlugin, (files, workingDir) => installPlugin(context.api, gameSpec, files, workingDir));
  context.registerInstaller(CUSTOMLEADERS_ID, 38, testCustomLeaders, installCustomLeaders);
  context.registerInstaller(ASSETS_ID, 39, testAssets, installAssets);
  if (hasCustomMods) {
    context.registerInstaller(CUSTOM_ID, 45, testCustom, installCustom);
  }
  if (fallbackInstaller) {
    context.registerInstaller(`${GAME_ID}-fallback`, 49, testFallback, (files, destinationPath) => installFallback(context.api, files, destinationPath));
  }
  
  //register actions
  context.registerAction('mod-icons', 300, 'open-ext', {}, `Download ${MODKIT_NAME}`, () => {
    downloadModkit(context.api, spec);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Data Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, DATA_FOLDER);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', async () => {
    //SAVE_PATH = await getSavePath(context.api);
    util.opn(SAVE_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open BepInEx Config', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, BEP_CONFIG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open BepInEx Log', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, BEP_LOG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download BepInExConfigManager', async () => {
    await downloadBepCfgMan(context.api, spec);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open MelonLoader Config', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, MEL_CONFIG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open MelonLoader Log', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, MEL_LOG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  /*
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download MelonPreferencesManager', async () => {
    await downloadMelonPrefMan(context.api, spec);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    const openPath = path.join(__dirname, 'CHANGELOG.md');
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    util.opn(CONFIG_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
}

//main function
function main(context) {
  applyGame(context, spec);
  if (enableLoadOrder) { //ModpackLaoder mods load order
    context.registerLoadOrder({
      gameId: GAME_ID,
      validate: async () => Promise.resolve(undefined), // no validation implemented yet
      deserializeLoadOrder: async () => await deserializeLoadOrder(context),
      serializeLoadOrder: async (loadOrder) => await serializeLoadOrder(context, loadOrder),
      toggleableEntries: false,
      usageInstructions: LoadOrderInstructions,
      customItemRenderer: LoadOrderItemRenderer,
    });
  }

  context.once(() => { // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    api.onAsync('did-deploy', async (profileId, deployment) => { 
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== LAST_ACTIVE_PROFILE) return;
      //release tracking one mod id at a time, and only once that mod's new version has
      //landed and is enabled, so a deploy that fires mid-batch can't disarm the guard for
      //mods that haven't been reinstalled yet
      //guard state as it stood before the loop below releases it - the FBLO refresh further
      //down only runs on the deploy that actually clears the guard
      const guardWasArmed = mod_update_all_profile;
      if (updateModIds.size > 0) {
        const state = api.getState();
        const profile = selectors.profileById(state, profileId);
        const mods = util.getSafe(state, ["persistent", "mods", GAME_ID], {});
        const now = Date.now();
        for (const [nexusId, { firstSeen, targetFileId }] of Array.from(updateModIds)) {
          const landed = Object.values(mods).some((mod) =>
            String(mod?.attributes?.modId ?? '') === nexusId &&
            //if the target file is unknown, fall back to "installed and enabled"
            (targetFileId === '' || String(mod?.attributes?.fileId ?? '') === targetFileId) &&
            util.getSafe(profile, ["modState", mod.id, "enabled"], false)
          );
          if (landed) {
            updateModIds.delete(nexusId);
          } else if (now - firstSeen > MAX_UPDATE_WAIT_MS) {
            log('warn', `[${GAME_ID}] Mod update tracking for Nexus mod ${nexusId} timed out without landing; releasing load order guard for it.`);
            updateModIds.delete(nexusId);
          }
        }
      }
      mod_update_all_profile = updateModIds.size > 0; //stay armed while any update is still outstanding
      //Core FBLO deserialized this order concurrently with this handler - did-deploy listeners run
      //in parallel and the core one is registered first - so it read the frozen order before the
      //guard cleared above, leaving its page stale. Re-run the deserialize it would have got and
      //push the result into state; cheaper and less disruptive than forcing a second deployment.
      if (guardWasArmed && !mod_update_all_profile) {
        try {
          const refreshedLO = await deserializeLoadOrder({ api: context.api });
          context.api.store.dispatch(actions.setFBLoadOrder(profileId, refreshedLO));
        } catch (err) {
          log('warn', `[${GAME_ID}] post-update load order refresh failed`, err);
        }
      }
      updating_mod = false; //reset updating flag on deploy
      bepinexInstalled = isBepinexInstalled(api, spec);
      melonInstalled = isMelonInstalled(api, spec);
      if (hasCustomLoader) {
        customInstalled = isCustomInstalled(api, spec);
      }
      if (!bepinexInstalled && !melonInstalled && !customInstalled) {
        await chooseModLoader(api, spec); //dialog to choose mod loader
      }
      if ( (bepinexInstalled && melonInstalled) || (bepinexInstalled && customInstalled) || (melonInstalled && customInstalled)) {
        await deconflictModLoaders(api, spec); //deconflict if multiple mod loaders are installed
      } //*/
      if (bepinexInstalled && allowBepCfgMan) {
        downloadBepCfgMan(api, spec); //download BepInExConfigManager
      } //*/
      if (melonInstalled && allowMelPrefMan) {
        downloadMelonPrefMan(api, spec); //download MelonPreferencesManager
      } //*/
      if (hasCustomLoader && customLoaderInstaller && customInstalled) {
        checkCustomInstalled(api, spec); //check if user has run installer and notify if not
      }
      if ((isMelonInstalled(api, spec) || isJiangyuInstalled(api, spec)) && BEPINEX_BUILD === 'il2cpp') {
        checkDotNetMelon(api); //check for .NET 6 installation - Jiangyu requires it as well
      }
      return Promise.resolve();
    });
    api.onAsync('did-purge', async (profileId) => { 
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== LAST_ACTIVE_PROFILE) return;
      if (hasCustomLoader) {
        bepinexInstalled = isBepinexInstalled(api, spec);
        melonInstalled = isMelonInstalled(api, spec);
        customInstalled = checkCustomInstalled(api, spec); //file check
        if (customInstalled && customLoaderInstaller) {
          await removeCustomFiles(api, spec); //delete installed files to clean folder
        }
        //*
        customInstalled = isCustomInstalled(api, spec);
        if (!bepinexInstalled && !melonInstalled && !customInstalled) {
          await chooseModLoader(api, spec); //dialog to choose mod loader
        } //*/
      }
      return Promise.resolve();
    });
    //detect mod update (to maintain LO position)
    //fileId is the version being updated TO, and is what tells the new version apart from
    //the old one on deploy - without it every mod not yet updated still looks "already installed"
    api.events.on("mod-update", (gameId, modId, fileId) => {
      if (GAME_ID == gameId) {
        updateModIds.set(String(modId), { firstSeen: Date.now(), targetFileId: String(fileId ?? '') });
      }
    });
    //detect batch mod update: the "Update all" button emits mods-update with LOCAL mod ids
    //and never emits mod-update, so resolve each one to its Nexus mod id before tracking it
    api.events.on("mods-update", (gameId, modIds) => {
      if (GAME_ID !== gameId) return;
      const mods = util.getSafe(api.getState(), ["persistent", "mods", GAME_ID], {});
      for (const modId of modIds ?? []) {
        const nexusModId = mods[modId]?.attributes?.modId;
        if (nexusModId !== undefined) {
          updateModIds.set(String(nexusModId), {
            firstSeen: Date.now(),
            targetFileId: String(mods[modId]?.attributes?.newestFileId ?? ''),
          });
        }
      }
    });
    //detect mod removal (to maintain LO position) - match on the Nexus mod id
    //recorded in state (attributes.modId), not the local modId string: the
    //local id's naming convention varies by when the mod was originally
    //downloaded (older dash-delimited vs current space-delimited), so string
    //parsing silently misses old installs.
    api.events.on("remove-mod", (gameMode, modId) => {
      const removedMod = util.getSafe(api.getState(), ["persistent", "mods", GAME_ID, modId], undefined);
      const nexusModId = removedMod?.attributes?.modId;
      if (nexusModId !== undefined && updateModIds.has(String(nexusModId))) {
        mod_update_all_profile = true;
      }
    });
    //detect mod installation (to maintain LO position). This only gates the
    //fallback-installer re-notify suppression, so a best-effort filename
    //match (covering both the old dash and current space delimiter) is fine.
    api.events.on("will-install-mod", (gameId, archiveId, modId) => {
      mod_install_name = modId.split("-")[0];
      updating_mod = GAME_ID == gameId && Array.from(updateModIds.keys()).some((id) =>
        modId.includes("-" + id + "-") || modId.includes(" " + id + " ")
      );
    }); //*/
  });
  return true;
}

// Test if BepInEx is installed
function isBepinexInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === BEPINEX_ID);
}

// Test if MelonLoader is installed
function isMelonInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === MELON_ID);
}

// Test if ModpackLoader is installed. It now arrives bundled inside the ModKit rather than as a mod
// of its own, so the file on disk counts as well as a mod carrying its type.
function isModpackLoaderInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  if (Object.keys(mods).some(id => mods[id]?.type === MODPACKLOADER_ID)) {
    return true;
  }
  return statCheckSync(getDiscoveryPath(api), path.join(MELON_MODS_PATH, MODPACKLOADER_FILE));
}

// Test if Jiangyu Loader is installed. The downloader installs it as a managed mod of its own type,
// so that check is the normal case; the file on disk still counts, for a loader placed by hand.
function isJiangyuInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  if (Object.keys(mods).some(id => mods[id]?.type === JIANGYU_ID)) {
    return true;
  }
  return statCheckSync(getDiscoveryPath(api), path.join(JIANGYU_PATH, JIANGYU_FILE));
}

// Test if Custom Mod Loader is installed
function isCustomInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  const idTest = Object.keys(mods).some(id => mods[id]?.type === CUSTOMLOADER_ID);
  if (!customLoaderInstaller) {
    return idTest;
  }
  GAME_PATH = getDiscoveryPath(api);
  let fileTest = false;
  try {
    fs.statSync(path.join(GAME_PATH, CUSTOMLOADER_MARKER_PATH));
    fileTest = true;
  } catch {
    fileTest = false;
  }
  return (idTest || fileTest);
}

// Test if Custom Mod Loader installer was run (marker file exists)
function checkCustomInstalled(api, spec) {
  GAME_PATH = getDiscoveryPath(api);
  let fileTest = false;
  try {
    fs.statSync(path.join(GAME_PATH, CUSTOMLOADER_MARKER_PATH));
    fileTest = true;
  } catch {
    customInstallerNotify(api);
    fileTest = false;
  }
  return fileTest;
}
//Notify user to run Custom Mod Loader Installer if marker file not found
function customInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-custominstaller`;
  const MOD_NAME = CUSTOMLOADER_NAME;
  const MESSAGE = `Run ${MOD_NAME} Installer`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Run ${MOD_NAME}`,
        action: (dismiss) => {
          runCustom(api);
          dismiss();
        },
      },
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `You must run the ${MOD_NAME} installer to install necessary files to the game folder.\n`
                + `\n`
                + `IMPORTANT: Use the default installation options for compatibility with Vortex.\n`
                + `\n`
                + `Use the included tool to launch ${MOD_NAME} installer (button on this notification or in "Dashboard" tab).\n`
          }, [
            {
              label: `Run ${MOD_NAME}`, action: () => {
                runCustom(api);
                dismiss();
              }
            },
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}
function runCustom(api) {
  const TOOL_ID = CUSTOMLOADER_ID;
  const TOOL_NAME = `${CUSTOMLOADER_NAME} Installer`;
  const state = api.store.getState();
  const tool = util.getSafe(state, ['settings', 'gameMode', 'discovered', GAME_ID, 'tools', TOOL_ID], undefined);
  try {
    const TOOL_PATH = tool.path;
    if (TOOL_PATH !== undefined) {
      return api.runExecutable(TOOL_PATH, [], { suggestDeploy: false })
        .catch(err => api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err,
          { allowReport: ['EPERM', 'EACCESS', 'ENOENT'].indexOf(err.code) !== -1 })
        );
    }
    else {
      return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, `Path to ${TOOL_NAME} executable could not be found. Ensure ${TOOL_NAME} is installed through Vortex.`);
    }
  } catch (err) {
    return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, { allowReport: ['EPERM', 'EACCESS', 'ENOENT'].indexOf(err.code) !== -1 });
  }
}

//Test if BepInExConfigManager is installed
function isBepCfgManInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === BEPCFGMAN_ID);
}

//Test if MelonPreferences Manager is installed
function isMelonPrefManInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === MELONPREFMAN_ID);
}

// Download BepInEx
async function downloadBepinex(api, gameSpec) {
  let isInstalled = isBepinexInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = BEPINEX_NAME;
    const MOD_TYPE = BEPINEX_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const URL = BEPINEX_URL;
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = BEPINEX_URL_ERR;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
}

/* Download MelonLoader (GitHub)
async function downloadMelon(api, gameSpec) {
  let isInstalled = isMelonInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = MELON_NAME;
    const MOD_TYPE = MELON_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const URL = MELON_URL;
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = MELON_URL_ERR;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Download MelonLoader Nightly (Nexus)
async function downloadMelon(api, gameSpec) {
  let isInstalled = isMelonInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = MELON_NAME;
    const MOD_TYPE = MELON_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = MELON_PAGE_NO;
    const FILE_ID = MELON_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = MELON_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// Download the Jiangyu Loader from GitHub. The release is a naked .dll, so this requirement runs in
// the module's direct-copy mode: the asset is fetched straight to the game's "Mods" folder and is
// never registered as a Vortex mod.
async function downloadJiangyu(api, gameSpec, check = true) {
  return download(api, JIANGYU_REQUIREMENTS, !check);
} //*/

// Download ModpackLoader, bundled inside the Menace Mod Manager release on GitHub. Some published
// mods still require it alongside Jiangyu, so setup() fetches it the same way it fetches Jiangyu.
async function downloadModpackLoader(api, gameSpec, check = true) {
  return download(api, MODPACKLOADER_REQUIREMENTS, !check);
} //*/

// Download the Menace ModKit from GitHub. Only the toolbar action calls this - the ModKit is an
// authoring tool, not something a player needs to run mods.
async function downloadModkit(api, gameSpec, check = true) {
  return download(api, MODKIT_REQUIREMENTS, !check);
} //*/

//* Function to auto-download Custom Mod Loader from Nexus Mods
async function downloadCustom(api, gameSpec) {
  let isInstalled = isCustomInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = CUSTOMLOADER_NAME;
    const MOD_TYPE = CUSTOMLOADER_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = CUSTOMLOADER_PAGE_NO;
    const FILE_ID = CUSTOMLOADER_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = CUSTOMLOADER_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
      if (customLoaderInstaller) { //run Custom Mod Loader installer if required
        /*
        try {
          GAME_PATH = getDiscoveryPath(api);
          const executable = path.join(GAME_PATH, CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC);
          api.runExecutable(executable, [], { suggestDeploy: false });
        } catch (err) {
          api.showErrorNotification(`Failed to run ${MOD_NAME} installer. You must run it manually.`, err, { allowReport: false });
        } //*/
      }
    }
  }
} //*/

// Download BepInExConfigManager from GitHub
async function downloadBepCfgMan(api, gameSpec) {
  let isInstalled = isBepCfgManInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = BEPCFGMAN_NAME;
    const MOD_TYPE = BEPCFGMAN_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    const URL = BEPCFGMAN_URL;
    const URL_ERR = BEPCFGMAN_URL_ERR;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// Download MelonPreferences Manager from GitHub
async function downloadMelonPrefMan(api, gameSpec) {
  let isInstalled = isMelonPrefManInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = MELONPREFMAN_NAME;
    const MOD_TYPE = MELONPREFMAN_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    const URL = MELONPREFMAN_URL;
    const URL_ERR = MELONPREFMAN_URL_ERR;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//Module-level pub-sub for multi-select + context menu + status filter (the Vortex FBLO page has
//no custom context provider, so row renderers share state through this instead)
let _fbloSelectedIds = new Set();
let _fbloContextMenu = null;
let _fbloStatusFilter = new Set();
const _fbloListeners = new Set();
function _notifyFblo() { _fbloListeners.forEach(l => l()); }
function useFbloState() {
  const [, forceUpdate] = React.useReducer(x => x + 1, 0);
  React.useEffect(() => {
    _fbloListeners.add(forceUpdate);
    return () => _fbloListeners.delete(forceUpdate);
  }, []);
  return {
    selectedIds: _fbloSelectedIds,
    setSelectedIds: (fn) => { _fbloSelectedIds = fn(_fbloSelectedIds); _notifyFblo(); },
    contextMenu: _fbloContextMenu,
    setContextMenu: (val) => { _fbloContextMenu = val; _notifyFblo(); },
    statusFilter: _fbloStatusFilter,
    setStatusFilter: (next) => { _fbloStatusFilter = next; _notifyFblo(); },
  };
}

//Resolve the mod page URL for a Vortex-managed load order entry (undefined when not resolvable).
//Prefers the mod's homepage attribute; falls back to composing the Nexus URL from the numeric mod id.
function getModPageURL(api, vortexModId) {
  if (vortexModId === undefined) return undefined;
  const attributes = util.getSafe(api.getState(), ['persistent', 'mods', GAME_ID, vortexModId, 'attributes'], {});
  if (attributes.homepage) return attributes.homepage;
  if (attributes.source === 'nexus' && attributes.modId !== undefined) {
    return `https://www.nexusmods.com/${GAME_ID}/mods/${attributes.modId}`;
  }
  return undefined;
}

//Resolve the staging folder of a Vortex-managed load order entry (undefined when not resolvable)
function getModStagingFolder(api, vortexModId) {
  if (vortexModId === undefined) return undefined;
  const state = api.getState();
  const installationPath = util.getSafe(state, ['persistent', 'mods', GAME_ID, vortexModId, 'installationPath'], undefined);
  const stagingPath = selectors.installPathForGame(state, GAME_ID);
  if (!installationPath || !stagingPath) return undefined;
  return path.join(stagingPath, installationPath);
}

//Status filter shared helpers (load order page). Groups combine with AND across, OR within.
const STATUS_GROUP_TOKENS = { enabled: ['enabled', 'disabled'], locked: ['locked', 'unlocked'], unmanaged: ['unmanaged'] };
const STATUS_TOKEN_LABELS = { enabled: 'Enabled', disabled: 'Disabled', locked: 'Locked', unlocked: 'Unlocked', unmanaged: 'Unmanaged' };

function matchesStatus(entry, active, isEnabledFn, isLockedFn) {
  if (active.has('enabled') || active.has('disabled')) {
    const en = isEnabledFn(entry);
    if (!((active.has('enabled') && en) || (active.has('disabled') && !en))) return false;
  }
  if (active.has('locked') || active.has('unlocked')) {
    const lk = isLockedFn(entry);
    if (!((active.has('locked') && lk) || (active.has('unlocked') && !lk))) return false;
  }
  if (active.has('unmanaged') && entry.modId !== undefined) return false;
  return true;
}

//Style blocks injected by the load order surfaces (see useInjectStyleOnce below)
const LO_INDEX_FOCUS_CSS = '.load-order-index input:focus { background: white !important; color: black !important; } .layout-flex.file-based-load-order-list-outer { overflow: auto; }';
const LO_ROW_HIDDEN_CSS = '.file-based-load-order-list .list-group > div:has(.lo-row-hidden) { display: none !important; }';
const LO_CTX_MENU_CSS = '.ue4ss-ctx-item:hover { background: rgba(255,255,255,0.1); }';

//Extensions cannot ship CSS, so a component injects its styles into the document head on mount.
//Guarded by a fixed id, so repeated mounts (every row, every page visit) never duplicate the block.
function useInjectStyleOnce(styleId, css) {
  React.useEffect(() => {
    if (globalThis.document.getElementById(styleId)) return;
    const style = globalThis.document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    globalThis.document.head.appendChild(style);
  }, [styleId, css]);
}

//Shared dismiss behaviour for the context menu: any click or right-click outside closes it, as
//does Escape. Menu items call stopPropagation, so their own clicks never reach these listeners.
function useDismissOnOutside(onClose) {
  React.useEffect(() => {
    const dismiss = () => onClose();
    const onKey = (evt) => { if (evt.key === 'Escape') onClose(); };
    globalThis.document.addEventListener('click', dismiss);
    globalThis.document.addEventListener('contextmenu', dismiss);
    globalThis.document.addEventListener('keydown', onKey);
    return () => {
      globalThis.document.removeEventListener('click', dismiss);
      globalThis.document.removeEventListener('contextmenu', dismiss);
      globalThis.document.removeEventListener('keydown', onKey);
    };
  }, [onClose]);
}

//Viewport clamp for the context menu. The clamped position is measured once into state and then
//rendered, rather than written onto el.style after the fact - a fresh callback ref every render
//makes React detach and reattach it, and the next render would overwrite the mutated style anyway.
function useClampedMenuPosition(x, y) {
  const [position, setPosition] = React.useState({ left: x, top: y });
  const measureRef = React.useCallback((el) => {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const vw = globalThis.window.innerWidth;
    const vh = globalThis.window.innerHeight;
    const left = (x + rect.width > vw) ? Math.max(8, vw - rect.width - 8) : x;
    const top = (y + rect.height > vh) ? Math.max(8, vh - rect.height - 8) : y;
    setPosition(prev => (prev.left === left && prev.top === top) ? prev : { left, top });
  }, [x, y]);
  return [position, measureRef];
}

//Inline toggle pills for status filtering (rendered in the load order page's InfoPanel)
function StatusPills({ active, setActive, groups, count }) {
  const { Button } = require('react-bootstrap');
  const tokens = groups.reduce((acc, g) => acc.concat(STATUS_GROUP_TOKENS[g] || []), []);
  const toggle = (token) => {
    const next = new Set(active);
    next.has(token) ? next.delete(token) : next.add(token);
    setActive(next);
  };
  return React.createElement('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 4, alignItems: 'center', marginBottom: 8 } },
    React.createElement('span', { style: { fontWeight: 'bold', marginRight: 4 } }, 'Filter:'),
    count != null ? React.createElement('span', { style: { color: '#7ec8e3', marginRight: 4 } }, `${count.matched} / ${count.total}`) : null,
    ...tokens.map(token => React.createElement(Button, {
      key: token,
      bsSize: 'xsmall',
      bsStyle: active.has(token) ? 'success' : 'default',
      style: active.has(token) ? { fontWeight: 'bold' } : undefined,
      onClick: () => toggle(token),
    }, STATUS_TOKEN_LABELS[token])),
    active.size > 0 ? React.createElement(Button, {
      key: '__clear',
      bsSize: 'xsmall',
      bsStyle: 'link',
      onClick: () => setActive(new Set()),
    }, 'Clear') : null,
  );
}

//React load order instructions renderer
function LoadOrderInstructions() {
  const { statusFilter, setStatusFilter } = useFbloState();
  const { useSelector } = require('react-redux');
  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) => util.getSafe(state, ['persistent', 'loadOrder', profile?.id], []));
  const modState = useSelector((state) => util.getSafe(state, ['persistent', 'profiles', profile?.id, 'modState'], {}));
  const isLocked = (entry) => [true, 'true', 'always'].includes(entry?.locked);
  const isEnabled = (entry) => util.getSafe(modState, [entry.modId, 'enabled'], false);
  //Count entries matching the active filter (matched / total), shown beside the pills.
  const total = loadOrder.length;
  const matched = statusFilter.size > 0
    ? loadOrder.filter((e) => matchesStatus(e, statusFilter, isEnabled, isLocked)).length
    : total;
  useInjectStyleOnce('fblo-status-filter-hide-style', LO_ROW_HIDDEN_CSS);
  return React.createElement('div', null,
    React.createElement(StatusPills, { active: statusFilter, setActive: setStatusFilter, groups: ['enabled', 'locked', 'unmanaged'], count: statusFilter.size > 0 ? { matched, total } : null }),
    React.createElement('p', { style: { fontStyle: 'italic', color: '#7ec8e3' } },
      'Filter the list above by status. Clear the filter before reordering mods.',
    ),
    React.createElement('br', null),
    React.createElement('p', null,
      `Drag and drop the mods on the left to change the order in which they load.   `,
    ),
    React.createElement('br', null),
    React.createElement('p', null,
      `${GAME_NAME} loads mods in the order you set from top to bottom.   `,
    ),
    React.createElement('br', null),
    React.createElement('p', { style: { fontWeight: 'bold', color: '#7ec8e3' } },
      'The Enable/Disable button on each row enables or disables the underlying Vortex mod. ',
      'Disabling a mod here removes it from this view and disables it on the Mods tab. ',
      'Re-enable it on the Mods tab to restore it to the load order.',
    ),
  );
}

//* React line item renderer for load order
function LoadOrderItemRenderer(props) {
  const { className, item } = props;
  if (item?.loEntry === undefined) return null;

  const { ListGroupItem, Checkbox } = require('react-bootstrap');
  const { Icon, LoadOrderIndexInput, MainContext } = require('vortex-api');
  const { useSelector, useDispatch } = require('react-redux');

  const context = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) =>
    util.getSafe(state, ['persistent', 'loadOrder', profile?.id], []),
  );

  const { loEntry, displayCheckboxes } = item;
  const mods = useSelector((state) => util.getSafe(state, ['persistent', 'mods', GAME_ID], {}));
  const pictureUrl = mods[loEntry.modId]?.attributes?.pictureUrl;
  //FBLO precomputes these on the item (memoized by its row cache); the fallbacks keep the
  //renderer working if it is ever mounted outside the FBLO page.
  const currentIdx = item.position ?? loadOrder.findIndex((e) => e.id === loEntry.id) + 1;
  const isModEnabled = useSelector((state) =>
    util.getSafe(state, ['persistent', 'profiles', profile?.id, 'modState', loEntry.modId, 'enabled'], false));
  const modState = useSelector((state) =>
    util.getSafe(state, ['persistent', 'profiles', profile?.id, 'modState'], {}));

  const isLocked = (entry) => [true, 'true', 'always'].includes(entry?.locked);
  //Core derives the index input's minimum from this and assumes locked entries sit at the top.
  //Only the LEADING locked run blocks row 1 - a lock further down must not raise the floor.
  const firstUnlocked = loadOrder.findIndex(e => !isLocked(e));
  const leadingLockedCount = firstUnlocked === -1 ? loadOrder.length : firstUnlocked;

  const onApplyIndex = React.useCallback((idx) => {
    if (currentIdx === idx || isLocked(loEntry)) return;
    //Locked entries hold their absolute index - the typed row picks a slot among the unlocked ones
    const bound = idx - 1 + (idx > currentIdx ? 1 : 0);
    const dest = loadOrder.filter((e, i) => !isLocked(e) && e.id !== loEntry.id && i < bound).length;
    const unlocked = loadOrder.filter((e) => !isLocked(e) && e.id !== loEntry.id);
    unlocked.splice(dest, 0, loEntry);
    let next = 0;
    const newLO = loadOrder.map((e) => isLocked(e) ? e : unlocked[next++]);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
  }, [dispatch, profile, loadOrder, loEntry, currentIdx]);

  const onModToggle = React.useCallback(() => {
    if (!loEntry.modId) return;
    actions.setModsEnabled(context.api, profile.id, [loEntry.modId], !isModEnabled, { allowAutoDeploy: true });
  }, [profile, loEntry.modId, isModEnabled, context]);

  const isEntryLocked = isLocked(loEntry);
  const { selectedIds, setSelectedIds, contextMenu, setContextMenu, statusFilter } = useFbloState();
  const isSelected = selectedIds.has(loEntry.id);
  //Shift-select must span visible rows only, so build the id list from the status-filtered order.
  //Memoized: a bare filter here would run once per row, i.e. O(n^2) over the whole load order.
  const allIds = React.useMemo(() => loadOrder
    .filter(e => matchesStatus(e, statusFilter, (entry) => util.getSafe(modState, [entry.modId, 'enabled'], false), isLocked))
    .map(e => e.id), [loadOrder, statusFilter, modState]);

  const onSelect = React.useCallback((evt) => {
    const ctrlKey = evt.ctrlKey || evt.metaKey;
    const shiftKey = evt.shiftKey;
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (ctrlKey) {
        next.has(loEntry.id) ? next.delete(loEntry.id) : next.add(loEntry.id);
      } else if (shiftKey) {
        const lastId = [...prev].at(-1);
        const start = allIds.indexOf(lastId ?? loEntry.id);
        const end = allIds.indexOf(loEntry.id);
        const [lo, hi] = [Math.min(start, end), Math.max(start, end)];
        for (let i = lo; i <= hi; i++) next.add(allIds[i]);
      } else {
        next.clear();
        next.add(loEntry.id);
      }
      return next;
    });
  }, [loEntry.id, setSelectedIds, allIds]);

  const onContextMenu = React.useCallback((evt) => {
    evt.preventDefault();
    evt.stopPropagation();
    setContextMenu({ x: evt.clientX, y: evt.clientY, itemId: loEntry.id });
  }, [loEntry.id, setContextMenu]);

  const onLock = React.useCallback(() => {
    const newLO = loadOrder.map(e => e.id === loEntry.id ? { ...e, locked: !isEntryLocked } : e);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
    serializeLoadOrder(context, newLO);
  }, [dispatch, context, profile, loadOrder, loEntry, isEntryLocked]);

  useInjectStyleOnce('lo-index-focus-style', LO_INDEX_FOCUS_CSS);

  const classes = ['load-order-entry'];
  if (className) classes.push(...className.split(' '));

  //Status filter: render hidden (but keep the DnD item count stable) when the entry is filtered
  //out. The 'lo-row-hidden' marker lets the injected CSS collapse the whole DraggableListItem
  //wrapper (the two dnd <div>s the renderer can't reach), otherwise their spacing leaves gaps.
  if (!matchesStatus(loEntry, statusFilter, () => isModEnabled, isLocked)) {
    return React.createElement(ListGroupItem, { key: loEntry.id, className: 'lo-row-hidden', style: { display: 'none' } });
  }

  return React.createElement(
    ListGroupItem,
    {
      key: loEntry.id,
      className: classes.join(' '),
      onClick: onSelect,
      onContextMenu: onContextMenu,
      style: { outline: isSelected ? '2px solid #337ab7' : 'none', outlineOffset: '-1px' },
    },
    React.createElement('div', { style: { visibility: isEntryLocked ? 'hidden' : 'visible' } },
      React.createElement(Icon, { className: 'drag-handle-icon', name: 'drag-handle' }),
    ),
    React.createElement('div', { style: { width: 24, flexShrink: 0, overflow: 'hidden' } },
      React.createElement(LoadOrderIndexInput, {
        className: 'load-order-index',
        api: context.api,
        item: loEntry,
        currentPosition: currentIdx,
        lockedEntriesCount: leadingLockedCount,
        loadOrder: loadOrder,
        isLocked: isLocked,
        onApplyIndex: onApplyIndex,
      }),
    ),
    React.createElement('div', {
      style: { cursor: 'pointer', display: 'flex', alignItems: 'center' },
      title: isEntryLocked ? 'Unlock position' : 'Lock position',
      onClick: (evt) => { evt.stopPropagation(); onLock(); },
    },
      React.createElement(Icon, { name: isEntryLocked ? 'locked' : 'unlocked', style: { color: isEntryLocked ? '#e2c04c' : 'inherit' } }),
    ),
    React.createElement('div', { className: 'load-order-thumb-slot', style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, marginRight: 4, flexShrink: 0 } },
      !loEntry.modId ? React.createElement('div', {
        className: 'load-order-unmanaged-banner',
        title: 'Not managed by Vortex',
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, textAlign: 'center', borderRadius: 2, border: '1px solid #e2c04c', background: 'rgba(226,192,76,0.12)', color: '#e2c04c', fontSize: 9, lineHeight: 1.1, padding: 2, pointerEvents: 'none' },
      },
        React.createElement(Icon, { className: 'external-caution-logo', name: 'feedback-warning', style: { color: '#e2c04c' } }),
        React.createElement('span', null, 'Not managed by Vortex'),
      ) : pictureUrl ? React.createElement('img', {
        className: 'load-order-thumb',
        src: pictureUrl,
        draggable: false,
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, objectFit: 'cover', borderRadius: 2, pointerEvents: 'none' },
      }) : null,
    ),
    React.createElement('p', { className: 'load-order-name', style: { whiteSpace: 'normal', wordBreak: 'break-word' } }, loEntry.name),
    loEntry.modId ? React.createElement('button', {
      className: 'btn btn-default btn-sm',
      style: { margin: '0 4px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4 },
      onClick: evt => { evt.stopPropagation(); onModToggle(); },
    },
      React.createElement(Icon, { name: isModEnabled ? 'toggle-disabled' : 'toggle-enabled' }),
      isModEnabled ? 'Disable' : 'Enable',
    ) : null,
    displayCheckboxes ? React.createElement(Checkbox, {
      className: 'entry-checkbox',
      checked: loEntry.enabled,
      disabled: isLocked(loEntry),
      onChange: (evt) => dispatch(actions.setFBLoadOrderEntry(profile.id, { ...loEntry, enabled: evt.target.checked })),
    }) : null,
    contextMenu?.itemId === loEntry.id ? React.createElement(FbloContextMenu, {
      x: contextMenu.x, y: contextMenu.y,
      item: loEntry, loadOrder, profile, dispatch, context, selectedIds, isModEnabled,
      onClose: () => setContextMenu(null),
    }) : null,
  );
} //*/

//Right-click context menu for load order entries (single + multi-select)
function FbloContextMenu({ x, y, item, loadOrder, profile, dispatch, context, selectedIds, isModEnabled, onClose }) {
  useDismissOnOutside(onClose);
  useInjectStyleOnce('ue4ss-ctx-menu-style', LO_CTX_MENU_CSS);

  const [menuPosition, clampRef] = useClampedMenuPosition(x, y);

  const isLocked = (e) => [true, 'true', 'always'].includes(e?.locked);
  const isMulti = selectedIds.size >= 2 && selectedIds.has(item.id);
  const targets = isMulti ? loadOrder.filter(e => selectedIds.has(e.id)) : [item];

  const applyToTargets = (transform, serialize = false) => {
    const newLO = transform(loadOrder, targets);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
    if (serialize) serializeLoadOrder(context, newLO);
    onClose();
  };

  const isEntryLocked = isLocked(item);

  const setModsEnabled = (entries, enable) => {
    const modIds = [...new Set(entries.filter(e => e.modId !== undefined).map(e => e.modId))];
    if (modIds.length > 0) {
      actions.setModsEnabled(context.api, profile.id, modIds, enable, { allowAutoDeploy: true });
    }
    onClose();
  };
  const openModFolders = async (entries) => {
    for (const e of entries) {
      if (e.id === undefined) continue;
      const folder = await resolveModFolder(context.api, e.id);
      if (folder) await util.opn(folder).catch(() => null);
    }
    onClose();
  };
  const modPageUrl = getModPageURL(context.api, item.modId);
  const stagingFolder = getModStagingFolder(context.api, item.modId);

  const menuStyle = {
    position: 'fixed', left: menuPosition.left, top: menuPosition.top, zIndex: 9999,
    background: '#1e1e1e', border: '1px solid rgba(255,255,255,0.2)',
    borderRadius: 4, padding: '4px 0', minWidth: 180,
    boxShadow: '0 4px 12px rgba(0,0,0,0.6)',
  };
  const itemStyle = { padding: '6px 16px', cursor: 'pointer', whiteSpace: 'nowrap' };
  const sepStyle = { borderTop: '1px solid rgba(255,255,255,0.1)', margin: '4px 0' };

  const menuItem = (label, onClick) => React.createElement('div', {
    className: 'ue4ss-ctx-item',
    style: itemStyle,
    onClick: (evt) => { evt.stopPropagation(); onClick(); },
  }, label);

  if (isMulti) {
    const n = targets.length;
    return React.createElement('div', { ref: clampRef, style: menuStyle },
      menuItem(`Lock Selected (${n})`, () => applyToTargets((lo) => lo.map(e => targets.find(t => t.id === e.id) ? { ...e, locked: true } : e), true)),
      menuItem(`Unlock Selected (${n})`, () => applyToTargets((lo) => lo.map(e => targets.find(t => t.id === e.id) ? { ...e, locked: false } : e), true)),
      React.createElement('div', { style: sepStyle }),
      menuItem(`Move to Top (${n})`, () => applyToTargets((lo) => {
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const selected = lo.filter(e => targets.find(t => t.id === e.id) && !isLocked(e));
        const rest = lo.filter(e => !isLocked(e) && !targets.find(t => t.id === e.id));
        const reordered = [...selected, ...rest];
        let next = 0;
        return lo.map(e => isLocked(e) ? e : reordered[next++]);
      })),
      menuItem(`Move to Bottom (${n})`, () => applyToTargets((lo) => {
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const selected = lo.filter(e => targets.find(t => t.id === e.id) && !isLocked(e));
        const rest = lo.filter(e => !isLocked(e) && !targets.find(t => t.id === e.id));
        const reordered = [...rest, ...selected];
        let next = 0;
        return lo.map(e => isLocked(e) ? e : reordered[next++]);
      })),
      React.createElement('div', { style: sepStyle }),
      menuItem(`Open Mod Folders (${n})`, () => openModFolders(targets)),
      targets.some(t => t.modId !== undefined) ? menuItem(`Open Staging Folders (${n})`, () => {
        const folders = [...new Set(targets.map(t => getModStagingFolder(context.api, t.modId)).filter(Boolean))];
        folders.forEach(f => util.opn(f).catch(() => null));
        onClose();
      }) : null,
      React.createElement('div', { style: sepStyle }),
      menuItem(`Disable Selected (${n})`, () => setModsEnabled(targets, false)),
    );
  }

  return React.createElement('div', { ref: clampRef, style: menuStyle },
    menuItem(isEntryLocked ? 'Unlock Position' : 'Lock Position', () => applyToTargets((lo) => lo.map(e => e.id === item.id ? { ...e, locked: !isEntryLocked } : e), true)),
    React.createElement('div', { style: sepStyle }),
    menuItem('Move to Top', () => applyToTargets((lo) => {
      if (isLocked(item)) return lo;
      //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
      const moved = lo.filter(e => !isLocked(e) && e.id === item.id);
      const rest = lo.filter(e => !isLocked(e) && e.id !== item.id);
      const reordered = [...moved, ...rest];
      let next = 0;
      return lo.map(e => isLocked(e) ? e : reordered[next++]);
    })),
    menuItem('Move to Bottom', () => applyToTargets((lo) => {
      if (isLocked(item)) return lo;
      //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
      const moved = lo.filter(e => !isLocked(e) && e.id === item.id);
      const rest = lo.filter(e => !isLocked(e) && e.id !== item.id);
      const reordered = [...rest, ...moved];
      let next = 0;
      return lo.map(e => isLocked(e) ? e : reordered[next++]);
    })),
    React.createElement('div', { style: sepStyle }),
    menuItem('Open Mod Folder', () => openModFolders([item])),
    stagingFolder ? menuItem('Open Staging Folder', () => { util.opn(stagingFolder).catch(() => null); onClose(); }) : null,
    modPageUrl ? menuItem('Open Mod Page', () => { util.opn(modPageUrl).catch(() => null); onClose(); }) : null,
    item.modId && isModEnabled ? React.createElement('div', { style: sepStyle }) : null,
    item.modId && isModEnabled ? menuItem('Disable Vortex Mod', () => setModsEnabled([item], false)) : null,
  );
}

//export to Vortex
module.exports = {
  default: main,
};
