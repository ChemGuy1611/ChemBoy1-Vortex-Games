# Changelog

## [0.1.3] - 2025-04-01
- Added missing mod installers for Loose File Loader and Plugin Loader (oopsie!).

## [0.1.2] - 2025-04-01
- Added automatic download and installers for Loose File Loader and Plugin Loader.

## [0.1.1] - 2025-03-31
- Added "data", "data_pc", and "plugins" folders to mod installer to match the legacy Control extension installer. Note that many Loose File and Plugin mods do not yet work with the March 2025 update.

## [0.1.0] - 2025-03-21
- Initial release