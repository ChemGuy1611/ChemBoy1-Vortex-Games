# Changelog

## Planned Improvements (Not Yet Released)

- None

## [0.2.1] - 2026-08-11

- Added Epic Games Store support

## [0.2.0] - 2026-05-05

- Fixed: Updated game launch for release version

## [0.1.1] - 2026-04-13

- Fixed: error no longer shown when launching demo version

## [0.1.0] - 2026-01-13

- Initial release
