# Changelog

## [1.1.7] - 2026-11-01

- Changed: manifest.json and icon.png files are no longer skipped during conflict checks.

## [1.1.6] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.5] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.4] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of a mod loader or plugin folder (for example "Myplugins" for "plugins") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Closing the "Wrong Mod Loader" or "Mixed Mod Detected" warning without pressing Ok now cancels the install instead of installing the mod anyway.
- Fixed: A mod archive is now recognised as a BepInEx patcher or a MelonLoader plugin whichever of its files is read last.
- Fixed: The missing .NET runtime warning for MelonLoader is no longer shown twice.

## [1.1.3] - 2026-10-01

- Thunderstore package files (manifest.json, icon.png) from newly installed mods are no longer copied into the shared mod loader folder, where they collided between mods.

## [1.1.2] - 2026-09-27

- Game version now shows the real game build instead of the Unity engine version.

## [1.1.1] - 2026-09-27

- Fixed: a non-Xbox install could be misidentified as the Xbox version, showing the wrong installed game version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.0] - 2026-09-20

- Added: "Browse Thunderstore" page, which opens the Blue Prince Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [1.0.0] - 2026-09-19

- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- BepInEx and MelonLoader downloads now automatically check for and install the latest version instead of a fixed one.
- Added: BepInExConfigManager can now be downloaded and is kept up to date automatically.
- Changed: Plugins that don't already ship their own folder are now installed into one of their own, so two mods with a same-named file no longer overwrite each other.

## [0.1.3] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.1.2] - 2026-04-22

- Bump: BepInEx Config Manager to 18.4.1 - changed repo

## [0.1.1] - 2026-03-15

- Fixed: Bump BepInEx BE version to 755
- Added: .NET 6 installation check and notification for MelonLoader
- Added: Automatic detection of BepInEx patchers

## [0.1.0] - 2025-10-31

- Initial release
