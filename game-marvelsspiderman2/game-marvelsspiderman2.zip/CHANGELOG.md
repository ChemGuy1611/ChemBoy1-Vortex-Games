# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.1.7] - 2025-10-31

- Fixes for Steam verification of "toc" file. Note that this function is still experimental.

## [0.1.6] - 2025-04-05

- Added .suit_style and .script extensions to Overstrike mod installer.
