# Changelog

## Future Improvements (Not Yet Released)

- None

## [2.0.0] - 2025-12-23

- Initial release
