# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.1] - 2025-11-24

- Added Xbox version support.

## [0.1.0] - 2025-10-16

- Initial release
