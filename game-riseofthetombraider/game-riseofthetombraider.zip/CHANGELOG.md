## [0.4.1]
- Added an installer for mods intended for the TR Reboot Mod Manager that did not include a top-level folder above the modified files.
- Added more file extensions to detect mods for TR Reboot Mod Manager

## [0.4.0]
- Updated support for new version of the SOTTR Mod Manager (now TR Reboot Mod Manager)
- Added notificaiton to run TR Reboot Mod Manager after deployment
- Added fallback installer for root folder
- Removed xbox id from discovery since that version of the game cannot be modded