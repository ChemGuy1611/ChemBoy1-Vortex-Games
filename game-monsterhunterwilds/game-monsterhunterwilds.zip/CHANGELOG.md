# Changelog

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mods packaged inside an outer folder named like one of the mod's key files (for example "dinput8.dll.old") now install into the right place.
- Fixed: Lua script mods with scripts in more than one folder now install every folder instead of only the first.
- Fixed: A mod archive containing another archive with an upper-case extension (.ZIP, .RAR, .7Z) is now installed as it is instead of being packed into another zip.
- Fixed: A mod whose key file name uses different letter case (for example "DINPUT8.DLL") no longer fails to install.
- Added a "Download Latest REFramework Nightly" button to the Mods toolbar.
- Added an "Open Save Folder (Steam)" button to the Mods toolbar.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.3.0] - 2026-03-05

- Improved: Mod installer performance by removing Bluebird.
- Added: Installer for Fluffy Preset files (.prt) - useful for collections
- Added: Buttons to open PCGamingWiki page and submit bug reports

## [0.2.2] - 2025-11-18

- Added a Root Folder installer to try and filter mods that are not for Fluffy from being re-zipped. Targets any mod with a .exe file and a few dlls for now.
- Added buttons to open useful files and folder (inside folder icon in Mods page toolbar).
- Added discovery for Benchmark demo version.
- Technical fixes and improvements.

## [0.2.1] - 2025-07-01

- Fixed error during automatic download of Fluffy MM.

## [0.2.0]

- Added a mod installer for loose lua files that cannot be properly installed with Fluffy

## [0.1.5]

- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including Fluffy MM, to fail with wrong URL
- Removed 'site' from compatibleDownloads, as it would cause all mods from the Modding Tools domain the user has installed to show up as uninstalled mods in the mod list
