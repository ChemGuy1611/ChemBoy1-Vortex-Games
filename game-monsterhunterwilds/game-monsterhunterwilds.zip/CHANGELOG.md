# Changelog

## FUTURE Improvements (Not Implemented Yet)

- None Planned

## [0.2.1] - 2025-07-01

- Fixed error during automatic download of Fluffy MM.

## [0.2.0]

- Added a mod installer for loose lua files that cannot be properly installed with Fluffy

## [0.1.5]

- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including Fluffy MM, to fail with wrong URL
- Removed 'site' from compatibleDownloads, as it would cause all mods from the Modding Tools domain the user has installed to show up as uninstalled mods in the mod list
