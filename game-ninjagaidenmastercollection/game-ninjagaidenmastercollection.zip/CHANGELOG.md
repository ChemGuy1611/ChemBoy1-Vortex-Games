# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.2.0] - 2025-11-10

- All versions now use TMX Mod Loader (alternative loader for Steam was removed from Nexus).
- Fixed game version detection for Xbox versions.
- Fixed gameId checks in installer functions.
- Added buttons to open Documents folder for each game (folder icon on Mods page toolbar).

## [0.1.1]

- Added mod types and installers to handle mods with "databin" folders and subfolders ("bgm" and "movies" for NGS1, "sound" and "movies" for NGS2 and NG3RE).
