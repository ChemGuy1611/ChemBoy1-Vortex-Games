# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- Notification to install .NET 9.0.4 SDK (x64 and x86) + may need to launch as admin once to download dependencies.

## [0.1.1] - 2025-10-09

- Added button to open Saves folder ("gamedata/savedata").

## [0.1.0] - 2025-10-04

- Initial Release
