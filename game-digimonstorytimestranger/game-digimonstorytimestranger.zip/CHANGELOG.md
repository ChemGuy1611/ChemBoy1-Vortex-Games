# Changelog

## Planned Improvements (Not Yet Released)

- Installer for Save (.bin) files (no mods of this type yet).

## [1.0.0] - 2026-10-03

- Added a fallback installer: when no other installer matches a mod, Vortex now shows a notice and installs the files to the game folder.
- Setup now makes sure the Reloaded mod and save folders in the game folder are writable.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.1.2] - 2025-10-14

- Added text information and button to run Reloaded-II as Admin to setup notification (needed to install dependencies if running from protected folder).
- Added deploy notification with a button to run Reloaded-II as Admin after deployment.

## [0.1.1] - 2025-10-09

- Added button to open Saves folder ("gamedata/savedata").
- Improved setup notification text.

## [0.1.0] - 2025-10-04

- Initial Release
