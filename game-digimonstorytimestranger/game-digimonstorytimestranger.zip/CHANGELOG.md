# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.1.2] - 2025-10-14

- Added text information and button to run Reloaded-II as Admin to setup notification (needed to install dependencies if running from protected folder).
- Added deploy notification with a button to run Reloaded-II as Admin after deployment.

## [0.1.1] - 2025-10-09

- Added button to open Saves folder ("gamedata/savedata").
- Improved setup notification text.

## [0.1.0] - 2025-10-04

- Initial Release
