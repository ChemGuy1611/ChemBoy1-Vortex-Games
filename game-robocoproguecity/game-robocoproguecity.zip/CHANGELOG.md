# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.6.0] - 2025-07-17

- Added support for RoboCop: Rogue City - Unfinished Business as a separate game.
- Added Game Pass support for RoboCop: Rogue City.
- Added full support for UE4SS and its script and dll mods.
- Installers for Config and Save mods (dependent on folders being on same partition).
- Many technical improvements.
