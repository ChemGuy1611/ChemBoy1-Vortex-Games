# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.2.0] - 2026-02-03

- Improved: Made UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names
- Fixed: path strings
- Fixed: Xbox game version detection
- Added: Buttons to open UE4SS settings files, PCGamingWiki page, view changelog, and submit bug reports

## [0.1.1] - 2025-12-15

- Made the UE4SS Scripts installer case-insensitive.

## [0.1.0] - 2025-07-28

- Initial release
