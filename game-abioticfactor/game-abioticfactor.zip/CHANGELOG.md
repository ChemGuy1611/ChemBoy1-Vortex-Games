# Changelog

## [1.1.1] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.1.0] - 2026-11-01

- Added: Installer for modkit mods with a .uplugin file. They now install into their own folder in "AbioticFactor/Mods" instead of being flattened into "~mods".
- Added: "Browse mod.io" page to browse the game's mods on mod.io and install them directly in Vortex, with update checks and dependency installs, plus an "Open mod.io Page" button.

## [1.0.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.1] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: Pak + UE4SS combo mods now show up on the UE4SS load order page on the Xbox / Game Pass version, instead of being listed as manual mods.

## [1.0.0] - 2026-10-01

- Migrated to file-based load order (FBLO); added a lock button, multi-select, and a right-click context menu to the Paks load order page.
- Added a UE4SS Load Order page and a LogicMods Load Order page for Blueprint pak mods.
- Added UE4SS and LogicMods load order support to Collections.
- Added a status filter to the load order pages.
- Updating a mod now keeps its place in the load order.
- Game version now shows the real game build instead of the Unreal engine version.
- Fixed: Save file mods were not recognized by the installer.
- Fixed: Mod files with no file extension were skipped during installation.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.2.1] - 2026-04-12

- Improved: Combo mod installer now checks only for "Binaries" and "Content" folders to install incomprehensibly packaged mods

## [0.2.0] - 2026-02-03

- Improved: Made UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names
- Fixed: path strings
- Fixed: Xbox game version detection
- Added: Buttons to open UE4SS settings files, PCGamingWiki page, view changelog, and submit bug reports

## [0.1.1] - 2025-12-15

- Made the UE4SS Scripts installer case-insensitive.

## [0.1.0] - 2025-07-28

- Initial release
