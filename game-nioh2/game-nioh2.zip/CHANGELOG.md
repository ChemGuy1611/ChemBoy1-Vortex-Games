# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2026-02-04

- Fixed: Missing DLL file name for mod loader.

## [0.1.0] - 2025-01-14

- Inital Release
