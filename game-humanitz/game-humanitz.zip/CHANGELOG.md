# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.0] - 2026-02-18

- Initial release
