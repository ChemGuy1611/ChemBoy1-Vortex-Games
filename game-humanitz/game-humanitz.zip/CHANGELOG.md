# Changelog

## [3.1.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [3.1.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [3.0.4] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [3.0.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [3.0.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [3.0.1] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: The "Open LogicMods Folder" button now opens the LogicMods folder instead of the Paks folder.

## [3.0.0] - 2026-10-02

- Migrated to file-based load order (FBLO); added a lock button, multi-select, and a right-click context menu to the Paks load order page.
- Added a UE4SS Load Order page and a LogicMods Load Order page for Blueprint pak mods.
- Added UE4SS and LogicMods load order support to Collections.
- Added a status filter to the load order pages.
- Updating a mod now keeps its place in the load order.
- UE4SS now downloads automatically and checks for updates.
- Game version now shows the real game build instead of the Unreal engine version.
- Added GOG support.
- Fixed: Mod files with no file extension were skipped during installation.
- Added an "Open SteamDB Page" button.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [2.0.1] - 2026-08-11

- Added GOG support

## [2.0.0] - 2026-02-23

- COMPLETELY NEW EXTENSION FROM THE AUTHOR OF OVER 200 VORTEX EXTENSIONS! SUPPORTS 1.0 RELEASE!
- Fixed: Moved pak install to new location ".\HumanitZ\Content\Paks\~mods"
- Fixed: Correct executable and folder names for 1.0 release
- Fixed: Load Order functions properly
