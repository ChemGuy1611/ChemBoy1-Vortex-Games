# Changelog

## [1.0.3] - 2026-01-28

- Better exit condition checking
- Improved exit behavior after successful operation
- Improved messages throughout the script

## [1.0.2] - 2026-01-27

- Added the ability to check both paths, even if the first does not exist

## [1.0.1] - 2026-01-26

- small fix to better handle the path to the overlay files from the registry
- Added fallback to default instllation path if registry value is not found

## [1.0.0] - 2026-01-25

- Initial release
