# Changelog

## [1.1.1] - 2026-11-23

- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.1.0] - 2026-11-09

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Added: RedHook plugins (.red files) now install to the game folder, including those packaged inside an outer folder.
- Added: Model mods (.wft, .wfd, and .wedt files) now install to the MagicRDR_Mods folder.
- Fixed: MagicRDR mods packaged across several folders now keep all of their files and folders instead of only one folder's files.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.3.5] - 2026-10-02

- Added support for the Xbox / Microsoft Store version of the game.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.3.4] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [0.3.3] - 2026-09-02

- Fixed: A required mod loader or tool is no longer matched against downloads belonging to other games, which could report the wrong installed version or check for updates against the wrong file

## [0.3.2] - 2026-08-22

- Fixed: Updating a required mod loader or tool now disables every older copy of it, so an out-of-date version can no longer stay enabled alongside the new one

## [0.3.1] - 2026-08-05

- Fixed: A required mod loader or tool that can no longer be found in its GitHub release is now reported, listing the files the release actually contains, instead of failing quietly
- Fixed: Requirement downloads are written to disk as they arrive rather than held in memory, and a failed download no longer leaves a temporary file behind
- Fixed: Pressing a requirement download button twice no longer starts the same download twice
- Fixed: Requirement update checks no longer stop working when a version number cannot be read
- Changed: Installed requirements are now identified by their own mod type. A requirement installed earlier without one is downloaded once more, after which it is identified correctly
- Added: Checking for updates now installs a missing requirement instead of reporting an update for something that is not installed
- Fixed: Updating a requirement now disables the version it replaces before the new one is installed, so the two cannot deploy on top of each other

## [0.3.0] - 2026-08-03

- Magic RDR now downloads the latest release automatically instead of a fixed version.
- Vortex now notifies you when a newer Magic RDR release is available.
- Fixed the Magic RDR installer not recognizing the tool's files.

## [0.2.5] - 2025-11-14

- Added buttons to open Config and Save folders (folder icon on Mods page toolbar).
- Added button to Magic-RDR notification to never show again (suppresses notification).
- Technical fixes and improvements.

## [0.2.4] - 2025-08-18

- Added Epic Games version support.
- Improved game discovery code.
- Updated Magic RDR download to v1.3.9.
