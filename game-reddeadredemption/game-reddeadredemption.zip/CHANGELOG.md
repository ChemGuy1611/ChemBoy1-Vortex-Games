# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- Loose Files loader support (once added)

## [0.2.5] - 2025-11-14

- Added buttons to open Config and Save folders (folder icon on Mods page toolbar).
- Added button to Magic-RDR notification to never show again (suppresses notification).
- Technical fixes and improvements.

## [0.2.4] - 2025-08-18

- Added Epic Games version support.
- Improved game discovery code.
- Updated Magic RDR download to v1.3.9.
