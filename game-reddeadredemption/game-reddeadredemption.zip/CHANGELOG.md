# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- Loose Files loader support (once added)

## [0.2.4] - 2025-08-18

- Added Epic Games version support.
- Improved game discovery code.
- Updated Magic RDR download to v1.3.9.
