# Changelog

## Planned Improvements (Not Yet Released)

- Changed launcher settings so that Steam version launches through Steam (so that Steam launch arguments are used).

## [1.1.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [1.0.5] - 2026-09-06

- Fixed: Locked load order entries could be moved out of position when using "Move to Top", "Move to Bottom" or the position number box on another entry. Locked entries now keep their place.
- Fixed: The load order position number box now accepts low numbers even when a locked entry is further down the list.

## [1.0.4] - 2026-09-05

- Fixed: A locked load order entry no longer unlocks itself after deploying or reopening the load order page.
- Fixed: Opening the load order on a fresh install could fail with a "file doesn't exist" error for mod_order.txt. The file is now created if it is missing.
- Fixed: Selecting several load order rows that all belong to the same mod no longer opens that mod's staging folder more than once, or acts on it twice.
- Changed: Long mod names in the load order now wrap onto a second line instead of being cut off.

## [1.0.3] - 2026-08-03

- Fixed: Error notification when trying to read Steam Workshop mods folder, even when present.

## [1.0.2] - 2026-07-30

- Fixed: KCSE Address Library installed correctly to game root folder.
- Fixed: Mods with only "KCSE" plugins are installed correctly.
- Fixed: More reliable guarding around Steam Workshop mods LO logic.
- Added: Fallback installer to game root folder.

## [1.0.1] - 2026-07-29

- Fixed: The load order could disappear after deploying while a mod update was in progress, and only came back after deploying a second time.
- Added: A message now appears if you change the load order while a mod update is still finishing, so it is clear the change was not applied and needs to be made again.
- Fixed: After a mod update finished, the load order page could keep showing out-of-date information until another deployment was run.

## [1.0.0] - 2026-07-29

- Changed: Load order rows redraw less when the order changes.
- Changed: The right-click menu works out its position once when opened instead of adjusting after it appears.

## [0.7.2] - 2026-07-27

- Fixed: "Move to Top" and "Move to Bottom" now leave locked entries where they are, instead of moving them or adding a duplicate entry.
- Fixed: Shift-clicking two rows while a status filter is active no longer selects the hidden rows between them.

## [0.7.1] - 2026-07-25

- Fixed: Using "Update all" to update several mods at once could move them in the load order or uncheck them.

## [0.7.0] - 2026-07-22

- Fixed: Updating a mod could uncheck it or move it in the load order, especially on profiles other than the one you were using.
- Added: Lock button on each load order entry.
- Added: Multi-select (Ctrl/Shift-click) and right-click context menu for the load order list.
- Added: Right-click options to open a mod's folder, staging folder, or mod page, and to enable/disable the Vortex mod.
- Added: Load order status filter (enabled/disabled, locked/unlocked, unmanaged) with a match count.
- Added: "Not managed by Vortex" indicator on load order entries with no matching mod.

## [0.6.0] - 2026-04-22

- Improved: Load Order rendering using React - show mod image thumbnails
- Fixed: Game version detection for Xbox version

## [0.5.1] - 2026-03-04

- Fixed: Corrected mod path for Xbox version (Documents)

## [0.5.0] - 2026-03-03

- Added: Xbox version support
- Improved: Filtering of the mod folder read to prevent invalid load order entries
- Added: Launch tools for each game version
- Fixed: Steam-related load order code no longer running on non-Steam versions

## [0.4.3] - 2026-01-29

- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, open downloads folder, and submit bug reports

## [0.4.2] - 2025-07-14

- Mods will now maintain their load order postion and enable/disable state when updating. Thanks to infarctus.

## [0.4.1] - 2025-03-29

- GOG version support added

## [0.4.0] - 2025-03-27

- Made game discovery more reliable
- Fixed load order errors that could sometimes occur when switching profiles

## [0.3.2]

- The mod.manifest file for Steam Workshop mods is now read only from the root folder

## [0.3.1]

- Fixed path replace functions for setting path to Steam Workshop mods folder
- Updated some notification text related to Steam Workshop mods

## [0.3.0]

- Added mods from Steam Workshop to load order. This obviously only applies to the Steam version of the game
