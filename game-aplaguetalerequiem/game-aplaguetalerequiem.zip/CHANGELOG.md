# Changelog

## Future Improvements (Not Yet Released)

- None

## [1.3.1] - 2025-11-17

- Added installer for folders in game root to help remove extraneous top-level folders.

## [1.3.0] - 2025-11-14

- Fixed game version detection for Xbox version.
- Added buttons to open Config and Save folders (folder icon on Mods page toolbar).
- Added custom launch tool.
