# Changelog

## Future Improvements (Not Yet Released)

- None

## [1.3.0] - 2025-11-14

- Fixed game version detection for Xbox version.
- Added buttons to open Config and Save folders (folder icon on Mods page toolbar).
- Added custom launch tool.
