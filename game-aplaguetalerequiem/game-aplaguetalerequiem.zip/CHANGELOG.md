# Changelog

## [1.4.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.4.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.4.1] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [1.4.0] - 2026-10-04

- Fixed: Launching the Epic Games Store version from Vortex now goes through the Epic launcher.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.3.1] - 2025-11-17

- Added installer for folders in game root to help remove extraneous top-level folders.

## [1.3.0] - 2025-11-14

- Fixed game version detection for Xbox version.
- Added buttons to open Config and Save folders (folder icon on Mods page toolbar).
- Added custom launch tool.
