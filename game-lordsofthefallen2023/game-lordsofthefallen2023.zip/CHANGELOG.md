# Changelog

## Future Improvements (Not Yet Released)

- Automate EAC bypass for Steam and Epic versions

## [0.1.1] - 2025-08-17

- Added Epic games version ID

## [0.1.0] - 2025-04-23

- Initial release
