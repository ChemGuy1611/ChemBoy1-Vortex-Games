# Changelog

## Future Improvements (Not Yet Released)
- 

## [0.1.0] - 2025-04-23
- Initial release