# Changelog

## [1.0.3] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Added a fallback installer: when no other installer matches a mod, Vortex now shows a notice and installs the files to the game folder.
- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyData" for "Data") now install into the right place instead of a doubled folder.
- Fixed: The Xbox (Game Pass) version now uses the correct game executable.
- Fixed: The Open Save Folder and Open Config Folder buttons could point to the wrong folder right after the first setup.
- Vortex now checks that the game's mod folders are writable when the game is set up.

## [0.3.0] - 2026-09-28

- Game version now shows the real installed build instead of always showing 0.0.0.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.2.0] - 2026-06-06

- Added: Xbox version support
- Fixed: ACSE Mods always installed with a top level folder

## [0.1.0] - 2025-10-22

- Initial release
