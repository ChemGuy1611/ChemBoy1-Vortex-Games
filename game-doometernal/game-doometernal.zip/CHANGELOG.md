# Changelog

## FUTURE CHANGES (NOT IMPLEMENTED YET)

- Config and save modtypes, installers, and open buttons.

## [0.3.2] - 2025-12-09

- Fixed required files and executable since the launcher file was moved.
- Fixed game version detection for Xbox version.
- Technical fixes and improvements.

## [0.3.1] - 2025-09-27

- Updated EternalModInjector download link.

## [0.3.0] - 2025-04-07

- Added notification to run EternalModInjector after deployment.
- Added button to open Vortex Downloads folder and changelog - folder icon in Mods toolbar.
