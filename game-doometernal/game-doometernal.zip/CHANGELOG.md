# Changelog

## Planned Improvements (Not Yet Released)

- Config and save modtypes, installers, and open buttons.

## [1.0.2] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [1.0.1] - 2026-08-30

- Fixed: EternalModInjector and mods installed from the Browse GameBanana page are now saved under their real file name. They previously used the numeric GameBanana file id, which left the mod folder unrecognisable and caused Vortex to delete the downloaded archive afterwards.

## [1.0.0] - 2026-08-17

- Added: "Browse GameBanana" page - browse the DOOM Eternal mod section inside Vortex, and a download started from it installs, enables and names itself like any managed mod
- Added: Update check for mods installed from the new page, shown with the "Check for Updates" button on the Mods page
- Added: Ad slots are hidden on the browse page, and ad links no longer open in your web browser
- Changed: The browse page asks you to confirm opening an external site once per Vortex session, instead of every time the page is opened
- Fixed: EternalModInjector lookups against GameBanana always failed, so the extension silently used its built-in download link and never reported an available update
- Fixed: EternalModInjector built-in download link, used only when GameBanana cannot be reached, pointed at a file that no longer exists

## [0.4.5] - 2026-08-11

- Added GOG support

## [0.4.4] - 2026-08-11

- Added Epic Games Store support

## [0.4.3] - 2026-08-05

- Added: Checking for updates now installs a missing requirement instead of reporting an update for something that is not installed
- Fixed: Updating a requirement now disables the version it replaces before the new one is installed, so the two cannot deploy on top of each other

## [0.4.2] - 2026-07-18

- Fixed: Minor technical changes.

## [0.4.1] - 2026-07-17

- Changed: EternalModInjector auto-download and update-check logic moved to the shared gamebanana_downloader.js module (no functional change)

## [0.4.0] - 2026-07-16

- Added: EternalModInjector downloads now automatically resolve the latest file from the GameBanana API - no more waiting for the extension to update the download link after an injector release (falls back to the last known link if the API is unreachable)
- Added: Update check for EternalModInjector when managing the game and when using the "Check for Updates" button on the Mods page - shows a notification with a download button when a newer version is available on GameBanana
- Added: Installed injector version is now shown in the Mods list entry.

## [0.3.6] - 2026-07-16

- Bump: EternalModInjector 6.66 Rev 3 N

## [0.3.5] - 2026-04-13

- Bump: EternalModInjector 6.66 Rev 3 L

## [0.3.4] - 2026-03-19

- Added: Button to download EternalModInjector - provides a means to update

## [0.3.3] - 2026-03-16

- Updated: EternalModInjector download link for game version 6.66 Rev3 I
- Added: Notification for Xbox users linking to manual file dump instructions

## [0.3.2] - 2025-12-09

- Fixed required files and executable since the launcher file was moved.
- Fixed game version detection for Xbox version.
- Technical fixes and improvements.

## [0.3.1] - 2025-09-27

- Updated EternalModInjector download link.

## [0.3.0] - 2025-04-07

- Added notification to run EternalModInjector after deployment.
- Added button to open Vortex Downloads folder and changelog - folder icon in Mods toolbar.
