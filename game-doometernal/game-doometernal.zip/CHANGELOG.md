# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):
- Config and save modtypes, installers, and open buttons.

## [0.3.0] - 2025-04-07
- Added notification to run EternalModInjector after deployment.
- Added button to open Vortex Downloads folder and changelog - folder icon in Mods toolbar.