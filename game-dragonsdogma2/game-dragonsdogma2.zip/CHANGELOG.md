# Changelog

## [0.5.0] - 2026-01-30

- Added: Installer for loose lua files - not installed properly by Fluffy
- Fixed: input undefined error when downloading Fluffy Mod Manager
- Fixed: path strings
- Added: Buttons to open Downloads folder, PCGamingWiki page, view changelog, and submit bug reports

## [0.4.3]

- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including Fluffy MM, to fail with wrong URL
- Removed 'site' from compatibleDownloads, as it would cause all mods from the Modding Tools domain the user has installed to show up as uninstalled mods in the mod list
