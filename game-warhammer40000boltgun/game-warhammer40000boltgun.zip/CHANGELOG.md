# Changelog

## [1.1.2] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.1.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [1.1.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [1.0.3] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyContent" for "Content") now install into the right place instead of a doubled folder.
- Added: UE4SS Load Order page to enable, disable and reorder UE4SS script and DLL mods.
- Added: LogicMods Load Order page to enable, disable and reorder Blueprint (LogicMods) mods.
- Added: Config and Save mod types, so config files and save files can be installed from Vortex (needs the game, the Vortex staging folder and Local AppData on the same drive).
- Added: "Open Paks Folder", "Open Binaries Folder", "Open Config Folder", "Open Saves Folder" and "Open Nexus Mods Page" buttons.
- Added: Vortex now notifies you when a newer UE4SS build is available.
- Added: A notification when a mod doesn't match any known layout and was installed as-is.
- Changed: The game now launches through its main executable (Warhammer 40,000 Boltgun.exe) instead of the shipping executable.

## [0.4.0] - 2026-04-06

- Added: UE4SS support

## [0.3.0]

- Initial release
