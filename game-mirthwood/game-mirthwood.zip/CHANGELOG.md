# Changelog

## [0.1.1] - 2025-05-14
- Changed BepinEx page and file IDs to strings to avoid errors with numeric IDs.

## [0.1.0] - 2025-04-22
- Initial release