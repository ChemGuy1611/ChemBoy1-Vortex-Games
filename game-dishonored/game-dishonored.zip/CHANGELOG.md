# Changelog

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Added a fallback installer: when no other installer matches a mod, Vortex now shows a notice and installs the files to the game folder.
- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyData" for "Data") now install into the right place instead of a doubled folder.
- Fixed: Mods made up only of loose package files (no containing folder) could fail to install.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.6.2] - 2026-05-06

- Fixed: Type error on race condition due to null path assignment

## [0.6.1] - 2025-11-16

- Further improvements to TFC mod installer.
- Add installer for .dll files to the "Binaries" folder.
- Added installer for .upk/.pck files to the "CookedPCConsole" folder.

## [0.6.0] - 2025-11-12

- Improved TFC mod installer to better handle different packaging methods.
- Fixed game version detection for Xbox version.
- Added installers for root folders ("DishonoredGame") and Movies files (.bik).

## [0.5.4] - 2025-09-18

- Improved TFC downloader to avoid potential issues.

## [0.5.3]

- Added extensions to detect TFC mods

## [0.5.2]

- Tweak TFC Mod installer criteria

## [0.5.1]

- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including TFC Installer, to fail with wrong URL
- Removed 'site' from compatibleDownloads, as it would cause all mods from the Modding Tools domain the user has installed to show up as uninstalled mods in the mod list

## [0.5.0]

- Improved support for TFC Installer and mods that use it
- Moved TFC mods to "TFC Installer\Mods" folder
- Added a tool for UPK Explorer if the user installs it to the game folder
