# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):

- Config and save modtypes, installers, and open buttons.

## [0.5.1] - 2025-05-28

- Added GOG version support.

## [0.5.0] - 2025-04-07

- Added notification to run DOOMModLoader after deployment.
- Added button to open Vortex Downloads folder and changelog - folder icon in Mods toolbar.