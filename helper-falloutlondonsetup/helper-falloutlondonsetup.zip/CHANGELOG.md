# Changelog

## [0.2.0] - 2026-10-21

- Added automatic enabling of the Fallout: London plugins when the falloutlondon mod is enabled.
- The falloutlondon mod is now added to Vortex, set to the "FOLON GOG Files" mod type and enabled automatically, with no 10-second time limit.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Added a button to open the Fallout: London Nexus Mods page.
- Added a button to submit a bug report for the FOLON Setup Helper.

## [0.1.6] - 2026-01-06

- Added a missing ini entry for "LondonWorldSpace - Textures14.ba2"

## [0.1.5] - 2025-07-09

- Changed some function calls to async.

## [0.1.4] - 2025-06-28

- Automated enabling and changing mod type for falloutlondon mod (Note this requires the user to respond to the "Accept Changes" prompt within 10 seconds to work).
- Setup function will now only run when FO4 game is activated in Vortex.

## [0.1.3] - 2025-06-25

- Improvements to notification with manual setup steps.
- Reduced logo file size.

## [0.1.2] - 2025-06-25

- Fixed test to prevent INI files being written on each startup after they'd been written the first time.
- Added instructions to the notification to enable the falloutlondon mod and plugins, in addition to changing the modtype.

## [0.1.1] - 2025-06-24

- Added partition check to ensure all 3 folders of interest are on the same drive partition (FO4 game, FOLON, FO4 Staging).
- Added some additional logging for debugging.
- Fixed error that would occur when installing other mods for FO4.

## [0.1.0] - 2025-06-23

- Initial release
