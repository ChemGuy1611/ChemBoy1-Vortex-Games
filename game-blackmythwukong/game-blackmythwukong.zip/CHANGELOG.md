# Changelog

## [1.0.4] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.3] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.2] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.

## [1.0.1] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.0.0] - 2026-09-21

- Migrated to file-based load order (FBLO); added a lock button, multi-select, and a right-click context menu to the Paks load order page.
- Added a UE4SS Load Order page and a LogicMods Load Order page for Blueprint pak mods.
- Added UE4SS load order support to Collections.
- Added: UE4SS and the Signature Bypass tool now download automatically and check for updates.
- Added a status filter to the load order pages.
- Added buttons to open the UE4SS settings file, the UE4SS mods.txt file, and the Vortex downloads folder.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Fixed: Updating a mod no longer moved it in the load order.
- Fixed: Mod files with no file extension were skipped during installation.
- Improved: Pak mods still carrying the old shared mod type are now retagged automatically instead of prompting you to reinstall them.
- Changed: UE4SS now downloads from its GitHub releases instead of this game's Nexus page, since that page is no longer maintained.

## [0.3.2] - 2026-02-03

- Improved: Made UE4SS Scripts, UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names

## [0.3.1] - 2026-02-01

- Fixed: Deploy notification not clearing on deploy

## [0.3.0] - 2026-01-30

- Added: Epic version support
- Fixed: Issue with Load Order sorting not working if certain other UE game extensions were installed. You will need to reinstall all pak mods to be able to sort them properly. A notification will be sent reminding you to do this.
- Added: Notification indicating deployment is required after changing the load order
- Fixed: Folder read permission poupus when installing UE4SS
- Fixed: Missing FOMOD installer check for pak mods
- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, and submit bug reports
