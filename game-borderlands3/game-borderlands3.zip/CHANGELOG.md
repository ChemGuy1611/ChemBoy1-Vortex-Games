# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.2.0] - 2025-09-21

- Converted from BL3 Hotfix Merger to Open Hotfix Loader (no need for running exe or using WebUI!).
- Added Python SDK support and auto-download (enables modding and loads plugins).
- Added installers for SDK mods (.py and .sdkmod files).
- Removed Plugin Loader as it is no longer needed with SDK.
- Fixed pathfinding for config and save folders.
- Added ignoreConflicts list for common files (i.e. LICENSE.txt, instructions.txt, readme.txt, etc.).
- Added tool for BL3 Save Editor.

## [0.1.0] - 2025-09-19

- Initial release.
