# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2025-10-24

- Fixed potential error when write checking Config folder and setting path to Saves folder.

## [0.1.0] - 2025-10-04

- Initial release
