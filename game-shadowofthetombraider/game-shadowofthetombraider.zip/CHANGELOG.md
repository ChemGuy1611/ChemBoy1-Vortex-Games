# Changelog

## Future Changes (Not Implemented Yet)

- None Planned

## [0.5.0] - 2025-10-29

- Improved game discovery reliability.
- Fixed Xbox game version detection.
- Disabled auto-download of Special K Plugin.

## [0.4.1]

- Added an installer for mods intended for the TR Reboot Mod Manager that did not include a top-level folder above the modified files.

## [0.4.0]

- Updated support for new version of the SOTTR Mod Manager (now TR Reboot Mod Manager)
- Added notificaiton to run TR Reboot Mod Manager after deployment
- Added fallback installer for root folder
