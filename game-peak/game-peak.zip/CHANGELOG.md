# Changelog

## Planned Improvements (Not Yet Released)

## [0.2.1] - 2026-09-28

- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Game version now shows the real game build instead of the Unity engine version.

## [0.2.0] - 2026-09-20

- Added: "Browse Thunderstore" page, which opens the PEAK Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [0.1.4] - 2026-09-13

- Updated: BepInExConfigManager now automatically checks for and installs the latest version instead of staying pinned to 18.4.1, and shows its proper name in the mod list
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.1.3] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.1.2] - 2026-04-22

- Added: Installer and download button for BepInEx Config Manager
- Bump: BepInEx version to 5.4.23.5
- Bump: BepInEx Config Manager to 18.4.1 - changed repo

## [0.1.1] - 2025-07-02

- Updated BepinEx auto-downloader to target version 5.4.23.3.

## [0.1.0] - 2025-06-27

- Initial release
