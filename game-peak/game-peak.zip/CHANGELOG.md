# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.1] - 2025-07-02

- Updated BepinEx auto-downloader to target version 5.4.23.3.

## [0.1.0] - 2025-06-27

- Initial release
