# Changelog

## [0.1.3] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.1.2] - 2026-04-22

- Added: Installer and download button for BepInEx Config Manager
- Bump: BepInEx version to 5.4.23.5
- Bump: BepInEx Config Manager to 18.4.1 - changed repo

## [0.1.1] - 2025-07-02

- Updated BepinEx auto-downloader to target version 5.4.23.3.

## [0.1.0] - 2025-06-27

- Initial release
