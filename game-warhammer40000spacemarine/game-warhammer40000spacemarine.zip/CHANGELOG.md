# Changelog

## [0.3.3] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [0.3.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [0.3.1] - 2026-10-16

- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Added the game's Nexus Mods ID to the extension's info file.

## [0.3.0] - 2026-08-03

- Fixed: Readme and changelog files inside mods no longer show up as file conflicts.
- Fixed: Paths are now built safely on all systems.
- Added: Buttons to open the game's PCGamingWiki page, view the changelog, submit a bug report, and open the downloads folder.

## [0.2.0] - 2025-08-18

- Added support for Master Crafted Edition (Steam, GOG, Epic, and Xbox versions).
- Improved reliability of game discovery.
- Added buttons to view the changelog and open the downloads folder.
- Updated game image.
