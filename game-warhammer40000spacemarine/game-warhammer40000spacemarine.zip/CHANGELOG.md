# Changelog

## Planned Improvements

- (UNCERTAIN) Installer for the preview folder???

## [0.2.0] - 2025-08-18

- Added support for Master Crafted Edition (Steam, GOG, Epic, and Xbox versions).
- Improved reliability of game discovery.
- Added buttons to view the changelog and open the downloads folder.
- Updated game image.
