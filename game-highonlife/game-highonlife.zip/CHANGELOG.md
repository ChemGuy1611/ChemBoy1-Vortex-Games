# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [2.0.0] - 2026-01-04

- Initial release
