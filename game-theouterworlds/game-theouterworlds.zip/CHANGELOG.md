# Changelog

## [1.2.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [1.2.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [1.1.5] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.1.4] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.3] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.2] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: Pak + UE4SS combo mods now show up on the UE4SS load order page on the Xbox / Game Pass version, instead of being listed as manual mods.
- Fixed: The "Open LogicMods Folder" button now opens the LogicMods folder instead of the Paks folder.

## [1.1.1] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.0] - 2026-09-19

- Dropped the Unreal Engine Mod Installer (UEMI) dependency - pak mod installation is now self-contained, and existing pak mods migrate automatically on update
- Added support for a FOMOD-packaged pak mod to correctly appear on the Load Order page

## [1.0.0] - 2026-09-17

- Migrated to file-based load order (FBLO) on the unified UE4-5 template; added lock button, multi-select, right-click context menu, UE4SS Load Order page
- Added UE4SS script/DLL/LogicMods mod support (new - not previously supported)
- Added a "Download UE4SS" button that downloads and installs the correct build automatically, and checks for UE4SS updates
- Added Save mod support (new - not previously supported)
- Kept Unreal Engine Mod Installer (UEMI) dependency for PAK installation - wired via a custom `loadOrderPrefixFunc` so FBLO correctly reorders UEMI-installed paks
- Fixed: Mod files with no file extension were skipped during installation

## [0.5.2] - 2026-05-28

- Fixed: Launching of Spacer's Choice Xbox version

## [0.5.1] - 2026-02-07

- Improved: Made Root folder installer case-insensitive

## [0.5.0] - 2026-02-02

- Fixed: Xbox version support for Spacer's Choice Edition
- Fixed: path strings
- Added: Custom launch tools for Classic and Spacer's Choice Edition
- Added: Buttons to open several files/folders/URLs
- Added: Deployment notification after changing the load order
- Fixed: Xbox game version detection
