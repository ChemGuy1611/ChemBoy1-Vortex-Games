# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- UE4SS support - Haven't seen any mods for it yet

## [0.5.1] - 2026-02-07

- Improved: Made Root folder installer case-insensitive

## [0.5.0] - 2026-02-02

- Fixed: Xbox version support for Spacer's Choice Edition
- Fixed: path strings
- Added: Custom launch tools for Classic and Spacer's Choice Edition
- Added: Buttons to open several files/folders/URLs
- Added: Deployment notification after changing the load order
- Fixed: Xbox game version detection
