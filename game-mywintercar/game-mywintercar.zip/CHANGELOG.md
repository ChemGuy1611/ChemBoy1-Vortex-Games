# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.0] - 2026-01-03

- Initial release
