# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.2.2] - 2026-01-12

- Removed some obsolete notification text related to MSCLoader installer.

## [0.2.1] - 2026-01-10

- Added customized MSCLoader installer to remove unnecessary checks. No longer requires deleting "BepInEx" and "Plugins" folders.

## [0.2.0] - 2026-01-09

- Added MSCLoader as mod loader option. Note that you still must choose only ONE loader.
- Added support for Texture Pack Loader and its mods (depends on MSCLoader).
- Added tool to launch MWCEditor (save editor) if installed.

## [0.1.0] - 2026-01-03

- Initial release
