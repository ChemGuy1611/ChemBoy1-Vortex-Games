# Changelog

## [0.4.1]
- Made game discovery more reliable
- Corrected a typo in a modtype id
- Added buttons to manually start RealRTCW and ioRTCW download processes (folder icon in Mods toolbar)

## [0.4.0]
- Improved notification to download RealRTCW or ioRTCW to automate the process
- Cleaned up code