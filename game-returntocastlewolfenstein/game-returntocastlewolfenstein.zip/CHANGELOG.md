# Changelog

## [1.1.2] - 2026-10-09

- Fixed: RealRTCW was downloaded automatically at startup. It is now only downloaded when you choose "Download RealRTCW" in the notification (or use the toolbar button), so you can use ioRTCW instead without RealRTCW being installed on top
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.1] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [1.1.0] - 2026-08-29

- Added: A page to browse mods on ModDB and install them without leaving Vortex

## [1.0.1] - 2026-08-05

- Added: Checking for updates now installs a missing requirement instead of reporting an update for something that is not installed
- Fixed: Updating a requirement now disables the version it replaces before the new one is installed, so the two cannot deploy on top of each other

## [1.0.0] - 2026-08-03

- Automated the RealRTCW download - Vortex now finds the latest version on ModDB and installs it for you
- Added a notification when a new version of RealRTCW is released
- Removed the ioRTCW download option - RealRTCW is the actively maintained fork. ioRTCW can still be installed manually and launched from the tools list

## [0.4.1]

- Made game discovery more reliable
- Corrected a typo in a modtype id
- Added buttons to manually start RealRTCW and ioRTCW download processes (folder icon in Mods toolbar)

## [0.4.0]

- Improved notification to download RealRTCW or ioRTCW to automate the process
- Cleaned up code
