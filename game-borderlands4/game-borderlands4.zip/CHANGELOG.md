# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- tool to launch bl4-crypt (by Cr4nkSt4r, naked exe file)

## [0.2.1] - 2025-09-26

- Fixed Documents folder discovery to work correctly with OneDrive paths.
- Added tool to launch BL4-Gear-N-Gun-Editor (by Awsam, Python required).

## [0.2.0] - 2025-09-25

- Installs pak mods directly to the "OakGame/Content/Paks" folder. This is thanks to Gearbox Software and their patch. This also means Load order is no longer supported.
- Added Epic version ID and full support.
- Added tool to launch BL4 Save Editor (by J_SUEY).
- Added .yaml extension to the save file installer.
- Fixed Save path (added "Profiles/client" to end of path).

## [0.1.0] - 2025-09-12

- Corrected config and save paths (Documents).

## [0.1.0] - 2025-09-11

- Initial release
