# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.0] - 2025-09-12

- Corrected config and save paths (Documents).

## [0.1.0] - 2025-09-11

- Initial release
