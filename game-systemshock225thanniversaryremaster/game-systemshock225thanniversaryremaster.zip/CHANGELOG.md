# Changelog

## Future Improvements (NOT implemented yet)

- ? Automatically detect and convert legacy SS2 mods to .kpf format? (Not sure if this is feasible).

## [0.2.0] - 2025-06-30

- Added installer to convert legacy mods to .kpf format for this remaster. Note that some .kpf files created by the installer may not always work if there are issues with the original mods.
- Added "systemshock2" domain to compatibleDownloads.
- Added tool to launch the game with custom command line arguements (specified by the user).

## [0.1.0] - 2025-06-30

- Initial release
