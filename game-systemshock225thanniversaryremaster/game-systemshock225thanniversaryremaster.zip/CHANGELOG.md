# Changelog

## Future Improvements (NOT implemented yet)

- None Planned

## [0.1.0] - 2025-06-30
- Initial release