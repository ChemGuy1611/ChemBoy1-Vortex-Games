# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2026-02-19

- Added: SaveEditor support (installer and launch tool)
- Fixed: Mod order instructions now clarify that mods higher up take priority over mods lower
- Removed: Unnecessary mod count launch parameter

## [0.1.0] - 2026-02-13

- Inital Release
