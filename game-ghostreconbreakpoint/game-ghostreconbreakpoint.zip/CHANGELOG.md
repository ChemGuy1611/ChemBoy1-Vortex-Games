# Changelog

## [1.0.0] - 2026-09-21

- Migrated to `template-anvilengine` (full DLC folder / .forge routing / ResoRep-ready toggle set).
- Added: DLC folder support. `.forge` mods for the Gold Edition DLC (dlc_10) now install into the correct DLC folder automatically instead of the base game folder.
- Fixed: Mod files with no file extension were skipped during installation.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.2.9] - 2026-08-11

- Added: Epic Games Store support
- Fixed: Steam version launch error

## [0.2.8] - 2026-04-06

- Fixed: Prevent folder rename dialogue from calling when mod info is missing.

## [0.2.7] - 2026-03-28

- Fixed: Handle case where user clicks "Rename" button in the folder rename dialog without entering anything in the text box.

## [0.2.6] - 2026-01-31

- Improved: Reliablity of ATK downloader function
- Fixed: Incorrect folder write check path causing inability to deploy mods
- Fixed: path strings
- Fixed: Several minor bugs

## [0.2.5] - 2025-11-12

- Quickfix to handle more edge cases with .forge folder rename dialog.

## [0.2.4] - 2025-11-09

- Improved handling of user input in .forge folder rename dialog.

## [0.2.3] - 2025-04-11

- Added extra checks and error handling for .forge folder rename dialog.
- Added button to open changelog in Mods toolbar.

## [0.2.2] - 2025-04-04

- Added option to open a dialog popup to rename .forge folder.

## [0.2.1] - 2025-04-02

- Added button to open Nexus Mods mod page for mods that require manual folder renaming and the fallback installer.

## [0.2.0] - 2025-04-02

- Added a missing folder write check for Individual Buildtables that could prevent deployment if you hadn't extracted the files beforehand.
- Added notification to run ATK after deployment.
- Added several installers and notifications to the user when installing mods for ATK that will require user intervetion to rename folders.
- Added button to open Vortex Downloads folder and the game settings INI - folder icon in Mods toolbar.
