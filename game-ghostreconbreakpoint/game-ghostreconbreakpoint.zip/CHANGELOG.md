# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.2.5] - 2025-11-12

- Quickfix to handle more edge cases with .forge folder rename dialog.

## [0.2.4] - 2025-11-09

- Improved handling of user input in .forge folder rename dialog.

## [0.2.3] - 2025-04-11

- Added extra checks and error handling for .forge folder rename dialog.
- Added button to open changelog in Mods toolbar.

## [0.2.2] - 2025-04-04

- Added option to open a dialog popup to rename .forge folder.

## [0.2.1] - 2025-04-02

- Added button to open Nexus Mods mod page for mods that require manual folder renaming and the fallback installer.

## [0.2.0] - 2025-04-02

- Added a missing folder write check for Individual Buildtables that could prevent deployment if you hadn't extracted the files beforehand.
- Added notification to run ATK after deployment.
- Added several installers and notifications to the user when installing mods for ATK that will require user intervetion to rename folders.
- Added button to open Vortex Downloads folder and the game settings INI - folder icon in Mods toolbar.
