# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.2.4] - 2025-XX-XX

- Several technical fixes and improvements.
- Added buttons to open several useful files and folders (inside folder icon on Mods page toolbar).
