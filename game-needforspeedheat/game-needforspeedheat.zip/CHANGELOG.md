# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.0] - 2026-06-15

- Initial Release
