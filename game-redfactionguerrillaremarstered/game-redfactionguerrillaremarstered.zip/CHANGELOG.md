# Changelog

## FUTURE Improvements (Not Implemented Yet)

- None Planned

## [0.2.0] - 2025-10-04

- Added automation for which mod manager to use (remastered or legacy) based on the managed game version.
- Several technical fixes and improvements.
