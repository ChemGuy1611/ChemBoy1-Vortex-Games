/*/////////////////////////////////////////
Name: Borderlands Vortex Extension
Structure: UE2/3 Game (TFC Installer)
Author: ChemBoy1
Version: 1.0.3
Date: 2026-11-15
/////////////////////////////////////////*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const { actions, fs: vfs, util, selectors, log, VortexError } = require("vortex-api");
const path = require("path");
const template = require("string-template");
//const winapi = require('winapi-bindings');
const {
  download,
  findModByFile,
  findDownloadIdByFile,
  resolveVersionByModVersion,
  testRequirementVersion,
} = require("./downloader");

//const USER_HOME = util.getVortexPath("home");
const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath('appData');
//const LOCALAPPDATA = util.getVortexPath('localAppData');

//Specify all the information about the game
const GAME_ID = "borderlands";
const STEAMAPP_ID = "8989";
const STEAMAPP_ID_GOTY = "729040";
const EPICAPP_ID = null;
const GOGAPP_ID = null;
const XBOXAPP_ID = null;
const XBOXEXECNAME = null;
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID_GOTY, STEAMAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const GAME_NAME = "Borderlands";
const GAME_NAME_SHORT = "Borderlands";
const EPIC_CODE_NAME = "WillowGame";

//feature toggles
let hasXbox = false; //toggle for Xbox version logic
if (DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID)) hasXbox = true;
const has64Bit = true; //toggle for 64-bit version logic
const allowSymlinks = true; //true if game can use symlinks without issues. Typically needs to be false if files have internal references (i.e. pak/ucas/utoc or ba2/esp)
const fallbackInstaller = true; //enable fallback installer. Set false if you need to avoid installer collisions
const setupNotification = false; //enable to show the user a notification with special instructions (specify below)
const upkFolderPicker = false; //true to ask where loose .upk files go (main CookedPC folder or one of the DLCSUB_FOLDERS) when the archive has no recognized folder
const debug = false; //toggle for debug mode

const SPECIAL_TFCMOD_FOLDERS = [];

const ROOT_FOLDERS = [EPIC_CODE_NAME, "Engine", "Binaries"];
const COOKED_FOLDER = "CookedPC";
const ROOTSUB_FOLDERS = ["Config", COOKED_FOLDER, "Localization", "Movies", "Splash"];
const COOKEDSUB_FOLDERS = ["DLC", "Maps", "Mods", "Packages", "Patch", "Test", "UI"];
const BINARIES_PATH = path.join("Binaries");
const EXEC_NAME = "Borderlands.exe";
const EXEC = path.join(BINARIES_PATH, EXEC_NAME);
const EXEC_NAME_GOTY = "BorderlandsGOTY.exe";
const BINARIES_PATH_GOTY = path.join("Binaries", "Win64");
const EXEC_GOTY = path.join(BINARIES_PATH_GOTY, EXEC_NAME_GOTY);
const DATA_FOLDER = path.join("Borderlands", "WillowGame");

let GAME_PATH = ""; //patched in the setup function to the discovered game path
let GAME_VERSION = ""; //Game version
let STAGING_FOLDER = ""; //Vortex staging folder path
let DOWNLOAD_FOLDER = ""; //Vortex download folder path
let BINARIES_TARGET = "";

//Information for mod types and installers
const TFC_ID = `${GAME_ID}-tfcinstaller`;
const TFC_NAME = "TFC Installer";
const TFC_EXEC = "tfcinstaller.exe";
const TFC_FOLDER = "TFCInstaller";
const TFC_PATH = ".";
const TFC_PAGE_NO = 588;
const TFC_FILE_NO = 12777;

const UPKEXPLORER_ID = `${GAME_ID}-tfcexplorer`;
const UPKEXPLORER_NAME = "UPK Explorer";
const UPKEXPLORER_EXEC = "upk explorer.exe";
const UPKEXPLORER_FOLDER = "UPK Explorer";
const UPKEXPLORER_PATH = path.join(".");

const TFCMOD_ID = `${GAME_ID}-tfcmod`;
const TFCMOD_NAME = "TFC Mod";
const TFCMOD_EXTS = [".packagepatch", ".descriptor", ".tfcmapping", ".inipatch"];
const TFCMOD_FILES = [
  "gameprofile.xml",
  "gameprofile.idremappings.xml",
  "objectdescriptors.xml",
  "packageextensions.xml",
  `texturepack`,
  "game",
];
const TFCMOD_PATH = path.join(TFC_FOLDER, "Mods");

const SDK_ID = `${GAME_ID}-sdk`;
const SDK_NAME = "Python SDK";
const SDK_FOLDER = "sdk_mods";
const SDK_DLL = "unrealsdk.dll";
const SDK_PATH = ".";
const SDK_URL_API = `https://api.github.com/repos/bl-sdk/willow1-mod-manager`;
const SDK_ARC_NAME = "bl1-sdk.zip"; //original Borderlands
const SDK_ARC_NAME_ENHANCED = "bl1-enhanced-sdk.zip"; //Borderlands Game of the Year Enhanced

//The SDK ships a separate build per game version, so each one gets its own requirement.
const REQUIREMENTS = [
  {
    //Python SDK - original Borderlands
    archiveFileName: SDK_ARC_NAME,
    modType: SDK_ID,
    assemblyFileName: SDK_DLL,
    userFacingName: SDK_NAME,
    githubUrl: SDK_URL_API,
    findMod: (api) => findModByFile(api, SDK_ID, SDK_DLL),
    findDownloadId: (api) => findDownloadIdByFile(api, SDK_ARC_NAME),
    fileArchivePattern: new RegExp(/^bl1-sdk/, "i"), //no capture group - the version is only in the release tag
    resolveVersion: (api) => resolveVersionByModVersion(api, REQUIREMENTS[0]),
  },
];
const REQUIREMENTS_ENHANCED = [
  {
    //Python SDK - Game of the Year Enhanced
    archiveFileName: SDK_ARC_NAME_ENHANCED,
    modType: SDK_ID,
    assemblyFileName: SDK_DLL,
    userFacingName: SDK_NAME,
    githubUrl: SDK_URL_API,
    findMod: (api) => findModByFile(api, SDK_ID, SDK_DLL),
    findDownloadId: (api) => findDownloadIdByFile(api, SDK_ARC_NAME_ENHANCED),
    fileArchivePattern: new RegExp(/^bl1-enhanced-sdk/, "i"), //no capture group - the version is only in the release tag
    resolveVersion: (api) => resolveVersionByModVersion(api, REQUIREMENTS_ENHANCED[0]),
  },
];

const SDKMOD_ID = `${GAME_ID}-sdkmod`;
const SDKMOD_NAME = "SDK Mod";
const SDKMOD_EXT = ".py";
const SDKMOD_EXT2 = ".sdkmod";
const SDKMOD_PATH = SDK_FOLDER;

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Folder";

const ROOTSUB_ID = `${GAME_ID}-rootsub`;
const ROOTSUB_NAME = "Root Sub Folder";
const ROOTSUB_PATH = path.join(EPIC_CODE_NAME);

const COOKEDSUB_ID = `${GAME_ID}-cookedsub`;
const COOKEDSUB_NAME = "Cooked Sub Folder";
const COOKEDSUB_PATH = path.join(ROOTSUB_PATH, COOKED_FOLDER);
const COOKEDSUB_EXTS = [".upk", ".u"];
const UPKPICKER_EXTS = [".upk"]; //extensions that trigger the install folder picker (upkFolderPicker toggle)
const DLCSUB_PATH = path.join(EPIC_CODE_NAME, COOKED_FOLDER, "DLC"); //folder (relative to the game root) that holds the DLCSUB_FOLDERS
const DLCSUB_FOLDERS = [];

const BINARIES_ID = `${GAME_ID}-binaries`;
const BINARIES_NAME = "Binaries (Engine Injector)";
const BINARIES_FILES = [EXEC_NAME, EXEC_NAME_GOTY];
const BINARIES_EXTS = [".dll", ".asi", ".addon64"];

const MOVIES_ID = `${GAME_ID}-movies`;
const MOVIES_NAME = "Movies";
const MOVIES_PATH = path.join(EPIC_CODE_NAME, "Movies");
const MOVIES_EXTS = [".bik"];

const CONFIG_PATH = path.join(DOCUMENTS, "My Games", DATA_FOLDER, "Config");
const SAVE_PATH = path.join(DOCUMENTS, "My Games", "Borderlands", "SaveData");

const REQ_FILE = EPIC_CODE_NAME;
let MODTYPE_FOLDERS = [TFCMOD_PATH, SDKMOD_PATH];
const IGNORE_CONFLICTS = [
  path.join("**", "LICENSE.txt"),
  path.join("**", "instructions.txt"),
  path.join("**", "CHANGELOG.md"),
  path.join("**", "readme.txt"),
  path.join("**", "README.txt"),
  path.join("**", "ReadMe.txt"),
  path.join("**", "Readme.txt"),
  path.join("**", "license!(*.*)"),
  path.join("**", "license*.{txt,md,rtf,pdf,html,htm}"),
];
const PARAMETERS = ["-nostartupmovies"];

//Filled in from the data above
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1450"; //Nexus link to this extension. Used for links
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Borderlands";
const STEAMDB_URL = `https://steamdb.info/app/${STEAMAPP_ID}/`;
const IGNORE_DEPLOY = [
  path.join("**", "change?([-_ ])log!(*.*)"),
  path.join("**", "change?([-_ ])log*.{txt,md,rtf,pdf,html,htm}"),
  path.join("**", "read?([-_ ])me!(*.*)"),
  path.join("**", "read?([-_ ])me*.{txt,md,rtf,pdf,html,htm}"),
  path.join("**", "license!(*.*)"),
  path.join("**", "license*.{txt,md,rtf,pdf,html,htm}"),
];
const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    shortName: GAME_NAME_SHORT,
    //"executable": EXEC,
    parameters: PARAMETERS,
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    modPath: ".",
    modPathIsRelative: true,
    requiresCleanup: true,
    requiredFiles: [REQ_FILE],
    details: {
      steamAppId: STEAMAPP_ID_GOTY,
      gogAppId: GOGAPP_ID,
      epicAppId: EPICAPP_ID,
      xboxAppId: XBOXAPP_ID,
      supportsSymlinks: allowSymlinks,
      ignoreConflicts: IGNORE_CONFLICTS,
      ignoreDeploy: IGNORE_DEPLOY,
    },
    environment: {
      SteamAPPId: STEAMAPP_ID_GOTY,
      GogAPPId: GOGAPP_ID,
      EpicAPPId: EPICAPP_ID,
      XboxAPPId: XBOXAPP_ID,
    },
  },
  modTypes: [
    {
      id: SDK_ID,
      name: SDK_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", SDK_PATH),
    },
    {
      id: SDKMOD_ID,
      name: SDKMOD_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", SDKMOD_PATH),
    },
    {
      id: TFCMOD_ID,
      name: TFCMOD_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", TFCMOD_PATH),
    },
    {
      id: ROOT_ID,
      name: ROOT_NAME,
      priority: "high",
      targetPath: `{gamePath}`,
    },
    {
      id: ROOTSUB_ID,
      name: ROOTSUB_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", ROOTSUB_PATH),
    },
    {
      id: COOKEDSUB_ID,
      name: COOKEDSUB_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", COOKEDSUB_PATH),
    },
    {
      id: MOVIES_ID,
      name: MOVIES_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", MOVIES_PATH),
    },
    {
      id: TFC_ID,
      name: TFC_NAME,
      priority: "low",
      targetPath: path.join("{gamePath}", TFC_PATH),
    },
    {
      id: UPKEXPLORER_ID,
      name: UPKEXPLORER_NAME,
      priority: "low",
      targetPath: path.join("{gamePath}", UPKEXPLORER_PATH),
    },
  ],
  discovery: {
    ids: DISCOVERY_IDS_ACTIVE,
    names: [],
  },
};

//3rd party tools and launchers
const tools = [
  {
    id: `${GAME_ID}-customlaunch`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC,
    requiredFiles: [EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  {
    id: `${GAME_ID}-customlaunchgoty`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC_GOTY,
    requiredFiles: [EXEC_GOTY],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  {
    id: TFC_ID,
    name: TFC_NAME,
    logo: "tfc.png",
    executable: () => TFC_EXEC,
    requiredFiles: [TFC_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
  },
  {
    id: UPKEXPLORER_ID,
    name: UPKEXPLORER_NAME,
    logo: "tfc.png",
    executable: () => UPKEXPLORER_EXEC,
    requiredFiles: [UPKEXPLORER_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
  },
];

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

//Set mod type priorities

// vortex-api's fs.ensureFileAsync is deprecated; this is the node equivalent.
async function ensureFileAsync(filePath) {
  await fsp.mkdir(path.dirname(filePath), { recursive: true });
  const handle = await fsp.open(filePath, "a");
  await handle.close();
}

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath:
        (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
          ? void 0
          : _a.path,
      documents: util.getVortexPath("documents"),
      localAppData: util.getVortexPath("localAppData"),
      appData: util.getVortexPath("appData"),
    });
  } catch (err) {
    //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification(
      "Failed to locate executable. Please launch the game at least once.",
      err,
    );
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () =>
    util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
}

//set launcher requirements
async function requiresLauncher(gamePath, store) {
  if (store === "xbox" && DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID)) {
    return Promise.resolve({
      launcher: "xbox",
      addInfo: {
        appId: XBOXAPP_ID,
        parameters: [{ appExecName: XBOXEXECNAME }],
        //parameters: [{ appExecName: XBOXEXECNAME }, PARAMETERS_STRING],
        //launchType: 'gamestore',
      },
    });
  } //*/
  if (store === "epic" && DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID)) {
    return Promise.resolve({
      launcher: "epic",
      addInfo: {
        appId: EPICAPP_ID,
        //parameters: PARAMETERS,
        //launchType: 'gamestore',
      },
    });
  } //*/
  /*
  if (store === 'steam') {
    return Promise.resolve({
      launcher: 'steam',
      addInfo: {
        appId: STEAM_ID,
        //parameters: PARAMETERS,
        //launchType: 'gamestore',
      } //
    });
  } //*/
  return Promise.resolve(undefined);
}

//Get correct shipping executable for game version
function getExecutable(gamePath) {
  const isCorrectExec = (exec) => {
    try {
      fs.statSync(path.join(gamePath, exec));
      return true;
    } catch {
      return false;
    }
  };
  if (isCorrectExec(EXEC_GOTY)) {
    BINARIES_TARGET = path.join("{gamePath}", BINARIES_PATH_GOTY);
    MODTYPE_FOLDERS.push(BINARIES_PATH_GOTY);
    return EXEC_GOTY;
  }
  BINARIES_TARGET = path.join("{gamePath}", BINARIES_PATH);
  MODTYPE_FOLDERS.push(BINARIES_PATH);
  return EXEC;
}

//Get correct game version
async function setGameVersion(gamePath) {
  if (has64Bit && (await statCheckAsync(gamePath, EXEC_GOTY))) {
    GAME_VERSION = "enhanced";
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC)) {
    GAME_VERSION = "default";
    return GAME_VERSION;
  }
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? {};
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}
async function deploy(api) {
  //useful to deploy mods after doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

// AUTOMATIC MOD DOWNLOADERS ///////////////////////////////////////////////////

//Check if TFC is installed
function isTfcInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === TFC_ID);
}

//Check which game version is installed so the matching SDK build is requested
function isEnhanced(gamePath) {
  try {
    fs.statSync(path.join(gamePath, EXEC_GOTY));
    return true;
  } catch {
    return false;
  }
}

//Get the requirements for the installed game version
function getRequirements(api) {
  return isEnhanced(getDiscoveryPath(api)) ? REQUIREMENTS_ENHANCED : REQUIREMENTS;
}

// AUTO-DOWNLOADER FUNCTIONS ///////////////////////////////////////////////////

async function asyncForEachTestVersion(api, requirements) {
  for (let index = 0; index < requirements.length; index++) {
    await testRequirementVersion(api, requirements[index]);
  }
}

async function asyncForEachCheck(api, requirements) {
  let mod = [];
  for (let index = 0; index < requirements.length; index++) {
    mod[index] = await requirements[index].findMod(api);
  }
  let checker = mod.every((entry) => entry !== undefined); //findMod resolves to a mod object or undefined, never a boolean
  return checker;
}

async function onCheckModVersion(api, gameId, mods, forced) {
  try {
    await asyncForEachTestVersion(api, getRequirements(api));
    log("warn", "Checked requirements versions");
  } catch (err) {
    log("warn", `Failed to test requirement version: ${err}`);
  }
}

async function checkForRequirements(api) {
  const CHECK = await asyncForEachCheck(api, getRequirements(api));
  return CHECK;
}

//* Function to auto-download TFC from Nexus Mods
async function downloadTfc(api, gameSpec) {
  let isInstalled = isTfcInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = TFC_NAME;
    const MOD_TYPE = TFC_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    let FILE_ID = TFC_FILE_NO; //If using a specific file id because "input" below gives an error
    const PAGE_ID = TFC_PAGE_NO;
    const GAME_DOMAIN = "site";
    api.sendNotification({
      //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) {
      //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = FILE_ID; //use the FILE_ID directly for the correct game store version
      let URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      try {
        //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter((file) => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new VortexError(`No ${MOD_NAME} main file found`, { kind: "process-canceled" });
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch {
        // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } //*/
      const dlInfo = {
        //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await new Promise((resolve, reject) =>
        api.events.emit(
          "start-download",
          [URL],
          dlInfo,
          undefined,
          (err, result) => (err ? reject(err) : resolve(result)),
          undefined,
          {
            allowInstall: false,
          },
        ),
      );
      const modId = await new Promise((resolve, reject) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, (err, result) =>
          err ? reject(err) : resolve(result),
        ),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      try {
        window.api.shell.openUrl(errPage);
      } catch (openErr) {
        api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
      }
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for Fluffy Mod Manager files
function testTfc(files, gameId) {
  const isTFC = files.some((file) => path.basename(file).toLowerCase() === TFC_EXEC);
  let supported = gameId === spec.game.id && isTFC;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Fluffy Mod Manger files
function installTfc(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === TFC_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: TFC_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(TFC_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Fluffy Mod Manager files
function testUpkExplorer(files, gameId) {
  const isUpk = files.some((file) => path.basename(file).toLowerCase() === UPKEXPLORER_EXEC);
  let supported = gameId === spec.game.id && isUpk;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Fluffy Mod Manger files
function installUpkExplorer(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === UPKEXPLORER_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: UPKEXPLORER_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(UPKEXPLORER_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test Fallback installer for TFC Mods
function testTfcMod(files, gameId) {
  const isExt = files.some((file) => TFCMOD_EXTS.includes(path.extname(file).toLowerCase()));
  const isFile = files.some((file) => TFCMOD_FILES.includes(path.basename(file).toLowerCase()));
  let supported = gameId === spec.game.id && (isExt || isFile);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer for TFC Mods
function installTfcMod(files, fileName) {
  const MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");
  const setModTypeInstruction = { type: "setmodtype", value: TFCMOD_ID };
  let modFile = files.find((file) => TFCMOD_FILES.includes(path.basename(file).toLowerCase())); //try files first
  if (modFile === undefined) {
    modFile = files.find((file) => TFCMOD_EXTS.includes(path.extname(file).toLowerCase())); //exts fallback
  }
  //let idx = modFile.lastIndexOf(path.basename(modFile));
  let rootPath = path.dirname(modFile);
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== ".") {
    MOD_FOLDER = "."; //no top level folder needed if it's already included in the archive
    modFile = rootPath; //make the folder the targeted modFile so we can grab any other folders also in its directory
    rootPath = path.dirname(modFile);
    /*const indexFolder = path.basename(modFile); //index to catch other folders in the same directory
    //idx = modFile.indexOf(`${indexFolder}${path.sep}`); //index on the folder with path separator //*/
  }
  //these are special cases for mods that have multiple levels of folders in the archive
  if (files.some((file) => SPECIAL_TFCMOD_FOLDERS.includes(path.basename(file)))) {
    modFile = files.find((file) => SPECIAL_TFCMOD_FOLDERS.includes(path.basename(file)));
    rootPath = path.dirname(modFile);
    /*const indexFolder = path.basename(modFile); //index to catch other folders in the same directory
    //idx = modFile.indexOf(`${indexFolder}${path.sep}`); //index on the folder with path separator //*/
  }
  const idx = modFile.lastIndexOf(path.basename(modFile));

  // Remove empty directories and anything that isn't in the rootPath
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Fluffy Mod Manager files
function testSdk(files, gameId) {
  const isFile = files.some((file) => path.basename(file).toLowerCase() === SDK_DLL);
  const isFolder = files.some((file) => path.basename(file).toLowerCase() === SDK_FOLDER);
  let supported = gameId === spec.game.id && isFile && isFolder;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Fluffy Mod Manger files
function installSdk(files) {
  const MOD_TYPE = SDK_ID;
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SDK_FOLDER);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test Fallback installer for SDK Mods
function testSdkMod(files, gameId) {
  const isMod = files.some((file) => path.extname(file).toLowerCase() === SDKMOD_EXT);
  const isMod2 = files.some((file) => path.extname(file).toLowerCase() === SDKMOD_EXT2);
  let supported = gameId === spec.game.id && (isMod || isMod2);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer for SDK Mods
function installSdkMod(files, fileName) {
  const MOD_TYPE = SDKMOD_ID;
  let modFile = files.find((file) => path.extname(file).toLowerCase() === SDKMOD_EXT2);
  if (modFile === undefined) {
    modFile = files.find((file) => path.extname(file).toLowerCase() === SDKMOD_EXT);
  }
  let MOD_FOLDER = ".";
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const ROOT_PATH = path.basename(path.dirname(modFile));
  const MOD_NAME = path.basename(fileName);
  if (ROOT_PATH === ".") {
    MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");
  }
  const setModTypeInstruction = { type: "setmodtype", value: MOD_TYPE };

  // Remove empty directories
  const filtered = files.filter((file) => !file.endsWith(path.sep));

  let instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(MOD_FOLDER, file),
    };
  });
  if (path.extname(modFile).toLowerCase() === SDKMOD_EXT2) {
    //index to .sdkmod file if it exists
    instructions = filtered.map((file) => {
      return {
        type: "copy",
        source: file,
        destination: path.join(file.substr(idx)),
      };
    });
  }

  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map((str) => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map((str) => str.toLowerCase());
  const DLCSUB_FOLDERS_LOWER = DLCSUB_FOLDERS.map((str) => str.toLowerCase());
  const isMod = files.some((file) =>
    ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  const isSub = files.some((file) =>
    ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  const isDlcSub = files.some((file) =>
    DLCSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  let supported = gameId === spec.game.id && (isMod || isSub || isDlcSub);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installRoot(files) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map((str) => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map((str) => str.toLowerCase());
  const DLCSUB_FOLDERS_LOWER = DLCSUB_FOLDERS.map((str) => str.toLowerCase());
  let modFile = files.find((file) =>
    ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  let setModTypeInstruction = { type: "setmodtype", value: ROOT_ID };
  if (modFile === undefined) {
    modFile = files.find((file) =>
      ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
    );
    setModTypeInstruction = { type: "setmodtype", value: ROOTSUB_ID };
  }
  let folder = "";
  if (modFile === undefined) {
    modFile = files.find((file) =>
      DLCSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
    );
    folder = DLCSUB_PATH;
  }
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`;
  const idx = modFile.lastIndexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test .bik files
function testMovies(files, gameId) {
  const isMod = files.some((file) => MOVIES_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer test for CookedPC folders/files
function testCookedSub(files, gameId) {
  const isFolder = files.some((file) => COOKEDSUB_FOLDERS.includes(path.basename(file)));
  const isExt = files.some((file) => COOKEDSUB_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = gameId === spec.game.id && (isFolder || isExt);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install CookedPC folders/files
async function installCookedSub(
  api,
  files,
  destinationPath,
  gameId,
  progressDel,
  choices,
  unattended,
  archivePath,
) {
  let modFile = files.find((file) => COOKEDSUB_FOLDERS.includes(path.basename(file)));
  let idx;
  let folder = ""; //stays empty for the main CookedPC folder, set to a DLC folder by the picker
  let skipPrefixes = []; //folders of the variants the user did not choose
  if (modFile === undefined) {
    modFile = files.find((file) => COOKEDSUB_EXTS.includes(path.extname(file).toLowerCase()));
    const pickerFiles = files.filter((file) =>
      UPKPICKER_EXTS.includes(path.extname(file).toLowerCase()),
    );
    // Folder picker: only for loose package files, and never on an unattended (collection or dependency) install.
    if (upkFolderPicker && pickerFiles.length > 0 && unattended !== true) {
      if (DLCSUB_FOLDERS.length > 0) {
        const downloads = api.getState()?.persistent?.downloads?.files ?? {};
        const archive = Object.values(downloads).find((arc) =>
          archivePath?.endsWith(arc.localPath),
        );
        const nexusModId = archive?.modInfo?.nexus?.ids?.modId;
        const choice = await api.showDialog(
          "question",
          "Select Install Directory for .upk Files",
          {
            bbcode:
              "Select the Install Destination for the .upk mod files you are installing.[br][/br][br][/br]" +
              "Read the mod's description to determine the correct location.[br][/br][br][/br]" +
              (nexusModId !== undefined
                ? `[url=https://www.nexusmods.com/${GAME_ID}/mods/${nexusModId}]VIEW MOD PAGE[/url][br][/br][br][/br]`
                : "[br][/br]"),
            choices: [{ id: "main", text: `Main - ${COOKEDSUB_PATH}`, value: true }].concat(
              DLCSUB_FOLDERS.map((dlc) => ({
                id: dlc,
                text: `DLC - ${path.join(DLCSUB_PATH, dlc)}`,
                value: false,
              })),
            ),
            options: { order: ["bbcode", "choices"], wrap: true },
          },
          [{ label: "Cancel" }, { label: "Install" }],
        );
        if (choice.action === "Cancel") {
          throw new VortexError("User canceled", { kind: "user-canceled", skipped: false });
        }
        const selected = Object.keys(choice.input).find((iter) => choice.input[iter]);
        if (selected !== undefined && selected !== "main") {
          folder = path.join(DLCSUB_PATH, selected);
        }
      }

      // Variants: the same package file name in more than one folder of the archive.
      const byName = pickerFiles.reduce((accum, iter) => {
        const name = path.basename(iter).toLowerCase();
        accum[name] = (accum[name] ?? []).concat(iter);
        return accum;
      }, {});
      const variantName = Object.keys(byName).find((name) => byName[name].length > 1);
      if (variantName !== undefined) {
        const variants = byName[variantName];
        const res = await api.showDialog(
          "question",
          "Choose Variant",
          {
            text:
              'This mod has several variants for "{{file}}" - please ' +
              "choose the variant you wish to install. (You can choose a " +
              "different variant by re-installing the mod)",
            choices: variants.map((iter, index) => ({ id: iter, text: iter, value: index === 0 })),
            parameters: { file: path.basename(variants[0]) },
          },
          [{ label: "Cancel" }, { label: "Confirm" }],
        );
        if (res.action !== "Confirm") {
          throw new VortexError("User canceled", { kind: "user-canceled", skipped: false });
        }
        modFile = Object.keys(res.input).find((iter) => res.input[iter]) ?? variants[0];
        skipPrefixes = variants
          .filter((iter) => path.dirname(iter) !== path.dirname(modFile))
          .map((iter) => path.dirname(iter))
          .filter((dir) => dir !== ".")
          .map((dir) => dir + path.sep);
      }
    }
    idx = modFile.lastIndexOf(path.basename(modFile));
  } else {
    idx = modFile.lastIndexOf(`${path.basename(modFile)}${path.sep}`);
  }
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  // A DLC destination sits outside the CookedPC folder, so those mods deploy from the game root.
  const setModTypeInstruction = {
    type: "setmodtype",
    value: folder === "" ? COOKEDSUB_ID : ROOT_ID,
  };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(
    (file) =>
      !file.endsWith(path.sep) &&
      file.startsWith(rootPrefix) &&
      !skipPrefixes.some((prefix) => file.startsWith(prefix)),
  );

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Install .bik files
function installMovies(files) {
  const modFile = files.find((file) => MOVIES_EXTS.includes(path.extname(file).toLowerCase()));
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: MOVIES_ID };

  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testBinaries(files, gameId) {
  const isFile = files.some((file) => BINARIES_FILES.includes(path.basename(file)));
  const isExt = files.some((file) => BINARIES_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = gameId === spec.game.id && (isFile || isExt);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installBinaries(files) {
  let modFile = files.find((file) => BINARIES_FILES.includes(path.basename(file)));
  if (modFile === undefined) {
    modFile = files.find((file) => BINARIES_EXTS.includes(path.extname(file).toLowerCase()));
  }
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: BINARIES_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Fallback installer to root folder
function testFallback(files, gameId) {
  let supported = gameId === spec.game.id;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to root folder
function installFallback(api, files, destinationPath) {
  fallbackInstallerNotify(api, destinationPath);

  const filtered = files.filter((file) => !file.endsWith(path.sep));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: file,
    };
  });
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  modName = path.basename(modName, ".installing");
  const id = modName.replace(/[^a-zA-Z0-9\s]*( )*/gi, "");
  const NOTIF_ID = `${GAME_ID}-${id}-fallback`;
  const MESSAGE = "Fallback installer reached for " + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: "info",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `The mod you just installed reached the fallback installer. This means Vortex could not determine where to place these mod files.\n` +
                `Please check the mod page description and review the files in the mod staging folder to determine if manual file manipulation is required.\n` +
                `\n` +
                `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n` +
                `\n` +
                `Mod Name: ${modName}.\n` +
                `\n`,
            },
            [
              { label: "Continue", action: () => dismiss() },
              {
                label: "Contact Ext. Developer",
                action: () => {
                  try {
                    window.api.shell.openUrl(`${EXTENSION_URL}?tab=posts`);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
              //*
              {
                label: `Open Mod Page + Staging Folder`,
                action: () => {
                  try {
                    window.api.shell.openFile(path.join(STAGING_FOLDER, modName));
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
                  const modMatch = Object.values(mods).find(
                    (mod) => mod.installationPath === modName,
                  );
                  log("warn", `Found ${modMatch?.id} for ${modName}`);
                  let PAGE = ``;
                  if (modMatch) {
                    const MOD_ID = modMatch.attributes.modId;
                    if (MOD_ID !== undefined) {
                      PAGE = `${MOD_ID}?tab=description`;
                    }
                  }
                  const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
                  try {
                    window.api.shell.openUrl(MOD_PAGE_URL);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
            ],
          );
        },
      },
    ],
  });
}

// MAIN EXTENSION FUNCTION /////////////////////////////////////////////////////

//Notify User of Setup instructions for TFC Installer
function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup`;
  const MOD_NAME = TFC_NAME;
  const MESSAGE = `${MOD_NAME} Setup Required`;
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `TFC Installer:\n` +
                `The ${MOD_NAME} tool downloaded by this extension requires setup.\n` +
                `Please launch the tool and set the Game Folder.\n` +
                `Mods to install with ${MOD_NAME} will be found at this folder: "[RootGameFolder]\\${TFC_FOLDER}\\Mods".\n` +
                `If you don't see your mod's folder there, check in the root game folder.\n` +
                `You must use ${MOD_NAME} to install and uninstall those mods after installing with Vortex.\n` +
                "\n",
            },
            [
              {
                label: "Run TFC",
                action: () => {
                  runModManager(api);
                  dismiss();
                },
              },
              { label: "Continue", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

//Notify User to run TFC Installer after deployment
function deployNotify(api) {
  const NOTIF_ID = `${GAME_ID}-deploy`;
  const MOD_NAME = TFC_NAME;
  const MESSAGE = `Run ${MOD_NAME} to Install Mods`;
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "Run TFC",
        action: (dismiss) => {
          runModManager(api);
          dismiss();
        },
      },
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `For most mods, you must use ${MOD_NAME} to install the mod to the game files after installing with Vortex.\n` +
                `Mods to install with ${MOD_NAME} will be found at this folder: "[RootGameFolder]\\${TFC_FOLDER}\\Mods".\n` +
                `If you don't see your mod's folder there, check in the root game folder.\n` +
                `Use the included tool to launch ${MOD_NAME} (button on notification or in "Dashboard" tab).\n`,
            },
            [
              {
                label: "Run TFC",
                action: () => {
                  runModManager(api);
                  dismiss();
                },
              },
              { label: "Continue", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

function runModManager(api) {
  const TOOL_ID = TFC_ID;
  const TOOL_NAME = TFC_NAME;
  const state = api.store.getState();
  const tool = state?.settings?.gameMode?.discovered?.[GAME_ID]?.tools?.[TOOL_ID] ?? undefined;

  try {
    const TOOL_PATH = tool.path;
    if (TOOL_PATH !== undefined) {
      return api.runExecutable(TOOL_PATH, [], { suggestDeploy: false }).catch((err) =>
        api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, {
          allowReport: ["EPERM", "EACCES", "ENOENT"].indexOf(err.code) !== -1,
        }),
      );
    } else {
      return api.showErrorNotification(
        `Failed to run ${TOOL_NAME}`,
        `Path to ${TOOL_NAME} executable could not be found. Ensure ${TOOL_NAME} is installed through Vortex.`,
      );
    }
  } catch (err) {
    return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, {
      allowReport: ["EPERM", "EACCES", "ENOENT"].indexOf(err.code) !== -1,
    });
  }
}

async function resolveGameVersion(gamePath) {
  GAME_VERSION = await setGameVersion(gamePath);
  const exec = GAME_VERSION === "enhanced" ? EXEC_GOTY : EXEC;
  let version = "0.0.0";
  try {
    const exeVersion = require("exe-version");
    version = exeVersion.getProductVersion(path.join(gamePath, exec));
    return Promise.resolve(version);
  } catch (err) {
    log("error", `Could not read ${exec} file to get game version: ${err}`);
    return Promise.resolve(version);
  }
}

async function modFoldersEnsureWritable(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    await vfs.ensureDirWritableAsync(path.join(gamePath, relPaths[index]));
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, gameSpec.game.id);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, gameSpec.game.id);
  if (setupNotification) setupNotify(api);
  // ASYNC CODE //////////////////////////////////////////
  await downloadTfc(api, gameSpec);
  const requirementsInstalled = await checkForRequirements(api);
  if (!requirementsInstalled) {
    await download(api, getRequirements(api));
  }
  await modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
  return ensureFileAsync(path.join(GAME_PATH, TFCMOD_PATH, "TFC_Mods_Go_Here.txt"));
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    executable: getExecutable,
    getGameVersion: resolveGameVersion,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //register mod types explicitly
  context.registerModType(
    BINARIES_ID,
    50,
    (gameId) => {
      var _a;
      return (
        gameId === GAME_ID &&
        !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
        _a === void 0
          ? void 0
          : _a.path)
      );
    },
    (game) => pathPattern(context.api, game, BINARIES_TARGET),
    () => Promise.resolve(false),
    { name: BINARIES_NAME },
  );

  //register mod installers
  context.registerInstaller(TFC_ID, 25, testTfc, installTfc);
  context.registerInstaller(UPKEXPLORER_ID, 27, testUpkExplorer, installUpkExplorer);
  context.registerInstaller(TFCMOD_ID, 29, testTfcMod, installTfcMod);
  context.registerInstaller(SDK_ID, 31, testSdk, installSdk);
  context.registerInstaller(SDKMOD_ID, 33, testSdkMod, installSdkMod);
  context.registerInstaller(ROOT_ID, 35, testRoot, installRoot);
  context.registerInstaller(
    COOKEDSUB_ID,
    37,
    testCookedSub,
    (files, destinationPath, gameId, progressDel, choices, unattended, archivePath) =>
      installCookedSub(
        context.api,
        files,
        destinationPath,
        gameId,
        progressDel,
        choices,
        unattended,
        archivePath,
      ),
  );
  context.registerInstaller(MOVIES_ID, 39, testMovies, installMovies);
  context.registerInstaller(BINARIES_ID, 41, testBinaries, installBinaries);
  if (fallbackInstaller) {
    context.registerInstaller(`${GAME_ID}-fallback`, 49, testFallback, (files, destinationPath) =>
      installFallback(context.api, files, destinationPath),
    );
  }

  //register actions
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Config Folder",
    () => {
      const openPath = CONFIG_PATH;
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Save Folder",
    () => {
      const openPath = SAVE_PATH;
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      const openPath = path.join(__dirname, "CHANGELOG.md");
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      const openPath = DOWNLOAD_FOLDER;
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );

  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Nexus Mods Page",
    () => {
      try {
        window.api.shell.openUrl(`https://www.nexusmods.com/${GAME_ID}/mods`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open SteamDB Page",
    () => {
      try {
        window.api.shell.openUrl(STEAMDB_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      try {
        window.api.shell.openUrl(`${EXTENSION_URL}?tab=bugs`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
}

//main function
function main(context) {
  applyGame(context, spec);
  context.once(() => {
    const api = context.api;
    context.api.onAsync("did-deploy", async (profileId, deployment) => {
      // put code here that should be run (once) when Vortex starts up
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(
        context.api.getState(),
        GAME_ID,
      );
      if (profileId !== LAST_ACTIVE_PROFILE) return;
      return deployNotify(context.api);
    });
    context.api.onAsync("check-mods-version", (gameId, mods, forced) => {
      if (gameId !== GAME_ID) return;
      return onCheckModVersion(context.api, gameId, mods, forced);
    });
  });
  return true;
}

//export to Vortex
module.exports = {
  default: main,
};
