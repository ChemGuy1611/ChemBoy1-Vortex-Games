# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.2.1] - 2025-09-23

- Added "-nostartupmovies" launch argument to all methods of launching the game - skips unskippable launch videos.

## [0.2.0] - 2025-09-21

- Autodownload of Python SDK (enables modding and plugin loading).
- Fixed pathfinding for config and save folders.
- Added ignoreConflicts list for common files (i.e. LICENSE.txt, instructions.txt, readme.txt, etc.).

## [0.1.1] - 2025-09-19

- Added installer for movies (.bik files).

## [0.1.0] - 2025-09-17

- Initial release.
