# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.1.1] - 2025-09-19

- Added installer for movies (.bik files).

## [0.1.0] - 2025-09-17

- Initial release.
