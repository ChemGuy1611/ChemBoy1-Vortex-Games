# Changelog

## [0.3.0] - 2025-09-27

- Fixed potential issues with Fluffy Mod Manager autodwonloader.
- Added loose lua file installer (loose lua files are not installed properly by Fluffy Mod Manager).
- Integrated Steam demo support into main extension.

## [0.2.0]

- Added notification for running FMM after mod deployment
- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including Fluffy MM, to fail with wrong URL
