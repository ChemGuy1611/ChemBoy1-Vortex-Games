# Changelog

## [1.1.6] - 2026-11-01

- Changed: manifest.json and icon.png files are no longer skipped during deployment and conflict checks.

## [1.1.5] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.4] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.3] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of a mod loader or plugin folder (for example "Myplugins" for "plugins") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Closing the "Wrong Mod Loader" or "Mixed Mod Detected" warning without pressing Ok now cancels the install instead of installing the mod anyway.
- Fixed: A mod archive is now recognised as a BepInEx patcher or a MelonLoader plugin whichever of its files is read last.
- Fixed: The missing .NET runtime warning for MelonLoader is no longer shown twice.

## [1.1.2] - 2026-10-01

- Fixed: MelonLoader mods installed into their own folder were missing the manifest file MelonLoader needs to load them.
- Thunderstore package files (manifest.json, icon.png) from newly installed mods are no longer copied into the shared mod loader folder, where they collided between mods.

## [1.1.1] - 2026-09-28

- Game version now shows the real game build instead of the Unity engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.0] - 2026-09-20

- Added: "Browse Thunderstore" page, which opens the How to Fish Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [1.0.4] - 2026-09-14

- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Fixed: MelonPreferencesManager was causing errors in-game, so it is no longer offered

## [1.0.3] - 2026-09-12

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank
- Changed: MelonPreferencesManager now installs as a mod, so it appears in the mods list with its own version and Remove button instead of being copied in as a loose file
- Changed: Plugins that don't already ship their own folder are now installed into one of their own, so two mods with a same-named file no longer overwrite each other
- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [1.0.2] - 2026-09-02

- Fixed: A required mod loader or tool is no longer matched against downloads belonging to other games, which could report the wrong installed version or check for updates against the wrong file

## [1.0.1] - 2026-08-26

- Changed: Introduced user choice of loader (BepInEx or MelonLoader), MelonLoader recommended.

## [1.0.0] - 2026-08-25

- Initial release
