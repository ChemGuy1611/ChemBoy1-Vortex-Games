/*///////////////////////////////////////////
Name: Unreal Tournament 2004 Vortex Extension
Structure: Basic Game
Author: ChemBoy1
Version: 1.0.1
Date: 2026-10-16
///////////////////////////////////////////*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const { actions, fs: vfs, util, selectors, log, VortexError } = require("vortex-api");
const path = require("path");
const template = require("string-template");
//const { parseStringPromise } = require('xml2js');
const winapi = require("winapi-bindings");
const { registerModDbBrowser, onceModDbBrowser } = require("./moddb_browser");

/*const USER_HOME = util.getVortexPath("home");
const LOCALLOW = path.join(USER_HOME, 'AppData', 'LocalLow'); //*/
//const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath("appData");
//const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all the information about the game
const GAME_ID = "unrealtournament2004";
const STEAMAPP_ID = "13230";
const GOGAPP_ID = "1207658691";
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, GOGAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const GAME_NAME = "Unreal Tournament 2004";
const GAME_NAME_SHORT = "UT2004";
const BINARIES_PATH = "System";
const EXEC_NAME = "UT2004.exe";
const EXEC = path.join(BINARIES_PATH, EXEC_NAME);
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Unreal_Tournament_2004";
const STEAMDB_URL = `https://steamdb.info/app/${STEAMAPP_ID}/`;
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1703"; //Nexus link to this extension. Used for links
const UNREALARCHIVE_URL = "https://unrealarchive.org/unreal-tournament-2004/index.html";
const UNREALWIKI_URL = "https://unreal.fandom.com/wiki/Unreal_Tournament_2004";
const OLDUNREAL_URL = "https://www.oldunreal.com/downloads/ut2004/full-game-installers/";
const MODDB_URL = "https://www.moddb.com/games/unreal-tournament-2004/mods";
const PATCHES_URL = "https://github.com/OldUnreal/UT2004Patches/releases";

const INSTALL_HIVE = "HKEY_LOCAL_MACHINE";
const INSTALL_KEY = `SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\OldUnreal_ut2004`;
const INSTALL_VALUE = "DisplayIcon"; //*/ need to pop twice to get to root

//feature toggles
const hasLoader = false; //true if game needs a mod loader
const allowSymlinks = true; //true if game can use symlinks without issues. Typically needs to be false if files have internal references (i.e. pak/ucas/utoc or ba2/esp)
const fallbackInstaller = true; //enable fallback installer. Set false if you need to avoid installer collisions
const setupNotification = false; //enable to show the user a notification with special instructions (specify below)
const debug = false; //toggle for debug mode
const moddbBrowser = true; //register the "Browse ModDB" page (moddb.com)

//info for modtypes, installers, tools, and actions
const ANIMATIONS_FOLDER = "Animations";
const ANIMATIONS_EXTS = [".ukx"];
const KARMADATA_FOLDER = "KarmaData";
const KARMADATA_EXTS = [".ka"];
const MAPS_FOLDER = "Maps";
const MAPS_EXTS = [".ut2"];
const MUSIC_FOLDER = "Music";
const MUSIC_EXTS = [".ogg"];
const SOUNDS_FOLDER = "Sounds";
const SOUNDS_EXTS = [".uax"];
const SPEECH_FOLDER = "Speech";
const SPEECH_EXTS = [".xml"];
const STATICMESHES_FOLDER = "StaticMeshes";
const STATICMESHES_EXTS = [".usx"];
const SYSTEM_FOLDER = "System";
const SYSTEM_EXTS = [".u", ".ucl", ".dll", ".ini"];
const TEXTURES_FOLDER = "Textures";
const TEXTURES_EXTS = [".utx"];
const SAVES_FOLDER = "Saves";
const SAVES_EXTS = [".uvx"];
const CONFIG_FILES = ["default.ini", "defuser.ini"];

const ROOT_FOLDERS = [
  ANIMATIONS_FOLDER,
  "Benchmark",
  "ForceFeedback",
  "Help",
  KARMADATA_FOLDER,
  MAPS_FOLDER,
  MUSIC_FOLDER,
  SOUNDS_FOLDER,
  SPEECH_FOLDER,
  STATICMESHES_FOLDER,
  SYSTEM_FOLDER,
  "SystemLocalized",
  TEXTURES_FOLDER,
  "Web",
  SAVES_FOLDER,
];
const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map((folder) => folder.toLowerCase());
const ALL_EXTS = [
  ...ANIMATIONS_EXTS,
  ...KARMADATA_EXTS,
  ...MAPS_EXTS,
  ...MUSIC_EXTS,
  ...SOUNDS_EXTS,
  ...SPEECH_EXTS,
  ...STATICMESHES_EXTS,
  ...SYSTEM_EXTS,
  ...TEXTURES_EXTS,
  ...SAVES_EXTS,
];

let GAME_PATH = "";
let GAME_VERSION = "";
let STAGING_FOLDER = "";
let DOWNLOAD_FOLDER = "";
const APPMANIFEST_FILE = "appxmanifest.xml";
const EXEC_XBOX = "gamelaunchhelper.exe";

const MOD_ID = `${GAME_ID}-mod`;
const MOD_NAME = "Mod";
const MOD_PATH = ".";
const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Folder";
const BINARIES_ID = `${GAME_ID}-binaries`;
const BINARIES_NAME = "Binaries (Engine Injector)";

const EDITOR_ID = `${GAME_ID}-editor`;
const EDITOR_NAME = "Unreal Editor";
const EDITOR_EXEC = path.join(BINARIES_PATH, "UnrealEd.exe");

const MOD_PATH_DEFAULT = ".";
const REQ_FILE = EXEC;
const PARAMETERS_STRING = "";
const PARAMETERS = [PARAMETERS_STRING];

const IGNORE_CONFLICTS = [
  path.join("**", "Preview - *"),
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];
const IGNORE_DEPLOY = [
  path.join("**", "Preview - *"),
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];

//Embedded ModDB browser page - the user browses the live moddb.com section for this game and
//installs from it. Vortex's download manager cannot fetch from this host, so the page fetches
//the file itself. No requirements: nothing on this game's ModDB page is a managed mod loader.
const MODDB_BROWSER_CONFIG = {
  moddbPath: "games/unreal-tournament-2004",
  pageId: `${GAME_ID}-moddb-browse`,
  pageTitle: "Browse ModDB",
};

//filled in from data above
const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    shortName: GAME_NAME_SHORT,
    executable: EXEC,
    //"parameters": PARAMETERS, //commented out by default to avoid passing empty string parameter
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    modPath: MOD_PATH_DEFAULT,
    modPathIsRelative: true,
    requiredFiles: [REQ_FILE],
    compatible: {
      dinput: false,
      enb: false,
    },
    details: {
      //"steamAppId": +STEAMAPP_ID,
      gogAppId: GOGAPP_ID,
      //"epicAppId": EPICAPP_ID,
      //"xboxAppId": XBOXAPP_ID,
      supportsSymlinks: allowSymlinks,
      ignoreConflicts: IGNORE_CONFLICTS,
      ignoreDeploy: IGNORE_DEPLOY,
    },
    environment: {
      //"SteamAPPId": STEAMAPP_ID,
      GogAPPId: GOGAPP_ID,
      //"EpicAPPId": EPICAPP_ID,
      //"XboxAPPId": XBOXAPP_ID,
    },
  },
  modTypes: [
    {
      id: MOD_ID,
      name: MOD_NAME,
      priority: "high",
      targetPath: "{gamePath}",
    },
    {
      id: BINARIES_ID,
      name: BINARIES_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", BINARIES_PATH),
    },
  ],
  discovery: {
    ids: DISCOVERY_IDS_ACTIVE,
    names: [],
  },
};

//3rd party tools and launchers
const tools = [
  //accepts: exe, jar, py, vbs, bat
  {
    id: `${GAME_ID}-customlaunch`,
    name: "Custom Launch",
    logo: "exec.png",
    executable: () => EXEC,
    requiredFiles: [EXEC],
    relative: true,
    exclusive: true,
    shell: true,
    detach: true,
    //defaultPrimary: true,
    //parameters: PARAMETERS,
  }, //*/
  {
    id: EDITOR_ID,
    name: EDITOR_NAME,
    logo: "editor.png",
    executable: () => EDITOR_EXEC,
    requiredFiles: [EDITOR_EXEC],
    relative: true,
    exclusive: true,
    //shell: true,
    detach: true,
    //defaultPrimary: true,
    //parameters: PARAMETERS,
  }, //*/
];

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

//Set mod type priorities
function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath:
        (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
          ? void 0
          : _a.path,
      documents: util.getVortexPath("documents"),
      localAppData: util.getVortexPath("localAppData"),
      appData: util.getVortexPath("appData"),
    });
  } catch (err) {
    //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification(
      "Failed to locate executable. Please launch the game at least once.",
      err,
    );
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  //* using registry - requires winapi-bindings
  try {
    const instPath = winapi.RegGetValue(INSTALL_HIVE, INSTALL_KEY, INSTALL_VALUE);
    if (!instPath) {
      throw new Error("empty registry key");
    }
    const splitPath = instPath.value.split("\\");
    const gamePath = splitPath.slice(0, splitPath.length - 2).join(path.sep);
    return () => Promise.resolve(gamePath);
  } catch {
    //*/
    return () =>
      util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
  }
  //*/
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? {};
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}
async function deploy(api) {
  //useful to deploy mods after doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Test for mod files
function testMod(files, gameId) {
  const isFolder = files.some((file) =>
    ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  const isExt = files.some((file) => ALL_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = gameId === spec.game.id && (isFolder || isExt);

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install mod files
function installMod(files) {
  const MOD_TYPE = MOD_ID;
  const setModTypeInstruction = { type: "setmodtype", value: MOD_TYPE };

  let folder = "";
  let modFile = "";
  if (files.some((file) => ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()))) {
    folder = "";
    modFile = files.find((file) => ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()));
  } else if (files.some((file) => ANIMATIONS_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = ANIMATIONS_FOLDER;
    modFile = files.find((file) => ANIMATIONS_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => KARMADATA_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = KARMADATA_FOLDER;
    modFile = files.find((file) => KARMADATA_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => MAPS_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = MAPS_FOLDER;
    modFile = files.find((file) => MAPS_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => MUSIC_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = MUSIC_FOLDER;
    modFile = files.find((file) => MUSIC_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => SOUNDS_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = SOUNDS_FOLDER;
    modFile = files.find((file) => SOUNDS_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => SPEECH_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = SPEECH_FOLDER;
    modFile = files.find((file) => SPEECH_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => STATICMESHES_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = STATICMESHES_FOLDER;
    modFile = files.find((file) => STATICMESHES_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => SYSTEM_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = SYSTEM_FOLDER;
    modFile = files.find((file) => SYSTEM_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => TEXTURES_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = TEXTURES_FOLDER;
    modFile = files.find((file) => TEXTURES_EXTS.includes(path.extname(file).toLowerCase()));
  } else if (files.some((file) => SAVES_EXTS.includes(path.extname(file).toLowerCase()))) {
    folder = SAVES_FOLDER;
    modFile = files.find((file) => SAVES_EXTS.includes(path.extname(file).toLowerCase()));
  }
  /*else {
    folder = '';
    modFile = files[0];
  } //*/
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Fallback installer to root folder
function testFallback(files, gameId) {
  let supported = gameId === spec.game.id;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to root folder
function installFallback(api, files, destinationPath) {
  fallbackInstallerNotify(api, destinationPath);
  const filtered = files.filter((file) => !file.endsWith(path.sep));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: file,
    };
  });
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  const NOTIF_ID = `${GAME_ID}-fallbackinstaller`;
  modName = path.basename(modName, ".installing");
  const MESSAGE = "Fallback installer reached for " + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: "info",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `The mod you just installed reached the fallback installer. This means Vortex could not determine where to place these mod files.\n` +
                `Please check the mod page description and review the files in the mod staging folder to determine if manual file manipulation is required.\n` +
                `\n` +
                `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n` +
                `\n` +
                `Mod Name: ${modName}.\n` +
                `\n`,
            },
            [
              { label: "Continue", action: () => dismiss() },
              {
                label: "Contact Ext. Developer",
                action: () => {
                  try {
                    window.api.shell.openUrl(`${EXTENSION_URL}?tab=posts`);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
              {
                label: "Open Staging Folder",
                action: () => {
                  try {
                    window.api.shell.openFile(path.join(STAGING_FOLDER, modName));
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
              //*
              {
                label: `Open Mod Page`,
                action: () => {
                  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
                  const modMatch = Object.values(mods).find(
                    (mod) => mod.installationPath === modName,
                  );
                  log("warn", `Found ${modMatch?.id} for ${modName}`);
                  let PAGE = ``;
                  if (modMatch) {
                    const MOD_ID = modMatch.attributes.modId;
                    if (MOD_ID !== undefined) {
                      PAGE = `${MOD_ID}?tab=description`;
                    }
                  }
                  const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
                  try {
                    window.api.shell.openUrl(MOD_PAGE_URL);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  //dismiss();
                },
              }, //*/
            ],
          );
        },
      },
    ],
  });
}

// AUTOMATIC MOD DOWNLOADERS ///////////////////////////////////////////////////

//* Download UE4SS from GitHub page (user browse for download)
async function downloadPatches(api, gameSpec) {
  const URL = PATCHES_URL;
  const MOD_NAME = "OldUnreal Patch";
  const MOD_TYPE = MOD_ID;
  const ARCHIVE_NAME = "OldUnreal-UT2004Patch";
  const instructions = api.translate(
    `Click on Continue below to open the browser. - ` +
      `Navigate to the a version of ${ARCHIVE_NAME} on the GitHub releases page and ` +
      `click on the "Windows" version file to download and install the mod.`,
  );

  return new Promise((resolve, reject) => {
    //Browse and download the mod
    return api
      .emitAndAwait("browse-for-download", URL, instructions)
      .then((result) => {
        //result is an array with the URL to the downloaded file as the only element
        if (!result || !result.length) {
          //user clicks outside the window without downloading
          return reject(
            new VortexError("User canceled", { kind: "user-canceled", skipped: false }),
          );
        }
        if (!result[0].includes(ARCHIVE_NAME)) {
          //if user downloads the wrong file
          return reject(
            new VortexError("Selected wrong download", { kind: "user-canceled", skipped: true }),
          );
        } //*/
        return Promise.resolve(result);
      })
      .catch((error) => {
        return reject(error);
      })
      .then((result) => {
        const dlInfo = { game: gameSpec.game.id, name: MOD_NAME };
        api.events.emit(
          "start-download",
          result,
          {},
          undefined,
          async (error, id) => {
            //callback function to check for errors and pass id to and call 'start-install-download' event
            if (error !== null && error.name !== "AlreadyDownloaded") {
              return reject(error);
            }
            api.events.emit(
              "start-install-download",
              id,
              { allowAutoEnable: true },
              async (error) => {
                //callback function to complete the installation
                if (error !== null) {
                  return reject(error);
                }
                const profileId = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
                const batched = [
                  actions.setModsEnabled(api, profileId, result, true, {
                    allowAutoDeploy: true,
                    installed: true,
                  }),
                  actions.setModType(GAME_ID, result[0], MOD_TYPE), // Set the mod type
                ];
                util.batchDispatch(api.store, batched); // Will dispatch both actions.
                return resolve();
              },
            );
          },
          "never",
          { allowInstall: false },
        );
      });
  }).catch((err) => {
    if (err?.data?.kind === "user-canceled") {
      api.showErrorNotification(
        `User cancelled download/install of ${MOD_NAME}. Please try again.`,
        err,
        { allowReport: false },
      );
      //window.api.shell.openUrl(URL);
      return Promise.resolve();
    } else if (err?.data?.kind === "process-canceled") {
      api.showErrorNotification(
        `Failed to download/install ${MOD_NAME}. Please try again or download manually.`,
        err,
        { allowReport: false },
      );
      try {
        window.api.shell.openUrl(URL);
      } catch (openErr) {
        api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
      }
      return Promise.reject(err);
    } else {
      return Promise.reject(err);
    }
  });
} //*/

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup-notify`;
  const MESSAGE = "Special Setup Instructions";
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text: `\n` + `TEXT HERE.\n` + `\n` + `TEXT HERE.\n` + `\n`,
            },
            [
              { label: "Acknowledge", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

//* Resolve game version dynamically for different game versions
async function resolveGameVersion(gamePath) {
  const versionFile = path.join(gamePath, BINARIES_PATH, "Build.ini");
  let data = "";
  try {
    data = await fsp.readFile(versionFile, { encoding: "utf8" });
  } catch (err) {
    log("error", `Could not read ${BINARIES_PATH}/Build.ini file to get game version: ${err}`);
    return Promise.resolve(undefined);
  }
  const segments = data.split("_");
  const v1 = segments[1].replace("v", ""); //3374
  const v2 = segments[4]; //e777cc6e
  const version = `${v1}-${v2}`;
  return Promise.resolve(version);
} //*/

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  // ASYNC CODE //////////////////////////////////////////
  if (setupNotification) {
    setupNotify(api);
  }
  return vfs.ensureDirWritableAsync(GAME_PATH);
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  const game = {
    //register game
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: () => gameSpec.game.executable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersion,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register the embedded moddb.com browser page
  if (moddbBrowser) {
    registerModDbBrowser(context, gameSpec, MODDB_BROWSER_CONFIG);
  }

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //register mod installers
  context.registerInstaller(MOD_ID, 27, testMod, installMod);
  if (fallbackInstaller) {
    context.registerInstaller(`${GAME_ID}-fallback`, 49, testFallback, (files, destinationPath) =>
      installFallback(context.api, files, destinationPath),
    );
  }

  //register actions
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    `Download OldUnreal Patches (Browse)`,
    () => {
      downloadPatches(context.api, spec);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open OldUnreal Page",
    () => {
      try {
        window.api.shell.openUrl(UNREALARCHIVE_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    `Open Engine Settings File`,
    () => {
      GAME_PATH = getDiscoveryPath(context.api);
      try {
        window.api.shell.openFile(path.join(GAME_PATH, BINARIES_PATH, CONFIG_FILES[0]));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    `Open User Settings File`,
    () => {
      GAME_PATH = getDiscoveryPath(context.api);
      try {
        window.api.shell.openFile(path.join(GAME_PATH, BINARIES_PATH, CONFIG_FILES[1]));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Save Folder",
    () => {
      GAME_PATH = getDiscoveryPath(context.api);
      try {
        window.api.shell.openFile(path.join(GAME_PATH, SAVES_FOLDER));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  ); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open SteamDB Page",
    () => {
      try {
        window.api.shell.openUrl(STEAMDB_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Unreal Wiki Page",
    () => {
      try {
        window.api.shell.openUrl(UNREALWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open OldUnreal Page",
    () => {
      try {
        window.api.shell.openUrl(OLDUNREAL_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open ModDB Page",
    () => {
      try {
        window.api.shell.openUrl(MODDB_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      const openPath = path.join(__dirname, "CHANGELOG.md");
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      try {
        window.api.shell.openUrl(`${EXTENSION_URL}?tab=bugs`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      try {
        window.api.shell.openFile(DOWNLOAD_FOLDER);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    try {
      window.api.shell.openFile(CONFIG_PATH);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
}

//main function
function main(context) {
  applyGame(context, spec);
  context.once(() => {
    // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    if (moddbBrowser) {
      //installs downloads started from the browse page, and update-checks the mods installed through it
      onceModDbBrowser(api, spec, MODDB_BROWSER_CONFIG);
    }
  });
  return true;
}

//export to Vortex
module.exports = {
  default: main,
};
