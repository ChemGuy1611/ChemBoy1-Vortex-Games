# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.0] - 2026-02-20

- Inital Release
