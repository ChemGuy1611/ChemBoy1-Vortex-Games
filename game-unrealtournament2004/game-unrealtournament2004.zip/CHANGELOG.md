# Changelog

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.1.3] - 2026-09-03

- Added: A "Browse ModDB" page in the sidebar. Browse the game's ModDB mod list inside Vortex and install mods with a click.

## [0.1.2] - 2026-08-11

- Added: GOG support
- Added: Steam ID for discovery

## [0.1.1] - 2026-03-27

- Added: Button to browse and download OldUnreal patches from GitHub

## [0.1.0] - 2026-02-20

- Inital Release
