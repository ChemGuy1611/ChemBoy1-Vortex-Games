# Changelog

## [0.1.1] - 2026-10-02

- Added support for the Xbox / Microsoft Store version of the game.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.1.0] - 2026-02-16

- Initial release
