# Changelog

## [0.5.3]
- Tweak Void Installer Mod installer criteria

## [0.5.2]
- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain to fail with wrong URL
- Added additional note to notifications related to Void Installer that users should check for mod folders in the root if they don't find it is the Mods folder

## [0.5.1]
- Added a tool for Void Explorer if the user installs it to the game folder

## [0.5.0]
- Added support for Void Installer and mods that use it
- Changed requiredFiles and getExecutable for more reliable game discovery