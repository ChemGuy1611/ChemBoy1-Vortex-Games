# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.5.1] - 2026-02-02

- Fixed: Extension now repackages poorly packaged MLUE4SS mods - places pak files in LogicMods folder
- Added: Deployment notification after changing the load order
- Added: Automatic renaming of "Win64" folder to "WinGDK" for UE4SS combo mod installer

## [0.5.0] - 2026-01-31

- Added: UE4SS auto-download function (if not already installed)
- Added: UE4SS DLL mod installer
- Added: Buttons to open multiple files and folders
- Fixed: path strings
- Fixed: Xbox game version detection
