# Changelog

## [1.2.2] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.2.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [1.2.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [1.1.6] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.1.5] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.4] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.3] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: Pak + UE4SS combo mods now show up on the UE4SS load order page on the Xbox / Game Pass version, instead of being listed as manual mods.
- Fixed: The "Open LogicMods Folder" button now opens the LogicMods folder instead of the Paks folder.

## [1.1.2] - 2026-09-27

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.1] - 2026-09-19

- Removed the dependency on the Unreal Engine Mod Installer extension. Pak mods are now installed and managed directly by this extension; existing installs are migrated automatically, no action needed.
- Fixed: A FOMOD-packaged MLUE4SS mod could be installed to the wrong location instead of the LogicMods folder.

## [1.0.0] - 2026-09-15

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Migrated the pak load order page to Vortex's newer file-based system, adding a lock button, multi-select, and a right-click context menu.
- Added dedicated UE4SS Load Order and LogicMods Load Order pages, so script/DLL and LogicMods pak mods can now be reordered directly instead of relying on install order alone.

## [0.5.2] - 2026-02-03

- Improved: Made UE4SS Scripts, UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names

## [0.5.1] - 2026-02-02

- Fixed: Extension now repackages poorly packaged MLUE4SS mods - places pak files in LogicMods folder
- Added: Deployment notification after changing the load order
- Added: Automatic renaming of "Win64" folder to "WinGDK" for UE4SS combo mod installer

## [0.5.0] - 2026-01-31

- Added: UE4SS auto-download function (if not already installed)
- Added: UE4SS DLL mod installer
- Added: Buttons to open multiple files and folders
- Fixed: path strings
- Fixed: Xbox game version detection
