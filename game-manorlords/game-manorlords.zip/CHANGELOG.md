# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.5.0] - 2026-01-31

- Added: UE4SS auto-download function (if not already installed)
- Added: UE4SS DLL mod installer
- Added: Buttons to open multiple files and folders
- Fixed: path strings
- Fixed: Xbox game version detection
