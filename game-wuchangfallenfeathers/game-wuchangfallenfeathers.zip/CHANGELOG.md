# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.1] - 2025-07-25

- Fixed Mod Enabler downloader to get the right file for the user's game version.
- Added Epic Games ID and full support.

## [0.1.0] - 2025-07-23

- Initial release
