# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.1.2] - 2025-06-05

- Added additional known IWADs to IWAD installer list.
- Corrected extension name in info.json file.

## [0.1.1] - 2025-06-01

- Added buttons for opening GZDoom Saves, GZDoom Config, gzdoom.ini, and Vortex Downloads folders (folder icon on Mods toolbar)

## [0.1.0] - 2025-05-29

- Initial release
