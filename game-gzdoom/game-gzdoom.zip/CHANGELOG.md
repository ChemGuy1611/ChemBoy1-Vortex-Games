# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.1.3] - 2025-06-28

- Updated DML Setup notification with some additional details.
- Added .iwad and .ipk3 extensions to game WAD installer.

## [0.1.2] - 2025-06-05

- Added additional known IWADs to IWAD installer list.
- Corrected extension name in info.json file.

## [0.1.1] - 2025-06-01

- Added buttons for opening GZDoom Saves, GZDoom Config, gzdoom.ini, and Vortex Downloads folders (folder icon on Mods toolbar)

## [0.1.0] - 2025-05-29

- Initial release
