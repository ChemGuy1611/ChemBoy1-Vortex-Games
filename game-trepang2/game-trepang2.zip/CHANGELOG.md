# Changelog

## Planned Improvements (Not Yet Released)

- None

## [1.2.0] - 2026-09-18

- Removed the dependency on the Unreal Engine Mod Installer extension. Pak mods are now installed and managed directly by this extension; existing installs are migrated automatically, no action needed.

## [1.1.0] - 2026-09-13

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Changed: "Download UE4SS" now downloads and installs the correct UE4SS build on its own, instead of opening a browser page and asking you to pick the file by hand.
- Added: Vortex now checks for UE4SS updates and notifies you when a newer build is available.
- Fixed: The UE4SS download could accept the development build, a much larger debug version, in place of the normal one.

## [1.0.3] - 2026-09-06

- Fixed: Locked load order entries could be moved out of position when using "Move to Top", "Move to Bottom" or the position number box on another entry. Locked entries now keep their place.
- Fixed: The load order position number box now accepts low numbers even when a locked entry is further down the list.

## [1.0.2] - 2026-08-24

- Fixed: Deploying could fail with an error when the load order had not been read yet, which can happen while installing a collection.
- Fixed: The load order no longer stops working for the rest of the session if its file cannot be read or is damaged.

## [1.0.1] - 2026-07-29

- Fixed: The load order could disappear after deploying while a mod update was in progress, and only came back after deploying a second time.
- Added: A message now appears if you change the load order while a mod update is still finishing, so it is clear the change was not applied and needs to be made again.
- Fixed: After a mod update finished, the load order page could keep showing out-of-date information until another deployment was run.

## [1.0.0] - 2026-07-29

- Fixed: Clicking the lock icon on a load order row no longer selects the row as well.
- Changed: Enabling or disabling a mod from a load order page now goes through Vortex's own enable/disable handling, so Vortex shows its usual "Deployment Required" prompt (or deploys straight away if you have automatic deployment on) and other extensions are told about the change.
- Changed: The UE4SS "Configure" button now looks for config files in the mod folder, its Scripts folder and its dlls folder instead of searching the whole mod folder. Opening the page with many mods installed is faster.
- Changed: Load order rows redraw less when the order changes.
- Changed: Right-click menus work out their position once when opened instead of adjusting after they appear, and all three menus now close the same way (click elsewhere, right-click elsewhere, or Escape).
- Changed: The checkbox on UE4SS load order rows now matches the styling used on the other pages.

## [0.3.2] - 2026-07-27

- Fixed: mods.txt could lose most of its contents when the BPModLoaderMod or Keybinds line was missing from the file.
- Fixed: Built-in UE4SS mod lines and comments in mods.txt were overwritten every time the load order was saved.
- Changed: ActorDumperMod and jsbLuaProfilerMod are now treated as built-in UE4SS mods. They no longer appear on the UE4SS Load Order page, no longer get duplicate entries in mods.txt, and no longer receive an enabled.txt file.
- Fixed: "Move to Top" and "Move to Bottom" now leave locked entries where they are, instead of moving them or adding a duplicate entry.
- Fixed: Typing in the search box on the UE4SS or LogicMods Load Order page no longer breaks the page when a collection has just been installed and not yet deployed.
- Fixed: Opening the UE4SS or LogicMods Load Order page when those folders cannot be read no longer raises an error dialog.
- Fixed: Locked entries on the LogicMods Load Order page no longer lose their lock after deploying.
- Fixed: Shift-clicking two rows while a status filter is active no longer selects the hidden rows between them.
- Fixed: The notification shown when turning the UE4SS Load Order setting on reported more enabled.txt files removed than it actually removed.

## [0.3.1] - 2026-07-25

- Fixed: Using "Update all" to update several mods at once could move them in the load order or uncheck them, including on the UE4SS and LogicMods load order pages.

## [0.3.0] - 2026-07-22

- Added: Updating a mod no longer unchecks it or moves it in the load order (Pak, UE4SS, and LogicMods pages), including on profiles other than the one you're using.

## [0.2.0] - 2026-07-22

- Migrated to file-based load order (FBLO) on the unified UE4-5 template; added lock button, multi-select, right-click context menu, UE4SS Load Order page
- Added UE4SS script/DLL/LogicMods mod support (new - not previously supported)
- Added Xbox Game Pass version support
- Kept Unreal Engine Mod Installer (UEMI) dependency for PAK installation - wired via a custom `loadOrderPrefixFunc` so FBLO correctly reorders UEMI-installed paks

## [0.1.1]

- Initial release
