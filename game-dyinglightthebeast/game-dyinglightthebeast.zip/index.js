/*///////////////////////////////////////////
Name: Dying Light The Beast Vortex Extension
Structure: Basic Game
Author: ChemBoy1
Version: 0.5.1
Date: 2026-09-08
///////////////////////////////////////////*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const { actions, fs: vfs, util, selectors, log } = require("vortex-api");
const path = require("path");
//const shortid = require('shortid');
const template = require("string-template");
const winapi = require("winapi-bindings");

//const USER_HOME = util.getVortexPath("home");
//const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath("appData");
//const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all the information about the game
const GAME_ID = "dyinglightthebeast";
const STEAMAPP_ID = "3008130";
const STEAMAPP_ID_DEMO = null;
const EPICAPP_ID = "32eba9473a5642ac947f33b7130094b1";
const GOGAPP_ID = null;
const XBOXAPP_ID = null;
const XBOXEXECNAME = null;
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, EPICAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const GAME_NAME = "Dying Light: The Beast";
const GAME_NAME_SHORT = "DL The Beast";
const BINARIES_PATH = path.join("ph_ft", "work", "bin", "x64");
const EXEC = path.join(BINARIES_PATH, "DyingLightGame_TheBeast_x64_rwdi.exe");
const EXEC_EGS = EXEC;
const EXEC_XBOX = "gamelaunchhelper.exe";

const ROOT_FOLDERS = ["ph_ft"];
/*
const DATA_FOLDER = 'XXX';
const CONFIGMOD_LOCATION = DOCUMENTS;
const CONFIG_FOLDERNAME = 'XXX';
const SAVEMOD_LOCATION = DOCUMENTS;
const SAVE_FOLDERNAME = CONFIG_FOLDERNAME;
//*/

let GAME_PATH = "";
let GAME_VERSION = ""; //Game version
let STAGING_FOLDER = "";
let DOWNLOAD_FOLDER = "";
let DOTNET_INSTALLED = false;
let superMergerInstalled = false;
let mergerInstalled = false;

const PAK_ID = `${GAME_ID}-pak`;
const PAK_NAME = "Pak Mod (Merged)";
//const PAK_PATH = path.join('ph_ft', 'source'); //
const PAK_PATH = path.join("ph_ft", "mods");
const PAK_EXT = ".pak";
const PAK_STRING = "data";
const PAK_IDX_START = 2; //data0 and data1 are vanilla
const PAK_IDX_END = 7; //cannot go above 7 or game won't load the file
const VANILLA_PAKS = ["data0.pak", "data1.pak"];
const VANILLA_PAK_PATH = path.join("ph_ft", "source");

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Folder";

const BINARIES_ID = `${GAME_ID}-binaries`;
const BINARIES_NAME = "Binaries (Engine Injector)";

const MERGER_ID = `${GAME_ID}-mergerutility`;
const MERGER_NAME = "UTM Mod Merger Utility";
const MERGER_PATH = "ph_ft";
const MERGER_EXEC = "unleashthemods.exe";
const MERGER_EXEC_PATH = path.join(MERGER_PATH, MERGER_EXEC);
const MERGER_PAGE_NO = 140;
const MERGER_FILE_NO = 1157;
const MERGER_DOMAIN = GAME_ID;

const SUPERMERGER_ID = `${GAME_ID}-supermerger`;
const SUPERMERGER_NAME = "Super Mod Merger";
const SUPERMERGER_PATH = MERGER_PATH;
const SUPERMERGER_EXEC_STRING = "SuperModMerger";
const SUPERMERGER_EXEC = `${SUPERMERGER_EXEC_STRING}.exe`;
const SUPERMERGER_EXEC_PATH = path.join(SUPERMERGER_PATH, SUPERMERGER_EXEC);
const SUPERMERGER_PAGE_NO = 699;
const SUPERMERGER_FILE_NO = 2477;
const SUPERMERGER_DOMAIN = GAME_ID;

/* Config and Save paths and modtypes
const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_NAME = "Config";
const CONFIG_PATH = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, CONFIG_FOLDERNAME);
const CONFIG_EXT = ".ini";
const CONFIG_FILES = ["XXX"];

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = "Save";
const SAVE_FOLDER = path.join(SAVEMOD_LOCATION, DATA_FOLDER, SAVE_FOLDERNAME);
let USERID_FOLDER = "";
function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}
try {
  const SAVE_ARRAY = fs.readdirSync(SAVE_FOLDER);
  USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_FOLDER, entry));
} catch {
  USERID_FOLDER = "";
}
if (USERID_FOLDER === undefined) {
  USERID_FOLDER = "";
}
const SAVE_PATH = path.join(SAVE_FOLDER, USERID_FOLDER);
const SAVE_EXT = ".sav";
const SAVE_FILES = ["XXX"];
//*/

const DOTNET_VER = "8.0";
const DOTNET_URL = `https://dotnet.microsoft.com/en-us/download/dotnet/${DOTNET_VER}`;
const DOTNET_REG_HIVE = "HKEY_LOCAL_MACHINE";
const DOTNET_REG_KEY = `SOFTWARE\\WOW6432Node\\dotnet\\Setup\\InstalledVersions\\x64\\sharedfx\\Microsoft.WindowsDesktop.App`;

const MOD_PATH_DEFAULT = PAK_PATH;
const REQ_FILE = EXEC;
const PARAMETERS_STRING = "";
const PARAMETERS = [PARAMETERS_STRING];
const IGNORED_FILES = [path.join("**", "**.pak")];
const DEPLOY_IGNORE = [path.join("**", "data0.pak"), path.join("**", "data1.pak")];

const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1456"; //Nexus link to this extension. Used for links
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Dying_Light%3A_The_Beast";
const IGNORE_CONFLICTS = [path.join("**", "changelog*"), path.join("**", "readme*")];
const IGNORE_DEPLOY = [path.join("**", "changelog*"), path.join("**", "readme*")];
const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    shortName: GAME_NAME_SHORT,
    executable: EXEC,
    //"parameters": PARAMETERS,
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    modPath: MOD_PATH_DEFAULT,
    modPathIsRelative: true,
    requiredFiles: [REQ_FILE],
    details: {
      steamAppId: +STEAMAPP_ID,
      epicAppId: EPICAPP_ID,
      //"ignoreConflicts": IGNORED_FILES,
      //"ignoreDeploy": DEPLOY_IGNORE,
    },
    environment: {
      SteamAPPId: STEAMAPP_ID,
      EpicAPPId: EPICAPP_ID,
    },
  },
  modTypes: [
    {
      id: PAK_ID,
      name: PAK_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", PAK_PATH),
    }, //*/
    {
      id: ROOT_ID,
      name: ROOT_NAME,
      priority: "high",
      targetPath: `{gamePath}`,
    },
    {
      id: BINARIES_ID,
      name: BINARIES_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", BINARIES_PATH),
    },
    {
      id: MERGER_ID,
      name: MERGER_NAME,
      priority: "low",
      targetPath: path.join("{gamePath}", MERGER_PATH),
    }, //*/
    {
      id: SUPERMERGER_ID,
      name: SUPERMERGER_NAME,
      priority: "low",
      targetPath: path.join("{gamePath}", SUPERMERGER_PATH),
    }, //*/
  ],
  discovery: {
    ids: DISCOVERY_IDS_ACTIVE,
    names: [],
  },
};

//3rd party tools and launchers
const tools = [
  {
    id: `${GAME_ID}-customlaunch`,
    name: "Custom Launch",
    logo: "exec.png",
    executable: () => EXEC,
    requiredFiles: [EXEC],
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  {
    id: MERGER_ID,
    name: MERGER_NAME,
    logo: "merger.png",
    executable: () => MERGER_EXEC_PATH,
    requiredFiles: [MERGER_EXEC_PATH],
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    //parameters: [],
  }, //*/
  {
    id: SUPERMERGER_ID,
    name: SUPERMERGER_NAME,
    logo: "supermerger.png",
    executable: () => SUPERMERGER_EXEC_PATH,
    requiredFiles: [SUPERMERGER_EXEC_PATH],
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    //parameters: [],
  }, //*/
];

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

//Set mod type priorities
function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath:
        (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
          ? void 0
          : _a.path,
      documents: util.getVortexPath("documents"),
      localAppData: util.getVortexPath("localAppData"),
      appData: util.getVortexPath("appData"),
    });
  } catch (err) {
    //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification(
      "Failed to locate executable. Please launch the game at least once.",
      err,
    );
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () =>
    util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher(gamePath, store) {
  if (store === "epic" && DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID)) {
    return Promise.resolve({
      launcher: "epic",
      addInfo: {
        appId: EPICAPP_ID,
        //parameters: PARAMETERS,
        //launchType: 'gamestore',
      },
    });
  } //*/
  /*
  if (store === 'steam') {
    return Promise.resolve({
      launcher: 'steam',
      addInfo: {
        appId: STEAM_ID,
        //parameters: PARAMETERS,
        //launchType: 'gamestore',
      } //
    });
  } //*/
  return Promise.resolve(undefined);
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, GAME_ID], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}
async function deploy(api) {
  //useful to deploy mods after doing some action
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

// AUTOMATIC DOWNLOADER FUNCTIONS ///////////////////////////////////////////////////

//Check if UTM is installed
function isMergerUtilityInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === MERGER_ID);
}

//Check if Super Merger Utility is installed
function isSuperMergerInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === SUPERMERGER_ID);
}

//Function to choose merger utility
async function chooseMerger(api, gameSpec) {
  const UNLEASHED_LABEL = `Unleash The Mods`;
  const SUPER_LABEL = `Super Mod Merger (Recommended)`;
  const t = api.translate;
  let choices = [{ label: t(SUPER_LABEL) }, { label: t(UNLEASHED_LABEL) }];
  const replace = {
    game: gameSpec.game.name,
    bl: "[br][/br][br][/br]",
  };
  return api
    .showDialog(
      "info",
      "Mod Merger Selection",
      {
        bbcode: t(
          "You must choose a mod merger to install mods.{{bl}}" +
            "You can change which merger you have installed by Uninstalling the current one from Vortex, which will bring up this dialog again.{{bl}}" +
            `Note that ${SUPERMERGER_NAME} is recommended as it can merge more file types and has no external dependencies.{{bl}}` +
            "Which mod loader would you like to use for {{game}}?",
          { replace },
        ),
      },
      choices,
    )
    .then(async (result) => {
      if (result === undefined) {
        return;
      }
      if (result.action === SUPER_LABEL) {
        await downloadSuperMerger(api, gameSpec);
      } else if (result.action === UNLEASHED_LABEL) {
        await downloadMergerUtility(api, gameSpec);
      }
    });
}

//* Function to auto-download Mod Merger Utility from Nexus Mods
async function downloadMergerUtility(api, gameSpec) {
  let isInstalled = isMergerUtilityInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = MERGER_NAME;
    const MOD_TYPE = MERGER_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    let FILE_ID = MERGER_FILE_NO; //If using a specific file id because "input" below gives an error
    const PAGE_ID = MERGER_PAGE_NO;
    const GAME_DOMAIN = GAME_ID;
    api.sendNotification({
      //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) {
      //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = FILE_ID; //use the FILE_ID directly for the correct game store version
      let URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      try {
        //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter((file) => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch {
        // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } //
      const dlInfo = {
        //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise((cb) =>
        api.events.emit("start-download", [URL], dlInfo, undefined, cb, undefined, {
          allowInstall: false,
        }),
      );
      const modId = await util.toPromise((cb) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, cb),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Function to auto-download Super Merger from Nexus Mods
async function downloadSuperMerger(api, gameSpec) {
  let isInstalled = isSuperMergerInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = SUPERMERGER_NAME;
    const MOD_TYPE = SUPERMERGER_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    let FILE_ID = SUPERMERGER_FILE_NO; //If using a specific file id because "input" below gives an error
    const PAGE_ID = SUPERMERGER_PAGE_NO;
    const GAME_DOMAIN = SUPERMERGER_DOMAIN;
    api.sendNotification({
      //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) {
      //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = FILE_ID; //use the FILE_ID directly for the correct game store version
      let URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      try {
        //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter((file) => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch {
        // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } //
      const dlInfo = {
        //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise((cb) =>
        api.events.emit("start-download", [URL], dlInfo, undefined, cb, undefined, {
          allowInstall: false,
        }),
      );
      const modId = await util.toPromise((cb) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, cb),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Test for .pak files (in mod merger)
function testPak(files, gameId) {
  const isMod = files.some((file) => path.extname(file).toLowerCase() === PAK_EXT);
  let supported = gameId === spec.game.id && isMod;

  //* Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  } //*/

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

/* Install pak files (Vortex merger function version)
function installPakInternal(api, files, fileName) {
  const rootCandidate = files.find(file => file.toLowerCase().split(path.sep).includes('ph_ft'));
  const idx = rootCandidate !== undefined
    ? rootCandidate.toLowerCase().split(path.sep).findIndex(seg => seg === 'ph_ft')
    : 0;

  let hasVariants = false;
  const pakFiles = files.reduce((accum, iter) => {
    if (path.extname(iter) === '.pak') {
      const exists = accum[path.basename(iter)] !== undefined;
      if (exists) {
        hasVariants = true;
      }
      accum[path.basename(iter)] = exists
        ? accum[path.basename(iter)].concat(iter)
        : [iter];
    }
    return accum;
  }, {});

  let filtered = files;
  const queryVariant = () => {
    const paks = Object.keys(pakFiles).filter(key => pakFiles[key].length > 1);
    return Promise.map(paks, pakFile => {
      return api.showDialog('question', 'Choose Variant', {
        text: 'This mod has several variants for "{{pak}}" - please '
            + 'choose the variant you wish to install. (You can choose a '
            + 'different variant by re-installing the mod)',
        choices: pakFiles[pakFile].map((iter, idx) => ({ 
          id: iter,
          text: iter,
          value: idx === 0,
        })),
        parameters: {
          pak: pakFile,
        },
      }, [
        { label: 'Cancel' },
        { label: 'Confirm' },
      ]).then(res => {
        if (res.action === 'Confirm') {
          const choice = Object.keys(res.input).find(choice => res.input[choice]);
          filtered = filtered.filter(file => (path.extname(file) !== PAK_EXT)
            || ((path.basename(file) === pakFile) && file.includes(choice))
            || (path.basename(file) !== pakFile));
          return Promise.resolve();
        } else {
          return new util.UserCanceled();
        }
      });
    })
  };
  const generateInstructions = () => {
    const fileInstructions = filtered.reduce((accum, iter) => {
      if (!iter.endsWith(path.sep)) {
        iter = iter.match(/data[2-7].pak/) !== null //only 2-7 will be loaded by the game. 0-1 are vanilla paks
          ? iter 
          : 'data2.pak'; //use data2.pak if mod's pak name is invalid
        const destination = isPak(iter)
          ? shortid() + PAK_EXT
          : iter.split(path.sep).slice(idx).join(path.sep);
        if (isPak(iter)) {
          const pakDictIdx = accum.findIndex(attrib =>
            (attrib.type === 'attribute') && (attrib.key === 'pakDictionary'));
          if (pakDictIdx !== -1) {
            accum[pakDictIdx] = {
              ...accum[pakDictIdx],
              [destination]: path.basename(iter),
            }
          } else {
            accum.push({
              type: 'attribute',
              key: 'pakDictionary',
              value: { [destination]: path.basename(iter) },
            });
          }
        }
        accum.push({
          type: 'copy',
          source: iter,
          destination: destination,
        });
      }
      return accum;
    }, []);
    const instructions = [{ 
      type: 'setmodtype',
      value: PAK_ID,
    }].concat(fileInstructions);
    return instructions;
  }

  const prom = hasVariants ? queryVariant : Promise.resolve;
  return prom()
    .then(() => Promise.resolve({ instructions: generateInstructions() }));
} //*/

//*Install pak files (Merger version)
function installPak(api, files, fileName) {
  const rootCandidate = files.find((file) => file.toLowerCase().split(path.sep).includes("ph_ft"));
  const idx =
    rootCandidate !== undefined
      ? rootCandidate
          .toLowerCase()
          .split(path.sep)
          .findIndex((seg) => seg === "ph_ft")
      : 0;

  const MOD_NAME = path.basename(fileName);
  const MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");

  let hasVariants = false;
  const pakFiles = files.reduce((accum, iter) => {
    if (path.extname(iter) === ".pak") {
      const exists = accum[path.basename(iter)] !== undefined;
      if (exists) {
        hasVariants = true;
      }
      accum[path.basename(iter)] = exists ? accum[path.basename(iter)].concat(iter) : [iter];
    }
    return accum;
  }, {});

  let filtered = files;
  const queryVariant = () => {
    const paks = Object.keys(pakFiles).filter((key) => pakFiles[key].length > 1);
    return Promise.map(paks, (pakFile) => {
      return api
        .showDialog(
          "question",
          "Choose Variant",
          {
            text:
              'This mod has several variants for "{{pak}}" - please ' +
              "choose the variant you wish to install. (You can choose a " +
              "different variant by re-installing the mod)",
            choices: pakFiles[pakFile].map((iter, idx) => ({
              id: iter,
              text: iter,
              value: idx === 0,
            })),
            parameters: {
              pak: pakFile,
            },
          },
          [{ label: "Cancel" }, { label: "Confirm" }],
        )
        .then((res) => {
          if (res.action === "Confirm") {
            const choice = Object.keys(res.input).find((choice) => res.input[choice]);
            filtered = filtered.filter(
              (file) =>
                path.extname(file) !== PAK_EXT ||
                (path.basename(file) === pakFile && file.includes(choice)) ||
                path.basename(file) !== pakFile,
            );
            return Promise.resolve();
          } else {
            return new util.UserCanceled();
          }
        });
    });
  };
  const generateInstructions = () => {
    const fileInstructions = filtered.reduce((accum, iter) => {
      if (!iter.endsWith(path.sep)) {
        accum.push({
          type: "copy",
          source: iter,
          destination: path.join(MOD_FOLDER, path.basename(iter)),
        });
      }
      return accum;
    }, []);
    const instructions = [
      {
        type: "setmodtype",
        value: PAK_ID,
      },
    ].concat(fileInstructions);
    return instructions;
  };

  const prom = hasVariants ? queryVariant : Promise.resolve;
  return prom().then(() => Promise.resolve({ instructions: generateInstructions() }));
} //*/

//Installer test for Merger files
function testMergerUtility(files, gameId) {
  const isMod = files.some(
    (file) => path.basename(file).toLowerCase() === MERGER_EXEC.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isMod;

  /* Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  } //*/

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Merger files
function installMergerUtility(files) {
  const MOD_TYPE = MERGER_ID;
  const modFile = files.find(
    (file) => path.basename(file).toLowerCase() === MERGER_EXEC.toLowerCase(),
  );
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: "setmodtype", value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(
    (file) => file.indexOf(rootPath) !== -1 && !file.endsWith(path.sep),
  );

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Super Merger files
function testSuperMerger(files, gameId) {
  const isMod = files.some(
    (file) => path.basename(file).toLowerCase() === SUPERMERGER_EXEC.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isMod;

  /* Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  } //*/

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Super Merger files
function installSuperMerger(files) {
  const MOD_TYPE = SUPERMERGER_ID;
  const modFile = files.find(
    (file) => path.basename(file).toLowerCase() === SUPERMERGER_EXEC.toLowerCase(),
  );
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: "setmodtype", value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(
    (file) => file.indexOf(rootPath) !== -1 && !file.endsWith(path.sep),
  );

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const isMod = files.some((file) => ROOT_FOLDERS.includes(path.basename(file)));
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installRoot(files) {
  const modFile = files.find((file) => ROOT_FOLDERS.includes(path.basename(file)));
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`;
  const idx = modFile.indexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: "setmodtype", value: ROOT_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(
    (file) => file.indexOf(rootPath) !== -1 && !file.endsWith(path.sep),
  );

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Fallback installer to Binaries folder
function testBinaries(files, gameId) {
  const isPak = files.some((file) => path.extname(file).toLowerCase() === PAK_EXT);
  let supported = gameId === spec.game.id && !isPak;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install fallback
function installBinaries(files) {
  const setModTypeInstruction = { type: "setmodtype", value: BINARIES_ID };

  const filtered = files.filter((file) => !file.endsWith(path.sep));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

/* MERGER FUNCTIONS ///////////////////////////////////////////////////////////

function isPak(filePath) {
  return path.extname(filePath.toLowerCase()) === PAK_EXT;
}

//test whether to use the merger
function mergeTest(api, game, discovery) {
  if (game.id !== GAME_ID && discovery?.path !== undefined) {
    return undefined;
  }

  const installPath = selectors.installPathForGame(api.store.getState(), game.id);
  return {
    baseFiles: (deployedFiles) => deployedFiles
      .filter(file => isPak(file.relPath))
      .map(file => ({
        in: path.join(installPath, file.source, file.relPath),
        out: file.relPath,
      })),
    filter: filePath => isPak(filePath),
  };
}

merger file operations - filePath points to the mod file - mergeDir points to the __merged directory
function mergeOperation(api, filePath, mergeDir) {
  const state = api.getState();
  const modId = Object.keys(state.persistent.mods[GAME_ID]).find(id => filePath.includes(id));
  let pakDict;
  if (modId !== undefined) {
    const mod = state.persistent.mods[GAME_ID][modId];
    pakDict = mod.attributes.pakDictionary;
  }

  if (pakDict?.[path.basename(filePath)] === undefined) {
    log('error', 'file is not present in pak dictionary',
      { filePath, pakDict: pakDict !== undefined ? JSON.stringify(pakDict, undefined, 2) : 'undefined' });
    return Promise.resolve();
  }
  const sevenzip = new util.SevenZip();
  const destDir = path.join(mergeDir);
  const mergeFilePath = path.join(destDir, pakDict[path.basename(filePath)]);
  const zipFile = mergeFilePath + '.zip';
  const tempDir = path.join(mergeDir, 'temp');
  return fs.ensureDirWritableAsync(destDir)
    .then(() => fs.ensureDirWritableAsync(tempDir))
    .then(() => fs.statAsync(mergeFilePath)
      .then(() => sevenzip.extractFull(mergeFilePath, tempDir))
      .catch(err => err.code === 'ENOENT')
        ? Promise.resolve()
        : Promise.reject(err))
    .then(() => sevenzip.extractFull(filePath, tempDir))
    .then(() => new Promise((resolve, reject) => setTimeout(() => resolve(), 500)))
    .then(() => fs.readdirAsync(tempDir))
    .then(entries => sevenzip.add(zipFile, entries.map(entry => path.join(tempDir, entry)),
      { raw: ['-r'] }))
    .then(() => fs.unlinkAsync(tempDir))
    .then(() => fs.unlinkAsync(mergeFilePath)
      .catch(err => err.code === 'ENOENT')
        ? Promise.resolve()
        : Promise.reject(err))
    .then(() => fs.moveAsync(zipFile, mergeFilePath, { overwrite: true }));
} 
//*/

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

//Notify User of Setup instructions
function dotNetNotify(api) {
  const NOTIF_ID = `${GAME_ID}-dotnet`;
  const MESSAGE = `.NET ${DOTNET_VER} Desktop Runtime Required`;
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `.NET ${DOTNET_VER} Desktop Runtime is required to run the ${MERGER_NAME}.\n` +
                `You can download and install the runtime from the Microsoft website using the button below.\n` +
                `If you don't install the correct version of .NET, the Merger window will open and close immediately when launched, without doing anything.\n` +
                `Mods must be merged by the utility in order to be loaded by the game.\n`,
            },
            [
              {
                label: `Go To .NET ${DOTNET_VER} Download Page`,
                action: () => {
                  util.opn(DOTNET_URL).catch(() => null);
                  dismiss();
                },
              },
              { label: "Acknowledge", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

function checkForDotNet() {
  const version = DOTNET_VER;
  let values = undefined;
  try {
    const buffer = winapi.WithRegOpen(
      //array of objects with values.type and values.key
      DOTNET_REG_HIVE,
      DOTNET_REG_KEY,
      (hkey) => {
        //have to enum in the callback - https://github.com/Nexus-Mods/node-winapi-bindings/blob/master/index.d.ts
        values = winapi.RegEnumValues(hkey); //array of objects with values.type and values.key
      },
    );
    if (!values) {
      return false;
    }
    values = values.map((value) => value.key); //map array to only keys
    const found = values.some((value) => value.startsWith(version)); //find entry starting with correct version number
    if (found) {
      //log('warn', `Found .NET ${version} installation`);
      return true;
    } else {
      return false;
    }
  } catch (err) {
    //*/
    log("warn", `Failed to read .NET registry key: ${err}`);
    return false;
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  // ASYNC CODE //////////////////////////////////////////
  mergerInstalled = isMergerUtilityInstalled(api, gameSpec);
  superMergerInstalled = isSuperMergerInstalled(api, gameSpec);
  if (!superMergerInstalled && !mergerInstalled) {
    await chooseMerger(api, gameSpec);
  }
  //await downloadMergerUtility(api, gameSpec);
  if (isMergerUtilityInstalled(api, gameSpec)) {
    DOTNET_INSTALLED = checkForDotNet();
    if (!DOTNET_INSTALLED) {
      dotNetNotify(api);
    }
  }
  /* remove old merger folder if the user has it (temporary, remove after a few releases)
  const MERGER_FOLDER_OLD = path.join(STAGING_FOLDER, '__merged.dyinglightthebeast-pak');
  try {
    await fs.statAsync(MERGER_FOLDER_OLD);
    await fs.unlinkAsync(MERGER_FOLDER_OLD);
  } catch {
    //do nothing
  } //*/
  return vfs.ensureDirWritableAsync(path.join(GAME_PATH, MOD_PATH_DEFAULT));
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: () => gameSpec.game.executable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  /*register mod types explicitly
  context.registerModType(PAK_ID, 25, //id, priority
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, //isSupported - Is this mod for this game
    (game) => pathPattern(context.api, game, path.join('{gamePath}', PAK_PATH)), //getPath - mod install location
    () => Promise.resolve(false), //test - is installed mod of this type
    {
      name: PAK_NAME,
    } //options
  ); //*/

  //register mod installers
  context.registerInstaller(MERGER_ID, 25, testMergerUtility, installMergerUtility);
  context.registerInstaller(SUPERMERGER_ID, 27, testSuperMerger, installSuperMerger);
  context.registerInstaller(PAK_ID, 29, testPak, (files, fileName) =>
    installPak(context.api, files, fileName),
  ); // Change back to this function once Mod Merger Utility is updated to look for paks in subfolders
  //context.registerInstaller(CONFIG_ID, 43, testConfig, installConfig);
  //context.registerInstaller(SAVE_ID, 45, testSave, installSave);
  context.registerInstaller(ROOT_ID, 47, testRoot, installRoot);
  context.registerInstaller(BINARIES_ID, 49, testBinaries, installBinaries);

  //register actions
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    `Download ${SUPERMERGER_NAME} `,
    () => {
      downloadSuperMerger(context.api, spec).catch(() => null);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      const openPath = path.join(__dirname, "CHANGELOG.md");
      util.opn(openPath).catch(() => null);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      const openPath = DOWNLOAD_FOLDER;
      util.opn(openPath).catch(() => null);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    util.opn(CONFIG_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', () => {
    util.opn(SAVE_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      util.opn(PCGAMINGWIKI_URL).catch(() => null);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
}

//main function
function main(context) {
  applyGame(context, spec);
  /* merger for pak mods
  context.registerMerge(
    (game, discovery) => mergeTest(context.api, game, discovery),
    (filePath, mergeDir) => mergeOperation(context.api, filePath, mergeDir),
    PAK_ID
  ); //*/
  context.once(() => {
    // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    api.onAsync("did-deploy", async (profileId, deployment) => {
      const lastActiveProfile = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== lastActiveProfile) return;
      mergerInstalled = isMergerUtilityInstalled(api, spec);
      superMergerInstalled = isSuperMergerInstalled(api, spec);
      if (!superMergerInstalled && !mergerInstalled) {
        await chooseMerger(api, spec);
      }
      if (isMergerUtilityInstalled(api, spec)) {
        DOTNET_INSTALLED = checkForDotNet();
        if (!DOTNET_INSTALLED) {
          dotNetNotify(api);
        }
      }
      return deployNotify(api);
    });
    api.onAsync("did-purge", async (profileId, deployment) => {
      const lastActiveProfile = selectors.lastActiveProfileForGame(context.api.getState(), GAME_ID);
      if (profileId !== lastActiveProfile) return;
      return didPurge(api);
    }); //*/
  });
  return true;
}

async function didPurge(api) {
  GAME_PATH = getDiscoveryPath(api);
  const PAK_DIRECTORY = path.join(GAME_PATH, VANILLA_PAK_PATH);
  let FILES = await fsp.readdir(PAK_DIRECTORY);
  try {
    //clear non-vanilla pak files
    FILES = FILES.filter(
      (file) =>
        path.extname(file).toLowerCase() === PAK_EXT && !VANILLA_PAKS.includes(path.basename(file)),
    );
    //log('warn', `Removing pak files on purge: ${FILES.join(', ')}`);
    for (const file of FILES) {
      await vfs.unlinkAsync(path.join(PAK_DIRECTORY, file));
    }
  } catch (err) {
    log("error", `Failed to remove merged pak files: ${FILES.join(", ")} - ${err.message}`);
  }
  return Promise.resolve();
}

//Notify User to run Merger after deployment
function deployNotify(api) {
  const NOTIF_ID = `${GAME_ID}-deploy`;
  const MOD_NAME = "Merger";
  const MESSAGE = `Run ${MOD_NAME} to Install Mods`;
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Run ${MOD_NAME}`,
        action: (dismiss) => {
          runModManager(api);
          dismiss();
        },
      },
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `\n` +
                `For pak mods, you must use ${MOD_NAME} to merge all your paks into a single pak after installing with Vortex.\n` +
                `Use the included tool to launch ${MOD_NAME} (button below, in "Dashboard" tab, or in notification shown after deployment).\n` +
                `\n` +
                `You can run ${MOD_NAME} using the button below, or using the button on the Dashboard tab.\n` +
                `The use of this tool ensures that all your mods can work together when they make modifications to common files (such as "player_atributes.scr").\n`,
            },
            [
              {
                label: `Run ${MOD_NAME}`,
                action: () => {
                  runModManager(api);
                  dismiss();
                },
              },
              { label: "Continue", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

function runModManager(api) {
  mergerInstalled = isMergerUtilityInstalled(api, spec);
  superMergerInstalled = isSuperMergerInstalled(api, spec);
  let TOOL_ID = MERGER_ID;
  let TOOL_NAME = MERGER_NAME;
  if (superMergerInstalled) {
    TOOL_ID = SUPERMERGER_ID;
    TOOL_NAME = SUPERMERGER_NAME;
  }
  const state = api.store.getState();
  const tool = util.getSafe(
    state,
    ["settings", "gameMode", "discovered", GAME_ID, "tools", TOOL_ID],
    undefined,
  );

  try {
    const TOOL_PATH = tool.path;
    if (TOOL_PATH !== undefined) {
      return api.runExecutable(TOOL_PATH, [], { suggestDeploy: false, shell: true }).catch((err) =>
        api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, {
          allowReport: ["EPERM", "EACCESS", "ENOENT"].indexOf(err.code) !== -1,
        }),
      );
    } else {
      return api.showErrorNotification(
        `Failed to run ${TOOL_NAME}`,
        `Path to ${TOOL_NAME} executable could not be found. Ensure ${TOOL_NAME} is installed through Vortex.`,
      );
    }
  } catch (err) {
    return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, {
      allowReport: ["EPERM", "EACCESS", "ENOENT"].indexOf(err.code) !== -1,
    });
  }
}

//export to Vortex
module.exports = {
  default: main,
};
