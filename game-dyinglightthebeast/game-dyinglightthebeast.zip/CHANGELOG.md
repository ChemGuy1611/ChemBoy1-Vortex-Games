# Changelog

## [1.0.4] - 2026-11-23

- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.0.3] - 2026-11-09

- Fixed: .pak mods no longer fail to install with an error. Cancelling the variant choice now cancels the install.
- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.5.1] - 2026-09-08

- Fixed: Non-vanilla .pak files are now reliably removed when you purge mods.

## [0.5.0] - 2026-03-22

- Improved: Users are now presented a choice of which merger to use (Super or Unleashed) when no merger is installed.
- Improved: .NET 8 check for Unleashed users.

## [0.4.0] - 2026-01-28

- Added: Initial support for Super Mod Merger (new merger utility) - Proper install, button to download, run it from notification if installed

## [0.3.1] - 2025-10-06

- Added notification to install .NET8 if not found in the registry (required for Merger Utility).
- Added check for FOMOD installer to the .pak mod installer. This allows authors to use FOMODs to handle variants if they choose.

## [0.3.0] - 2025-09-27

- Updated pak installer to no longer re-zip pak mods files (Merger Utility was updated to look for paks in subfolders). Mods are installed in individual folders inside the "ph_ft/mods" folder.
- Removed pak deletion from "source" folder on deploy (Merger Utility now always outputs "data7.pak" file to "source" folder).
- Moved UTM Mod Merger Utility installer to top priority so it will always install properly.

## [0.2.1] - 2025-09-26

- Fixed undefined variable in the "More" text of the deployment notification to run UTM Mod Merger Utility.

## [0.2.0] - 2025-09-25

- Redesigned the pak installer to use "Unleash The Mods - Mod Merger Utility" as it can deconflict individual files within paks (i.e. player_variables.scr) and correct folder structure inside paks - <https://www.nexusmods.com/dyinglightthebeast/mods/140>
- Automatic download and install of Mod Merger Utility.
- User will receive a notification to run Mod Merger Utility after deploying mods.
- Extension will delete old merger folder from the staging folder if the user has used v0.1.1 previously.

## [0.1.1] - 2025-09-23

- Improved pak installer to ensure only paks with files names from data2.pak to data7.pak are merged (anything outside this range will be merged into data2.pak). The game will ONLY load paks from data2.pak to data7.pak.

## [0.1.0] - 2025-09-20

- Inital Release
