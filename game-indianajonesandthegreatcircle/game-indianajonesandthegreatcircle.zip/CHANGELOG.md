# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2025-12-09

- Added support for GOG version.
- Fixed game version detection for Xbox version.
- Added buttons to open folders (Config, Saves, and Downloads).
- Technical fixes and improvements.
