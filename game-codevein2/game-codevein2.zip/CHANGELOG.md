# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.1] - 2026-02-04

- Added: Support for RHFF Framework and its mods (.toml in pak installer)

## [0.1.0] - 2026-01-29

- Initial release
