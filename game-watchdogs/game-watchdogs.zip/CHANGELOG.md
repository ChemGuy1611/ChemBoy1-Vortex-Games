# Changelog

## [1.0.4] - 2026-11-23

- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.0.3] - 2026-11-20

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: The game is now named "Watch Dogs" (no underscore), so it is easier to find when searching for games in Vortex.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.2.3] - 2026-09-15

- Fixed: Mods packaged inside a subfolder could install to the wrong location if the archive also included an extra wrapper folder with a similar name.

## [0.2.2] - 2026-09-14

- Added "Open NexusTools Folder" and "Open Load Order File" buttons.

## [0.2.1] - 2026-09-13

- Fixed: Mods without .dat/.fat files are properly installed by detecting modconfig.json file.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.2.0] - 2026-09-12

- Added a "Skip NexusTools Confirm Window" setting, enabled by default, that skips NexusTools' in-game mod confirmation popup and the "Run NexusTools to Install Mods" notification after deploying.
- Added a Load Order page that controls NexusTools' own mod order and enabled state.
- Added right-click context menu (enable/disable, lock position, move to top/bottom, open mod/staging folder, open mod page), position locking, and status filtering (enabled/locked/unmanaged) to the Load Order page.

## [0.1.0] - 2026-06-16

- Initial Release
