# Changelog

Future Changes (NOT IMPLEMENTED YET):

- NONE

## [0.2.0] - 2025-05-28

- Added Xbox version support, with custom game version detection
- Added option to suppress setup notification
- Added button to force download latest Reloaded Mod Manager (folder icon in Mods toolbar)
- Several technical improvements
