# Changelog

## [1.1.2] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.1.1] - 2026-11-04

- Changed: Browse pages no longer open ads and other pop-ups in your web browser. A blocked page shows a notification with an "Open" button instead.

## [1.1.0] - 2026-11-03

- Added: "Browse GameBanana" page to browse the game's mods on GameBanana and install them directly in Vortex, with an "Open GameBanana Page" button.

## [1.0.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.1] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyData" for "Data") now install into the right place instead of a doubled folder.

## [1.0.0] - 2026-10-03

- Added a fallback installer: when no other installer matches a mod, Vortex now shows a notice and installs the files to the game folder.
- Setup now makes sure the Reloaded mod folders in the game folder are writable.

## [0.3.0] - 2026-10-02

- Added text information and button to run Reloaded-II as Admin to the setup notification (needed to install dependencies if running from a protected folder).
- Added a deploy notification with a button to run Reloaded-II as Admin after deployment.
- Fixed: Reloaded mods packaged inside a folder now keep that folder's name instead of being renamed after the downloaded file.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.2.1] - 2025-10-05

- Fixed an undefined variable in the game version detection function.

## [0.2.0] - 2025-05-28

- Added Xbox version support, with custom game version detection
- Added option to suppress setup notification
- Added button to force download latest Reloaded Mod Manager (folder icon in Mods toolbar)
- Several technical improvements
