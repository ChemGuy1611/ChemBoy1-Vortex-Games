# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.1] - 2026-01-27

- Fixed a possible deployment error due to missing BepInEx patchers folder.

## [0.1.0] - 2026-01-20

- Initial release
