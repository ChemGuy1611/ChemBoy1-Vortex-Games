# Changelog

## Planned Improvements (Not Yet Released)

## [0.2.1] - 2026-09-28

- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Game version now shows the real game build instead of the Unity engine version.

## [0.2.0] - 2026-09-20

- Added: "Browse Thunderstore" page, which opens the Disco Elysium Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [0.1.6] - 2026-09-13

- Updated: BepInExConfigManager now automatically checks for and installs the latest version instead of staying pinned to 18.4.1, and shows its proper name in the mod list
- Fixed: The "Download BepInExConfigManager" button did nothing when the mod was already installed. It now always downloads and reinstalls it
- Updated: BepInEx now installs a newer bleeding edge build
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.1.5] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.1.4] - 2026-03-22

- Fixed: Typo in a function name

## [0.1.3] - 2026-03-19

- Added: Xbox Game Pass version support

## [0.1.2] - 2026-03-16

- Fixed: Bump BepInEx BE to version 755
- Fixed: Migrated to more updated version of BepInExConfigManager

## [0.1.1] - 2026-01-27

- Fixed a possible deployment error due to missing BepInEx patchers folder.

## [0.1.0] - 2026-01-20

- Initial release
