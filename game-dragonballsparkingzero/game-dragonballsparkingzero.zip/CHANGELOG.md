# Changelog

## [1.0.0] - 2026-09-22

- Migrated to file-based load order (FBLO); added a lock button, multi-select, and a right-click context menu to the Paks load order page.
- Added a UE4SS Load Order page and a LogicMods Load Order page for Blueprint pak mods.
- Added UE4SS load order support to Collections.
- Added a status filter to the load order pages.
- Fixed: UE4SS auto-download was pointed at the wrong Nexus page and never worked; it now downloads from its GitHub releases and checks for updates.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Fixed: Mod files with no file extension were skipped during installation.
- Improved: Pak mods still carrying the old shared mod type are now retagged automatically instead of prompting you to reinstall them.

## [0.5.1] - 2026-02-05

- Improved: Made UE4SS Scripts, UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names
- Improved: Filter out JsonFiles.json file from SZModLoader, its mods, and JSON mods to avoid external changes popups
- Fixed: Corrected error message text

## [0.5.0] - 2026-02-01

- Fixed: Issue with Load Order sorting not working if certain other UE game extensions were installed. You will need to reinstall all pak mods to be able to sort them properly. A notification will be sent reminding you to do this.
- Added: Notification indicating deployment is required after changing the load order.
- Fixed: Missing FOMOD installer check for pak mods.
- Added: Installer for UE4SS DLL mods
- Improved: JsonFiles.json file update performance
- Improved: Reliability of download functions
- Improved: Config installer notification text
- Fixed: Path strings
- Added: Buttons to open JsonFiles.json file, open PCGamingWiki page, view changelog, and submit bug reports

## [0.4.3] - 2025-04-12

- Added automatic install of SZModLoader mod.

## [0.4.2] - 2025-04-12

- Fixed Vortex failing to manage the game on a clean game install by write-checking the Json folder before writing the JsonFiles.json file.

## [0.4.1] - 2025-04-11

- Fixed JsonFiles.json file list including the vortex.deployment.dragonballsparkingzero-json.json file.

## [0.4.0] - 2025-04-11

- Implemented automatic updating of the JsonFiles.json file with all installed json mod file names!
- Added a check for enabling config modtype if the user has the game, staging folder, and Local AppData folder on the same drive.
- Added an error message if the user attempts to install a config mod when the modtype is not available.
- Fixed mods not from Nexus not being sortable in the load order.
