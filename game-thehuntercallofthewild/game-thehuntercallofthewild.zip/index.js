/*///////////////////////////////////////////
Name: theHunter: Call of the Wild Vortex Extension
Structure: Basic Game
Author: ChemBoy1
Version: 0.2.1
Date: 2026-06-28
///////////////////////////////////////////*/

//Import libraries
const { actions, fs, util, selectors, log } = require('vortex-api');
const path = require('path');
const template = require('string-template');
const { parseStringPromise } = require('xml2js');

//const USER_HOME = util.getVortexPath("home");
const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath("appData");
//const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all the information about the game
const GAME_ID = "thehuntercallofthewild";
const STEAMAPP_ID = "518790";
const EPICAPP_ID = "4f0c34d469bb47b2bcf5b377f47ccfe3";
const GOGAPP_ID = null;
const XBOXAPP_ID = "AvalancheStudios.theHunterCalloftheWild-Windows10";
const XBOXEXECNAME = "Game";
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, EPICAPP_ID, XBOXAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const GAME_NAME = "theHunter: Call of the Wild";
const GAME_NAME_SHORT = "theHunter: CotW";
const EXEC = "theHunterCotW_F.exe";
const EXEC_EGS = EXEC;
const EXEC_XBOX = 'gamelaunchhelper.exe';
const CONFIGMOD_LOCATION = DOCUMENTS;
const CONFIG_FOLDERNAME = 'theHunter Call of the Wild';
const SAVEMOD_LOCATION = DOCUMENTS;
const SAVE_FOLDERNAME = 'COTW';
const EGS_FILE = 'versions.Paris-RC-Final.txt';
const APPMANIFEST_FILE = 'appxmanifest.xml';

let GAME_PATH = '';
let GAME_VERSION = '';
let STAGING_FOLDER = '';
let DOWNLOAD_FOLDER = '';

const DROPZONE_ID = `${GAME_ID}-dropzonefolder`;
const DROPZONE_NAME = "Dropzone Folder";
const DROPZONE_PATH = ".";
const DROPZONE_FOLDER = "dropzone";

const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_NAME = "Config";
const CONFIG_FOLDER = path.join(CONFIGMOD_LOCATION, 'Avalanche Studios');
const CONFIG_PATH_XBOX = path.join(CONFIG_FOLDER, 'Microsoft Store', CONFIG_FOLDERNAME, 'Saves', 'settings');
const CONFIG_PATH_EPIC = path.join(CONFIG_FOLDER, 'Epic Games Store', CONFIG_FOLDERNAME, 'Saves', 'settings');
const CONFIG_PATH_STEAM = path.join(CONFIG_FOLDER, CONFIG_FOLDERNAME, 'Saves', 'settings');
let CONFIG_PATH = CONFIG_FOLDER;

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = "Save Data File";
const SAVE_FOLDER = path.join(SAVEMOD_LOCATION, 'Avalanche Studios');
const SAVE_PATH_XBOX = path.join(SAVE_FOLDER, 'Microsoft Store', SAVE_FOLDERNAME, 'Saves');
const SAVE_PATH_EPIC = path.join(SAVE_FOLDER, 'Epic Games Store', SAVE_FOLDERNAME, 'Saves');
const SAVE_PATH_STEAM = path.join(SAVE_FOLDER, SAVE_FOLDERNAME, 'Saves');
let SAVE_PATH = SAVE_FOLDER;
let USERID_FOLDER = "";
const SAVE_STRINGS = [
  "found_icons_",
  "animal_population_",
];
const SAVE_FILES = [
  "achievements_adf",
  "achievements_progress_missiondata_adf",
  "codex_seen_status_adf",
  "collectibles_adf",
  "contextual_help_adf",
  "found_need_zones_adf",
  "health_component_manager_adf",
  "hunting_log_adf",
  "leaderboard_adf",
  "missions_missiondata_adf",
  "playerinformation_adf",
  "regions_adf",
  "reserveworlddata_adf",
  "settings_adf",
  "socialconfig",
  "statistics_adf",
  "thp_dog_profile_adf",
  "thp_player_profile_adf",
  "tropy_lodges_adf",
  "worlditemsdata_adf",
  "found_icons_0",
  "found_icons_1",
  "found_icons_2",
  "found_icons_3",
  "found_icons_4",
  "found_icons_5",
  "found_icons_6",
  "found_icons_7",
  "found_icons_8",
  "found_icons_9",
  "found_icons_10",
  "found_icons_11",
  "found_icons_12",
  "found_icons_13",
  "found_icons_14",
  "found_icons_15",
  "found_icons_16",
  "found_icons_17",
  "found_icons_18",
  "found_icons_19",
  "animal_population_0",
  "animal_population_1",
  "animal_population_2",
  "animal_population_3",
  "animal_population_4",
  "animal_population_5",
  "animal_population_6",
  "animal_population_7",
  "animal_population_8",
  "animal_population_9",
  "animal_population_10",
  "animal_population_11",
  "animal_population_12",
  "animal_population_13",
  "animal_population_14",
  "animal_population_15",
  "animal_population_16",
  "animal_population_17",
  "animal_population_18",
  "animal_population_19",
  "adf_fog_of_war_data_faster_0",
  "adf_fog_of_war_data_faster_1",
  "adf_fog_of_war_data_faster_2",
  "adf_fog_of_war_data_faster_3",
  "adf_fog_of_war_data_faster_4",
  "adf_fog_of_war_data_faster_5",
  "adf_fog_of_war_data_faster_6",
  "adf_fog_of_war_data_faster_7",
  "adf_fog_of_war_data_faster_8",
  "adf_fog_of_war_data_faster_9",
  "adf_fog_of_war_data_faster_10",
  "adf_fog_of_war_data_faster_11",
  "adf_fog_of_war_data_faster_12",
  "adf_fog_of_war_data_faster_13",
  "adf_fog_of_war_data_faster_14",
  "adf_fog_of_war_data_faster_15",
  "adf_fog_of_war_data_faster_16",
  "adf_fog_of_war_data_faster_17",
  "adf_fog_of_war_data_faster_18",
  "adf_fog_of_war_data_faster_19",
];

const APCGUI_ID = `${GAME_ID}-apcguide`;
const APCGUI_NAME = "Animal Population Changer GUI";
const APCGUI_EXEC = path.join('apcgui', 'apcgui.exe');

const MOD_PATH_DEFAULT = '.';
const REQ_FILE = 'archives_win64';
const PARAMETERS_STRING0 = '--vfs-fs dropzone';
const PARAMETERS_STRING1 = '--vfs-archive patch_win64';
const PARAMETERS_STRING2 = '--vfs-archive archives_win64';
const PARAMETERS_STRING3 = '--vfs-archive dlc_win64';
const PARAMETERS_STRING4 = '--vfs-fs.';
const PARAMETERS = [PARAMETERS_STRING0, PARAMETERS_STRING1, PARAMETERS_STRING2, PARAMETERS_STRING3, PARAMETERS_STRING4];

const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1432"; //Nexus link to this extension. Used for links
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/The_Hunter%3A_Call_of_the_Wild";
const IGNORE_CONFLICTS = [path.join('**', 'changelog*'), path.join('**', 'readme*')];
const IGNORE_DEPLOY = [path.join('**', 'changelog*'), path.join('**', 'readme*')];
const spec = {
  "game": {
    "id": GAME_ID,
    "name": GAME_NAME,
    "shortName": GAME_NAME_SHORT,
    "executable": EXEC,
    "parameters": PARAMETERS,
    "logo": `${GAME_ID}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPath": MOD_PATH_DEFAULT,
    "modPathIsRelative": true,
    "requiredFiles": [
      REQ_FILE
    ],
    "details": {
      "steamAppId": +STEAMAPP_ID,
      "gogAppId": GOGAPP_ID,
      "epicAppId": EPICAPP_ID,
      "xboxAppId": XBOXAPP_ID,
      "ignoreConflicts": IGNORE_CONFLICTS,
      "ignoreDeploy": IGNORE_DEPLOY,
    },
    "environment": {
      "SteamAPPId": STEAMAPP_ID,
      "GogAPPId": GOGAPP_ID,
      "EpicAPPId": EPICAPP_ID,
      "XboxAPPId": XBOXAPP_ID,
    }
  },
  "modTypes": [
    {
      "id": DROPZONE_ID,
      "name": DROPZONE_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', DROPZONE_PATH)
    },
  ],
  "discovery": {
    "ids": DISCOVERY_IDS_ACTIVE,
    "names": []
  }
};

//3rd party tools and launchers
const tools = [
  {
    id: `${GAME_ID}-customlaunch`,
    name: 'Custom Launch',
    logo: 'exec.png',
    executable: () => EXEC,
    requiredFiles: [
      EXEC,
    ],
    relative: true,
    exclusive: true,
    shell: true,
    defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  {
    id: APCGUI_ID,
    name: APCGUI_NAME,
    logo: 'apcgui.png',
    executable: () => APCGUI_EXEC,
    requiredFiles: [
      APCGUI_EXEC,
    ],
    relative: true,
    exclusive: true,
    //shell: true,
    //parameters: [],
  }, //*/
];

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fs.statAsync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

//Set mod type priorities
async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fs.readdirAsync(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fs.statAsync(fullPath);
      if (stats.isDirectory()) { // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else { // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log('warn', `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath: (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0 ? void 0 : _a.path,
      documents: util.getVortexPath('documents'),
      localAppData: util.getVortexPath('localAppData'),
      appData: util.getVortexPath('appData'),
    });
  }
  catch (err) { //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification('Failed to locate executable. Please launch the game at least once.', err);
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () => gameSpec.game.modPathIsRelative !== false
    ? gameSpec.game.modPath || '.'
    : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () => util.GameStoreHelper.findByAppId(gameSpec.discovery.ids)
    .then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher(gamePath, store) {
  if (store === 'xbox' && (DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID))) {
      return Promise.resolve({
        launcher: 'xbox',
        addInfo: {
          appId: XBOXAPP_ID,
          parameters: [{ appExecName: XBOXEXECNAME }],
          //parameters: [{ appExecName: XBOXEXECNAME }, PARAMETERS_STRING0, PARAMETERS_STRING1, PARAMETERS_STRING2, PARAMETERS_STRING3, PARAMETERS_STRING4],
          //launchType: 'gamestore',
        },
      });
  } //*/
  if (store === 'epic' && (DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID))) {
    return Promise.resolve({
        launcher: 'epic',
        addInfo: {
          appId: EPICAPP_ID,
          //parameters: PARAMETERS,
          //launchType: 'gamestore',
        },
    });
  } //*/
  //*
  if (store === 'steam') {
    return Promise.resolve({
      launcher: 'steam',
    });
  } //*/
  return Promise.resolve(undefined);
}

//Get correct executable for game version
function getExecutable(discoveryPath) {
  if (statCheckSync(discoveryPath, EXEC_XBOX)) {
    GAME_VERSION = 'xbox';
    CONFIG_PATH = CONFIG_PATH_XBOX;
    SAVE_PATH = SAVE_PATH_XBOX;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return EXEC;
  };
  if (statCheckSync(discoveryPath, EGS_FILE)) {
    GAME_VERSION = 'epic';
    CONFIG_PATH = CONFIG_PATH_EPIC;
    SAVE_PATH = SAVE_PATH_EPIC;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return EXEC;
  };
  if (statCheckSync(discoveryPath, EXEC)) {
    GAME_VERSION = 'steam';
    CONFIG_PATH = CONFIG_PATH_STEAM;
    SAVE_PATH = SAVE_PATH_STEAM;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return EXEC;
  };
}

//Get correct game version
async function setGameVersion(gamePath) {
  if (await statCheckAsync(gamePath, EXEC_XBOX)) {
    GAME_VERSION = 'xbox';
    return GAME_VERSION;
  };
  if (await statCheckAsync(gamePath, EGS_FILE)) {
    GAME_VERSION = 'epic';
    return GAME_VERSION;
  };
  if (await statCheckAsync(gamePath, EXEC)) {
    GAME_VERSION = 'steam';
    return GAME_VERSION;
  };
}

//Get correct game version
function getSavePath(api) {
  GAME_PATH = getDiscoveryPath(api);
  if (statCheckSync(GAME_PATH, EXEC_XBOX)) {
    GAME_VERSION = 'xbox';
    CONFIG_PATH = CONFIG_PATH_XBOX;
    SAVE_PATH = SAVE_PATH_XBOX;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return SAVE_PATH;
  };
  if (statCheckSync(GAME_PATH, EGS_FILE)) {
    GAME_VERSION = 'epic';
    CONFIG_PATH = CONFIG_PATH_EPIC;
    SAVE_PATH = SAVE_PATH_EPIC;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return SAVE_PATH;
  };
  if (statCheckSync(GAME_PATH, EXEC)) {
    GAME_VERSION = 'steam';
    CONFIG_PATH = CONFIG_PATH_STEAM;
    SAVE_PATH = SAVE_PATH_STEAM;
    try {
      const SAVE_ARRAY = fs.readdirSync(SAVE_PATH);
      USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_PATH, entry));
    } catch {
      USERID_FOLDER = "";
    }
    if (USERID_FOLDER === undefined) {
      USERID_FOLDER = "";
    } //*/
    SAVE_PATH = path.join(SAVE_PATH, USERID_FOLDER);
    return SAVE_PATH;
  };
}

const getDiscoveryPath = (api) => { //get the game's discovered path
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, GAME_ID], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) { //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) => api.events.emit('purge-mods', true, (err) => err ? reject(err) : resolve()));
}
async function deploy(api) { //useful to deploy mods after doing some action
  return new Promise((resolve, reject) => api.events.emit('deploy-mods', (err) => err ? reject(err) : resolve()));
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Test for dropzone folder
function testDropzone(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === DROPZONE_FOLDER));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install dropzone folder
function installDropzone(files) {
  const MOD_TYPE = DROPZONE_ID;
  const modFile = files.find(file => (path.basename(file).toLowerCase() === DROPZONE_FOLDER));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for save files
function testSave(files, gameId) {
  const isMod = files.some(file => (SAVE_FILES.includes(path.basename(file).toLowerCase())));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install save files
function installSave(files) {
  const MOD_TYPE = SAVE_ID;
  const modFile = files.find(file => (SAVE_FILES.includes(path.basename(file).toLowerCase())));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    SAVE_FILES.includes(path.basename(file).toLowerCase()) &&
    //(file.indexOf(rootPath) !== -1) &&
    !file.endsWith(path.sep)
  ));

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

async function resolveGameVersion(gamePath) {
  GAME_VERSION = await setGameVersion(gamePath);
  let version = '0.0.0';
  if (GAME_VERSION === 'xbox') { // use appxmanifest.xml for Xbox version
    try { //try to parse appxmanifest.xml
      const appManifest = await fs.readFileAsync(path.join(gamePath, APPMANIFEST_FILE), 'utf8');
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log('error', `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  else { // use exe
    try {
      const exeVersion = require('exe-version');
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC));
      return Promise.resolve(version);
    } catch (err) {
      log('error', `Could not read ${EXEC} file to get Steam game version: ${err}`);
      return Promise.resolve(version);
    }
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, gameSpec.game.id);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, gameSpec.game.id);
  SAVE_PATH = getSavePath(api);
  // ASYNC CODE //////////////////////////////////////////
  await fs.ensureDirWritableAsync(SAVE_PATH);
  return fs.ensureDirWritableAsync(path.join(GAME_PATH, DROPZONE_FOLDER));
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  const game = { //register game
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: () => gameSpec.game.executable,
    //executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersion,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //register mod types explicitly
  /*context.registerModType(CONFIG_ID, 60,
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    },
    (game) => pathPattern(context.api, game, CONFIG_PATH),
    () => Promise.resolve(false),
    { name: CONFIG_NAME }
  ); //*/
  context.registerModType(SAVE_ID, 60,
    (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    },
    (game) => getSavePath(context.api),
    () => Promise.resolve(false),
    { name: SAVE_NAME }
  ); //*/

  //register mod installers
  context.registerInstaller(DROPZONE_ID, 25, testDropzone, installDropzone);
  //context.registerInstaller(CONFIG_ID, 48, testConfig, installConfig);
  context.registerInstaller(SAVE_ID, 49, testSave, installSave);

  //register actions
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Data Folder', () => {
    util.opn(SAVE_PATH).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    util.opn(CONFIG_PATH).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    const openPath = path.join(__dirname, 'CHANGELOG.md');
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', () => {
    util.opn(SAVE_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
}

//main function
function main(context) {
  applyGame(context, spec);
  context.once(() => { // put code here that should be run (once) when Vortex starts up
    const api = context.api;

  });
  return true;
}

//export to Vortex
module.exports = {
  default: main,
};
