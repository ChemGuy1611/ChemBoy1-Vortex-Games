# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.0] - 2025-08-18

- Inital Release
