# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.0] - 2025-09-13

- Added error catch for undefined executable (caused by Xbox app locking down the game folder).

## [0.1.0] - 2025-09-10

- Inital Release
