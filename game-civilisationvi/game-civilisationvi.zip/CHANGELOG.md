# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):

- None Planned

## [0.1.2] - 2025-07-20

- Fixed Epic version mod folder name.
- Corrected Epic app ID for discovery.

## [0.1.1] - 2025-05-15

- Added Epic version support. Thanks to user Ateih for the info.
- Several technical fixes and QoL improvements.

## [0.1.0]

- Initial release
