# Changelog

## [1.0.3] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.2.1] - 2026-10-02

- Added support for the Xbox / Microsoft Store version of the game.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.2.0] - 2026-08-03

- Fixed: Multiple technical fixes.

## [0.1.3] - 2025-07-31

- Fixed an undefined variable error that could occur if the game folder is not readable.

## [0.1.2] - 2025-07-20

- Fixed Epic version mod folder name.
- Corrected Epic app ID for discovery.
- Added installer for game root folder (mod contains "Base" folder).

## [0.1.1] - 2025-05-15

- Added Epic version support. Thanks to user Ateih for the info.
- Several technical fixes and QoL improvements.

## [0.1.0]

- Initial release
