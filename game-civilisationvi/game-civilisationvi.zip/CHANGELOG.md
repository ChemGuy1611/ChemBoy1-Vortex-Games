# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET)

- None Planned

## [0.1.3] - 2025-07-31

- Fixed an undefined variable error that could occur if the game folder is not readable.

## [0.1.2] - 2025-07-20

- Fixed Epic version mod folder name.
- Corrected Epic app ID for discovery.
- Added installer for game root folder (mod contains "Base" folder).

## [0.1.1] - 2025-05-15

- Added Epic version support. Thanks to user Ateih for the info.
- Several technical fixes and QoL improvements.

## [0.1.0]

- Initial release
