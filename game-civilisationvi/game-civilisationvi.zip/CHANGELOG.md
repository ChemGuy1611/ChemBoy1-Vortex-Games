# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):
- 

## [0.1.1] - 2025-05-15
- Added Epic version support. Thanks to user Ateih for the info.
- Several technical fixes and QoL improvements.

## [0.1.0]
- Initial release
