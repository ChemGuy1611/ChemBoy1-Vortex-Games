# Changelog

## [1.3.1] - 2026-11-04

- Changed: Browse pages no longer open ads and other pop-ups in your web browser. A blocked page shows a notification with an "Open" button instead.

## [1.3.0] - 2026-11-03

- Added: "Browse GameBanana" and "Browse ModWorkshop" pages to browse the game's mods on those sites and install them directly in Vortex, with "Open GameBanana Page" and "Open ModWorkshop Page" buttons.

## [1.2.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.2.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.2.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [1.1.1] - 2026-09-06

- Fixed: Locked load order entries could be moved out of position when using "Move to Top", "Move to Bottom" or the position number box on another entry. Locked entries now keep their place.
- Fixed: The load order position number box now accepts low numbers even when a locked entry is further down the list.

## [1.1.0] - 2026-08-31

- Added: Binaries (.dll) and fallback installers.

## [1.0.1] - 2026-08-29

- The mod options dialog has a "Select All" button for mods that offer several components to install.

## [1.0.0] - 2026-08-23

- Patch mods for any game archive are now ordered and renamed automatically. Previously only mods for one specific archive were, and everything else had to be renumbered by hand.
- Sound mods are now handled like every other patch mod. They appear in the load order and no longer overwrite each other when two of them change the same archive.
- New "Patch Conflicts" page lists the archives that more than one mod changes, and lets you reorder the mods within one of those archives on its own.
- The load order page has been rebuilt: multi-select, right-click menu, position locking, status filters, and a marker on any mod that shares an archive with another.
- Added a warning when a mod patches an archive your installed version of the game does not have, since those files have no effect in game.
- Deployment now stops with an error if a patch file cannot be written, instead of quietly skipping it and leaving the remaining mods for that archive broken.
- Mods that offer several versions now ask once for the whole mod. Previously the same question was repeated for each file in the mod, and answering them differently produced a broken install.
- Mods that include a `manifest.json` now show the options the mod author wrote, with their descriptions, images and categories. Optional extras can be enabled together, and a mod can offer a choice of versions within one of them.
- Files from two options that change the same game archive are now numbered so both are installed, instead of one replacing the other.
- The "Patch Conflicts" page has its own icon so it is easier to tell apart from the load order page.
- Fixed: readme and other documentation files included in a patch mod are no longer discarded.
- Fixed: patch mods that keep their files in a subfolder are now recognised correctly.

## [0.7.1] - 2026-01-28

- Fixed: Path strings

## [0.7.0] - 2025-09-24

- .patch_0 graphics mods installer will present the user a dialogue to select which variant to install if the mod archive has multiple variants. Currently, the user must select the same variant for each of the .patch_0, .stream, and .gpu_resources files.
- .patch_0 sound mods installer will present the user a dialogue to select which variant to install if the mod archive has multiple variants. Files still must be manually renamed at this time.

## [0.6.1] - 2025-09-20

- Disabled notification suggesting the user disable auto-deploy (Vortex has been updated so that this is no longer needed).
