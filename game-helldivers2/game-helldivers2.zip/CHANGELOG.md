# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.6.1] - 2025-09-20

- Disabled notification suggesting the user disable auto-deploy (Vortex has been updated so that this is no longer needed).
