# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.7.0] - 2025-09-24

- .patch_0 graphics mods installer will present the user a dialogue to select which variant to install if the mod archive has multiple variants. Currently, the user must select the same variant for each of the .patch_0, .stream, and .gpu_resources files.
- .patch_0 sound mods installer will present the user a dialogue to select which variant to install if the mod archive has multiple variants. Files still must be manually renamed at this time.

## [0.6.1] - 2025-09-20

- Disabled notification suggesting the user disable auto-deploy (Vortex has been updated so that this is no longer needed).
