# Changelog

## [2.2.2] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [2.2.1] - 2026-11-04

- Changed: Browse pages no longer open ads and other pop-ups in your web browser. A blocked page shows a notification with an "Open" button instead.

## [2.2.0] - 2026-11-03

- Added: "Browse GameBanana" page to browse the game's mods on GameBanana and install them directly in Vortex, with an "Open GameBanana Page" button.

## [2.1.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [2.1.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [2.1.1] - 2026-10-12

- Fixed: Removed the "Custom Launch (Demo)" button. The demo uses the same re2.exe as the full game, so the button only started the full game a second time.

## [2.1.0] - 2026-10-11

- Fixed: Steam installs of the full game were treated as the 1-Shot Demo, so mods went to the demo's Fluffy folders and the save-game lookup used the demo's app id. The full game now uses its own folders, so purge and redeploy your mods after updating. The demo (same re2.exe) is no longer handled separately.
- Fixed: Mods packaged inside an outer folder named like one of the mod's key files (for example "dinput8.dll.old") now install into the right place.
- Fixed: Lua script mods with scripts in more than one folder now install every folder instead of only the first.
- Fixed: A mod archive containing another archive with an upper-case extension (.ZIP, .RAR, .7Z) is now installed as it is instead of being packed into another zip.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [2.0.0] - 2026-09-15

- Migrated extension to new Fluffy-integrated system. Users of old versions must verify their game files and reinstall all mods in Vortex.
