# Changelog

## [1.0.3] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.0.2] - 2026-10-22

- Changed: The Xbox version is no longer detected until it is supported.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyData" for "Data") now install into the right place instead of a doubled folder.
- Fixed: Mods whose main file name uses different letter casing no longer fail to install.

## [0.2.0] - 2026-04-17

- Added: Root files installer
- Fixed: Updated SRMM Mod installer to look for mod-meta.yaml file.

## [0.1.4] - 2025-03-12

- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including SRMM, to fail with wrong URL
- Removed 'site' from compatibleDownloads, as it would cause all mods from the Modding Tools domain the user has installed to show up as uninstalled mods in the mod list
