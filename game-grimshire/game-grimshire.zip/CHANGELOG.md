# Changelog

## Planned Improvements (Not Yet Released)

## [1.0.1] - 2026-09-27

- Game version now shows the real game build instead of the Unity engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.0.0] - 2026-09-15

- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Bepinex Config Manager always fetches the latest version, and gives update notifications when a new version is available.
- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation
- Changed: Plugins that don't already ship their own folder are now installed into one of their own, so two mods with a same-named file no longer overwrite each other

## [0.1.1] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.1.0] - 2026-04-09

- Initial release
