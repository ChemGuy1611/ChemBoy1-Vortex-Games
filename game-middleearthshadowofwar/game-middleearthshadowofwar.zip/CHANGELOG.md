# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [2.0.0] - 2025-12-19

- Inital Release
