# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [2.1.0] - 2025-12-22

- Added Load Order support and automatic update of default.archcfg file for .arch06 mods

## [2.0.0] - 2025-12-19

- Inital Release
