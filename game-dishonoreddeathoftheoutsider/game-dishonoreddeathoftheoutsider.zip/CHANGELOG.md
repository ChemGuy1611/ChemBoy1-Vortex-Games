# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- Better installer for D2Fix mod - handle multiple folders + select options based on game version.
- ? Disable Config/Save installers so that hardlinks will be available for more users? - symlinks seem fine.

## [0.1.1] - 2025-11-23

- Added Epic version support. Thanks to user originalksd for the info.

## [0.1.0] - 2025-11-13

- Initial release.
