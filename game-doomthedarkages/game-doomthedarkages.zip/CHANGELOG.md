# Changelog

FUTURE CHANGES (NOT IMPLEMENTED YET):

- Mod Injector integration - upon release

## [0.1.3] - 2025-05-28

- Fixed game version detection for Xbox version

## [0.1.2] - 2025-05-24

- Added installer for .cfg files to "base" folder
- Added functions to write all user-installed .cfg files to the autoexec.cfg file
- Added "+exec autoexec.cfg" to all launch parameters
- Added button to open autoexec.cfg file (folder icon in Mods toolbar)

## [0.1.1] - 2025-05-19

- Changed executable to idTechLauncher.exe to ensure proper dll injection when launching the game.
- Added skip intro launch parameters for Steam (GamePass can use the Custom Launch tool).
- Fixed config and save folder open buttons (Steam Saves folder not accessible).

## [0.1.0] - 2025-05-14

- Initial release
