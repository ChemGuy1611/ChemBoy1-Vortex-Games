# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2025-09-22

- Added Xbox version ID and full support.
