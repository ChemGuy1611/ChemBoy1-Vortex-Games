# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.2.1] - 2025-10-02

- Added notification on deployment to run Mod Importer.

## [0.2.0] - 2025-09-22

- Added Xbox version ID and full support.
