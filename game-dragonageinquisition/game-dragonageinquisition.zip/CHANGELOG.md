# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.2.4] - 2026-01-30

- Fixed: paths strings
- Added: Buttons to open Config/Save folder, Downloads folder, PCGamingWiki page, view changelog, and submit bug reports
