# Changelog

## Planned Improvements (Not Yet Released)

- None

## [0.2.3] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [0.2.2] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [0.2.1] - 2026-10-02

- Added support for the Xbox / Microsoft Store version of the game.
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [0.2.0] - 2026-08-03

- Fixed: Readme and changelog files inside mods no longer show up as file conflicts.
- Fixed: Paths are now built safely on all systems.
- Added: Buttons to open the game's PCGamingWiki page, view the changelog, submit a bug report, and open the downloads folder.

## [0.1.2]

- Initial release
