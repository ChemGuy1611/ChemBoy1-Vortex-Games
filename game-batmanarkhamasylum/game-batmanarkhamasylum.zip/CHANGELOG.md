# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.1.1] - 2026-01-30

- Fixed: Game version detection

## [0.1.0] - 2025-XX-XX

- Initial release.
