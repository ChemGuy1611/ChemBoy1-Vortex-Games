# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.1.0] - 2025-XX-XX

- Initial release.
