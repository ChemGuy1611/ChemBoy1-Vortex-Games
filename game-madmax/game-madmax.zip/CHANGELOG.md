# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.0] - 2026-04-24

- Initial Release
