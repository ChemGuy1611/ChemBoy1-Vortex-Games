/*////////////////////////////////////////////////
Name: Keeper Vortex Extension
Structure: Unreal Engine 4-5 Game
Author: ChemBoy1
Version: 1.0.4
Date: 2026-11-01
Notes:
- The project folder differs per store: Steam and GOG use Keeper\ (Keeper\Content, Keeper\Binaries\Win64), the Microsoft Store (Xbox) build uses PaganIdol\ (PaganIdol\Content, PaganIdol\Binaries\WinGDK). EPIC_CODE_NAME is the Steam/GOG folder and XBOX_CODE_NAME the Xbox one. The template assumes one folder, so setProjectFolder() (every site marked KEEPER ONLY) swaps each project-relative path to the active store's folder from getExecutable() and setup().
- The game is Unreal Engine 5.5.4. No Keeper mod has used UE4SS yet; other UE 5.5 games needed a hand-made ue4ss\UE4SS_Signatures\*.lua next to stock UE4SS, which the Download UE4SS button does not provide, so UE4SS may not start until a signature file is added.
- Unverified (no install was available and PCGamingWiki's Windows config and save rows are empty): the Steam/GOG Config folder name (Windows assumed), the Steam/GOG Save layout (flat SaveGames assumed), and the whole GOG build (assumed identical to Steam). Xbox Config (%LOCALAPPDATA%\Keeper\Saved\Config\WinGDK) and Save (Packages\Microsoft.PaganIdol_8wekyb3d8bbwe\SystemAppData\wgs) come from PCGamingWiki and files on disk. The data folder is Keeper, not PaganIdol, on every store.
////////////////////////////////////////////////*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const {
  actions,
  fs: vfs,
  util,
  selectors,
  log,
  MainPage,
  FlexLayout,
  DNDContainer,
  DraggableList,
  VortexError,
} = require("vortex-api");
const path = require("path");
const crypto = require("crypto");
const winapi = require("winapi-bindings");
const template = require("string-template");
const { parseStringPromise } = require("xml2js");
const { default: IniParser, WinapiFormat } = require("vortex-parse-ini");
const React = require("react");
//Auto-downloader module
const {
  download,
  findModByFile,
  findDownloadIdByFile,
  resolveVersionByModVersion,
  testRequirementVersion,
} = require("./downloader");

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

/*const USER_HOME = util.getVortexPath("home");
const LOCALLOW = path.join(USER_HOME, 'AppData', 'LocalLow'); //*/
//const DOCUMENTS = util.getVortexPath('documents');
//const ROAMINGAPPDATA = util.getVortexPath('appData');
const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all information about the game
const GAME_ID = "keeper"; //same as Nexus domain
const STEAMAPP_ID = "3043580"; //from steamdb.info
const STEAMAPP_ID_DEMO = null; //no demo exists
const EPICAPP_ID = null; //not on Epic
const GOGAPP_ID = "1428536898"; // from gogdb.org
const XBOXAPP_ID = "Microsoft.PaganIdol"; //from appxmanifest.xml
const XBOXEXECNAME = "AppKeeperShipping"; //from appxmanifest.xml
const XBOX_PUB_ID = "8wekyb3d8bbwe"; //get from Save folder. '8wekyb3d8bbwe' if published by Microsoft
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, GOGAPP_ID, XBOXAPP_ID]; // UPDATE THIS WITH ALL VALID IDs

const GAME_NAME = "Keeper";
const GAME_NAME_SHORT = "Keeper"; //Try for 8-10 characters
const EPIC_CODE_NAME = "Keeper"; //Folder in root (Steam + GOG)
const XBOX_CODE_NAME = "PaganIdol"; //KEEPER ONLY: Folder in root of the Microsoft Store (Xbox) build
const EXEC = `${EPIC_CODE_NAME}.exe`; //This is true ~80% of the time. Change if different
const EXEC_EPIC = EXEC; //change these 3 if different
const EXEC_GOG = EXEC;
const EXEC_DEMO = EXEC;
const PARAMETERS_STRING = ""; //launch arguments to pass when launching the game
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Keeper";
const STEAMDB_URL = `https://steamdb.info/app/${STEAMAPP_ID}/`;
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1504"; //Nexus link to this extension. Used for links

//feature toggles
let hasXbox = false; //toggle for Xbox version logic.
if (DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID)) hasXbox = true;
let multiExe = false; //toggle for multiple executables (Epic/GOG/Demo don't match Steam)
if (EXEC !== EXEC_EPIC || EXEC !== EXEC_GOG || EXEC !== EXEC_DEMO) {
  multiExe = true;
} //*/
const setupNotification = false; //enable to show the user a notification with special instructions (specify below)
const hasModKit = false; //toggle for UE ModKit mod support
const hasServer = false; //toggle for server pak mod logic
const preferHardlinks = true; //set true to perform partition checks when IO-STORE=false for Config/Save modtypes so that hardlinks available to more users
const autoDownloadUe4ss = false; //toggle for auto downloading UE4SS (only applies when ue4ssLoadOrder is enabled)
const writeEngineVersion = false; //toggle to write ENGINE_VERSION into UE4SS-settings.ini (EngineVersionOverride) on deploy, when UE4SS is installed
const SIGBYPASS_REQUIRED = false; //set true if there are .sig files in the Paks folder
const IO_STORE = true; //true if the Paks folder contains .ucas and .utoc files
const hasUserIdFolder = false; //true if there is a folder in the Save path that is a user ID that must be read (i.e. Steam ID)
const debug = false; //toggle for debug mode
const exeHasGameVersion = false; //toggle: true if the game devs stamp the real game version (not just the UE engine version) into the exe ProductVersion

//UE specific
const ENGINE_VERSION = "5.5.4.0"; //Unreal Engine version. usually '4.27.2.0' or '5.X.X.0'. Written to UE4SS-settings.ini if writeEngineVersion is enabled
const MAJOR_VERSION = ENGINE_VERSION.split(".")[0]; //major UE version
const MINOR_VERSION = ENGINE_VERSION.split(".")[1]; //minor UE version
const ROOT_FOLDERS = [EPIC_CODE_NAME, XBOX_CODE_NAME, "Engine"]; //addressable folders in root (KEEPER ONLY: both store project folders)
const ROOTSUB_FOLDERS = ["Content", "Binaries", "Mods"]; //subfolders of EPIC_CODE_NAME. Don't use "Plugins" here since it can conflict with plugin loader/asi mods
const CONTENTSUB_FOLDERS = ["Paks", "Movies"]; //subfolders of Content folder
const UE4SS_SUBFOLDERS = [
  "MapGenBP",
  "MemberVarLayoutTemplates",
  "UE4SS_Signatures",
  "VTableLayoutTemplates",
]; //subfolders of UE4SS folder
const SAVE_EXTS = [".sav"];
const SAVE_COMPAT_VERSIONS = ["steam", "epic", "gog"]; //game versions with installable save mods (never Xbox)
let PAKMOD_PATH = path.join(EPIC_CODE_NAME, "Content", "Paks", "~mods"); //usually works. Some games don't work from "~mods".
const PAKMOD_LOADORDER = true; //set to false if you don't want loadOrder. If must be in "Paks" root, disable loadOrder.
const FBLO = true; //set to false to use legacy load order page
const LO_IMAGE_WIDTH = 96; //Width of the load order thumbnail image
const SPECIAL_LO_INSTRUCTIONS = ""; //Show special load order instructions
const PAKMOD_EXTRA_EXTS = []; //extra extensions to include with paks (usually for custom modding frameworks, i.e .toml, .json)
const ue4ssLoadOrder = true; //master toggle for UE4SS support: UE4SS/Scripts/DLL/LogicMods mod types and installers, UE4SS buttons, load order page, and mods.txt writing
const logicModsLoadOrder = true; //enable load order page and load_order.txt writing for LogicMods/Blueprint pak mods
const collectionsLoadOrder = true; //include UE4SS and LogicMods load orders in collections (ANDed with the toggles above)
const UE4SS_PAGE_NO = 0; //set these if there is a customized UE4SS Nexus page
const UE4SS_FILE_NO = 0;
const UE4SS_DOMAIN = GAME_ID; //either GAME_ID or 'site'
const UE4SS_FOLDER = "ue4ss"; //this should probably never change
const UE4SS_MOD_PATH = path.join(UE4SS_FOLDER, "Mods"); //this should probably never change (unless UE4SS team changes it again lol)

//config and save
const DATA_FOLDER = EPIC_CODE_NAME; //almost always matches.
const CONFIG_FOLDERNAME = "Windows"; //UE 4 games are often 'WindowsNoEditor' - "Windows", "WindowsClient", "WindowsNoEditor"
const CONFIG_LOC = "Local AppData"; //string for notification text.
const SAVE_LOC = CONFIG_LOC; //string for notification text. Config and Save mods are almost always in the same place
const CONFIGMOD_LOCATION = LOCALAPPDATA; //almost always matches. Some are in game folder or Documents.
const SAVEMOD_LOCATION = CONFIGMOD_LOCATION;

//shipping exe
const SHIPEXE_STRING_DEFAULT = "";
const SHIPEXE_STRING_EGS = "";
const SHIPEXE_STRING_GOG = "";
const SHIPEXE_STRING_XBOX = "";
const SHIPEXE_STRING_DEMO = "";
const SHIPEXE_PROJECTNAME = EPIC_CODE_NAME; //almost always matches.
const SHIPEXE_PROJECTNAME_XBOX = XBOX_CODE_NAME; //KEEPER ONLY: Xbox shipping exe is PaganIdol-WinGDK-Shipping.exe

//Save Editor (only used if one is available)
const SAVE_EDITOR_ID = `${GAME_ID}-saveeditor`;
const SAVE_EDITOR_NAME = "Save Editor";
const SAVE_EDITOR_EXEC = "XXX.exe";

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const LO_IMAGE_HEIGHT = LO_IMAGE_WIDTH * 0.5625;
//const ENGINE_VERSION_NO = +ENGINE_VERSION;
let configSaveMatch = CONFIGMOD_LOCATION === SAVEMOD_LOCATION; //true if the config and save mods are in the same folder
const XBOX_SAVE_STRING = XBOX_PUB_ID;
const CONFIG_PATH_DEFAULT = path.join(
  CONFIGMOD_LOCATION,
  DATA_FOLDER,
  "Saved",
  "Config",
  CONFIG_FOLDERNAME,
);
const CONFIG_PATH_XBOX = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, "Saved", "Config", "WinGDK"); //XBOX Version
const SAVE_PATH_DEFAULT = path.join(SAVEMOD_LOCATION, DATA_FOLDER, "Saved", "SaveGames");
const SAVE_PATH_XBOX = path.join(
  LOCALAPPDATA,
  "Packages",
  `${XBOXAPP_ID}_${XBOX_SAVE_STRING}`,
  "SystemAppData",
  "wgs",
); //XBOX Version

//Settings related to the IO Store UE feature
if (!PAKMOD_LOADORDER) PAKMOD_PATH = path.join(EPIC_CODE_NAME, "Content", "Paks"); //if loadOrder is disabled, Paks must be in root
let PAKMOD_EXTS = [".pak"].concat(PAKMOD_EXTRA_EXTS);
let PAK_FILE_MIN = PAKMOD_EXTS.length;
let SYM_LINKS = true;
if (IO_STORE) {
  //Set file number for pak installer file selection (needs to be 3 if IO Store is used to accomodate .ucas and .utoc files)
  SYM_LINKS = false;
  PAKMOD_EXTS = [".pak", ".ucas", ".utoc"].concat(PAKMOD_EXTRA_EXTS);
  PAK_FILE_MIN = PAKMOD_EXTS.length;
}

//global variables to set later
let GAME_PATH = ""; //game installation path
let CHECK_CONFIG = false; //boolean to check if game, staging folder, and config and save folders are on the same drive
let CHECK_SAVE = false; //secondary same as above (if save and config are in different locations)
let STAGING_FOLDER = ""; //Vortex staging folder path
let DOWNLOAD_FOLDER = ""; //Vortex download folder path
let GAME_VERSION = "";
let mod_update_all_profile = false; // for mod update to keep them in the load order and not uncheck them
let updateModIds = new Map(); // Nexus mod id -> {firstSeen, targetFileId} (Map, not scalar, so batch updates don't clobber each other)
const MAX_UPDATE_WAIT_MS = 5 * 60 * 1000; // release the guard for an update that never lands (cancelled or failed install)
let updating_mod = false; // used to see if it's a mod update or not
let USERID_FOLDER = "";
let STORE_FOLDER = "";

//other constants
const APPMANIFEST_FILE = "appxmanifest.xml";
const EXEC_XBOX = "gamelaunchhelper.exe";
const EXEC_FOLDER_DEFAULT = "Win64"; //almost never changes
const EXEC_FOLDER_XBOX = "WinGDK"; //almost never changes

//Unreal Engine Game Data
const UNREALDATA = {
  modsPath: PAKMOD_PATH,
  fileExt: PAKMOD_EXTS,
  loadOrder: PAKMOD_LOADORDER,
};
const UE5_SORTABLE_ID = `${GAME_ID}-uesortablepak`; //this should not be changed to be maintain consistency with other UE5 games
const UE5_SORTABLE_NAME = "UE Sortable Pak Mod";

//Information for modtypes, installers, tools, and actions
const BINARIES_ID = `${GAME_ID}-binaries`;
const BINARIES_NAME = "Binaries (Engine Injector)";
let BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
let SHIPPING_EXE = path.join(
  BINARIES_PATH,
  `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEFAULT}-Shipping.exe`,
);

const GOG_FILE = path.join("Plugins", "OnlineSubsystemGOG", "GalaxySDK", "Galaxy64.dll");
const STEAM_FILE = path.join(
  "Engine",
  "Binaries",
  "ThirdParty",
  "Steamworks",
  "Steamv153",
  "Win64",
  "steam_api64.dll",
);
const EPIC_FILE = path.join(EPIC_CODE_NAME, "Binaries", "Win64", SHIPPING_EXE);
const XBOX_FILE = EXEC_XBOX;

const PAK_ALT_ID = `${GAME_ID}-pakalt`;
let PAK_ALT_NAME = 'Paks (no "~mods")';
let PAK_ALT_PATH = path.join(EPIC_CODE_NAME, "Content", "Paks");
if (UNREALDATA.loadOrder === false) {
  PAK_ALT_PATH = path.join(EPIC_CODE_NAME, "Content", "Paks", "~mods");
  PAK_ALT_NAME = 'Paks (with "~mods")';
}
let PAK_PATH = UNREALDATA.modsPath; //KEEPER ONLY: let, setProjectFolder() swaps the project folder
const PAK_EXT = ".pak";

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Folder";
let ROOT_FOLDER = EPIC_CODE_NAME; //KEEPER ONLY: let, setProjectFolder() swaps the project folder
//const ROOTSUB_ID = `${GAME_ID}-rootsubfolders`;
//const ROOTSUB_NAME = "Root Sub-Folders";
let ROOTSUB_PATH = EPIC_CODE_NAME; //KEEPER ONLY: let, setProjectFolder() swaps the project folder

const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_NAME = `Config (${CONFIG_LOC})`;
let CONFIG_PATH = CONFIG_PATH_DEFAULT;
const CONFIG_FILES = [
  "engine.ini",
  "game.ini",
  "gameusersettings.ini",
  "input.ini",
  "scalability.ini",
  "hardware.ini",
  "deviceprofiles.ini",
  "compat.ini",
  "runtimeoptions.ini",
  "gameplaytags.ini",
  "enhancedinput.ini",
  "consolevariables.ini",
];
const CONFIG_EXTS = [".ini"];

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = `Saves (${SAVE_LOC})`;
const SAVE_FOLDER = SAVE_PATH_DEFAULT;
if (hasUserIdFolder) {
  try {
    const SAVE_ARRAY = fs.readdirSync(SAVE_FOLDER);
    USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_FOLDER, entry));
  } catch {
    USERID_FOLDER = "";
  }
  if (USERID_FOLDER === undefined) {
    USERID_FOLDER = "";
  } //*/
}
let SAVE_PATH = path.join(SAVE_FOLDER, USERID_FOLDER);

const SCRIPTS_ID = `${GAME_ID}-scripts`;
const SCRIPTS_NAME = "UE4SS Script Mod";
const SCRIPTS_EXT = ".lua";
const SCRIPTS_FOLDER = "Scripts";
let SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);

const DLL_ID = `${GAME_ID}-ue4ssdll`;
const DLL_NAME = "UE4SS DLL Mod";
const DLL_EXT = ".dll";
const DLL_FOLDER = "dlls";
let DLL_PATH = SCRIPTS_PATH;

const LOGICMODS_ID = `${GAME_ID}-logicmods`;
const LOGICMODS_NAME = "UE4SS LogicMods (Blueprint)";
const UE4SSCOMBO_ID = `${GAME_ID}-ue4sscombo`;
const UE4SSCOMBO_NAME = "UE4SS Script-LogicMod Combo";
let LOGICMODS_PATH = path.join(EPIC_CODE_NAME, "Content", "Paks", "LogicMods"); //already ends in the folder itself for this game (kept from the 0.1.1 extension) - the sites that would otherwise double-append LOGICMODS_FOLDER drop the second path.join arg, and installLogic stays flat. KEEPER ONLY: let, setProjectFolder() swaps the project folder
const LOGICMODS_FOLDER = "LogicMods";
const LOGICMODS_EXT = ".pak";

const UE4SS_ID = `${GAME_ID}-ue4ss`;
const UE4SS_NAME = "UE4SS";
const UE4SS_FILE = "dwmapi.dll";
const UE4SS_DLFILE_STRING = "ue4ss_v";
//anchored so the zDEV- dev-build sibling never matches; the capture group is the version the
//mod is stamped with, e.g. UE4SS_v3.0.1-1133-gb4cefa18.zip -> 3.0.1-1133.
//The trailing -g<hash> is deliberately NOT captured. It parses as valid semver, but it turns the
//prerelease into ONE alphanumeric identifier ("1133-gb4cefa18") which semver compares as ASCII
//text, so build 10000 would sort BELOW build 9999 and updates would stall for good at that
//rollover. Captured bare, "1133" is a numeric identifier and compares numerically.
const UE4SS_ARC_PATTERN = /^UE4SS_v(\d+\.\d+\.\d+(?:-\d+)?)/i;
const UE4SS_URL_API = "https://api.github.com/repos/UE4SS-RE/RE-UE4SS";
const UE4SS_REQUIREMENTS = [
  {
    //'ue4ss_v' is a prefix, not a basename, so findDownloadIdByFile (full-name compare) never
    //matches and the already-downloaded shortcut never fires. That is correct here: a stale local
    //archive must not satisfy a rolling tag. The value still names the update notification's id.
    archiveFileName: UE4SS_DLFILE_STRING,
    modType: UE4SS_ID,
    assemblyFileName: UE4SS_FILE,
    userFacingName: UE4SS_NAME,
    githubUrl: UE4SS_URL_API,
    findMod: (api) => findModByFile(api, UE4SS_ID, UE4SS_FILE),
    findDownloadId: (api) => findDownloadIdByFile(api, UE4SS_DLFILE_STRING),
    prereleaseTag: "experimental-latest", //NOT 'experimental' - that tag holds 857 archived builds
    fileArchivePattern: UE4SS_ARC_PATTERN,
    //UE4SS arrives from the Download UE4SS button, or from setup() when
    //autoDownloadUe4ss is on - never as a side effect of an update check. Without this,
    //testRequirementVersion's missing-branch calls download() and installs it unprompted:
    //on a Nexus-route game that bypasses downloadUe4ssNexus and pulls from GitHub, and on a
    //ue4ssLoadOrder = false game it installs UE4SS with every UE4SS surface switched off.
    autoInstall: false,
    //The version comes from the asset name, not the tag - the rolling tag never changes. Safe
    //here only because prereleaseTag pins the fetch to that one tag, so the stable 3.0.1 release
    //is never fetched and can never outrank an experimental 3.0.1-NNNN on the latest side.
    resolveVersion: (api) => resolveVersionByModVersion(api, UE4SS_REQUIREMENTS[0]),
  },
];
const UE4SS_SETTINGS_FILE = "UE4SS-settings.ini";
const UE4SS_PLUGIN = "UE4SS.dll";
UE4SS_SUBFOLDERS.push(UE4SS_SETTINGS_FILE, UE4SS_PLUGIN);
const UE4SS_SETTINGS_FILEPATH = path.join(UE4SS_FOLDER, UE4SS_SETTINGS_FILE); //relative to Binaries folder
const UE4SS_MODSJSON_FILE = "mods.json";
const UE4SS_MODSTXT_FILE = "mods.txt";
const UE4SS_MODSJSON_FILEPATH = path.join(UE4SS_MOD_PATH, UE4SS_MODSJSON_FILE); //relative to Binaries folder
const UE4SS_MODSTXT_FILEPATH = path.join(UE4SS_MOD_PATH, UE4SS_MODSTXT_FILE);
const UE4SS_LO_FILE = "ue4ss_loadOrder.json";
const LO_ATTRIBUTE_UE4SS = "ue4ssModFolder";
const UE4SS_CONFIG_FILES = ["config.txt", "settings.json", "config.lua"]; //files that trigger the Configure button on UE4SS LO items
const UE4SS_NATIVE_MODS = [
  "ActorDumperMod",
  "BPML_GenericFunctions",
  "BPModLoaderMod",
  "CheatManagerEnablerMod",
  "ConsoleCommandsMod",
  "ConsoleEnablerMod",
  "jsbLuaProfilerMod",
  "Keybinds",
  "LineTraceMod",
  "shared",
  "SplitScreenMod",
];
const ENABLEDTXT_FILE = "enabled.txt";
const UE4SS_ICON =
  "M12 0c-6.5745 0-11.899 5.371-11.899 12s5.324 12 11.899 12c6.57 0 11.899-5.371 11.899-12s-5.328-12-11.903-12zM12 0.527c3.035 0 5.894 1.196 8.043 3.359 2.144 2.156 3.34 5.075 3.332 8.114 0 3.062-1.184 5.945-3.332 8.114-2.121 2.153-5.02 3.363-8.043 3.359-3.023 0.004-5.922-1.207-8.043-3.359-2.144-2.156-3.344-5.075-3.336-8.114 0-3.062 1.187-5.945 3.332-8.114 2.121-2.156 5.024-3.368 8.047-3.359zM11.402 4.75c-1.937 0.52-3.731 1.516-6.121 4.258s-1.937 5.008-1.937 5.008c0 0 0.66-1.559 2.246-3.2 0.754-0.777 1.313-1.039 1.7-1.039 0.344-0.02 0.633 0.258 0.633 0.602v5.567c0 0.551-0.356 0.672-0.683 0.664-0.278-0.004-0.536-0.101-0.536-0.101 1.629 2.367 5.528 2.699 5.528 2.699l1.711-1.829 0.039 0.035 1.567 1.336c2.867-1.703 4.25-4.859 4.25-4.859-1.281 1.352-2.094 1.668-2.579 1.668-0.43-0.004-0.598-0.254-0.598-0.254-0.023-0.117-0.062-1.813-0.078-3.508-0.016-1.754 0-3.512 0.086-3.516 0.496-0.93 2.075-2.805 2.075-2.805-2.949 0.582-4.555 2.516-4.555 2.516-0.476-0.375-1.445-0.313-1.445-0.313 0.453 0.25 0.906 0.977 0.906 1.578v5.922c0 0-0.989 0.871-1.75 0.871-0.453 0-0.731-0.246-0.883-0.449-0.059-0.078-0.11-0.164-0.149-0.258v-7.313c-0.106 0.078-0.235 0.121-0.363 0.125-0.164 0-0.332-0.082-0.446-0.32-0.086-0.18-0.141-0.449-0.141-0.844 0-1.348 1.523-2.243 1.523-2.243z";
const BLUEPRINT_ICON =
  "M19.5 17C19.36 17 19.24 17 19.11 17.04L17.5 13.8C17.95 13.35 18.25 12.71 18.25 12C18.25 10.62 17.13 9.5 15.75 9.5C15.61 9.5 15.5 9.5 15.35 9.54L13.74 6.3C14.21 5.84 14.5 5.21 14.5 4.5C14.5 3.12 13.38 2 12 2S9.5 3.12 9.5 4.5C9.5 5.2 9.79 5.84 10.26 6.29L8.65 9.54C8.5 9.5 8.39 9.5 8.25 9.5C6.87 9.5 5.75 10.62 5.75 12C5.75 12.71 6.04 13.34 6.5 13.79L4.89 17.04C4.76 17 4.64 17 4.5 17C3.12 17 2 18.12 2 19.5C2 20.88 3.12 22 4.5 22S7 20.88 7 19.5C7 18.8 6.71 18.16 6.24 17.71L7.86 14.46C8 14.5 8.12 14.5 8.25 14.5C8.38 14.5 8.5 14.5 8.63 14.46L10.26 17.71C9.79 18.16 9.5 18.8 9.5 19.5C9.5 20.88 10.62 22 12 22S14.5 20.88 14.5 19.5C14.5 18.12 13.38 17 12 17C11.87 17 11.74 17 11.61 17.04L10 13.8C10.45 13.35 10.75 12.71 10.75 12C10.75 11.3 10.46 10.67 10 10.21L11.61 6.96C11.74 7 11.87 7 12 7C12.13 7 12.26 7 12.39 6.96L14 10.21C13.54 10.66 13.25 11.3 13.25 12C13.25 13.38 14.37 14.5 15.75 14.5C15.88 14.5 16 14.5 16.13 14.46L17.76 17.71C17.29 18.16 17 18.8 17 19.5C17 20.88 18.12 22 19.5 22S22 20.88 22 19.5C22 18.12 20.88 17 19.5 17M4.5 20.5C3.95 20.5 3.5 20.05 3.5 19.5S3.95 18.5 4.5 18.5 5.5 18.95 5.5 19.5 5.05 20.5 4.5 20.5M13 19.5C13 20.05 12.55 20.5 12 20.5S11 20.05 11 19.5 11.45 18.5 12 18.5 13 18.95 13 19.5M7.25 12C7.25 11.45 7.7 11 8.25 11S9.25 11.45 9.25 12 8.8 13 8.25 13 7.25 12.55 7.25 12M11 4.5C11 3.95 11.45 3.5 12 3.5S13 3.95 13 4.5 12.55 5.5 12 5.5 11 5.05 11 4.5M14.75 12C14.75 11.45 15.2 11 15.75 11S16.75 11.45 16.75 12 16.3 13 15.75 13 14.75 12.55 14.75 12M19.5 20.5C18.95 20.5 18.5 20.05 18.5 19.5S18.95 18.5 19.5 18.5 20.5 18.95 20.5 19.5 20.05 20.5 19.5 20.5Z"; // mdiGraphOutline (@mdi/js 7.4.47)
const BPML_FOLDER = "BPModLoaderMod"; //UE4SS native mod that reads load_order.txt (also in UE4SS_NATIVE_MODS)
const BPML_LO_FILE = "load_order.txt"; //file BPModLoaderMod reads for BP pak load order
const LOGICMODS_LO_FILE = "logicMods_loadOrder.json"; //persisted LO state, profile-prefixed, stored in BPModLoaderMod folder
const LO_ATTRIBUTE_LOGIC = "logicModFiles"; //mod install attribute: array of pak basenames (no ext) in LogicMods folder

const SET_UE4SS_LOAD_ORDER = `SET_${GAME_ID.toUpperCase()}_UE4SS_LOAD_ORDER`;

// vortex-api's fs.ensureFileAsync is deprecated; this is the node equivalent.
async function ensureFileAsync(filePath) {
  await fsp.mkdir(path.dirname(filePath), { recursive: true });
  const handle = await fsp.open(filePath, "a");
  await handle.close();
}

function setUe4ssLoadOrder(profileId, loadOrder) {
  return { type: SET_UE4SS_LOAD_ORDER, payload: { profileId, loadOrder } };
}
setUe4ssLoadOrder.toString = () => SET_UE4SS_LOAD_ORDER;

const SET_UE4SS_LO_ENABLED = `SET_${GAME_ID.toUpperCase()}_UE4SS_LO_ENABLED`;
function setUe4ssLoEnabled(value) {
  return { type: SET_UE4SS_LO_ENABLED, payload: value };
}
setUe4ssLoEnabled.toString = () => SET_UE4SS_LO_ENABLED;

const SET_LOGICMODS_LOAD_ORDER = `SET_${GAME_ID.toUpperCase()}_LOGICMODS_LOAD_ORDER`;
function setLogicModsLoadOrder(profileId, loadOrder) {
  return { type: SET_LOGICMODS_LOAD_ORDER, payload: { profileId, loadOrder } };
}
setLogicModsLoadOrder.toString = () => SET_LOGICMODS_LOAD_ORDER;

//Signature Bypass (only used if game requires)
const SIGBYPASS_ID = `${GAME_ID}-sigbypass`;
const SIGBYPASS_NAME = "Sig Bypass";
const SIGBYPASS_DLL = "dsound.dll";
const SIGBYPASS_LUA = "UniversalSigBypasser.asi";
const SIGBYPASS_PAGE_NO = 1416;
const SIGBYPASS_FILE_NO = 5719;
const SIGBYPASS_DOMAIN = "site";

//ModKit (only used if game supports)
const MODKITMOD_ID = `${GAME_ID}-modkitmod`;
const MODKITMOD_NAME = "ModKit mod";
const MODKITMOD_FILE = "mod.json";
const MODKITMOD_EXT = ".uplugin";
const MODKITMOD_PATH = path.join(EPIC_CODE_NAME, "Mods");

const MODKIT_ID = `${GAME_ID}-modkit`;
const MODKIT_NAME = "ModKit";
const MODKITAPP_ID = "XXX";
const MODKIT_EXEC_NAME = "ModKit.exe";
const MODKIT_FOLDER = path.join("XXX", "Binaries", "Win64");
const MODKIT_EXEC_PATH = path.join(MODKIT_FOLDER, MODKIT_EXEC_NAME);

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const LO_FILE_NAME = "loadOrder.json";
let MOD_PATH_DEFAULT = PAK_PATH; //KEEPER ONLY: let, setProjectFolder() swaps the project folder
const REQ_FILE = "Engine"; //KEEPER ONLY: the project folder differs per store (Keeper / PaganIdol), only the Engine folder is in both roots
const PARAMETERS = [PARAMETERS_STRING];

const IGNORE_CONFLICTS = [
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];
const IGNORE_DEPLOY = [
  path.join("**", "changelog*"),
  path.join("**", "readme*"),
  path.join("**", "license*"),
];
let MODTYPE_FOLDERS = [PAK_PATH, PAK_ALT_PATH];
if (ue4ssLoadOrder) {
  //LogicMods are only loaded when UE4SS's BPModLoaderMod is present
  MODTYPE_FOLDERS.push(LOGICMODS_PATH); //LOGICMODS_PATH already ends in the folder for this game
}
if (hasModKit) {
  MODTYPE_FOLDERS.push(MODKITMOD_PATH);
}

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

//Filled in from data above
const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    shortName: GAME_NAME_SHORT,
    //"parameters": PARAMETERS, //must uncomment manually since we don't want to send empty string parameter
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    modPath: MOD_PATH_DEFAULT,
    modPathIsRelative: true,
    requiredFiles: [REQ_FILE],
    compatible: {
      dinput: false,
      enb: false,
    },
    details: {
      steamAppId: +STEAMAPP_ID,
      gogAppId: GOGAPP_ID,
      epicAppId: EPICAPP_ID,
      xboxAppId: XBOXAPP_ID,
      supportsSymlinks: SYM_LINKS,
      ignoreConflicts: IGNORE_CONFLICTS,
      ignoreDeploy: IGNORE_DEPLOY,
    },
    environment: {
      SteamAPPId: STEAMAPP_ID,
      GogAPPId: GOGAPP_ID,
      EpicAPPId: EPICAPP_ID,
      XboxAPPId: XBOXAPP_ID,
    },
  },
  modTypes: [
    {
      id: UE4SSCOMBO_ID,
      name: UE4SSCOMBO_NAME,
      priority: "high",
      targetPath: "{gamePath}",
    },
    {
      id: LOGICMODS_ID,
      name: LOGICMODS_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", LOGICMODS_PATH),
    },
    {
      id: PAK_ALT_ID,
      name: PAK_ALT_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", PAK_ALT_PATH),
    },
    {
      id: ROOT_ID,
      name: ROOT_NAME,
      priority: "high",
      targetPath: "{gamePath}",
    },
  ],
  discovery: {
    ids: DISCOVERY_IDS_ACTIVE,
    names: [],
  },
};

if (hasModKit) {
  spec.modTypes.push({
    id: MODKITMOD_ID,
    name: MODKITMOD_NAME,
    priority: "high",
    targetPath: path.join("{gamePath}", MODKITMOD_PATH),
  });
}

if (!ue4ssLoadOrder) {
  //LogicMods are blueprint paks loaded by UE4SS's BPModLoaderMod, so they need UE4SS
  spec.modTypes = spec.modTypes.filter((type) => type.id !== LOGICMODS_ID);
}

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

//Set mod type priority
function modTypePriority(priority) {
  return {
    high: 30,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath:
        (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
          ? void 0
          : _a.path,
      documents: util.getVortexPath("documents"),
      localAppData: util.getVortexPath("localAppData"),
      appData: util.getVortexPath("appData"),
    });
  } catch (err) {
    //this happens if the executable comes back as "undefined", usually caused by another app locking down the folder
    api.showErrorNotification(
      "Failed to locate executable. Please launch the game at least once.",
      err,
    );
  }
}

//Set mod path
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () =>
    util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
}

async function requiresLauncher(gamePath, store) {
  //*
  if (store === "steam") {
    return Promise.resolve({
      launcher: "steam",
    });
  } //*/
  if (store === "xbox" && DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID)) {
    return Promise.resolve({
      launcher: "xbox",
      addInfo: {
        appId: XBOXAPP_ID,
        parameters: [{ appExecName: XBOXEXECNAME }],
      },
    });
  } //*/
  //*
  if (store === "epic" && DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID)) {
    return Promise.resolve({
      launcher: "epic",
      addInfo: {
        appId: EPICAPP_ID,
      },
    });
  } //*/
  return Promise.resolve(undefined);
}

function getUserIdFolder(savePath) {
  try {
    const SAVE_ARRAY = fs.readdirSync(savePath);
    USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(savePath, entry));
  } catch {
    USERID_FOLDER = "";
  }
  if (USERID_FOLDER === undefined) {
    USERID_FOLDER = "";
  }
  return (SAVE_PATH = path.join(savePath, USERID_FOLDER));
}

//KEEPER ONLY: Steam/GOG ship the project folder as EPIC_CODE_NAME, the Microsoft Store (Xbox) build as XBOX_CODE_NAME.
//Every project-relative path above is built from EPIC_CODE_NAME; setProjectFolder() swaps the leading folder of each to the active store's.
let PROJECT_FOLDER = EPIC_CODE_NAME;
function swapProjectFolder(relPath, from, to) {
  const segs = relPath.split(path.sep);
  if (segs[0].toLowerCase() !== from.toLowerCase()) return relPath;
  segs[0] = to;
  return segs.join(path.sep);
}

//Rewrite a mod's destination that starts with the OTHER store's project folder (a mod packaged for the other store) to the active one
function toProjectFolder(destination) {
  for (const name of [EPIC_CODE_NAME, XBOX_CODE_NAME]) {
    if (name !== PROJECT_FOLDER) destination = swapProjectFolder(destination, name, PROJECT_FOLDER);
  }
  return destination;
}

function setProjectFolder(folder) {
  if (folder === PROJECT_FOLDER) return;
  const swap = (relPath) => swapProjectFolder(relPath, PROJECT_FOLDER, folder);
  PAKMOD_PATH = swap(PAKMOD_PATH);
  UNREALDATA.modsPath = PAKMOD_PATH;
  PAK_PATH = swap(PAK_PATH);
  MOD_PATH_DEFAULT = swap(MOD_PATH_DEFAULT);
  spec.game.modPath = MOD_PATH_DEFAULT; //read live by makeGetModPath
  PAK_ALT_PATH = swap(PAK_ALT_PATH);
  LOGICMODS_PATH = swap(LOGICMODS_PATH);
  ROOT_FOLDER = folder;
  ROOTSUB_PATH = folder;
  //same order as the MODTYPE_FOLDERS declaration (the Binaries/UE4SS entries are pushed later in setup())
  MODTYPE_FOLDERS[0] = PAK_PATH;
  MODTYPE_FOLDERS[1] = PAK_ALT_PATH;
  if (ue4ssLoadOrder) MODTYPE_FOLDERS[2] = LOGICMODS_PATH;
  //spec-registered mod types read type.targetPath on every call
  for (const type of spec.modTypes) {
    if (type.id === LOGICMODS_ID) type.targetPath = path.join("{gamePath}", LOGICMODS_PATH);
    if (type.id === PAK_ALT_ID) type.targetPath = path.join("{gamePath}", PAK_ALT_PATH);
  }
  PROJECT_FOLDER = folder;
}

//Get correct executable for game version
function getExecutable(discoveryPath) {
  if (!hasXbox && !multiExe) {
    return EXEC;
  }
  if (hasXbox) {
    if (statCheckSync(discoveryPath, EXEC_XBOX)) {
      GAME_VERSION = "xbox";
      setProjectFolder(XBOX_CODE_NAME); //KEEPER ONLY
      BINARIES_PATH = path.join(XBOX_CODE_NAME, "Binaries", EXEC_FOLDER_XBOX); //KEEPER ONLY: XBOX_CODE_NAME
      SHIPPING_EXE = path.join(
        BINARIES_PATH,
        `${SHIPEXE_PROJECTNAME_XBOX}-${EXEC_FOLDER_XBOX}${SHIPEXE_STRING_XBOX}-Shipping.exe`, //KEEPER ONLY: SHIPEXE_PROJECTNAME_XBOX
      );
      SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
      DLL_PATH = SCRIPTS_PATH;
      CONFIG_PATH = CONFIG_PATH_XBOX;
      //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
      SAVE_PATH = getUserIdFolder(SAVE_PATH_XBOX);
      return EXEC_XBOX;
    }
  }
  if (statCheckSync(discoveryPath, EXEC)) {
    GAME_VERSION = "steam";
    setProjectFolder(EPIC_CODE_NAME); //KEEPER ONLY
    BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(
      BINARIES_PATH,
      `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEFAULT}-Shipping.exe`,
    );
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_DEMO)) {
    GAME_VERSION = "demo";
    setProjectFolder(EPIC_CODE_NAME); //KEEPER ONLY
    BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(
      BINARIES_PATH,
      `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEMO}-Shipping.exe`,
    );
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_DEMO;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_EPIC)) {
    GAME_VERSION = "epic";
    setProjectFolder(EPIC_CODE_NAME); //KEEPER ONLY
    BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(
      BINARIES_PATH,
      `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_EGS}-Shipping.exe`,
    );
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_EPIC;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_GOG)) {
    GAME_VERSION = "gog";
    setProjectFolder(EPIC_CODE_NAME); //KEEPER ONLY
    BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(
      BINARIES_PATH,
      `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_GOG}-Shipping.exe`,
    );
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_GOG;
  } //*/
  GAME_VERSION = "default";
  return EXEC;
}

//Get correct shipping executable for game version
function getShippingExe(gamePath) {
  if (hasXbox) {
    if (statCheckSync(gamePath, EXEC_XBOX)) {
      SHIPPING_EXE = path.join(
        XBOX_CODE_NAME, //KEEPER ONLY
        "Binaries",
        EXEC_FOLDER_XBOX,
        `${SHIPEXE_PROJECTNAME_XBOX}${SHIPEXE_STRING_XBOX}-${EXEC_FOLDER_XBOX}-Shipping.exe`, //KEEPER ONLY
      );
      return SHIPPING_EXE;
    }
  }
  if (statCheckSync(gamePath, EXEC)) {
    SHIPPING_EXE = path.join(
      EPIC_CODE_NAME,
      "Binaries",
      EXEC_FOLDER_DEFAULT,
      `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_DEFAULT}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`,
    );
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_EPIC)) {
    SHIPPING_EXE = path.join(
      EPIC_CODE_NAME,
      "Binaries",
      EXEC_FOLDER_DEFAULT,
      `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_EGS}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`,
    );
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_GOG)) {
    SHIPPING_EXE = path.join(
      EPIC_CODE_NAME,
      "Binaries",
      EXEC_FOLDER_DEFAULT,
      `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_GOG}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`,
    );
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_DEMO)) {
    SHIPPING_EXE = path.join(
      EPIC_CODE_NAME,
      "Binaries",
      EXEC_FOLDER_DEFAULT,
      `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_DEMO}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`,
    );
    return SHIPPING_EXE;
  }
}

//Get correct shipping executable folder for game version (for tool pathing)
function getBinariesFolder(discoveryPath) {
  if (!hasXbox) {
    return BINARIES_PATH;
  }
  if (statCheckSync(discoveryPath, EXEC_FOLDER_XBOX)) {
    BINARIES_PATH = path.join(XBOX_CODE_NAME, "Binaries", EXEC_FOLDER_XBOX); //KEEPER ONLY: XBOX_CODE_NAME
    return BINARIES_PATH;
  }
  if (statCheckSync(discoveryPath, EXEC_FOLDER_DEFAULT)) {
    BINARIES_PATH = path.join(EPIC_CODE_NAME, "Binaries", EXEC_FOLDER_DEFAULT);
    return BINARIES_PATH;
  }
}

//Get correct game version - async
async function setGameVersionAsync(gamePath) {
  if (hasXbox) {
    if (await statCheckAsync(gamePath, EXEC_XBOX)) {
      GAME_VERSION = "xbox";
      return GAME_VERSION;
    }
  }
  if (await statCheckAsync(gamePath, EXEC)) {
    GAME_VERSION = "steam";
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_EPIC)) {
    GAME_VERSION = "epic";
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_GOG)) {
    GAME_VERSION = "gog";
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_DEMO)) {
    GAME_VERSION = "demo";
    return GAME_VERSION;
  } //*/
}

//Get correct game version - synchronous
function setGameVersionSync(gamePath) {
  if (hasXbox) {
    if (statCheckSync(gamePath, EXEC_XBOX)) {
      GAME_VERSION = "xbox";
      return GAME_VERSION;
    }
  }
  if (statCheckSync(gamePath, EXEC)) {
    GAME_VERSION = "steam";
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_EPIC)) {
    GAME_VERSION = "epic";
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_GOG)) {
    GAME_VERSION = "gog";
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_DEMO)) {
    GAME_VERSION = "demo";
    return GAME_VERSION;
  } //*/
}

//Get correct config path for game version
async function setConfigPath(version) {
  const DATA_PATH = path.join(CONFIGMOD_LOCATION, DATA_FOLDER);
  try {
    const ARRAY = await fsp.readdir(DATA_PATH);
    STORE_FOLDER = ARRAY.find((entry) => isDir(DATA_PATH, entry));
  } catch {
    STORE_FOLDER = "";
  }
  if (STORE_FOLDER === undefined) {
    STORE_FOLDER = "";
  }
  CONFIG_PATH = path.join(
    CONFIGMOD_LOCATION,
    DATA_FOLDER,
    STORE_FOLDER,
    "Saved",
    "Config",
    CONFIG_FOLDERNAME,
  );
  if (version === "xbox") {
    CONFIG_PATH = path.join(
      CONFIGMOD_LOCATION,
      DATA_FOLDER,
      STORE_FOLDER,
      "Saved",
      "Config",
      "WinGDK",
    );
  }
  return CONFIG_PATH;
}

//Get correct save path for game version
async function setSavePath() {
  const DATA_PATH = path.join(SAVEMOD_LOCATION, DATA_FOLDER);
  try {
    const ARRAY = await fsp.readdir(DATA_PATH);
    STORE_FOLDER = ARRAY.find((entry) => isDir(DATA_PATH, entry));
  } catch {
    STORE_FOLDER = "";
  }
  if (STORE_FOLDER === undefined) {
    STORE_FOLDER = "";
  }
  SAVE_PATH = path.join(SAVEMOD_LOCATION, DATA_FOLDER, STORE_FOLDER, "Saved", "SaveGames");
  SAVE_PATH = getUserIdFolder(SAVE_PATH);
  return SAVE_PATH;
} //*/

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? {};
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}
async function deploy(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for modkit mod files
function testModKitMod(files, gameId) {
  const isMod = files.some((file) => path.extname(file).toLowerCase() === MODKITMOD_EXT);
  const isJson = files.some((file) => path.basename(file).toLowerCase() === MODKITMOD_FILE);
  let supported = gameId === spec.game.id && isMod && isJson;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install modkit mod files
async function installModKitMod(files, fileName) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === MODKITMOD_FILE);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: MODKITMOD_ID };
  let MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");
  if (rootPath !== ".") {
    MOD_NAME = path.basename(rootPath);
    MOD_FOLDER = MOD_NAME;
  }
  try {
    //read mod.json file to get folder name (game will crash if this doesn't match)
    let contents = await fsp.readFile(path.join(fileName, rootPath, MODKITMOD_FILE), "utf8");
    contents = util.deBOM(contents);
    const JSON_OBJECT = JSON.parse(contents);
    const JSON_MOD_NAME = JSON_OBJECT["modPluginName"];
    if (typeof JSON_MOD_NAME === "string" && JSON_MOD_NAME !== "") {
      MOD_FOLDER = JSON_MOD_NAME; //without a name the folder keeps the wrapper or archive name
    }
  } catch {
    //mod.json could not be read.
    log("error", `Could not read mod.json file for mod ${MOD_NAME}.`);
  }

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for UE4SS combo (pak and lua/dll) mod files
function testUe4ssCombo(files, gameId) {
  //const isMod = files.some(file => (path.extname(file).toLowerCase() === SCRIPTS_EXT));
  const isBinaries = files.some((file) => path.basename(file).toLowerCase() === "binaries"); //added to catch mods packaged with paks and dll/asi, but no lua scripts.
  //const isPak = files.some(file => (path.extname(file).toLowerCase() === LOGICMODS_EXT));
  const isContent = files.some((file) => path.basename(file).toLowerCase() === "content");
  //const isFolder = files.some(file => (path.basename(file).toLowerCase() === ROOT_FOLDER.toLowerCase()));
  let supported = gameId === spec.game.id && isContent && isBinaries;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS combo (pak and lua/dll) mod files
async function installUe4ssCombo(files, workingDir) {
  //const modFile = files.find(file => (path.basename(file).toLowerCase() === ROOT_FOLDER.toLowerCase()));
  const modFile = files.find((file) => path.basename(file).toLowerCase() === "binaries");
  const idx = modFile.lastIndexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: UE4SSCOMBO_ID };

  if (GAME_VERSION === "xbox") {
    try {
      /*await fs.statAsync(path.join(workingDir, modFile, 'Binaries', 'Win64'));
      await fs.renameAsync(path.join(workingDir, modFile, 'Binaries', 'Win64'), path.join(workingDir, modFile, 'Binaries', 'WinGDK')); //*/
      await fsp.stat(path.join(workingDir, modFile, "Win64"));
      await fsp.rename(
        path.join(workingDir, modFile, "Win64"),
        path.join(workingDir, modFile, "WinGDK"),
      ); //*/
      const paths = await getAllFiles(workingDir);
      files = [...paths.map((p) => p.replace(`${workingDir}${path.sep}`, ""))];
    } catch (err) {
      log(
        "warn",
        `Failed to rename "Win64" folder to "WinGDK" for UE4SS combo mod ${workingDir} (or "Win64" folder is not present): ${err}`,
      );
    }
  }

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));

  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      //destination: path.join(file.substr(idx)),
      destination: path.join(PROJECT_FOLDER, file.substr(idx)), //KEEPER ONLY: PROJECT_FOLDER
    };
  });
  instructions.push(setModTypeInstruction);
  const logicPakBasenames = filtered
    .filter(
      (f) =>
        f.toLowerCase().includes(`${LOGICMODS_FOLDER.toLowerCase()}${path.sep}`) &&
        path.extname(f).toLowerCase() === LOGICMODS_EXT,
    )
    .map((f) => path.basename(f, path.extname(f)));
  if (logicPakBasenames.length) {
    instructions.push({ type: "attribute", key: LO_ATTRIBUTE_LOGIC, value: logicPakBasenames });
  }
  //The mod folder is the one holding a Scripts folder. Read it from the path segments, so it also
  //works for the Xbox list rebuilt above, which holds files only and no folder entries.
  const ue4ssModFolders = [
    ...new Set(
      files
        .filter((f) => f.toLowerCase().includes(UE4SS_MOD_PATH.toLowerCase()))
        .map((f) => {
          const segments = f.split(path.sep);
          const scriptsAt = segments.findIndex(
            (segment, i) =>
              i > 0 &&
              i < segments.length - 1 &&
              segment.toLowerCase() === SCRIPTS_FOLDER.toLowerCase(),
          );
          return scriptsAt === -1 ? undefined : segments[scriptsAt - 1];
        })
        .filter(Boolean),
    ),
  ];
  if (ue4ssModFolders.length) {
    instructions.push({ type: "attribute", key: LO_ATTRIBUTE_UE4SS, value: ue4ssModFolders[0] }); //!only picking one folder to have a string. Can change to array if needed, but need to change in load order modId function too.
    log("warn", `Installer: UE4SS LO attribute: ${ue4ssModFolders.join(", ")}`);
  }
  return Promise.resolve({ instructions });
}

//Test for save files
function testLogic(files, gameId) {
  const isMod = files.some(
    (file) => path.basename(file).toLowerCase() === LOGICMODS_FOLDER.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install save files
function installLogic(files) {
  //indexed off the pak itself, not the LogicMods folder: the mod type path already ends in
  //LogicMods for this game, so the staged layout must stay flat (matches the 0.1.1 extension)
  const modFile = files.find((file) => path.extname(file).toLowerCase() === LOGICMODS_EXT);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: LOGICMODS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  const pakBasenames = filtered
    .filter((f) => path.extname(f).toLowerCase() === LOGICMODS_EXT)
    .map((f) => path.basename(f, path.extname(f)));
  instructions.push(setModTypeInstruction);
  if (pakBasenames.length) {
    instructions.push({ type: "attribute", key: LO_ATTRIBUTE_LOGIC, value: pakBasenames });
  }
  return Promise.resolve({ instructions });
}

//Installer test for UE4SS files
function testUe4ss(files, gameId) {
  const UE4SS_SUBFOLDERS_LOWER = UE4SS_SUBFOLDERS.map((str) => str.toLowerCase());
  const isMod = files.some((file) => path.basename(file).toLowerCase() === UE4SS_FILE);
  const isFolder = files.some((file) =>
    UE4SS_SUBFOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  let supported = gameId === spec.game.id && (isMod || isFolder);

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install UE4SS files
function installUe4ss(files) {
  let folder = "";
  let modFile = files.find((file) => path.basename(file).toLowerCase() === UE4SS_FILE);
  if (modFile === undefined) {
    folder = UE4SS_FOLDER;
    const UE4SS_SUBFOLDERS_LOWER = UE4SS_SUBFOLDERS.map((str) => str.toLowerCase());
    modFile = files.find((file) =>
      UE4SS_SUBFOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
    );
  }
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: UE4SS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Signature Bypass files
function testSigBypass(files, gameId) {
  const isDll = files.some((file) => path.basename(file).toLowerCase() === SIGBYPASS_DLL);
  const isLua = files.some(
    (file) => path.basename(file).toLowerCase() === SIGBYPASS_LUA.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isDll && isLua;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install UE4SS files
function installSigBypass(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === SIGBYPASS_DLL);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: SIGBYPASS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for UE4SS Script files
function testScripts(files, gameId) {
  const isMod = files.some((file) => path.extname(file).toLowerCase() === SCRIPTS_EXT);
  const isFolder = files.some(
    (file) => path.basename(file).toLowerCase() === SCRIPTS_FOLDER.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isMod && isFolder;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS Script files
async function installScripts(api, files, fileName) {
  const scriptsFolder = files.find(
    (file) => path.basename(file).toLowerCase() === SCRIPTS_FOLDER.toLowerCase(),
  );
  const setModTypeInstruction = { type: "setmodtype", value: SCRIPTS_ID };
  let modFile = scriptsFolder;
  let rootPath = path.dirname(modFile);
  const MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");
  let fallbackName = true;
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== ".") {
    fallbackName = false;
    MOD_FOLDER = ""; //no top level folder needed if it's already included in the archive
    modFile = rootPath; //make the folder the targeted modFile so we can grab any other folders also in its directory
    rootPath = path.dirname(modFile);
  }
  const idx = modFile.lastIndexOf(path.basename(modFile));
  //handle enabled.txt file
  if (!ue4ssLoadOrder || !(api.store.getState()?.settings?.[GAME_ID]?.ue4ssLoEnabled ?? true)) {
    const ENABLEDTXT_PATH = path.join(fileName, path.dirname(scriptsFolder), ENABLEDTXT_FILE);
    try {
      await fsp.stat(ENABLEDTXT_PATH);
    } catch (err) {
      try {
        await fsp.writeFile(ENABLEDTXT_PATH, "", { encoding: "utf8" });
        files.push(path.join(path.dirname(scriptsFolder), ENABLEDTXT_FILE));
        log("info", `Successfully created ${ENABLEDTXT_FILE} for UE4SS Script Mod: ${MOD_NAME}`);
      } catch {
        log("error", `Could not create ${ENABLEDTXT_FILE} for UE4SS Script Mod: ${MOD_NAME}`);
      }
    }
  } else {
    files = files.filter((f) => path.basename(f).toLowerCase() !== ENABLEDTXT_FILE);
  }
  //Filter files and set instructions
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const MOD_ATTRIBUTE = {
    type: "attribute",
    key: LO_ATTRIBUTE_UE4SS,
    value: fallbackName ? MOD_FOLDER : path.basename(modFile),
  };
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  instructions.push(MOD_ATTRIBUTE);
  return Promise.resolve({ instructions });
}

//Test for UE4SS DLL files
function testDll(files, gameId) {
  const isMod = files.some((file) => path.extname(file).toLowerCase() === DLL_EXT);
  const isFolder = files.some(
    (file) => path.basename(file).toLowerCase() === DLL_FOLDER.toLowerCase(),
  );
  let supported = gameId === spec.game.id && isMod && isFolder;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS DLL files
async function installDll(api, files, fileName) {
  const dllFolder = files.find(
    (file) => path.basename(file).toLowerCase() === DLL_FOLDER.toLowerCase(),
  );
  const setModTypeInstruction = { type: "setmodtype", value: DLL_ID };
  let modFile = dllFolder;
  let rootPath = path.dirname(modFile);
  const MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, "");
  let fallbackName = true;
  const ROOT_PATH = path.basename(rootPath);
  if (ROOT_PATH !== ".") {
    fallbackName = false;
    MOD_FOLDER = ""; //no top level folder needed if it's already included in the archive
    modFile = rootPath; //make the folder the targeted modFile so we can grab any other folders also in its directory
    rootPath = path.dirname(modFile);
  }
  const idx = modFile.lastIndexOf(path.basename(modFile));
  //handle enabled.txt file
  if (!ue4ssLoadOrder || !(api.store.getState()?.settings?.[GAME_ID]?.ue4ssLoEnabled ?? true)) {
    const ENABLEDTXT_PATH = path.join(fileName, path.dirname(dllFolder), ENABLEDTXT_FILE);
    try {
      await fsp.stat(ENABLEDTXT_PATH);
    } catch (err) {
      try {
        await fsp.writeFile(ENABLEDTXT_PATH, "", { encoding: "utf8" });
        files.push(path.join(path.dirname(dllFolder), ENABLEDTXT_FILE));
        log("info", `Successfully created ${ENABLEDTXT_FILE} for UE4SS DLL Mod: ${MOD_NAME}`);
      } catch {
        log("error", `Could not create ${ENABLEDTXT_FILE} for UE4SS DLL Mod: ${MOD_NAME}`);
      }
    }
  } else {
    files = files.filter((f) => path.basename(f).toLowerCase() !== ENABLEDTXT_FILE);
  }
  //Filter files and set instructions
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const MOD_ATTRIBUTE = {
    type: "attribute",
    key: LO_ATTRIBUTE_UE4SS,
    value: fallbackName ? MOD_FOLDER : path.basename(modFile),
  };
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  instructions.push(MOD_ATTRIBUTE);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map((str) => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map((str) => str.toLowerCase());
  const CONTENTSUB_FOLDERS_LOWER = CONTENTSUB_FOLDERS.map((str) => str.toLowerCase());
  const isMod = files.some((file) =>
    ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  const isSub = files.some((file) =>
    ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  const isContentSub = files.some((file) =>
    CONTENTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  let supported = gameId === spec.game.id && (isMod || isSub || isContentSub);

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installRoot(files) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map((str) => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map((str) => str.toLowerCase());
  const CONTENTSUB_FOLDERS_LOWER = CONTENTSUB_FOLDERS.map((str) => str.toLowerCase());
  let folder = "";
  let modFile = files.find((file) =>
    ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
  );
  if (modFile === undefined) {
    modFile = files.find((file) =>
      ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
    );
    folder = ROOTSUB_PATH;
  }
  if (modFile === undefined) {
    modFile = files.find((file) =>
      CONTENTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()),
    );
    folder = path.join(PROJECT_FOLDER, "Content"); //KEEPER ONLY: PROJECT_FOLDER
  }
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`;
  const idx = modFile.lastIndexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: ROOT_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: toProjectFolder(path.join(folder, file.substr(idx))), //KEEPER ONLY: a mod packaged for the other store's project folder
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for config files
function testConfig(files, gameId) {
  const isConfig = files.some((file) => CONFIG_FILES.includes(path.basename(file).toLowerCase()));
  let supported = gameId === spec.game.id && isConfig;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install config files
function installConfig(api, files) {
  const modFile = files.find((file) => CONFIG_FILES.includes(path.basename(file).toLowerCase()));
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: CONFIG_ID };

  //Filter files and set instructions
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  GAME_PATH = getDiscoveryPath(api);
  const IS_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
  if (IS_CONFIG === false) {
    //api.showErrorNotification(`Could not install mod as Config`, `You tried installing a Config mod, but the game, staging folder, and ${CONFIG_LOC} folder are not all on the same drive. Please move the game and/or staging folder to the same drive as the ${CONFIG_LOC} folder (typically C Drive) to install these types of mods with Vortex.`, { allowReport: false });
    configInstallerNotify(api);
    throw new VortexError("User canceled", { kind: "user-canceled", skipped: false });
  }
  return Promise.resolve({ instructions });
}

//Notification for config installer
function configInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-configinstaller`;
  const MESSAGE = "Could not install mod as Config";
  api.sendNotification({
    id: NOTIF_ID,
    type: "error",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `You tried installing a Config file mod, but the game, staging folder, and ${CONFIG_LOC} folder are not all on the same drive.\n` +
                `Please move the game and/or staging folder to the same drive as the ${CONFIG_LOC} folder (typically C Drive) to install these types of mods with Vortex.\n` +
                `\n` +
                `Config Path: ${CONFIG_PATH}\n` +
                `\n` +
                `If you want to use this mod installer, you must move the game and staging folder to the same partition as the ${CONFIG_LOC} folder (typically C Drive).\n` +
                `\n`,
            },
            [
              { label: "Continue", action: () => dismiss() },
              {
                label: "Open Config Folder",
                action: () => {
                  try {
                    window.api.shell.openFile(CONFIG_PATH);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

//error notification for Xbox version save install attempt
function saveErrorNotify(api) {
  const NOTIF_ID = `${GAME_ID}-saveinsterrxbox`;
  const MESSAGE = `Save files are not supported by the Xbox version of ${GAME_NAME}`;
  api.sendNotification({
    id: NOTIF_ID,
    type: "error",
    message: MESSAGE,
    allowSuppress: true,
    actions: [],
  });
}

//Test for save files
function testSave(files, gameId) {
  const isMod = files.some((file) => SAVE_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install save files
async function installSave(api, files) {
  const modFile = files.find((file) => SAVE_EXTS.includes(path.extname(file).toLowerCase()));
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: SAVE_ID };

  GAME_PATH = getDiscoveryPath(api);
  GAME_VERSION = await setGameVersionAsync(GAME_PATH);
  const TEST = SAVE_COMPAT_VERSIONS.includes(GAME_VERSION);
  if (!TEST) {
    saveErrorNotify(api);
    throw new VortexError("User canceled", { kind: "user-canceled", skipped: false });
  }

  //Filter files and set instructions
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  const IS_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
  if (IS_SAVE === false) {
    saveInstallerNotify(api);
    throw new VortexError("User canceled", { kind: "user-canceled", skipped: false });
  }
  return Promise.resolve({ instructions });
}

//Error notification for save installer when not on same partition
function saveInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-saveinstaller`;
  const MESSAGE = "Could not install mod as Save";
  api.sendNotification({
    id: NOTIF_ID,
    type: "error",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `You tried installing a Save file mod, but the game, staging folder, and ${SAVE_LOC} folder are not all on the same drive.\n` +
                `Please move the game and/or staging folder to the same drive as the ${SAVE_LOC} folder (typically C Drive) to install these types of mods with Vortex.\n` +
                `\n` +
                `Save Path: ${SAVE_PATH}\n` +
                `\n` +
                `If you want to use this mod installer, you must move the game and staging folder to the same partition as the ${SAVE_LOC} folder (typically C Drive).\n` +
                `\n`,
            },
            [
              { label: "Continue", action: () => dismiss() },
              {
                label: "Open Save Folder",
                action: () => {
                  try {
                    window.api.shell.openFile(SAVE_PATH);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

//Test Fallback installer to Binaries folder
function testBinaries(files, gameId) {
  const isPak = files.some((file) => path.extname(file).toLowerCase() === PAK_EXT);
  let supported = gameId === spec.game.id && !isPak;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to Binaries folder
function installBinaries(api, files, fileName) {
  if (!updating_mod) {
    fallbackInstallerNotify(api, fileName);
  }
  const setModTypeInstruction = { type: "setmodtype", value: BINARIES_ID };

  const filtered = files.filter((file) => !file.endsWith(path.sep));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: file,
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  modName = path.basename(modName, ".installing");
  const id = modName.replace(/[^a-zA-Z0-9\s]*( )*/gi, "").slice(0, 20);
  const NOTIF_ID = `${GAME_ID}-${id}-fallback`;
  const MESSAGE = "Fallback installer reached for " + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: "info",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `\n` +
                `The mod you just installed reached the fallback installer to the Binaries folder. This means Vortex could not determine where to place these mod files.\n` +
                `Please check the mod page description and review the files in the mod staging folder to determine whether the mod was installed correctly.\n` +
                `It may be necessary to perform manual file manipulation for the mod, or to manually change the Mod Type.\n` +
                `It is also possible that the mod was installed correctly. For example a non-UE4SS dll mod, like Optiscaler, is installed correctly to the Binaries folder.\n` +
                `\n` +
                `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n` +
                `\n` +
                `Mod Name: ${modName}.\n` +
                `\n`,
            },
            [
              { label: "Continue", action: () => dismiss() },
              {
                label: "Contact Ext. Developer",
                action: () => {
                  try {
                    window.api.shell.openUrl(`${EXTENSION_URL}?tab=posts`);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
              //*
              {
                label: `Open Mod Page + Staging Folder`,
                action: () => {
                  try {
                    window.api.shell.openFile(path.join(STAGING_FOLDER, modName));
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
                  const modMatch = Object.values(mods).find(
                    (mod) => mod.installationPath === modName,
                  );
                  log("warn", `Found ${modMatch?.id} for ${modName}`);
                  let PAGE = ``;
                  if (modMatch) {
                    const MOD_ID = modMatch.attributes.modId;
                    if (MOD_ID !== undefined) {
                      PAGE = `${MOD_ID}?tab=description`;
                    }
                  }
                  const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
                  try {
                    window.api.shell.openUrl(MOD_PAGE_URL);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
            ],
          );
        },
      },
    ],
  });
}

// AUTOMATIC MOD DOWNLOADERS ///////////////////////////////////////////////////

//Check if UE4SS is installed
function isUe4ssInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === UE4SS_ID);
}

//Check if Signature Bypass is installed
function isSigBypassInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === SIGBYPASS_ID);
}

//* Download UE4SS from the RE-UE4SS GitHub releases, through the shared auto-downloader module.
//check === false forces a re-download even when it is already installed.
async function downloadUe4ss(api, gameSpec, check = true) {
  return download(api, UE4SS_REQUIREMENTS, !check);
} //*/

async function asyncForEachTestVersion(api, requirements) {
  for (let index = 0; index < requirements.length; index++) {
    await testRequirementVersion(api, requirements[index]);
  }
}

async function onCheckModVersion(api, gameId, mods, forced) {
  try {
    await asyncForEachTestVersion(api, UE4SS_REQUIREMENTS);
  } catch (err) {
    log("warn", `Failed to test requirement version: ${err}`);
  }
}

//* Function to auto-download UE4SS from Nexus Mods
async function downloadUe4ssNexus(api, gameSpec, check = true) {
  let isInstalled = isUe4ssInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = UE4SS_NAME;
    const MOD_TYPE = UE4SS_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = UE4SS_PAGE_NO;
    const FILE_ID = UE4SS_FILE_NO; //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = UE4SS_DOMAIN;
    api.sendNotification({
      //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) {
      //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try {
        //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter((file) => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new VortexError(`No ${MOD_NAME} main file found`, { kind: "process-canceled" });
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch {
        // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = {
        //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await new Promise((resolve, reject) =>
        api.events.emit(
          "start-download",
          [URL],
          dlInfo,
          undefined,
          (err, result) => (err ? reject(err) : resolve(result)),
          undefined,
          {
            allowInstall: false,
          },
        ),
      );
      const modId = await new Promise((resolve, reject) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, (err, result) =>
          err ? reject(err) : resolve(result),
        ),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      try {
        window.api.shell.openUrl(errPage);
      } catch (openErr) {
        api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
      }
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Function to auto-download Sig Bypass from Nexus Mods
async function downloadSigBypass(api, gameSpec, check = true) {
  let isInstalled = isSigBypassInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = SIGBYPASS_NAME;
    const MOD_TYPE = SIGBYPASS_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    let FILE_ID = SIGBYPASS_FILE_NO; //If using a specific file id because "input" below gives an error
    const PAGE_ID = SIGBYPASS_PAGE_NO;
    const GAME_DOMAIN = SIGBYPASS_DOMAIN;
    api.sendNotification({
      //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: "activity",
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) {
      //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = FILE_ID; //use the FILE_ID directly for the correct game store version
      let URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      try {
        //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter((file) => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new VortexError(`No ${MOD_NAME} main file found`, { kind: "process-canceled" });
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch {
        // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } //*/
      const dlInfo = {
        //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await new Promise((resolve, reject) =>
        api.events.emit(
          "start-download",
          [URL],
          dlInfo,
          undefined,
          (err, result) => (err ? reject(err) : resolve(result)),
          undefined,
          {
            allowInstall: false,
          },
        ),
      );
      const modId = await new Promise((resolve, reject) =>
        api.events.emit("start-install-download", dlId, { allowAutoEnable: false }, (err, result) =>
          err ? reject(err) : resolve(result),
        ),
      );
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      try {
        window.api.shell.openUrl(errPage);
      } catch (openErr) {
        api.showErrorNotification("Failed to open the URL", openErr, { allowReport: false });
      }
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// UNREAL FUNCTIONS ///////////////////////////////////////////////////////////////

//* FBLO Functions
function generateProps(context, profileId) {
  const api = context.api;
  const state = api.getState();
  const profile =
    profileId !== undefined
      ? selectors.profileById(state, profileId)
      : selectors.activeProfile(state);
  if (profile?.gameId !== GAME_ID) {
    return undefined;
  }

  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? undefined;
  if (discovery?.path === undefined) {
    return undefined;
  }

  const mods = state?.persistent?.mods?.[GAME_ID] ?? {};
  return { api, state, profile, mods, discovery };
}

async function ensureLOFile(context, profileId, props) {
  if (props === undefined) {
    props = generateProps(context, profileId);
  }
  if (props === undefined) {
    return Promise.reject(
      new VortexError("failed to generate game props", { kind: "process-canceled" }),
    );
  }
  const targetPath = path.join(props.discovery.path, props.profile.id + "_" + LO_FILE_NAME);
  try {
    await ensureFileAsync(targetPath);
    return targetPath;
  } catch (err) {
    return Promise.reject(err);
  }
}

//Reordering is ignored while a mod update is in flight: the deserializers below freeze the stored
//order and the serializers skip writing, so tell the user their change was not applied.
function notifyLoadOrderPaused(api, gameId) {
  api.sendNotification({
    id: `${gameId}-loadorder-update-paused`,
    type: "warning",
    message:
      "Load order changes are paused while a mod update finishes. Reorder again once it completes.",
    displayMS: 6000,
  });
}

async function deserializeLoadOrder(context) {
  if (mod_update_all_profile) {
    //A mod update briefly removes and reinstalls mods, so rebuilding the order from disk right now
    //would drop their entries. Return the stored order untouched instead: positions are preserved
    //and the page keeps showing the real load order rather than a placeholder row.
    const updateState = context.api.getState();
    const updateProfileId = selectors.lastActiveProfileForGame(updateState, GAME_ID);
    return updateState?.persistent?.loadOrder?.[updateProfileId] ?? [];
  }

  const props = generateProps(context, undefined);
  if (props?.profile?.gameId !== GAME_ID) {
    return Promise.reject(new VortexError("invalid props", { kind: "process-canceled" }));
  }

  // The deserialization function should be used to filter and insert wanted data into Vortex's
  //  loadOrder application state, once that's done, Vortex will trigger a serialization event
  //  which will ensure that the data is written to the LO file.
  const currentModsState = props.profile?.modState ?? {};

  // we only want to insert enabled mods.
  const enabledModIds = Object.keys(currentModsState).filter(
    (modId) => currentModsState?.[modId]?.enabled ?? false,
  );
  const mods = props.state?.persistent?.mods?.[GAME_ID] ?? {};
  let data = [];
  try {
    const loFilePath = await ensureLOFile(context, props.profile.gameId, props);
    const fileData = await fsp.readFile(loFilePath, { encoding: "utf8" });
    if (fileData.length > 0) {
      data = JSON.parse(fileData);
    }
    if (!Array.isArray(data)) {
      data = [];
    }
  } catch (err) {
    //Vortex discards a rejection from here without storing anything, so an unreadable or malformed
    //file would leave the load order unset for the whole session and mod types that sort by it
    //would deploy unsorted. Fall back to the order already in state - never to an empty list,
    //which would be serialized straight back over the file.
    log("warn", "failed to read load order file", err);
    const storedLO = props.state?.persistent?.loadOrder?.[props.profile.id] ?? [];
    data = Array.isArray(storedLO) ? storedLO : [];
  }
  try {
    /*try {
      data = JSON.parse(fileData);
    } catch (err) {
      await new Promise((resolve, reject) => {
        props.api.showDialog('error', 'Corrupt load order file', {
          bbcode: props.api.translate('The load order file is in a corrupt state. You can try to fix it yourself '
              + 'or Vortex can regenerate the file for you, but that may result in loss of data ' +
              '(Will only affect load order items you added manually, if any).')
          },
          [
            { label: 'Cancel', action: () => reject(err) },
            {
              label: 'Regenerate File', action: () => {
                data = [];
                return resolve();
              }
            }
          ]
        )
      })
    } //*/

    // User may have disabled/removed a mod - we need to filter out any existing entries from the data we parsed.
    let filteredData = data.filter((entry) => enabledModIds.includes(entry.id));
    // Check if the user added any new mods
    const diff = enabledModIds.filter(
      (id) =>
        mods[id]?.type === UE5_SORTABLE_ID && !filteredData.some((loEntry) => loEntry.id === id),
    );
    // Add any newly added mods to the bottom of the loadOrder.
    diff.forEach((id) => {
      filteredData.push({
        id: id,
        modId: id,
        enabled: true,
        name: mods[id] !== undefined ? util.renderModName(mods[id]) : id,
      });
    });
    return Promise.resolve(filteredData);
  } catch (err) {
    return Promise.reject(err);
  }
}

async function serializeLoadOrder(context, loadOrder) {
  if (mod_update_all_profile) {
    notifyLoadOrderPaused(context.api, GAME_ID);
    return;
  }

  const props = generateProps(context, undefined);
  if (props === undefined) {
    return Promise.reject(new VortexError("invalid props", { kind: "process-canceled" }));
  }
  // Make sure the LO file is created and ready to be written to.
  const loFilePath = await ensureLOFile(context, props.profile.id, props);
  // Write the prefixed LO to file
  await fsp.writeFile(loFilePath, JSON.stringify(loadOrder, null, 4), { encoding: "utf8" });
  // something has changed so we need to tell vortex that a deployment will be necessary
  requestDeployment(context.api, spec);
  return Promise.resolve();
}
//*/

async function deserializeUe4ss(api) {
  if (mod_update_all_profile) {
    //Freeze the order while a mod update is in flight - see deserializeLoadOrder above.
    const updateState = api.getState();
    const updateProfileId = selectors.lastActiveProfileForGame(updateState, GAME_ID);
    return updateState?.persistent?.ue4ssLoadOrder?.[updateProfileId]?.loadOrder ?? [];
  }

  //Set basic information for load order paths and data
  const state = api.getState();
  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
  GAME_PATH = getDiscoveryPath(api);
  let modFolderPath = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH);
  const profile = selectors.activeProfile(state);
  const filename = profile.id + "_" + UE4SS_LO_FILE;
  let loadOrderPath = path.join(modFolderPath, filename);
  let LO_MOD_ARRAY = [];
  try {
    const raw = await fsp.readFile(loadOrderPath, { encoding: "utf8" });
    if (raw.length > 0) LO_MOD_ARRAY = JSON.parse(util.deBOM(raw));
  } catch {
    /* file doesn't exist yet; start with empty array */
  }
  if (debug) {
    log("warn", `UE4SS LO_MOD_ARRAY: ${LO_MOD_ARRAY.map((mod) => mod.id).join(", ")}`);
  }

  //Get all mod files from mods folder
  let modFolders = [];
  try {
    modFolders = await fsp.readdir(modFolderPath);
    modFolders = modFolders
      .filter((file) => isDir(modFolderPath, file) && !UE4SS_NATIVE_MODS.includes(file))
      .sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  } catch {
    return Promise.reject(new Error("Failed to read UE4SS Mods folder"));
  }

  //Determine if mod is managed by Vortex (async version)
  const isVortexManaged = async (modId) => {
    return fsp
      .stat(path.join(modFolderPath, modId, `__folder_managed_by_vortex`))
      .then(() => true)
      .catch(() => false);
  };

  // Get readable mod name using attribute from mod installer
  async function getModName(folder) {
    const VORTEX = await isVortexManaged(folder);
    if (!VORTEX) {
      return "Manual Mod";
    }
    try {
      //Mod installed by Vortex, find mod where atrribute (from installer) matches folder in the load order
      const modMatch = Object.values(mods).find(
        (mod) => (mods[mod.id]?.attributes?.[LO_ATTRIBUTE_UE4SS] ?? "") === folder,
      );
      if (modMatch) {
        return (
          modMatch.attributes.customFileName ??
          modMatch.attributes.logicalFileName ??
          modMatch.attributes.name
        );
      }
      return folder;
    } catch {
      return folder;
    }
  }

  // Get Vortex mod id using attribute from mod installer
  async function getModId(folder) {
    try {
      //find mod where atrribute (from installer) matches file in the load order
      const modMatch = Object.values(mods).find(
        (mod) => (mods[mod.id]?.attributes?.[LO_ATTRIBUTE_UE4SS] ?? "") === folder,
      ); //find mod by folder name attribute
      if (modMatch) {
        return modMatch.id;
      }
      return undefined;
    } catch {
      return undefined;
    }
  }

  //Set load order
  let loadOrder = await LO_MOD_ARRAY.reduce(async (accumP, entry) => {
    const accum = await accumP;
    const folder = entry.id;
    if (!modFolders.includes(folder)) {
      return Promise.resolve(accum);
    }
    accum.push({
      id: folder,
      name: `${await getModName(folder)} (${folder})`,
      modId: (await isVortexManaged(folder)) ? await getModId(folder) : undefined,
      enabled: entry.enabled,
      locked: entry?.locked,
    });
    return Promise.resolve(accum);
  }, Promise.resolve([]));

  //push new mods to loadOrder
  for (let folder of modFolders) {
    if (!loadOrder.find((mod) => mod.id === folder)) {
      loadOrder.push({
        id: folder,
        name: `${await getModName(folder)} (${folder})`,
        modId: (await isVortexManaged(folder)) ? await getModId(folder) : undefined,
        enabled: true,
      });
    }
  }

  return loadOrder;
}

//Write load order to files
async function serializeUe4ss(api, loadOrder) {
  if (mod_update_all_profile) {
    notifyLoadOrderPaused(api, GAME_ID);
    return;
  }

  const state = api.getState();
  if (selectors.activeGameId(state) !== GAME_ID) return;
  GAME_PATH = getDiscoveryPath(api);
  const profile = selectors.activeProfile(state);
  const filename = profile.id + "_" + UE4SS_LO_FILE;
  const jsonPath = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH, filename);
  await fsp.writeFile(jsonPath, JSON.stringify(loadOrder, null, 2), { encoding: "utf8" });

  let loadOrderPath = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH, UE4SS_MODSTXT_FILE);
  await ensureFileAsync(loadOrderPath);
  let loadOrderMapped = loadOrder.map((mod) => `${mod.id} : ${mod.enabled ? 1 : 0}`);
  let contents = await fsp.readFile(loadOrderPath, "utf8");
  const lines = contents.split("\n");
  const bpIdx = lines.findIndex((l) => l.trim().startsWith("BPModLoaderMod"));
  const kbIdx = lines.findIndex((l) => l.trim().startsWith("Keybinds"));
  //A missing marker must degrade to "rebuild the load order band", never truncate the file.
  const headEnd = bpIdx >= 0 ? bpIdx + 1 : 0;
  const tailStart = kbIdx >= headEnd ? kbIdx : lines.length;
  //Comments and UE4SS native mod lines inside the band survive; every other line is load order owned.
  const bandKeep = lines.slice(headEnd, tailStart).filter((l) => {
    const t = l.trim();
    if (t === "") return false;
    if (t.startsWith(";")) return true;
    return UE4SS_NATIVE_MODS.includes(t.split(":")[0].trim());
  });
  const loadOrderOutput = [
    ...lines.slice(0, headEnd),
    ...loadOrderMapped,
    ...bandKeep,
    ...lines.slice(tailStart),
  ].join("\n");
  return fsp.writeFile(loadOrderPath, loadOrderOutput, { encoding: "utf8" });
}

async function deserializeLogicMods(api) {
  if (mod_update_all_profile) {
    //Freeze the order while a mod update is in flight - see deserializeLoadOrder above.
    const updateState = api.getState();
    const updateProfileId = selectors.lastActiveProfileForGame(updateState, GAME_ID);
    return updateState?.persistent?.logicModsLoadOrder?.[updateProfileId]?.loadOrder ?? [];
  }

  const state = api.getState();
  const mods = state?.persistent?.mods?.[spec.game.id] ?? {};
  GAME_PATH = getDiscoveryPath(api);
  const logicModsFolder = path.join(GAME_PATH, LOGICMODS_PATH); //LOGICMODS_PATH already ends in the folder for this game
  const bpmlFolder = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH, BPML_FOLDER);
  const profile = selectors.activeProfile(state);
  const filename = profile.id + "_" + LOGICMODS_LO_FILE;
  const jsonPath = path.join(bpmlFolder, filename);

  let LO_MOD_ARRAY = [];
  try {
    const raw = await fsp.readFile(jsonPath, { encoding: "utf8" });
    if (raw.length > 0) LO_MOD_ARRAY = JSON.parse(util.deBOM(raw));
  } catch {
    /* file doesn't exist yet; start with empty array */
  }

  let pakFiles = [];
  try {
    const all = await getAllFiles(logicModsFolder);
    const seen = new Set();
    for (const f of all) {
      if (path.extname(f).toLowerCase() === LOGICMODS_EXT) {
        const name = path.basename(f, path.extname(f));
        if (!seen.has(name)) {
          seen.add(name);
          pakFiles.push(name);
        }
      }
    }
  } catch {
    return Promise.reject(new Error("Failed to read LogicMods folder"));
  }

  const getModName = (pakName) => {
    try {
      const modMatch = Object.values(mods).find((mod) => {
        const attr = mod?.attributes?.[LO_ATTRIBUTE_LOGIC] ?? [];
        return Array.isArray(attr) ? attr.includes(pakName) : attr === pakName;
      });
      if (modMatch) {
        return (
          modMatch.attributes.customFileName ??
          modMatch.attributes.logicalFileName ??
          modMatch.attributes.name
        );
      }
      return undefined;
    } catch {
      return undefined;
    }
  };

  const getModId = (pakName) => {
    try {
      const modMatch = Object.values(mods).find((mod) => {
        const attr = mod?.attributes?.[LO_ATTRIBUTE_LOGIC] ?? [];
        return Array.isArray(attr) ? attr.includes(pakName) : attr === pakName;
      });
      return modMatch ? modMatch.id : undefined;
    } catch {
      return undefined;
    }
  };

  //prev carries the persisted entry, so a locked position survives the rebuild on every deploy
  const makeEntry = (pakName, prev) => {
    const modName = getModName(pakName);
    return {
      id: pakName,
      name: modName
        ? `${modName} (${pakName}${LOGICMODS_EXT})`
        : `Manual Mod (${pakName}${LOGICMODS_EXT})`,
      modId: getModId(pakName),
      ...(prev?.locked !== undefined ? { locked: prev.locked } : {}),
    };
  };

  let loadOrder = LO_MOD_ARRAY.filter((entry) => pakFiles.includes(entry.id)).map((entry) =>
    makeEntry(entry.id, entry),
  );

  for (const pakName of pakFiles) {
    if (!loadOrder.find((e) => e.id === pakName)) {
      loadOrder.push(makeEntry(pakName));
    }
  }

  return loadOrder;
}

//Write load order for LogicMods/Blueprint pak mods
async function serializeLogicMods(api, loadOrder) {
  if (mod_update_all_profile) {
    notifyLoadOrderPaused(api, GAME_ID);
    return;
  }

  const state = api.getState();
  if (selectors.activeGameId(state) !== GAME_ID) return;
  GAME_PATH = getDiscoveryPath(api);
  const profile = selectors.activeProfile(state);
  const bpmlFolder = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH, BPML_FOLDER);
  const jsonPath = path.join(bpmlFolder, profile.id + "_" + LOGICMODS_LO_FILE);
  await fsp.writeFile(jsonPath, JSON.stringify(loadOrder, null, 2), { encoding: "utf8" });

  const loTxtPath = path.join(bpmlFolder, BPML_LO_FILE);
  await ensureFileAsync(loTxtPath);
  await fsp.writeFile(loTxtPath, loadOrder.map((e) => e.id).join("\n"), { encoding: "utf8" });
}

//Generate UE4SS + LogicMods load order data for inclusion in a collection
async function genUe4ssCollectionsData(api, gameId, includedMods) {
  const state = api.getState();
  const profileId = selectors.lastActiveProfileForGame(state, gameId);
  if (profileId === undefined) {
    return Promise.reject(
      new Error("Invalid profile - cannot generate UE4SS load order collection data"),
    );
  }
  const result = {};
  if (ue4ssLoadOrder) {
    const lo = state?.persistent?.ue4ssLoadOrder?.[profileId]?.loadOrder ?? [];
    result.ue4ssLoadOrder = lo
      .filter((entry) => entry.modId !== undefined && includedMods.includes(entry.modId)) //drop manual mods and mods not in the collection
      .map((entry) => ({ id: entry.id, enabled: entry.enabled, locked: entry.locked })); //name and modId are machine-specific - recomputed on deserialize
  }
  if (logicModsLoadOrder) {
    const lo = state?.persistent?.logicModsLoadOrder?.[profileId]?.loadOrder ?? [];
    result.logicModsLoadOrder = lo
      .filter((entry) => entry.modId !== undefined && includedMods.includes(entry.modId))
      .map((entry) => ({ id: entry.id }));
  }
  return Promise.resolve(result);
}

//Apply UE4SS + LogicMods load order data from an installed collection
async function parseUe4ssCollectionsData(api, gameId, collection) {
  const state = api.getState();
  const profileId = selectors.lastActiveProfileForGame(state, gameId);
  if (profileId === undefined) {
    return Promise.reject(
      new Error("Invalid profile - cannot apply UE4SS load order collection data"),
    );
  }
  const ue4ssLO = collection?.ue4ssLoadOrder;
  const logicLO = collection?.logicModsLoadOrder;
  GAME_PATH = getDiscoveryPath(api);
  if (ue4ssLoadOrder && Array.isArray(ue4ssLO) && ue4ssLO.length > 0) {
    api.store.dispatch(setUe4ssLoadOrder(profileId, ue4ssLO));
    if (GAME_PATH !== undefined) {
      //write per-profile json file so deserializeUe4ss picks up the ordering on next deploy
      try {
        const modFolderPath = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH);
        await vfs.ensureDirWritableAsync(modFolderPath);
        await fsp.writeFile(
          path.join(modFolderPath, profileId + "_" + UE4SS_LO_FILE),
          JSON.stringify(ue4ssLO, null, 2),
          { encoding: "utf8" },
        );
      } catch (err) {
        log("warn", `[${GAME_ID}] Failed to write UE4SS load order file from collection`, err);
      }
    }
  }
  if (logicModsLoadOrder && Array.isArray(logicLO) && logicLO.length > 0) {
    api.store.dispatch(setLogicModsLoadOrder(profileId, logicLO));
    if (GAME_PATH !== undefined) {
      try {
        const bpmlFolder = path.join(GAME_PATH, BINARIES_PATH, UE4SS_MOD_PATH, BPML_FOLDER);
        await vfs.ensureDirWritableAsync(bpmlFolder);
        await fsp.writeFile(
          path.join(bpmlFolder, profileId + "_" + LOGICMODS_LO_FILE),
          JSON.stringify(logicLO, null, 2),
          { encoding: "utf8" },
        );
      } catch (err) {
        log("warn", `[${GAME_ID}] Failed to write LogicMods load order file from collection`, err);
      }
    }
  }
  return Promise.resolve();
}

//UNREAL - Pre-sort function - legacy load order page
async function preSort(api, items, direction) {
  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
  const fileExt = UNREALDATA.fileExt;

  const loadOrder = items.map((mod) => {
    const modInfo = mods[mod.id];
    let name =
      modInfo?.attributes?.customFileName ??
      modInfo?.attributes?.logicalFileName ??
      modInfo?.attributes?.name ??
      mod.name;
    const paks = modInfo?.attributes?.unrealModFiles ?? [];
    if (paks.length > 1) name = name + ` (${paks.length} ${fileExt} files)`;

    return {
      id: mod.id,
      name,
      imgUrl: modInfo?.attributes?.pictureUrl ?? path.join(__dirname, spec.game.logo),
    };
  });

  return direction === "descending"
    ? Promise.resolve(loadOrder.reverse())
    : Promise.resolve(loadOrder);
}

//Make prefix based on loadOrder index
function makePrefix(input) {
  let res = "";
  let rest = input;
  while (rest > 0) {
    res = String.fromCharCode(65 + (rest % 25)) + res;
    rest = Math.floor(rest / 25);
  }
  return util.pad(res, "A", 3);
}

//Find the loadOrder index and convert to prefix
function loadOrderPrefix(api, mod) {
  const state = api.getState();
  const profile = selectors.lastActiveProfileForGame(state, GAME_ID);
  const loadOrder = state?.persistent?.loadOrder?.[profile] ?? undefined;
  let pos = -1;
  if (Array.isArray(loadOrder)) {
    pos = loadOrder.findIndex((entry) => entry.id === mod.id); //FBLO stores an array
  } else if (loadOrder !== undefined && loadOrder !== null && typeof loadOrder === "object") {
    pos = Object.keys(loadOrder).indexOf(mod.id); //legacy load order page stores an object
  }
  if (pos === -1) {
    return "ZZZZ-";
  }
  return makePrefix(pos) + "-";
}

//Split a list of paths into every path segment they contain, both separators, blanks dropped.
//The test* functions above can get away with path.basename() because Vortex hands an installer
//an archive listing that includes standalone directory entries ("LogicMods\"), whose basename
//IS the folder name. A listing built by walking the staging folder (getAllFiles) has files only,
//so a basename check there would reduce "LogicMods/foo.pak" to just "foo.pak" and never match a
//folder marker. Matching segments works for both shapes - a directory entry splits to
//["LogicMods", ""] and the blank is filtered out.
function pathSegments(files) {
  return files.flatMap((file) => file.split(path.sep)).filter(Boolean);
}

//Mirrors the registration-priority ladder in main() for just the installers that sit ABOVE the
//pak installer's priority (UE5_SORTABLE_ID = 29): Mod Kit (25, only when hasModKit), UE4SS Combo
//(26, always registered) and LogicMods (27, only when ue4ssLoadOrder). An installer at or
//below priority 29 never gets a turn once a pak-type file is present, since testPak's own check
//is just "has a pak-type file" with no exclusivity - so lower-priority markers can't have
//"actually" claimed the archive and are not checked here. Used by retagFomodPakMod() below to
//work out, after the fact, what a FOMOD-installed mod would have been classified as had FOMOD
//not intercepted it first. Pass paths relative to the staging folder when calling this on a
//staged tree: an absolute path drags the staging root's own segments in, and a staging folder
//living under the game's root folder name would then satisfy that check for every mod.
function beatsPakInstaller(files) {
  const segsLower = pathSegments(files).map((seg) => seg.toLowerCase());
  if (hasModKit) {
    const hasModKitExt = files.some((file) => path.extname(file).toLowerCase() === MODKITMOD_EXT);
    const hasModKitFile = segsLower.includes(MODKITMOD_FILE.toLowerCase());
    if (hasModKitExt && hasModKitFile) return true; //Mod Kit (25)
  }
  const hasBinariesFolder = segsLower.includes("binaries");
  const hasContentFolder = segsLower.includes("content");
  if (hasBinariesFolder && hasContentFolder) return true; //UE4SS Combo (26)
  if (ue4ssLoadOrder && segsLower.includes(LOGICMODS_FOLDER.toLowerCase())) return true; //LogicMods (27)
  return false;
}

//Test for pak mods
function testPak(files, gameId) {
  const supportedGame = gameId === spec.game.id;
  const isPak = files.some((file) => path.extname(file).toLowerCase() === PAK_EXT);
  let supported = supportedGame && isPak;

  // Test for a mod installer
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//install pak mods
async function installPak(api, files) {
  const fileExt = UNREALDATA.fileExt;
  const modFiles = files.filter((file) => fileExt.includes(path.extname(file).toLowerCase()));
  const modType = {
    type: "setmodtype",
    value: UE5_SORTABLE_ID,
  };
  const installFiles =
    modFiles.length > PAK_FILE_MIN ? await chooseFilesToInstall(api, modFiles, fileExt) : modFiles;
  const unrealModFiles = {
    type: "attribute",
    key: "unrealModFiles",
    value: installFiles.map((f) => path.basename(f)),
  };
  let instructions = installFiles.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.basename(file),
    };
  });
  instructions.push(modType);
  instructions.push(unrealModFiles);
  return Promise.resolve({ instructions });
}

//file selection dialog for pak mods
async function chooseFilesToInstall(api, files, fileExt) {
  const t = api.translate;
  return api
    .showDialog(
      "question",
      t("Multiple {{PAK}} files", { replace: { PAK: fileExt } }),
      {
        text:
          t("The mod you are installing contains {{x}} {{ext}} files.", {
            replace: { x: files.length, ext: fileExt },
          }) +
          `This can be because the author intended for you to chose one of several options. Please select which files to install below:`,
        checkboxes: files.map((pak) => {
          return {
            id: pak,
            text: pak,
            value: false,
          };
        }),
      },
      [{ label: "Cancel" }, { label: "Install Selected" }, { label: "Install All_plural" }],
    )
    .then((result) => {
      if (result.action === "Cancel")
        return Promise.reject(
          new VortexError("User cancelled.", { kind: "user-canceled", skipped: true }),
        );
      else {
        const installAll =
          result.action === "Install All" || result.action === "Install All_plural";
        const installPAKS = installAll
          ? files
          : Object.keys(result.input)
              .filter((s) => result.input[s])
              .map((file) => files.find((f) => f === file));
        return installPAKS;
      }
    });
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

// Function to check if staging folder and game path are on same drive partition to enable modtypes + installers
function checkPartitions(folder, discoveryPath) {
  if (!preferHardlinks && !IO_STORE) {
    //only do early return if hardlinks have no benefits and aren't required
    return true;
  }
  try {
    // Define paths
    const path1 = discoveryPath;
    const path2 = STAGING_FOLDER;
    const path3 = folder;
    // Ensure all folders exist
    fs.mkdirSync(path1, { recursive: true });
    fs.mkdirSync(path2, { recursive: true });
    fs.mkdirSync(path3, { recursive: true });
    // Get the stats for all folders
    const stats1 = fs.statSync(path1);
    const stats2 = fs.statSync(path2);
    const stats3 = fs.statSync(path3);
    // Read device IDs and check if they are all the same
    const a = stats1.dev;
    const b = stats2.dev;
    const c = stats3.dev;
    const TEST = a === b && b === c;
    return TEST;
  } catch {
    return false;
  }
}

//Notification if Config/Save folders are not on the same partition as the game and staging folder
function partitionCheckNotify(api, CHECK_CONFIG, CHECK_SAVE) {
  const NOTIF_ID = `${GAME_ID}-partioncheck`;
  const MESSAGE = "Some Mods Installers are Not Available";
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `Because ${GAME_NAME} includes the IO-Store Unreal Engine feature (or because hardlinks are preferred), Vortex must use hardlinks to install mods for the game.\n` +
                `As such, the game, staging folder, and user folder (typically on C Drive) must all be on the same drive partition to install certain mods with Vortex.\n` +
                `Vortex detected that one or more of the mod types listed below are not available because the game, staging folder, and mod type folder(s) are not all on the same drive partition.\n` +
                `\n` +
                `Here are your results for the partition checks to enable these mod types:\n` +
                `  - Config: ${CHECK_CONFIG ? `ENABLED: ${CONFIG_LOC} folder is on the same partition as the game and the Vortex staging folder, so the Config modtype is available` : `DISABLED: ${CONFIG_LOC} folder is NOT on the same partition as the game and the Vortex staging folder, so the Config modtype is NOT available`}\n` +
                `  - Save: ${CHECK_SAVE ? `ENABLED: ${SAVE_LOC} folder is on the same partition as the game and the Vortex staging folder, so the Save modtype is available` : `DISABLED: ${SAVE_LOC} folder is NOT on the same partition as the game and the Vortex staging folder, so the Save modtype is NOT available`}\n` +
                `\n` +
                `Game Path: ${GAME_PATH}\n` +
                `Staging Path: ${STAGING_FOLDER}\n` +
                `Config Path: ${CONFIG_PATH}\n` +
                `Save Path (installer for Steam/Epic/GOG versions only): ${SAVE_PATH}\n` +
                `\n` +
                `If you want to use the disabled mod types, you must move the game and staging folder to the same partition as the folders shown above.\n` +
                `\n`,
            },
            [
              { label: "Acknowledge", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup-notify`;
  const MESSAGE = "Special Setup Instructions";
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text: `\n` + `TEXT HERE.\n` + `\n` + `TEXT HERE.\n` + `\n`,
            },
            [
              { label: "Acknowledge", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

async function getExeProductVersion(filePath) {
  const exeVersion = require("exe-version");
  return exeVersion.getProductVersion(filePath);
}

function findSteamAppsDir(gamePath) {
  //walk up from gamePath to the ancestor dir whose parent is 'steamapps' and whose name is 'common'
  let dir = gamePath;
  for (;;) {
    const parent = path.dirname(dir);
    if (parent === dir) return undefined; //reached filesystem root
    if (
      path.basename(parent).toLowerCase() === "common" &&
      path.basename(path.dirname(parent)).toLowerCase() === "steamapps"
    ) {
      return path.dirname(parent);
    }
    dir = parent;
  }
}

async function resolveSteamBuildVersion(gamePath) {
  const steamAppsDir = findSteamAppsDir(gamePath);
  if (!steamAppsDir) return undefined;
  for (const appId of [STEAMAPP_ID, STEAMAPP_ID_DEMO]) {
    if (!appId || appId === "XXX") continue;
    try {
      const contents = await fsp.readFile(
        path.join(steamAppsDir, `appmanifest_${appId}.acf`),
        "utf8",
      );
      const match = contents.match(/"buildid"\s+"(\d+)"/);
      if (match) return match[1];
    } catch {
      //manifest for this appId not present here, try next
    }
  }
  return undefined;
}

async function resolveEpicBuildVersion(gamePath) {
  if (!EPICAPP_ID || EPICAPP_ID === "XXX") return undefined;
  let dataPath;
  try {
    dataPath = winapi.RegGetValue(
      "HKEY_LOCAL_MACHINE",
      "SOFTWARE\\WOW6432Node\\Epic Games\\EpicGamesLauncher",
      "AppDataPath",
    ).value;
  } catch {
    dataPath = path.join(
      process.env.ProgramData || process.env.ALLUSERSPROFILE,
      "Epic",
      "EpicGamesLauncher",
      "Data",
    );
  }
  const normalizedGamePath = path.normalize(gamePath).toLowerCase();
  try {
    const manifestsDir = path.join(dataPath, "Manifests");
    const entries = await fsp.readdir(manifestsDir);
    for (const entry of entries) {
      if (!entry.toLowerCase().endsWith(".item")) continue;
      try {
        const data = JSON.parse(await fsp.readFile(path.join(manifestsDir, entry), "utf8"));
        const matches =
          data.AppName === EPICAPP_ID ||
          path.normalize(data.InstallLocation || "").toLowerCase() === normalizedGamePath;
        if (matches && data.AppVersionString) return data.AppVersionString;
      } catch {
        //unreadable/invalid manifest, skip it
      }
    }
  } catch (err) {
    log("warn", `Could not read Epic manifests for ${GAME_ID}: ${err}`);
  }
  return undefined;
}

async function resolveGogVersion(gamePath) {
  if (!GOGAPP_ID || GOGAPP_ID === "XXX") return undefined;
  try {
    const regKey = `SOFTWARE\\WOW6432Node\\GOG.com\\Games\\${GOGAPP_ID}`;
    const regPath = winapi.RegGetValue("HKEY_LOCAL_MACHINE", regKey, "path").value;
    if (path.normalize(regPath).toLowerCase() !== path.normalize(gamePath).toLowerCase()) {
      return undefined;
    }
    return winapi.RegGetValue("HKEY_LOCAL_MACHINE", regKey, "ver").value;
  } catch {
    //RegGetValue throws (never returns null) when the key/value is missing
    return undefined;
  }
}

async function resolveStoreVersion(gamePath) {
  const steamVersion = await resolveSteamBuildVersion(gamePath);
  if (steamVersion !== undefined) return steamVersion;
  const epicVersion = await resolveEpicBuildVersion(gamePath);
  if (epicVersion !== undefined) return epicVersion;
  return resolveGogVersion(gamePath);
}

let VERSION_HASH_CACHE = {}; //cacheKey (MD5 of sorted mtimes) -> hash string; paid once per build, not per mod-installed health check

async function resolveHashVersion(gamePath) {
  const hashFiles = [SHIPPING_EXE]; //game-code file(s), never the launcher EXEC
  try {
    const mtimes = [];
    for (const relFile of hashFiles) {
      mtimes.push((await fsp.stat(path.join(gamePath, relFile))).mtimeMs);
    }
    mtimes.sort((a, b) => a - b);
    const cacheKey = crypto
      .createHash("md5")
      .update(mtimes.map((m) => m.toString()).join(""))
      .digest("hex");
    if (VERSION_HASH_CACHE[cacheKey] !== undefined) return VERSION_HASH_CACHE[cacheKey];
    const fileHashes = [];
    for (const relFile of hashFiles) {
      fileHashes.push(await util.fileMD5(path.join(gamePath, relFile)));
    }
    const hash = crypto.createHash("md5").update(fileHashes.join("")).digest("hex");
    VERSION_HASH_CACHE[cacheKey] = hash;
    return hash;
  } catch (err) {
    log("warn", `Could not compute hash game version for ${GAME_ID}: ${err}`);
    return undefined;
  }
}

async function resolveGameVersion(gamePath, exePath) {
  GAME_VERSION = await setGameVersionAsync(gamePath);
  const READ_FILE = path.join(gamePath, SHIPPING_EXE);
  let version = "0.0.0";
  if (GAME_VERSION === "xbox") {
    // use appxmanifest.xml for Xbox version
    try {
      //try to parse appxmanifest.xml
      const appManifest = await fsp.readFile(path.join(gamePath, APPMANIFEST_FILE), "utf8");
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  if (exeHasGameVersion) {
    try {
      return await getExeProductVersion(READ_FILE);
    } catch (err) {
      log("error", `Could not read ${READ_FILE} file to get game version: ${err}`);
    }
  }
  const storeVersion = await resolveStoreVersion(gamePath);
  if (storeVersion !== undefined) return storeVersion;
  const hashVersion = await resolveHashVersion(gamePath);
  if (hashVersion !== undefined) return hashVersion;
  //last resort: exe ProductVersion (UE engine version), then "0.0.0". Never throw.
  try {
    version = await getExeProductVersion(READ_FILE);
    return version;
  } catch (err) {
    log("error", `Could not read ${READ_FILE} file to get game version: ${err}`);
    return version;
  }
}

async function modFoldersEnsureWritable(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    await vfs.ensureDirWritableAsync(path.join(gamePath, relPaths[index]));
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, gameSpec.game.id);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, gameSpec.game.id);
  CHECK_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
  if (configSaveMatch) {
    CHECK_SAVE = CHECK_CONFIG;
  } else {
    CHECK_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
  }
  if (!CHECK_CONFIG || !CHECK_SAVE) {
    partitionCheckNotify(api, CHECK_CONFIG, CHECK_SAVE);
  }
  if (setupNotification) {
    setupNotify(api);
  }
  // ASYNC CODE ///////////////////////////////////
  GAME_VERSION = await setGameVersionAsync(GAME_PATH);
  setProjectFolder(GAME_VERSION === "xbox" ? XBOX_CODE_NAME : EPIC_CODE_NAME); //KEEPER ONLY: the folder checks below must never create a stray project folder
  if (CHECK_CONFIG) {
    //if game, staging folder, and config and save folders are on the same drive
    await vfs.ensureDirWritableAsync(CONFIG_PATH);
    if (SAVE_COMPAT_VERSIONS.includes(GAME_VERSION)) {
      if (configSaveMatch) {
        await vfs.ensureDirWritableAsync(SAVE_PATH);
      }
    }
  } //*/
  if (!configSaveMatch) {
    if (CHECK_SAVE) {
      //if game, staging folder, and config and save folders are on the same drive
      await vfs.ensureDirWritableAsync(SAVE_PATH);
    }
  }
  if (ue4ssLoadOrder && autoDownloadUe4ss) {
    if (UE4SS_PAGE_NO !== 0) {
      await downloadUe4ssNexus(api, gameSpec);
    } else {
      await downloadUe4ss(api, gameSpec);
    }
  } //*/
  if (SIGBYPASS_REQUIRED === true) {
    await downloadSigBypass(api, gameSpec);
  }
  if (ue4ssLoadOrder) {
    MODTYPE_FOLDERS.push(SCRIPTS_PATH);
    if (logicModsLoadOrder) {
      MODTYPE_FOLDERS.push(path.join(SCRIPTS_PATH, BPML_FOLDER));
    }
  }
  MODTYPE_FOLDERS.push(BINARIES_PATH);
  return modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
}

//* Get ModKit install path with GameStoreHelper
async function getModKitPath() {
  let game = undefined;
  try {
    game = await util.GameStoreHelper.findByAppId(MODKITAPP_ID, "epic");
  } catch {
    //log('warn', `ModKit path not found`);
    return undefined;
  }
  if (game === undefined) {
    //log('warn', `ModKit path not found`);
    return undefined;
  }
  let instPath = game.gamePath;
  log("warn", `ModKit path found at ${instPath}`);
  instPath = path.join(instPath, MODKIT_FOLDER);
  return instPath;
} //*/

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register the game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    getGameVersion: resolveGameVersion,
    supportedTools: [
      {
        id: `${GAME_ID}-customlaunch`,
        name: `Custom Launch`,
        logo: `exec.png`,
        executable: () => EXEC,
        requiredFiles: [EXEC],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        //parameters: [],
      }, //*/
      {
        id: `${GAME_ID}-customlaunchxbox`,
        name: `Custom Launch (Xbox)`,
        logo: `exec.png`,
        executable: () => EXEC_XBOX,
        requiredFiles: [EXEC_XBOX],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        //parameters: [],
      }, //*/
      /*{
        id: SAVE_EDITOR_ID,
        name: SAVE_EDITOR_NAME,
        logo: `saveeditor.png`,
        queryPath: getBinariesFolder,
        executable: () => SAVE_EDITOR_EXEC,
        requiredFiles: [SAVE_EDITOR_EXEC],
        detach: true,
        relative: true,
        exclusive: true,
        //shell: true,
        //parameters: [],
      }, //*/
      /*
      {
        id: MODKIT_ID,
        name: MODKIT_NAME,
        logo: `modkit.png`,
        queryPath: async () => await getModKitPath(),
        //queryPath: () => getModKitPathReg(),
        executable: () => MODKIT_EXEC_NAME,
        requiredFiles: [MODKIT_EXEC_NAME],
        detach: true,
        relative: false,
        exclusive: false,
        //parameters: [],
      }, //*/
    ],
  };
  context.registerGame(game);

  //register mod types recursively (types that are always the same)
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //Pak modType
  context.registerModType(
    UE5_SORTABLE_ID,
    25,
    (gameId) => {
      var _a;
      return (
        gameId === GAME_ID &&
        !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
        _a === void 0
          ? void 0
          : _a.path)
      );
    },
    (game) => pathPattern(context.api, game, path.join("{gamePath}", UNREALDATA.modsPath)),
    () => Promise.resolve(false),
    {
      name: UE5_SORTABLE_NAME,
      mergeMods: (mod) => {
        if (UNREALDATA.loadOrder === true) {
          return loadOrderPrefix(context.api, mod) + mod.id;
        } else {
          //If load order is disabled, don't use sorting folders
          return "";
        }
      }, //*/
    },
  );

  //register mod types explicitly (due to potentially dynamic Binaries folder)
  if (ue4ssLoadOrder) {
    context.registerModType(
      SCRIPTS_ID,
      50,
      (gameId) => {
        var _a;
        return (
          gameId === GAME_ID &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, path.join("{gamePath}", SCRIPTS_PATH)),
      () => Promise.resolve(false),
      { name: SCRIPTS_NAME },
    );
    context.registerModType(
      DLL_ID,
      52,
      (gameId) => {
        var _a;
        return (
          gameId === GAME_ID &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, path.join("{gamePath}", SCRIPTS_PATH)),
      () => Promise.resolve(false),
      { name: DLL_NAME },
    );
  }
  context.registerModType(
    BINARIES_ID,
    54,
    (gameId) => {
      var _a;
      return (
        gameId === GAME_ID &&
        !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
        _a === void 0
          ? void 0
          : _a.path)
      );
    },
    (game) => pathPattern(context.api, game, path.join("{gamePath}", BINARIES_PATH)),
    () => Promise.resolve(false),
    { name: BINARIES_NAME },
  );
  if (ue4ssLoadOrder) {
    context.registerModType(
      UE4SS_ID,
      56,
      (gameId) => {
        var _a;
        return (
          gameId === GAME_ID &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, path.join("{gamePath}", BINARIES_PATH)),
      () => Promise.resolve(false),
      { name: UE4SS_NAME },
    );
  }

  //register sigbypass modtype
  if (SIGBYPASS_REQUIRED === true) {
    context.registerModType(
      SIGBYPASS_ID,
      58,
      (gameId) => {
        var _a;
        return (
          gameId === GAME_ID &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, path.join("{gamePath}", BINARIES_PATH)),
      () => Promise.resolve(false),
      { name: SIGBYPASS_NAME },
    );
  }

  //* register modtypes with partition checks
  context.registerModType(
    CONFIG_ID,
    62,
    (gameId) => {
      GAME_PATH = getDiscoveryPath(context.api);
      if (GAME_PATH !== undefined) {
        CHECK_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
      }
      return gameId === GAME_ID && CHECK_CONFIG === true;
    },
    (game) => pathPattern(context.api, game, CONFIG_PATH),
    () => Promise.resolve(false),
    { name: CONFIG_NAME },
  ); //*/
  context.registerModType(
    SAVE_ID,
    64,
    (gameId) => {
      GAME_PATH = getDiscoveryPath(context.api);
      GAME_VERSION = setGameVersionSync(GAME_PATH);
      if (GAME_PATH !== undefined) {
        if (configSaveMatch) {
          CHECK_SAVE = CHECK_CONFIG;
        } else {
          CHECK_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
        }
      }
      return (
        gameId === GAME_ID && CHECK_SAVE === true && SAVE_COMPAT_VERSIONS.includes(GAME_VERSION)
      );
    },
    (game) => pathPattern(context.api, game, SAVE_PATH),
    () => Promise.resolve(false),
    { name: SAVE_NAME },
  ); //*/

  //register mod installers
  if (hasModKit === true) {
    context.registerInstaller(MODKITMOD_ID, 25, testModKitMod, installModKitMod);
  }
  context.registerInstaller(UE4SSCOMBO_ID, 26, testUe4ssCombo, installUe4ssCombo); //not gated on ue4ssLoadOrder - also handles mods with both Binaries and Content folders that are not for UE4SS
  if (ue4ssLoadOrder) {
    context.registerInstaller(LOGICMODS_ID, 27, testLogic, installLogic);
  }
  context.registerInstaller(UE5_SORTABLE_ID, 29, testPak, (files) =>
    installPak(context.api, files),
  ); //Pak installer
  if (ue4ssLoadOrder) {
    context.registerInstaller(UE4SS_ID, 31, testUe4ss, installUe4ss);
  }
  if (SIGBYPASS_REQUIRED === true) {
    context.registerInstaller(SIGBYPASS_ID, 33, testSigBypass, installSigBypass);
  }
  if (ue4ssLoadOrder) {
    context.registerInstaller(SCRIPTS_ID, 35, testScripts, (files, fileName) =>
      installScripts(context.api, files, fileName),
    );
    context.registerInstaller(DLL_ID, 37, testDll, (files, fileName) =>
      installDll(context.api, files, fileName),
    );
  }
  context.registerInstaller(ROOT_ID, 39, testRoot, installRoot);
  context.registerInstaller(CONFIG_ID, 41, testConfig, (files) =>
    installConfig(context.api, files),
  );
  context.registerInstaller(SAVE_ID, 43, testSave, (files) => installSave(context.api, files));
  context.registerInstaller(BINARIES_ID, 49, testBinaries, (files, fileName) =>
    installBinaries(context.api, files, fileName),
  );

  //register actions
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Paks Folder",
    () => {
      GAME_PATH = getDiscoveryPath(context.api);
      try {
        window.api.shell.openFile(path.join(GAME_PATH, PAK_ALT_PATH));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Binaries Folder",
    () => {
      GAME_PATH = getDiscoveryPath(context.api);
      try {
        window.api.shell.openFile(path.join(GAME_PATH, BINARIES_PATH));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  if (ue4ssLoadOrder) {
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Open UE4SS Mods Folder",
      () => {
        GAME_PATH = getDiscoveryPath(context.api);
        try {
          window.api.shell.openFile(path.join(GAME_PATH, SCRIPTS_PATH));
        } catch (err) {
          context.api.showErrorNotification("Failed to open the file or folder", err, {
            allowReport: false,
          });
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Open LogicMods Folder",
      () => {
        GAME_PATH = getDiscoveryPath(context.api);
        try {
          window.api.shell.openFile(path.join(GAME_PATH, LOGICMODS_PATH, LOGICMODS_FOLDER));
        } catch (err) {
          context.api.showErrorNotification("Failed to open the file or folder", err, {
            allowReport: false,
          });
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
  }
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Config Folder",
    async () => {
      //CONFIG_PATH = await setConfigPath(GAME_VERSION);
      try {
        window.api.shell.openFile(CONFIG_PATH);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Saves Folder",
    async () => {
      //SAVE_PATH = await setSavePath();
      try {
        window.api.shell.openFile(SAVE_PATH);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  if (ue4ssLoadOrder) {
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Download UE4SS",
      () => {
        if (UE4SS_PAGE_NO !== 0) {
          //download from Nexus if the page exists
          downloadUe4ssNexus(context.api, gameSpec);
        } else {
          downloadUe4ss(context.api, gameSpec, false);
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Open UE4SS Settings INI",
      () => {
        GAME_PATH = getDiscoveryPath(context.api);
        try {
          window.api.shell.openFile(path.join(GAME_PATH, BINARIES_PATH, UE4SS_SETTINGS_FILEPATH));
        } catch (err) {
          context.api.showErrorNotification("Failed to open the file or folder", err, {
            allowReport: false,
          });
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Open UE4SS mods.txt",
      () => {
        GAME_PATH = getDiscoveryPath(context.api);
        try {
          window.api.shell.openFile(path.join(GAME_PATH, BINARIES_PATH, UE4SS_MODSTXT_FILEPATH));
        } catch (err) {
          context.api.showErrorNotification("Failed to open the file or folder", err, {
            allowReport: false,
          });
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
  }
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Nexus Mods Page",
    () => {
      try {
        window.api.shell.openUrl(`https://www.nexusmods.com/${GAME_ID}/mods`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open SteamDB Page",
    () => {
      try {
        window.api.shell.openUrl(STEAMDB_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      try {
        window.api.shell.openFile(path.join(__dirname, "CHANGELOG.md"));
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      try {
        window.api.shell.openUrl(`${EXTENSION_URL}?tab=bugs`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      try {
        window.api.shell.openFile(DOWNLOAD_FOLDER);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
}

//Main function
function main(context) {
  applyGame(context, spec);
  if (UNREALDATA.loadOrder === true) {
    //UNREAL - mod load order
    if (FBLO) {
      context.registerLoadOrder({
        gameId: spec.game.id,
        validate: async () => Promise.resolve(undefined), // no validation implemented yet
        deserializeLoadOrder: async () => await deserializeLoadOrder(context),
        serializeLoadOrder: async (loadOrder) => await serializeLoadOrder(context, loadOrder),
        toggleableEntries: false,
        usageInstructions: LoadOrderInstructions,
        customItemRenderer: LoadOrderItemRenderer,
      }); //*/
    } else {
      //legacy Load Order
      let previousLO;
      context.registerLoadOrderPage({
        gameId: spec.game.id,
        gameArtURL: path.join(__dirname, spec.game.logo),
        preSort: (items, direction) => preSort(context.api, items, direction),
        filter: (mods) => mods.filter((mod) => mod.type === UE5_SORTABLE_ID),
        displayCheckboxes: false,
        callback: (loadOrder) => {
          if (previousLO === undefined) previousLO = loadOrder;
          if (loadOrder === previousLO) return;
          requestDeployment(context.api, spec);
          previousLO = loadOrder;
        },
        createInfoPanel: () =>
          context.api.translate(
            `Drag and drop the mods on the left to change the order in which they load.\n` +
              `${spec.game.name} loads mods in alphanumerical order, so Vortex prefixes the folder names with "AAA, AAB, AAC, ..." to ensure they load in the order you set here.\n` +
              "The number in the left column represents the overwrite order. The changes from mods with higher numbers will take priority over other mods which make similar edits.\n" +
              "\n" +
              "YOU MUST DEPLOY MODS AFTER CHANGING THE ORDER TO APPLY CHANGES.",
          ),
      }); //*/
    }
  }
  if (ue4ssLoadOrder) {
    context.registerReducer(["settings", GAME_ID], {
      reducers: {
        [setUe4ssLoEnabled.toString()]: (state, payload) => ({ ...state, ue4ssLoEnabled: payload }),
      },
      defaults: { ue4ssLoEnabled: true },
    });
    context.registerSettings(
      "Mods",
      GameSettings,
      () => ({}),
      () => selectors.activeGameId(context.api.getState()) === GAME_ID,
      150,
    );
    context.registerReducer(["persistent", "ue4ssLoadOrder"], {
      reducers: {
        [setUe4ssLoadOrder.toString()]: (state, payload) => ({
          ...state,
          [payload.profileId]: { ...state[payload.profileId], loadOrder: payload.loadOrder },
        }),
      },
      defaults: {},
    });
    context.registerMainPage("unreal", "UE4SS Load Order", Ue4ssLoadOrderPage, {
      id: `${GAME_ID}-ue4ss-loadorder`,
      priority: 31,
      group: "per-game",
      hotkey: "U",
      mdi: UE4SS_ICON,
      visible: () => {
        const state = context.api.store.getState();
        const gameId = selectors.activeGameId(state);
        //const loEnabled = util.getSafe(state, ['settings', GAME_ID, 'ue4ssLoEnabled'], true);
        return gameId === GAME_ID && ue4ssLoadOrder; //not using loEnabled so that the page is still visible
      },
      props: () => ({ api: context.api }),
    });
  }
  if (collectionsLoadOrder && (ue4ssLoadOrder || logicModsLoadOrder)) {
    context.optional.registerCollectionFeature(
      `${GAME_ID}_ue4ss_collection_data`,
      (gameId, includedMods) => genUe4ssCollectionsData(context.api, gameId, includedMods),
      (gameId, collection) => parseUe4ssCollectionsData(context.api, gameId, collection),
      () => Promise.resolve(),
      (t) => t("UE4SS Load Orders"),
      (state, gameId) => gameId === GAME_ID,
      CollectionsDataView,
    );
  }
  if (logicModsLoadOrder) {
    context.registerReducer(["persistent", "logicModsLoadOrder"], {
      reducers: {
        [setLogicModsLoadOrder.toString()]: (state, payload) => ({
          ...state,
          [payload.profileId]: { ...state[payload.profileId], loadOrder: payload.loadOrder },
        }),
      },
      defaults: {},
    });
    context.registerMainPage("unreal", "LogicMods Load Order", LogicModsLoadOrderPage, {
      id: `${GAME_ID}-logicmods-loadorder`,
      priority: 32,
      group: "per-game",
      hotkey: "L",
      mdi: BLUEPRINT_ICON,
      visible: () => {
        const state = context.api.store.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID && logicModsLoadOrder;
      },
      props: () => ({ api: context.api }),
    });
  }
  context.once(() => {
    // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    api.onAsync("check-mods-version", (gameId, mods, forced) => {
      //UE4SS_PAGE_NO !== 0 means this game installs UE4SS from its own Nexus page, and the
      //update notification's Download action installs from GitHub - so an ungated check would
      //quietly replace that curated copy with an upstream build. ue4ssLoadOrder is the master
      //UE4SS toggle, and a live update check is a UE4SS surface like any other.
      if (gameId !== GAME_ID || UE4SS_PAGE_NO !== 0 || !ue4ssLoadOrder) {
        return Promise.resolve();
      }
      return onCheckModVersion(api, gameId, mods, forced);
    });
    api.onAsync("did-deploy", (profileId) => didDeploy(api, profileId)); //*/
    //api.onAsync('did-purge', (profileId) => didPurge(api, profileId)); //*/
    //detect mod update (to maintain LO position)
    //fileId is the version being updated TO, and is what tells the new version apart from the
    //old one on deploy - without it every mod not yet updated still looks "already installed"
    api.events.on("mod-update", (gameId, modId, fileId) => {
      if (GAME_ID === gameId) {
        updateModIds.set(String(modId), {
          firstSeen: Date.now(),
          targetFileId: String(fileId ?? ""),
        });
      }
    });
    //detect batch mod update: the "Update all" button emits mods-update with LOCAL mod ids
    //and never emits mod-update, so resolve each one to its Nexus mod id before tracking it
    api.events.on("mods-update", (gameId, modIds) => {
      if (GAME_ID !== gameId) return;
      const mods = api.getState()?.persistent?.mods?.[GAME_ID] ?? {};
      for (const modId of modIds ?? []) {
        const nexusModId = mods[modId]?.attributes?.modId;
        if (nexusModId !== undefined) {
          updateModIds.set(String(nexusModId), {
            firstSeen: Date.now(),
            targetFileId: String(mods[modId]?.attributes?.newestFileId ?? ""),
          });
        }
      }
    });
    //detect mod removal (to maintain LO position) - match on the Nexus mod id
    //recorded in state (attributes.modId), not the local modId string: the
    //local id's naming convention varies by when the mod was originally
    //downloaded (older dash-delimited vs current space-delimited), so string
    //parsing silently misses old installs.
    api.events.on("remove-mod", (gameMode, modId) => {
      const removedMod = api.getState()?.persistent?.mods?.[GAME_ID]?.[modId] ?? undefined;
      const nexusModId = removedMod?.attributes?.modId;
      if (nexusModId !== undefined && updateModIds.has(String(nexusModId))) {
        mod_update_all_profile = true;
      }
    });
    //detect mod installation (to maintain LO position). This only gates the
    //fallback-installer re-notify suppression, so a best-effort filename
    //match (covering both the old dash and current space delimiter) is fine.
    api.events.on("will-install-mod", (gameId, archiveId, modId) => {
      updating_mod =
        GAME_ID === gameId &&
        Array.from(updateModIds.keys()).some(
          (id) => modId.includes("-" + id + "-") || modId.includes(" " + id + " "),
        );
    });
    //Retag a FOMOD-installed plain pak mod as the sortable pak modtype so it shows up on
    //the Load Order page - see retagFomodPakMod() for why this is needed. Covers both a
    //first install and a mod update (did-install-mod fires for both).
    api.events.on("did-install-mod", (gameId, archiveId, modId) => {
      retagFomodPakMod(api, gameId, modId).catch((err) =>
        log("warn", `[${GAME_ID}] retagFomodPakMod failed for "${modId}"`, err),
      );
    });
  });
  return true;
}

const requestDeployment = (api, spec) => {
  api.store.dispatch(actions.setDeploymentNecessary(spec.game.id, true));
  api.sendNotification({
    id: `${spec.game.id}-loadorderdeploy-notif`,
    type: "warning",
    message: "Deployment Required to Apply Load Order Changes",
    allowSuppress: true,
    actions: [
      {
        title: "Deploy",
        action: (dismiss) => {
          deploy(api);
          dismiss();
        },
      },
    ],
  });
};

//FOMOD's built-in installer (and the generic basicInstaller fallback) never emit a
//`setmodtype` instruction, so a mod they hand off keeps modtype '' forever - and
//deserializeLoadOrder() above only ever pulls in enabled mods whose type is exactly
//UE5_SORTABLE_ID. That's the entire reason a FOMOD-packaged pak mod (e.g. one built with
//a checkbox wizard picking between pak variants) never shows up on the Load Order page:
//it was never tagged as a sortable pak mod in the first place. did-install-mod fires after
//Vortex's own processSetModType step has already run, so mod.type here is final for this
//install - retag it here if it looks like a plain pak mod that just happened to go through
//FOMOD instead of this extension's own testPak/installPak.
async function retagFomodPakMod(api, gameId, modId) {
  if (gameId !== GAME_ID || !PAKMOD_LOADORDER) return;
  const mod = api.getState()?.persistent?.mods?.[GAME_ID]?.[modId] ?? undefined;
  //Non-empty type means one of this extension's own installers already classified it
  //correctly (or a previous run of this same handler already fixed it) - strict no-op for
  //every mod that didn't go through FOMOD/basicInstaller, so normal installs can't regress.
  if (mod === undefined || !!mod.type) return;
  const stagingFolder = getModStagingFolder(api, modId);
  if (!stagingFolder) return;
  //Relative to the staging folder: beatsPakInstaller matches path segments, and the staging
  //root's own segments are not part of the mod (see the note on that function).
  const files = (await getAllFiles(stagingFolder)).map((file) =>
    path.relative(stagingFolder, file),
  );
  const fileExt = UNREALDATA.fileExt;
  const pakFiles = files.filter((file) => fileExt.includes(path.extname(file).toLowerCase()));
  if (pakFiles.length === 0 || beatsPakInstaller(files)) return;
  //installPak() flattens an archive down to just the pak-type files at the staging root, so
  //retagging only reproduces what it would have done when the FOMOD staged its paks shallowly
  //too. A mod staged in full game-root layout would deploy to a nested path this extension
  //never produces itself - leave those with the empty type they already had rather than list
  //them on the Load Order page implying they are sorted correctly.
  const stagedAsGameRoot = pakFiles.some((file) =>
    pathSegments([path.dirname(file)]).some(
      (seg) => seg.toLowerCase() === ROOT_FOLDER.toLowerCase(),
    ),
  );
  if (stagedAsGameRoot) return;
  api.store.dispatch(actions.setModType(GAME_ID, modId, UE5_SORTABLE_ID));
  if (debug)
    log(
      "debug",
      `[${GAME_ID}] retagged FOMOD-installed mod "${modId}" as ${UE5_SORTABLE_ID} so it shows up on the Load Order page`,
    );
  //The retag above has to happen unconditionally - it touches no load order state, and a
  //collection-installed FOMOD pak mod needs it just as much as a manually installed one. Only
  //the refresh and the deployment request below are skipped mid-collection-install: core's
  //file_based_loadorder skips every one of its own load triggers while installing_dependencies
  //is non-empty, and the did-deploy at the end of the collection install re-deserializes anyway
  //- by then with the type set here. (This key is core activity state; this extension never
  //sets it.)
  const state = api.getState();
  const installingDependencies = state?.session?.base?.activity?.installing_dependencies ?? [];
  if (
    Array.isArray(installingDependencies)
      ? installingDependencies.length > 0
      : !!installingDependencies
  )
    return;
  //deserializeLoadOrder builds its result from selectors.activeProfile (via generateProps), so
  //resolve the profile the same way here: installing a mod for this game while a different game
  //is active would otherwise have us dispatch against a profile the deserialize never saw.
  const profile = selectors.activeProfile(state);
  if (profile?.gameId !== GAME_ID) return;
  //The core file_based_loadorder extension already deserialized before this handler ran (it
  //registers first and did-install-mod listeners run concurrently), so it read the mod's old
  //(empty) type. Re-read it ourselves now that the type is fixed and push the result into
  //state - same pattern didDeploy() above uses after its own update guard clears.
  try {
    const refreshedLO = await deserializeLoadOrder({ api });
    //did-install-mod is emitted right after setModsEnabled, which awaits will-enable-mods before
    //the mod lands in profile.modState - so an extension with a slow handler there can leave the
    //mod still disabled at this point, and deserializeLoadOrder filters strictly on enabled mods.
    //Dispatching that result would drop the mod from the order and deploy it under a ZZZZ- prefix
    //until the next deserialize, so leave the stored order alone and let that next one pick it up.
    if (refreshedLO.some((entry) => entry.id === modId)) {
      api.store.dispatch(actions.setFBLoadOrder(profile.id, refreshedLO));
    }
  } catch (err) {
    log("warn", `[${GAME_ID}] load order refresh after retagging "${modId}" failed`, err);
  }
  requestDeployment(api, spec);
}

async function didDeploy(api, profileId) {
  //run on mod deploy
  const state = api.getState();
  const profile = selectors.profileById(state, profileId);
  const gameId = profile === null || profile === void 0 ? void 0 : profile.gameId;
  if (gameId !== GAME_ID) {
    return Promise.resolve();
  }
  //release tracking one mod id at a time, and only once that mod's new version has landed
  //and is enabled, so a deploy that fires mid-batch can't disarm the guard for mods that
  //haven't been reinstalled yet. Must stay above the UE4SS/LogicMods blocks below, which
  //rewrite their order files from whatever is on disk at this moment.
  //guard state as it stood before the loop below releases it - the FBLO refresh further
  //down only runs on the deploy that actually clears the guard
  const guardWasArmed = mod_update_all_profile;
  if (updateModIds.size > 0) {
    const mods = state?.persistent?.mods?.[GAME_ID] ?? {};
    const now = Date.now();
    for (const [nexusId, { firstSeen, targetFileId }] of Array.from(updateModIds)) {
      const landed = Object.values(mods).some(
        (mod) =>
          String(mod?.attributes?.modId ?? "") === nexusId &&
          //if the target file is unknown, fall back to "installed and enabled"
          (targetFileId === "" || String(mod?.attributes?.fileId ?? "") === targetFileId) &&
          (profile?.modState?.[mod.id]?.enabled ?? false),
      );
      if (landed) {
        updateModIds.delete(nexusId);
      } else if (now - firstSeen > MAX_UPDATE_WAIT_MS) {
        log(
          "warn",
          `[${GAME_ID}] Mod update tracking for Nexus mod ${nexusId} timed out without landing; releasing load order guard for it.`,
        );
        updateModIds.delete(nexusId);
      }
    }
  }
  mod_update_all_profile = updateModIds.size > 0; //stay armed while any update is still outstanding
  //Core FBLO deserialized this order concurrently with this handler - did-deploy listeners run
  //in parallel and the core one is registered first - so it read the frozen order before the
  //guard cleared above, leaving its page stale. Re-run the deserialize it would have got and
  //push the result into state; cheaper and less disruptive than forcing a second deployment.
  if (guardWasArmed && !mod_update_all_profile) {
    try {
      const refreshedLO = await deserializeLoadOrder({ api });
      api.store.dispatch(actions.setFBLoadOrder(profileId, refreshedLO));
    } catch (err) {
      log("warn", `[${GAME_ID}] post-update load order refresh failed`, err);
    }
  }
  updating_mod = false; //reset updating flag on deploy
  if (ue4ssLoadOrder && isUe4ssInstalled(api, spec)) {
    const loEnabled = state?.settings?.[GAME_ID]?.ue4ssLoEnabled ?? true;
    if (loEnabled) {
      let UE4SS_LOAD_ORDER;
      try {
        UE4SS_LOAD_ORDER = await deserializeUe4ss(api);
        api.store.dispatch(setUe4ssLoadOrder(profileId, UE4SS_LOAD_ORDER));
      } catch (err) {
        log(
          "error",
          `[${GAME_ID}] didDeploy: deserializeUe4ss failed, falling back to store state`,
          err,
        );
        UE4SS_LOAD_ORDER = state?.persistent?.ue4ssLoadOrder?.[profileId]?.loadOrder ?? [];
      }
      if (UE4SS_LOAD_ORDER.length > 0) {
        await serializeUe4ss(api, UE4SS_LOAD_ORDER);
      }
    }
  }
  if (logicModsLoadOrder && isUe4ssInstalled(api, spec)) {
    let LO;
    try {
      LO = await deserializeLogicMods(api);
      api.store.dispatch(setLogicModsLoadOrder(profileId, LO));
    } catch (err) {
      log(
        "error",
        `[${GAME_ID}] didDeploy: deserializeLogicMods failed, falling back to store state`,
        err,
      );
      LO = state?.persistent?.logicModsLoadOrder?.[profileId]?.loadOrder ?? [];
    }
    if (LO.length > 0) {
      await serializeLogicMods(api, LO);
    }
  }
  if (writeEngineVersion && isUe4ssInstalled(api, spec)) {
    try {
      GAME_PATH = getDiscoveryPath(api);
      const INI_PATH = path.join(GAME_PATH, BINARIES_PATH, UE4SS_SETTINGS_FILEPATH);
      await fsp.stat(INI_PATH); //check if UE4SS settings file exists
      let engineMajor = MAJOR_VERSION;
      let engineMinor = MINOR_VERSION;
      try {
        //try to read the real engine version from the shipping exe file properties first
        const exeVersion = require("exe-version");
        const exeProductVersion = await exeVersion.getProductVersion(
          path.join(GAME_PATH, SHIPPING_EXE),
        );
        const [exeMajor, exeMinor] = exeProductVersion.split(".");
        if (exeMajor && exeMinor) {
          engineMajor = exeMajor;
          engineMinor = exeMinor;
        }
      } catch (err) {
        log(
          "info",
          `[${GAME_ID}] Could not read engine version from shipping exe, falling back to ENGINE_VERSION constant: ${err.message}`,
        );
      }
      const parser = new IniParser(new WinapiFormat());
      const contents = await parser.read(INI_PATH);
      const data = contents.data;
      data.EngineVersionOverride.MajorVersion = ` ${engineMajor}`; // Set the UE Engine version
      data.EngineVersionOverride.MinorVersion = ` ${engineMinor}`;
      //data.EngineVersionOverride.DebugBuild = ` 0`;
      await parser.write(INI_PATH, contents); //write the INI file
    } catch (err) {
      log(
        "info",
        `[${GAME_ID}] Failed to read UE4SS Settings INI file and write Engine Version: ${err.message}`,
      );
    }
  }
  api.dismissNotification(`${GAME_ID}-loadorderdeploy-notif`);
  return Promise.resolve();
}

async function didPurge(api, profileId) {
  //run on mod purge
  const state = api.getState();
  const profile = selectors.profileById(state, profileId);
  const gameId = profile === null || profile === void 0 ? void 0 : profile.gameId;
  if (gameId !== GAME_ID) {
    return Promise.resolve();
  }

  return Promise.resolve();
}

//React load order instructions renderer
function LoadOrderInstructions() {
  const { statusFilter, setStatusFilter } = usePakLOState();
  const { useSelector } = require("react-redux");
  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) => state?.persistent?.loadOrder?.[profile?.id] ?? []);
  const modState = useSelector(
    (state) => state?.persistent?.profiles?.[profile?.id]?.modState ?? {},
  );
  const isLocked = (entry) => [true, "true", "always"].includes(entry?.locked);
  const isEnabled = (entry) => modState?.[entry.modId]?.enabled ?? false;
  // Count entries matching the active filter (matched / total), shown beside the pills.
  const total = loadOrder.length;
  const matched =
    statusFilter.size > 0
      ? loadOrder.filter((e) => matchesStatus(e, statusFilter, isEnabled, isLocked)).length
      : total;
  useInjectStyleOnce("fblo-status-filter-hide-style", LO_ROW_HIDDEN_CSS);
  return React.createElement(
    "div",
    null,
    React.createElement(StatusPills, {
      active: statusFilter,
      setActive: setStatusFilter,
      groups: ["enabled", "locked", "unmanaged"],
      count: statusFilter.size > 0 ? { matched, total } : null,
    }),
    React.createElement(
      "p",
      { style: { fontStyle: "italic", color: "#7ec8e3" } },
      "Filter the list above by status. Clear the filter before reordering mods.",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      null,
      "Drag and drop the mods on the left to change the order in which they load. ",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      null,
      `${GAME_NAME_SHORT} loads mods in alphanumerical order, so Vortex prefixes the folder `,
      'names with "AAA, AAB, AAC, ..." to ensure they load in the order you set here. ',
      "The number in the left column represents the overwrite order. Changes from ",
      "mods with higher numbers take priority over mods that make similar edits.",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      { style: { fontWeight: "bold", color: "#7ec8e3" } },
      "The Enable/Disable button on each row enables or disables the underlying Vortex mod. ",
      "Disabling a mod here will remove it from this view and disable it on the Mods tab. ",
      "Re-enabling it on the Mods tab will restore it to the load order.",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      { style: { fontWeight: "bold" } },
      "YOU MUST DEPLOY MODS AFTER CHANGING THE ORDER TO APPLY CHANGES! ",
      "- This is required to rename the folders for the correct order.",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      { style: { fontStyle: "italic", color: "yellow", fontWeight: "bold" } },
      "Note: This page manages Pak mods only. UE4SS mod load order is managed on the UE4SS Load Order page.",
    ),
    React.createElement("br", null),
    React.createElement(
      "p",
      { style: { color: "yellow", fontWeight: "bold" } },
      SPECIAL_LO_INSTRUCTIONS,
    ),
  );
}

//* PAK LO selection + context menu + status filter state (module-level pub-sub, shared across all item renderer instances)
let _pakSelectedIds = new Set();
let _pakContextMenu = null;
let _pakStatusFilter = new Set();
const _pakListeners = new Set();
function _notifyPak() {
  _pakListeners.forEach((l) => l());
}
function usePakLOState() {
  const [, forceUpdate] = React.useReducer((x) => x + 1, 0);
  React.useEffect(() => {
    _pakListeners.add(forceUpdate);
    return () => _pakListeners.delete(forceUpdate);
  }, []);
  return {
    selectedIds: _pakSelectedIds,
    setSelectedIds: (fn) => {
      _pakSelectedIds = fn(_pakSelectedIds);
      _notifyPak();
    },
    contextMenu: _pakContextMenu,
    setContextMenu: (val) => {
      _pakContextMenu = val;
      _notifyPak();
    },
    statusFilter: _pakStatusFilter,
    setStatusFilter: (next) => {
      _pakStatusFilter = next;
      _notifyPak();
    },
  };
}

//Resolve the mod page URL for a Vortex-managed load order entry (undefined when not resolvable).
//Prefers the mod's homepage attribute; falls back to composing the Nexus URL from the numeric mod id.
function getModPageURL(api, vortexModId) {
  if (vortexModId === undefined) return undefined;
  const attributes = api.getState()?.persistent?.mods?.[GAME_ID]?.[vortexModId]?.attributes ?? {};
  if (attributes.homepage) return attributes.homepage;
  if (attributes.source === "nexus" && attributes.modId !== undefined) {
    return `https://www.nexusmods.com/${GAME_ID}/mods/${attributes.modId}`;
  }
  return undefined;
}

//Resolve the staging folder of a Vortex-managed load order entry (undefined when not resolvable)
function getModStagingFolder(api, vortexModId) {
  if (vortexModId === undefined) return undefined;
  const state = api.getState();
  const installationPath =
    state?.persistent?.mods?.[GAME_ID]?.[vortexModId]?.installationPath ?? undefined;
  const stagingPath = selectors.installPathForGame(state, GAME_ID);
  if (!installationPath || !stagingPath) return undefined;
  return path.join(stagingPath, installationPath);
}

//Status filter shared helpers (load order pages). Groups combine with AND across, OR within.
const STATUS_GROUP_TOKENS = {
  enabled: ["enabled", "disabled"],
  locked: ["locked", "unlocked"],
  unmanaged: ["unmanaged"],
};
const STATUS_TOKEN_LABELS = {
  enabled: "Enabled",
  disabled: "Disabled",
  locked: "Locked",
  unlocked: "Unlocked",
  unmanaged: "Unmanaged",
};

function matchesStatus(entry, active, isEnabledFn, isLockedFn) {
  if (active.has("enabled") || active.has("disabled")) {
    const en = isEnabledFn(entry);
    if (!((active.has("enabled") && en) || (active.has("disabled") && !en))) return false;
  }
  if (active.has("locked") || active.has("unlocked")) {
    const lk = isLockedFn(entry);
    if (!((active.has("locked") && lk) || (active.has("unlocked") && !lk))) return false;
  }
  if (active.has("unmanaged") && entry.modId !== undefined) return false;
  return true;
}

//Style blocks injected by the load order surfaces (see useInjectStyleOnce below)
const LO_INDEX_FOCUS_CSS =
  ".load-order-index input:focus { background: white !important; color: black !important; } .layout-flex.file-based-load-order-list-outer { overflow: auto; }";
const LO_ROW_HIDDEN_CSS =
  ".file-based-load-order-list .list-group > div:has(.lo-row-hidden) { display: none !important; }";
const LO_CTX_MENU_CSS = ".ue4ss-ctx-item:hover { background: rgba(255,255,255,0.1); }";

//Extensions cannot ship CSS, so a component injects its styles into the document head on mount.
//Guarded by a fixed id, so repeated mounts (every row, every page visit) never duplicate the block.
function useInjectStyleOnce(styleId, css) {
  React.useEffect(() => {
    if (globalThis.document.getElementById(styleId)) return;
    const style = globalThis.document.createElement("style");
    style.id = styleId;
    style.textContent = css;
    globalThis.document.head.appendChild(style);
  }, [styleId, css]);
}

//Shared dismiss behaviour for the context menus: any click or right-click outside closes the menu,
//as does Escape. Menu items call stopPropagation, so their own clicks never reach these listeners.
function useDismissOnOutside(onClose) {
  React.useEffect(() => {
    const dismiss = () => onClose();
    const onKey = (evt) => {
      if (evt.key === "Escape") onClose();
    };
    globalThis.document.addEventListener("click", dismiss);
    globalThis.document.addEventListener("contextmenu", dismiss);
    globalThis.document.addEventListener("keydown", onKey);
    return () => {
      globalThis.document.removeEventListener("click", dismiss);
      globalThis.document.removeEventListener("contextmenu", dismiss);
      globalThis.document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);
}

//Viewport clamp for the context menus. The clamped position is measured once into state and then
//rendered, rather than written onto el.style after the fact - a fresh callback ref every render
//makes React detach and reattach it, and the next render would overwrite the mutated style anyway.
function useClampedMenuPosition(x, y) {
  const [position, setPosition] = React.useState({ left: x, top: y });
  const measureRef = React.useCallback(
    (el) => {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const vw = globalThis.window.innerWidth;
      const vh = globalThis.window.innerHeight;
      const left = x + rect.width > vw ? Math.max(8, vw - rect.width - 8) : x;
      const top = y + rect.height > vh ? Math.max(8, vh - rect.height - 8) : y;
      setPosition((prev) => (prev.left === left && prev.top === top ? prev : { left, top }));
    },
    [x, y],
  );
  return [position, measureRef];
}

//Inline toggle pills for status filtering (used in the InfoPanel surfaces, i.e. the core FBLO page)
function StatusPills({ active, setActive, groups, count }) {
  const { Button } = require("react-bootstrap");
  const tokens = groups.reduce((acc, g) => acc.concat(STATUS_GROUP_TOKENS[g] || []), []);
  const toggle = (token) => {
    const next = new Set(active);
    next.has(token) ? next.delete(token) : next.add(token);
    setActive(next);
  };
  return React.createElement(
    "div",
    { style: { display: "flex", flexWrap: "wrap", gap: 4, alignItems: "center", marginBottom: 8 } },
    React.createElement("span", { style: { fontWeight: "bold", marginRight: 4 } }, "Filter:"),
    count != null
      ? React.createElement(
          "span",
          { style: { color: "#7ec8e3", marginRight: 4 } },
          `${count.matched} / ${count.total}`,
        )
      : null,
    ...tokens.map((token) =>
      React.createElement(
        Button,
        {
          key: token,
          bsSize: "xsmall",
          bsStyle: active.has(token) ? "success" : "default",
          style: active.has(token) ? { fontWeight: "bold" } : undefined,
          onClick: () => toggle(token),
        },
        STATUS_TOKEN_LABELS[token],
      ),
    ),
    active.size > 0
      ? React.createElement(
          Button,
          {
            key: "__clear",
            bsSize: "xsmall",
            bsStyle: "link",
            onClick: () => setActive(new Set()),
          },
          "Clear",
        )
      : null,
  );
}

//Dropdown status filter (used on the custom UE4SS/LogicMods pages, beside the text search box).
//Hand-built (not react-bootstrap Dropdown, which auto-closes on every inner click) - dismiss on
//outside click / contextmenu / Escape, matching the dismiss pattern already used for context menus.
function LoadOrderStatusFilter({ active, setActive, groups, count }) {
  const { Button } = require("react-bootstrap");
  const { Icon } = require("vortex-api");
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  const tokens = groups.reduce((acc, g) => acc.concat(STATUS_GROUP_TOKENS[g] || []), []);

  React.useEffect(() => {
    if (!open) return;
    const dismiss = (evt) => {
      if (ref.current && !ref.current.contains(evt.target)) setOpen(false);
    };
    const onKey = (evt) => {
      if (evt.key === "Escape") setOpen(false);
    };
    globalThis.document.addEventListener("click", dismiss);
    globalThis.document.addEventListener("contextmenu", dismiss);
    globalThis.document.addEventListener("keydown", onKey);
    return () => {
      globalThis.document.removeEventListener("click", dismiss);
      globalThis.document.removeEventListener("contextmenu", dismiss);
      globalThis.document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const toggle = (token) => {
    const next = new Set(active);
    next.has(token) ? next.delete(token) : next.add(token);
    setActive(next);
  };

  return React.createElement(
    "div",
    { ref, style: { position: "relative", display: "inline-block", marginLeft: 8 } },
    React.createElement(
      Button,
      {
        bsStyle: active.size > 0 ? "success" : "primary",
        style: { display: "flex", alignItems: "center", gap: 6, fontWeight: "bold" },
        onClick: (evt) => {
          evt.stopPropagation();
          setOpen((o) => !o);
        },
      },
      React.createElement(Icon, { name: "filter" }),
      `Filter${active.size > 0 ? ` (${active.size})` : ""}${count != null ? ` — ${count.matched}/${count.total}` : ""}`,
    ),
    open
      ? React.createElement(
          "div",
          {
            style: {
              position: "absolute",
              top: "100%",
              right: 0,
              zIndex: 9999,
              marginTop: 2,
              background: "#1e1e1e",
              border: "1px solid rgba(255,255,255,0.2)",
              borderRadius: 4,
              padding: "6px 0",
              minWidth: 160,
              boxShadow: "0 4px 12px rgba(0,0,0,0.6)",
            },
          },
          tokens.map((token) =>
            React.createElement(
              "label",
              {
                key: token,
                style: {
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "4px 12px",
                  cursor: "pointer",
                  margin: 0,
                },
              },
              React.createElement("input", {
                type: "checkbox",
                checked: active.has(token),
                onChange: () => toggle(token),
              }),
              STATUS_TOKEN_LABELS[token],
            ),
          ),
          active.size > 0
            ? React.createElement(
                "div",
                {
                  style: {
                    padding: "4px 12px",
                    cursor: "pointer",
                    color: "#7ec8e3",
                    borderTop: "1px solid rgba(255,255,255,0.1)",
                    marginTop: 4,
                  },
                  onClick: () => setActive(new Set()),
                },
                "Clear",
              )
            : null,
        )
      : null,
  );
}

//* React line item renderer for load order
function LoadOrderItemRenderer(props) {
  const { className, item } = props;
  if (item?.loEntry === undefined) return null;

  const { ListGroupItem, Checkbox } = require("react-bootstrap");
  const { Icon, LoadOrderIndexInput, MainContext } = require("vortex-api");
  const { useSelector, useDispatch } = require("react-redux");

  const context = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) => state?.persistent?.loadOrder?.[profile?.id] ?? []);

  const { loEntry, displayCheckboxes } = item;
  const mods = useSelector((state) => state?.persistent?.mods?.[GAME_ID] ?? {});
  const pictureUrl = mods[loEntry.modId]?.attributes?.pictureUrl;
  //FBLO precomputes these on the item (memoized by its row cache); the fallbacks keep the
  //renderer working if it is ever mounted outside the FBLO page.
  const currentIdx = item.position ?? loadOrder.findIndex((e) => e.id === loEntry.id) + 1;
  const isModEnabled = useSelector(
    (state) =>
      state?.persistent?.profiles?.[profile?.id]?.modState?.[loEntry.modId]?.enabled ?? false,
  );
  const modState = useSelector(
    (state) => state?.persistent?.profiles?.[profile?.id]?.modState ?? {},
  );

  const isLocked = (entry) => [true, "true", "always"].includes(entry?.locked);
  //Core derives the index input's minimum from this and assumes locked entries sit at the top.
  //Only the LEADING locked run blocks row 1 - a lock further down must not raise the floor.
  const firstUnlocked = loadOrder.findIndex((e) => !isLocked(e));
  const leadingLockedCount = firstUnlocked === -1 ? loadOrder.length : firstUnlocked;

  const onApplyIndex = React.useCallback(
    (idx) => {
      if (currentIdx === idx || isLocked(loEntry)) return;
      //Locked entries hold their absolute index - the typed row picks a slot among the unlocked ones
      const bound = idx - 1 + (idx > currentIdx ? 1 : 0);
      const dest = loadOrder.filter(
        (e, i) => !isLocked(e) && e.id !== loEntry.id && i < bound,
      ).length;
      const unlocked = loadOrder.filter((e) => !isLocked(e) && e.id !== loEntry.id);
      unlocked.splice(dest, 0, loEntry);
      let next = 0;
      const newLO = loadOrder.map((e) => (isLocked(e) ? e : unlocked[next++]));
      dispatch(actions.setFBLoadOrder(profile.id, newLO));
    },
    [dispatch, profile, loadOrder, loEntry, currentIdx],
  );

  const onToggle = React.useCallback(
    (evt) => {
      dispatch(
        actions.setFBLoadOrderEntry(profile.id, { ...loEntry, enabled: evt.target.checked }),
      );
    },
    [dispatch, profile, loEntry],
  );

  const onModToggle = React.useCallback(() => {
    if (!loEntry.modId) return;
    actions.setModsEnabled(context.api, profile.id, [loEntry.modId], !isModEnabled, {
      allowAutoDeploy: true,
    });
  }, [profile, loEntry.modId, isModEnabled, context]);

  const isEntryLocked = isLocked(loEntry);

  const { selectedIds, setSelectedIds, contextMenu, setContextMenu, statusFilter } =
    usePakLOState();
  const isSelected = selectedIds.has(loEntry.id);
  //Shift-select must span visible rows only, so build the id list from the status-filtered order.
  //Memoized: a bare filter here would run once per row, i.e. O(n^2) over the whole load order.
  const allIds = React.useMemo(
    () =>
      loadOrder
        .filter((e) =>
          matchesStatus(
            e,
            statusFilter,
            (entry) => modState?.[entry.modId]?.enabled ?? false,
            isLocked,
          ),
        )
        .map((e) => e.id),
    [loadOrder, statusFilter, modState],
  );

  const onSelect = React.useCallback(
    (evt) => {
      const ctrlKey = evt.ctrlKey || evt.metaKey;
      const shiftKey = evt.shiftKey;
      setSelectedIds((prev) => {
        const next = new Set(prev);
        if (ctrlKey) {
          next.has(loEntry.id) ? next.delete(loEntry.id) : next.add(loEntry.id);
        } else if (shiftKey) {
          const lastId = [...prev].at(-1);
          const start = allIds.indexOf(lastId ?? loEntry.id);
          const end = allIds.indexOf(loEntry.id);
          const [lo, hi] = [Math.min(start, end), Math.max(start, end)];
          for (let i = lo; i <= hi; i++) next.add(allIds[i]);
        } else {
          next.clear();
          next.add(loEntry.id);
        }
        return next;
      });
    },
    [loEntry.id, setSelectedIds, allIds],
  );

  const onContextMenu = React.useCallback(
    (evt) => {
      evt.preventDefault();
      evt.stopPropagation();
      setContextMenu({ x: evt.clientX, y: evt.clientY, itemId: loEntry.id });
    },
    [loEntry.id, setContextMenu],
  );

  const onLock = React.useCallback(() => {
    const newLO = loadOrder.map((e) =>
      e.id === loEntry.id ? { ...e, locked: !isEntryLocked } : e,
    );
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
    serializeLoadOrder(context, newLO);
  }, [dispatch, context, profile, loadOrder, loEntry, isEntryLocked]);

  useInjectStyleOnce("lo-index-focus-style", LO_INDEX_FOCUS_CSS);

  const classes = ["load-order-entry"];
  if (className) classes.push(...className.split(" "));

  // Status filter: render hidden (but keep the DnD item count stable) when the entry is filtered out.
  // The 'lo-row-hidden' marker lets the injected CSS collapse the whole DraggableListItem wrapper
  // (the two dnd <div>s the renderer can't reach), otherwise their spacing leaves visible gaps.
  if (!matchesStatus(loEntry, statusFilter, () => isModEnabled, isLocked)) {
    return React.createElement(ListGroupItem, {
      key: loEntry.id,
      className: "lo-row-hidden",
      style: { display: "none" },
    });
  }

  return React.createElement(
    ListGroupItem,
    {
      key: loEntry.id,
      className: classes.join(" "),
      onClick: onSelect,
      onContextMenu: onContextMenu,
      style: { outline: isSelected ? "2px solid #337ab7" : "none", outlineOffset: "-1px" },
    },
    React.createElement(
      "div",
      { style: { visibility: isEntryLocked ? "hidden" : "visible" } },
      React.createElement(Icon, { className: "drag-handle-icon", name: "drag-handle" }),
    ),
    React.createElement(
      "div",
      { style: { width: 24, flexShrink: 0, overflow: "hidden" } },
      React.createElement(LoadOrderIndexInput, {
        className: "load-order-index",
        api: context.api,
        item: loEntry,
        currentPosition: currentIdx,
        lockedEntriesCount: leadingLockedCount,
        loadOrder: loadOrder,
        isLocked: isLocked,
        onApplyIndex: onApplyIndex,
      }),
    ),
    React.createElement(
      "div",
      {
        style: { cursor: "pointer", display: "flex", alignItems: "center" },
        title: isEntryLocked ? "Unlock position" : "Lock position",
        onClick: (evt) => {
          evt.stopPropagation();
          onLock();
        },
      },
      React.createElement(Icon, {
        name: isEntryLocked ? "locked" : "unlocked",
        style: { color: isEntryLocked ? "#e2c04c" : "inherit" },
      }),
    ),
    React.createElement(
      "div",
      {
        className: "load-order-thumb-slot",
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, marginRight: 4, flexShrink: 0 },
      },
      !loEntry.modId
        ? React.createElement(
            "div",
            {
              className: "load-order-unmanaged-banner",
              title: "Not managed by Vortex",
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                textAlign: "center",
                borderRadius: 2,
                border: "1px solid #e2c04c",
                background: "rgba(226,192,76,0.12)",
                color: "#e2c04c",
                fontSize: 9,
                lineHeight: 1.1,
                padding: 2,
                pointerEvents: "none",
              },
            },
            React.createElement(Icon, {
              className: "external-caution-logo",
              name: "feedback-warning",
              style: { color: "#e2c04c" },
            }),
            React.createElement("span", null, "Not managed by Vortex"),
          )
        : pictureUrl
          ? React.createElement("img", {
              className: "load-order-thumb",
              src: pictureUrl,
              draggable: false,
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                objectFit: "cover",
                borderRadius: 2,
                pointerEvents: "none",
              },
            })
          : null,
    ),
    React.createElement(
      "p",
      { className: "load-order-name", style: { whiteSpace: "normal", wordBreak: "break-word" } },
      loEntry.name,
    ),
    loEntry.modId
      ? React.createElement(
          "button",
          {
            className: "btn btn-default btn-sm",
            style: {
              margin: "0 4px",
              flexShrink: 0,
              display: "flex",
              alignItems: "center",
              gap: 4,
            },
            onClick: (evt) => {
              evt.stopPropagation();
              onModToggle();
            },
          },
          React.createElement(Icon, { name: isModEnabled ? "toggle-disabled" : "toggle-enabled" }),
          isModEnabled ? "Disable" : "Enable",
        )
      : null,
    displayCheckboxes
      ? React.createElement(Checkbox, {
          className: "entry-checkbox",
          checked: loEntry.enabled,
          disabled: isLocked(loEntry),
          onChange: onToggle,
        })
      : null,
    contextMenu?.itemId === loEntry.id
      ? React.createElement(PakContextMenu, {
          x: contextMenu.x,
          y: contextMenu.y,
          item: loEntry,
          loadOrder,
          profile,
          dispatch,
          context,
          selectedIds,
          isModEnabled,
          onClose: () => setContextMenu(null),
        })
      : null,
  );
} //*/

function PakContextMenu({
  x,
  y,
  item,
  loadOrder,
  profile,
  dispatch,
  context,
  selectedIds,
  isModEnabled,
  onClose,
}) {
  useDismissOnOutside(onClose);

  useInjectStyleOnce("ue4ss-ctx-menu-style", LO_CTX_MENU_CSS);

  const isLocked = (e) => [true, "true", "always"].includes(e?.locked);
  const isMulti = selectedIds.size >= 2 && selectedIds.has(item.id);
  const targets = isMulti ? loadOrder.filter((e) => selectedIds.has(e.id)) : [item];

  const applyToTargets = (transform, serialize = false) => {
    const newLO = transform(loadOrder, targets);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
    if (serialize) serializeLoadOrder(context, newLO);
    onClose();
  };

  const isEntryLocked = isLocked(item);

  const setModsEnabled = (entries, enable) => {
    const modIds = entries.filter((e) => e.modId !== undefined).map((e) => e.modId);
    if (modIds.length > 0) {
      actions.setModsEnabled(context.api, profile.id, modIds, enable, { allowAutoDeploy: true });
    }
    onClose();
  };

  const [menuPosition, clampRef] = useClampedMenuPosition(x, y);
  const menuStyle = {
    position: "fixed",
    left: menuPosition.left,
    top: menuPosition.top,
    zIndex: 9999,
    background: "#1e1e1e",
    border: "1px solid rgba(255,255,255,0.2)",
    borderRadius: 4,
    padding: "4px 0",
    minWidth: 180,
    boxShadow: "0 4px 12px rgba(0,0,0,0.6)",
  };
  const itemStyle = { padding: "6px 16px", cursor: "pointer", whiteSpace: "nowrap" };
  const sepStyle = { borderTop: "1px solid rgba(255,255,255,0.1)", margin: "4px 0" };

  const menuItem = (label, onClick) =>
    React.createElement(
      "div",
      {
        className: "ue4ss-ctx-item",
        style: itemStyle,
        onClick: (evt) => {
          evt.stopPropagation();
          onClick();
        },
      },
      label,
    );

  if (isMulti) {
    const n = targets.length;
    return React.createElement(
      "div",
      { ref: clampRef, style: menuStyle },
      menuItem(`Lock Selected (${n})`, () =>
        applyToTargets(
          (lo) => lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: true } : e)),
          true,
        ),
      ),
      menuItem(`Unlock Selected (${n})`, () =>
        applyToTargets(
          (lo) => lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: false } : e)),
          true,
        ),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Move to Top (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...selected, ...rest];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      menuItem(`Move to Bottom (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...rest, ...selected];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      React.createElement("div", { style: sepStyle }),
      //menuItem(`Enable Selected (${n})`, () => setModsEnabled(targets, true)),
      menuItem(`Disable Selected (${n})`, () => setModsEnabled(targets, false)),
    );
  }

  const modPageUrl = getModPageURL(context.api, item.modId);
  const stagingFolder = getModStagingFolder(context.api, item.modId);

  return React.createElement(
    "div",
    { ref: clampRef, style: menuStyle },
    menuItem(isEntryLocked ? "Unlock Position" : "Lock Position", () =>
      applyToTargets(
        (lo) => lo.map((e) => (e.id === item.id ? { ...e, locked: !isEntryLocked } : e)),
        true,
      ),
    ),
    React.createElement("div", { style: sepStyle }),
    menuItem("Move to Top", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...moved, ...rest];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    menuItem("Move to Bottom", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...rest, ...moved];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    stagingFolder || modPageUrl ? React.createElement("div", { style: sepStyle }) : null,
    stagingFolder
      ? menuItem("Open Staging Folder", () => {
          try {
            window.api.shell.openFile(stagingFolder);
          } catch (err) {
            context.api.showErrorNotification("Failed to open the file or folder", err, {
              allowReport: false,
            });
          }
          onClose();
        })
      : null,
    modPageUrl
      ? menuItem("Open Mod Page", () => {
          try {
            window.api.shell.openUrl(modPageUrl);
          } catch (err) {
            context.api.showErrorNotification("Failed to open the URL", err, {
              allowReport: false,
            });
          }
          onClose();
        })
      : null,
    item.modId && isModEnabled ? React.createElement("div", { style: sepStyle }) : null,
    item.modId && isModEnabled
      ? menuItem("Disable Vortex Mod", () => setModsEnabled([item], false))
      : null,
  );
}

function GameSettings() {
  const { Toggle, More, MainContext } = require("vortex-api");
  const { useSelector, useDispatch } = require("react-redux");
  const dispatch = useDispatch();
  const { api } = React.useContext(MainContext);
  const ue4ssLoEnabled = useSelector((state) => state?.settings?.[GAME_ID]?.ue4ssLoEnabled ?? true);
  const onToggle = React.useCallback(
    (checked) => {
      dispatch(setUe4ssLoEnabled(checked));
      reconcileEnabledTxt(api, !checked).catch((err) =>
        log("warn", `UE4SS LO reconcile failed: ${err.message}`),
      );
    },
    [api, dispatch],
  );
  return React.createElement(
    "form",
    null,
    React.createElement(
      "div",
      { className: "settings-group" },
      React.createElement(
        Toggle,
        { checked: ue4ssLoEnabled, onToggle },
        "UE4SS Load Order",
        React.createElement(
          More,
          { id: `${GAME_ID}-ue4ss-lo-more`, name: "UE4SS Load Order" },
          "Enable the UE4SS mod load order page and mods.txt management. " +
            `Disabling will have the extension write ${ENABLEDTXT_FILE} files with no Load Order control.`,
        ),
      ),
    ),
  );
}

async function reconcileEnabledTxt(api, write) {
  const state = api.getState();
  const stagingPath = selectors.installPathForGame(state, GAME_ID);
  if (!stagingPath) return;

  const targets = new Set();
  await util.walk(
    stagingPath,
    (iterPath, stats) => {
      if (!stats.isDirectory()) return Promise.resolve();
      const base = path.basename(iterPath).toLowerCase();
      if (base === "scripts" || base === "dlls") {
        if (!UE4SS_NATIVE_MODS.includes(path.basename(path.dirname(iterPath)))) {
          targets.add(path.dirname(iterPath));
        }
      }
      return Promise.resolve();
    },
    { ignoreErrors: true },
  );

  let touched = 0;
  for (const parent of targets) {
    const marker = path.join(parent, ENABLEDTXT_FILE);
    try {
      if (write) {
        try {
          await fsp.stat(marker);
        } catch {
          await fsp.writeFile(marker, "");
          touched++;
        }
      } else {
        //removeAsync never reports a missing file, so stat first to keep the count honest
        try {
          await fsp.stat(marker);
          await fsp.rm(marker, { recursive: true, force: true });
          touched++;
        } catch (err) {
          if (err.code !== "ENOENT") throw err;
        }
      }
    } catch (err) {
      log(
        "warn",
        `${ENABLEDTXT_FILE} ${write ? "write" : "delete"} failed at ${marker}: ${err.message}`,
      );
    }
  }

  api.sendNotification({
    id: `${GAME_ID}-ue4ss-lo-reconcile`,
    type: "success",
    message: write
      ? `UE4SS Load Order disabled: wrote ${ENABLEDTXT_FILE} for ${touched} mod folder(s).`
      : `UE4SS Load Order enabled: cleared ${ENABLEDTXT_FILE} for ${touched} mod folder(s).`,
    displayMS: 5000,
  });
}

//* React components for UE4SS load order page
const Ue4ssSelectionContext = React.createContext({
  selectedIds: new Set(),
  setSelectedIds: () => {},
  allIds: [],
  contextMenu: null,
  setContextMenu: () => {},
});

function Ue4ssItemRenderer({ className, item }) {
  const { Checkbox } = require("react-bootstrap");
  const { Icon, LoadOrderIndexInput, MainContext } = require("vortex-api");
  const { useSelector, useDispatch } = require("react-redux");

  const vortexContext = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profileId = useSelector((state) => selectors.activeProfile(state)?.id);
  const loadOrder = useSelector(
    (state) => state?.persistent?.ue4ssLoadOrder?.[profileId]?.loadOrder ?? [],
  );
  const mods = useSelector((state) => state?.persistent?.mods?.[GAME_ID] ?? {});
  const pictureUrl = mods[item.modId]?.attributes?.pictureUrl;
  const gamePath = useSelector(
    (state) => state?.settings?.gameMode?.discovered?.[GAME_ID]?.path ?? "",
  );

  const currentIdx = loadOrder.findIndex((e) => e.id === item.id) + 1;
  const isLocked = (entry) => [true, "true", "always"].includes(entry?.locked);
  //Core derives the index input's minimum from this and assumes locked entries sit at the top.
  //Only the LEADING locked run blocks row 1 - a lock further down must not raise the floor.
  const firstUnlocked = loadOrder.findIndex((e) => !isLocked(e));
  const leadingLockedCount = firstUnlocked === -1 ? loadOrder.length : firstUnlocked;

  const onApplyIndex = React.useCallback(
    (idx) => {
      if (currentIdx === idx || isLocked(item)) return;
      //Locked entries hold their absolute index - the typed row picks a slot among the unlocked ones
      const bound = idx - 1 + (idx > currentIdx ? 1 : 0);
      const dest = loadOrder.filter((e, i) => !isLocked(e) && e.id !== item.id && i < bound).length;
      const unlocked = loadOrder.filter((e) => !isLocked(e) && e.id !== item.id);
      unlocked.splice(dest, 0, item);
      let next = 0;
      const newLO = loadOrder.map((e) => (isLocked(e) ? e : unlocked[next++]));
      dispatch(setUe4ssLoadOrder(profileId, newLO));
      serializeUe4ss(vortexContext.api, newLO);
    },
    [dispatch, vortexContext, profileId, loadOrder, item, currentIdx],
  );

  const isEntryLocked = isLocked(item);

  const onLock = React.useCallback(() => {
    const newLO = loadOrder.map((e) => (e.id === item.id ? { ...e, locked: !isEntryLocked } : e));
    dispatch(setUe4ssLoadOrder(profileId, newLO));
    serializeUe4ss(vortexContext.api, newLO);
  }, [dispatch, vortexContext, profileId, loadOrder, item, isEntryLocked]);

  const [configFilePath, setConfigFilePath] = React.useState("");
  React.useEffect(() => {
    if (!gamePath || !item.id) {
      setConfigFilePath("");
      return;
    }
    const modFolder = path.join(gamePath, BINARIES_PATH, UE4SS_MOD_PATH, item.id);
    const localConfigFiles = [
      ...UE4SS_CONFIG_FILES,
      `${item.id}.txt`,
      `${item.id}.ini`,
      `${item.id}.json`,
    ];
    //Stat the conventional locations rather than walking the folder: the walk ran per row on every
    //page open and profile switch. UE4SS keeps lua configs beside Scripts/ and dll configs beside
    //dlls/, so a config below any other subfolder is not found - accepted trade for the IO.
    const candidates = [
      modFolder,
      path.join(modFolder, "Scripts"),
      path.join(modFolder, "dlls"),
    ].reduce((acc, dir) => acc.concat(localConfigFiles.map((name) => path.join(dir, name))), []);
    let cancelled = false;
    (async () => {
      for (const candidate of candidates) {
        try {
          await fsp.stat(candidate);
          if (!cancelled) setConfigFilePath(candidate);
          return;
        } catch {
          /* try the next candidate */
        }
      }
      if (!cancelled) setConfigFilePath("");
    })();
    return () => {
      cancelled = true;
    };
  }, [gamePath, item.id]);

  const onConfigure = React.useCallback(() => {
    try {
      window.api.shell.openFile(configFilePath);
    } catch (err) {
      vortexContext.api.showErrorNotification("Failed to open the file or folder", err, {
        allowReport: false,
      });
    }
  }, [configFilePath, vortexContext]);

  const onToggle = React.useCallback(
    (evt) => {
      const newLO = loadOrder.map((e) =>
        e.id === item.id ? { ...e, enabled: evt.target.checked } : e,
      );
      dispatch(setUe4ssLoadOrder(profileId, newLO));
      serializeUe4ss(vortexContext.api, newLO);
    },
    [dispatch, vortexContext, loadOrder, item, profileId],
  );

  const { selectedIds, setSelectedIds, allIds, contextMenu, setContextMenu } =
    React.useContext(Ue4ssSelectionContext);
  const isSelected = selectedIds.has(item.id);

  const onContextMenu = React.useCallback(
    (evt) => {
      evt.preventDefault();
      evt.stopPropagation();
      setContextMenu({ x: evt.clientX, y: evt.clientY, itemId: item.id });
    },
    [item.id, setContextMenu],
  );

  const onSelect = React.useCallback(
    (evt) => {
      const ctrlKey = evt.ctrlKey || evt.metaKey;
      const shiftKey = evt.shiftKey;
      setSelectedIds((prev) => {
        const next = new Set(prev);
        if (ctrlKey) {
          next.has(item.id) ? next.delete(item.id) : next.add(item.id);
        } else if (shiftKey) {
          const lastId = [...prev].at(-1);
          const start = allIds.indexOf(lastId ?? item.id);
          const end = allIds.indexOf(item.id);
          const [lo, hi] = [Math.min(start, end), Math.max(start, end)];
          for (let i = lo; i <= hi; i++) next.add(allIds[i]);
        } else {
          next.clear();
          next.add(item.id);
        }
        return next;
      });
    },
    [item.id, setSelectedIds, allIds],
  );

  const classes = ["load-order-entry"];
  if (className) classes.push(...className.split(" ").filter(Boolean));

  return React.createElement(
    "div",
    {
      key: item.id,
      className: classes.join(" "),
      onClick: onSelect,
      onContextMenu: onContextMenu,
      style: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
        padding: "4px 12px",
        margin: 0,
        border: "1px solid rgba(255,255,255,0.15)",
        borderRadius: 4,
        minHeight: 52,
        outline: isSelected ? "2px solid #337ab7" : "none",
        outlineOffset: "-1px",
      },
    },
    React.createElement(
      "div",
      { style: { visibility: isEntryLocked ? "hidden" : "visible" } },
      React.createElement(Icon, { className: "drag-handle-icon", name: "drag-handle" }),
    ),
    React.createElement(
      "div",
      { style: { width: 24, flexShrink: 0, overflow: "hidden" } },
      React.createElement(LoadOrderIndexInput, {
        className: "load-order-index",
        api: vortexContext.api,
        item: item,
        currentPosition: currentIdx,
        lockedEntriesCount: leadingLockedCount,
        loadOrder: loadOrder,
        isLocked: isLocked,
        onApplyIndex: onApplyIndex,
      }),
    ),
    React.createElement(
      "div",
      {
        style: { cursor: "pointer", display: "flex", alignItems: "center" },
        title: isEntryLocked ? "Unlock position" : "Lock position",
        onClick: (evt) => {
          evt.stopPropagation();
          onLock();
        },
      },
      React.createElement(Icon, {
        name: isEntryLocked ? "locked" : "unlocked",
        style: { color: isEntryLocked ? "#e2c04c" : "inherit" },
      }),
    ),
    React.createElement(
      "div",
      {
        className: "load-order-thumb-slot",
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, flexShrink: 0 },
      },
      !item.modId
        ? React.createElement(
            "div",
            {
              className: "load-order-unmanaged-banner",
              title: "Not managed by Vortex",
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                textAlign: "center",
                borderRadius: 2,
                border: "1px solid #e2c04c",
                background: "rgba(226,192,76,0.12)",
                color: "#e2c04c",
                fontSize: 9,
                lineHeight: 1.1,
                padding: 2,
                pointerEvents: "none",
              },
            },
            React.createElement(Icon, {
              className: "external-caution-logo",
              name: "feedback-warning",
              style: { color: "#e2c04c" },
            }),
            React.createElement("span", null, "Not managed by Vortex"),
          )
        : pictureUrl
          ? React.createElement("img", {
              className: "load-order-thumb",
              src: pictureUrl,
              draggable: false,
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                objectFit: "cover",
                borderRadius: 2,
                pointerEvents: "none",
              },
            })
          : null,
    ),
    React.createElement(
      "p",
      {
        className: "load-order-name",
        style: { flex: "1 1 0", margin: 0, whiteSpace: "normal", wordBreak: "break-word" },
      },
      item.name ?? item.id,
    ),
    configFilePath
      ? React.createElement(
          "button",
          {
            className: "btn btn-default btn-sm",
            style: { margin: "0 4px" },
            title: path.basename(configFilePath),
            onClick: onConfigure,
          },
          "Configure",
        )
      : null,
    React.createElement(Checkbox, {
      style: { alignSelf: "center", cursor: "pointer", margin: 0 },
      checked: item.enabled ?? true,
      onChange: onToggle,
    }),
    contextMenu?.itemId === item.id
      ? React.createElement(Ue4ssContextMenu, {
          x: contextMenu.x,
          y: contextMenu.y,
          item,
          loadOrder,
          profileId,
          dispatch,
          api: vortexContext.api,
          gamePath,
          configFilePath,
          selectedIds,
          onClose: () => setContextMenu(null),
        })
      : null,
  );
}

function Ue4ssContextMenu({
  x,
  y,
  item,
  loadOrder,
  profileId,
  dispatch,
  api,
  gamePath,
  configFilePath,
  selectedIds,
  onClose,
}) {
  useDismissOnOutside(onClose);

  useInjectStyleOnce("ue4ss-ctx-menu-style", LO_CTX_MENU_CSS);

  const isLocked = (e) => [true, "true", "always"].includes(e?.locked);
  const isMulti = selectedIds.size >= 2 && selectedIds.has(item.id);
  const targets = isMulti ? loadOrder.filter((e) => selectedIds.has(e.id)) : [item];

  const applyToTargets = (transform) => {
    const newLO = transform(loadOrder, targets);
    dispatch(setUe4ssLoadOrder(profileId, newLO));
    serializeUe4ss(api, newLO);
    onClose();
  };

  const isEntryLocked = isLocked(item);
  const isEntryEnabled = item.enabled ?? true;

  //Vortex mod state (deployment), distinct from the LO-entry enabled flag written to mods.txt
  const isModEnabled =
    api.getState()?.persistent?.profiles?.[profileId]?.modState?.[item.modId]?.enabled ?? false;
  const setVortexModsEnabled = (entries, enable) => {
    const modIds = entries.filter((e) => e.modId !== undefined).map((e) => e.modId);
    if (modIds.length > 0) {
      actions.setModsEnabled(api, profileId, modIds, enable, { allowAutoDeploy: true });
    }
    onClose();
  };

  const [menuPosition, clampRef] = useClampedMenuPosition(x, y);
  const menuStyle = {
    position: "fixed",
    left: menuPosition.left,
    top: menuPosition.top,
    zIndex: 9999,
    background: "#1e1e1e",
    border: "1px solid rgba(255,255,255,0.2)",
    borderRadius: 4,
    padding: "4px 0",
    minWidth: 180,
    boxShadow: "0 4px 12px rgba(0,0,0,0.6)",
  };
  const itemStyle = { padding: "6px 16px", cursor: "pointer", whiteSpace: "nowrap" };
  const sepStyle = { borderTop: "1px solid rgba(255,255,255,0.1)", margin: "4px 0" };

  const menuItem = (label, onClick) =>
    React.createElement(
      "div",
      {
        className: "ue4ss-ctx-item",
        style: itemStyle,
        onClick: (evt) => {
          evt.stopPropagation();
          onClick();
        },
      },
      label,
    );

  if (isMulti) {
    const n = targets.length;
    return React.createElement(
      "div",
      { ref: clampRef, style: menuStyle },
      menuItem(`Enable Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, enabled: true } : e)),
        ),
      ),
      menuItem(`Disable Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, enabled: false } : e)),
        ),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Lock Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: true } : e)),
        ),
      ),
      menuItem(`Unlock Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: false } : e)),
        ),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Move to Top (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...selected, ...rest];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      menuItem(`Move to Bottom (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...rest, ...selected];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Open Mod Folders (${n})`, () => {
        targets.forEach((t) => {
          try {
            window.api.shell.openFile(path.join(gamePath, BINARIES_PATH, UE4SS_MOD_PATH, t.id));
          } catch (err) {
            api.showErrorNotification("Failed to open the file or folder", err, {
              allowReport: false,
            });
          }
        });
        onClose();
      }),
      targets.some((t) => t.modId !== undefined)
        ? menuItem(`Open Staging Folders (${n})`, () => {
            targets.forEach((t) => {
              const folder = getModStagingFolder(api, t.modId);
              if (folder) {
                try {
                  window.api.shell.openFile(folder);
                } catch (err) {
                  api.showErrorNotification("Failed to open the file or folder", err, {
                    allowReport: false,
                  });
                }
              }
            });
            onClose();
          })
        : null,
      React.createElement("div", { style: sepStyle }),
      menuItem(`Disable Vortex Mod (${n})`, () => setVortexModsEnabled(targets, false)),
    );
  }

  const modPageUrl = getModPageURL(api, item.modId);
  const stagingFolder = getModStagingFolder(api, item.modId);

  return React.createElement(
    "div",
    { ref: clampRef, style: menuStyle },
    menuItem(isEntryEnabled ? "Disable" : "Enable", () =>
      applyToTargets((lo) =>
        lo.map((e) => (e.id === item.id ? { ...e, enabled: !isEntryEnabled } : e)),
      ),
    ),
    menuItem(isEntryLocked ? "Unlock Position" : "Lock Position", () =>
      applyToTargets((lo) =>
        lo.map((e) => (e.id === item.id ? { ...e, locked: !isEntryLocked } : e)),
      ),
    ),
    configFilePath
      ? menuItem("Configure", () => {
          try {
            window.api.shell.openFile(configFilePath);
          } catch (err) {
            api.showErrorNotification("Failed to open the file or folder", err, {
              allowReport: false,
            });
          }
          onClose();
        })
      : null,
    React.createElement("div", { style: sepStyle }),
    menuItem("Move to Top", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...moved, ...rest];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    menuItem("Move to Bottom", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...rest, ...moved];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    React.createElement("div", { style: sepStyle }),
    menuItem("Open Mod Folder", () => {
      try {
        window.api.shell.openFile(path.join(gamePath, BINARIES_PATH, UE4SS_MOD_PATH, item.id));
      } catch (err) {
        api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
      }
      onClose();
    }),
    stagingFolder
      ? menuItem("Open Staging Folder", () => {
          try {
            window.api.shell.openFile(stagingFolder);
          } catch (err) {
            api.showErrorNotification("Failed to open the file or folder", err, {
              allowReport: false,
            });
          }
          onClose();
        })
      : null,
    modPageUrl
      ? menuItem("Open Mod Page", () => {
          try {
            window.api.shell.openUrl(modPageUrl);
          } catch (err) {
            api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
          }
          onClose();
        })
      : null,
    item.modId !== undefined ? React.createElement("div", { style: sepStyle }) : null,
    item.modId !== undefined
      ? menuItem(isModEnabled ? "Disable Vortex Mod" : "Enable Vortex Mod", () =>
          setVortexModsEnabled([item], !isModEnabled),
        )
      : null,
  );
}

function Ue4ssLoadOrderInfoPanel() {
  return React.createElement(
    "div",
    {
      id: "loadorderinfo",
      style: { padding: "12px", borderTop: "1px solid rgba(255,255,255,0.1)" },
    },
    React.createElement(
      "h2",
      { style: { marginTop: 0, display: "flex", alignItems: "center", gap: 10 } },
      React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          style: { width: 28, height: 28, fill: "currentColor", flexShrink: 0 },
        },
        React.createElement("path", { d: UE4SS_ICON }),
      ),
      React.createElement(
        "span",
        null,
        React.createElement("span", { style: { fontWeight: "bold" } }, "UE4SS"),
        React.createElement(
          "span",
          { style: { fontWeight: 300, color: "rgba(255,255,255,0.65)" } },
          " Mod Load Order",
        ),
      ),
    ),
    React.createElement(
      "ul",
      { style: { margin: 0, paddingLeft: 20, listStyleType: "disc" } },
      React.createElement(
        "li",
        null,
        "Drag and drop mods to change the order in which UE4SS loads them. Changes write to mods.txt immediately.",
      ),
      React.createElement(
        "li",
        null,
        "Use the checkboxes to enable or disable each mod. All changes write to mods.txt immediately.",
      ),
      React.createElement(
        "li",
        null,
        `Mods with a ${UE4SS_CONFIG_FILES.join("/")} file will have a "Configure" button to open the file externally.`,
      ),
      React.createElement(
        "li",
        { style: { fontStyle: "italic", color: "yellow", fontWeight: "bold" } },
        "Note: This page manages UE4SS mods only. Pak mod load order is managed on the Load Order page.",
      ),
    ),
  );
}

function Ue4ssLoadOrderPage({ api }) {
  const { useSelector, useDispatch } = require("react-redux");
  const { FormControl } = require("react-bootstrap");

  const profileId = useSelector((state) => selectors.activeProfile(state)?.id);
  const loadOrder = useSelector(
    (state) => state?.persistent?.ue4ssLoadOrder?.[profileId]?.loadOrder ?? [],
  );
  const loEnabled = useSelector((state) => state?.settings?.[GAME_ID]?.ue4ssLoEnabled ?? true);
  const dispatch = useDispatch();
  const [filterText, setFilterText] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState(new Set());
  const [selectedIds, setSelectedIds] = React.useState(new Set());
  const [contextMenu, setContextMenu] = React.useState(null);

  React.useEffect(() => {
    if (!profileId) return;
    if (selectors.activeGameId(api.getState()) !== GAME_ID) return;
    deserializeUe4ss(api)
      .then((lo) => dispatch(setUe4ssLoadOrder(profileId, lo)))
      .catch((err) => log("warn", `[${GAME_ID}] UE4SS load order refresh failed`, err));
    setSelectedIds(new Set());
  }, [profileId]);

  useInjectStyleOnce("lo-index-focus-style", LO_INDEX_FOCUS_CSS);

  const isFiltered = !!filterText || statusFilter.size > 0;
  const isEntryEnabled = (e) => e.enabled !== false;
  const isEntryLocked = (e) => [true, "true", "always"].includes(e?.locked);

  const onApply = React.useCallback(
    (reordered) => {
      let newLO;
      if (isFiltered) {
        const filteredIds = new Set(reordered.map((e) => e.id));
        const positions = loadOrder.reduce((acc, e, i) => {
          if (filteredIds.has(e.id)) acc.push(i);
          return acc;
        }, []);
        newLO = [...loadOrder];
        positions.forEach((pos, i) => {
          newLO[pos] = reordered[i];
        });
      } else {
        newLO = reordered;
      }
      dispatch(setUe4ssLoadOrder(profileId, newLO));
      serializeUe4ss(api, newLO);
    },
    [dispatch, loadOrder, isFiltered, profileId],
  );

  const filteredOrder = loadOrder.filter(
    (e) =>
      (!filterText || (e.name ?? e.id).toLowerCase().includes(filterText.toLowerCase())) &&
      matchesStatus(e, statusFilter, isEntryEnabled, isEntryLocked),
  );

  const allIds = filteredOrder.map((e) => e.id);

  if (!loEnabled) {
    return React.createElement(
      MainPage,
      null,
      React.createElement(
        MainPage.Body,
        null,
        React.createElement(
          "p",
          { style: { padding: "12px", fontWeight: "bold", color: "yellow" } },
          "UE4SS load order is disabled in Settings.",
        ),
      ),
    );
  }

  if (!loadOrder.length) {
    return React.createElement(
      MainPage,
      null,
      React.createElement(
        MainPage.Body,
        null,
        React.createElement(
          "p",
          { style: { padding: "12px", fontWeight: "bold", color: "yellow" } },
          "No UE4SS mods are installed.",
        ),
      ),
    );
  }

  return React.createElement(
    MainPage,
    null,
    React.createElement(
      MainPage.Header,
      null,
      React.createElement(
        "div",
        { style: { display: "flex", alignItems: "center", width: "100%" } },
        React.createElement(FormControl, {
          type: "search",
          placeholder: "Filter mods...",
          className: "file-based-load-order-filter",
          style: { flex: 1 },
          value: filterText,
          onChange: (evt) => setFilterText(evt.target.value),
        }),
        React.createElement(LoadOrderStatusFilter, {
          active: statusFilter,
          setActive: setStatusFilter,
          groups: ["enabled", "locked", "unmanaged"],
          count:
            statusFilter.size > 0
              ? { matched: filteredOrder.length, total: loadOrder.length }
              : null,
        }),
      ),
    ),
    React.createElement(
      MainPage.Body,
      null,
      React.createElement(
        DNDContainer,
        { style: { height: "95%" } },
        React.createElement(
          FlexLayout,
          {
            type: "column",
            className: "file-based-load-order-container",
            style: { height: "100%" },
          },
          React.createElement(
            FlexLayout.Flex,
            { className: "file-based-load-order-list", style: { overflowY: "auto", minHeight: 0 } },
            React.createElement(
              Ue4ssSelectionContext.Provider,
              { value: { selectedIds, setSelectedIds, allIds, contextMenu, setContextMenu } },
              React.createElement(DraggableList, {
                itemTypeId: `${GAME_ID}-ue4ss-lo-entry`,
                id: `${GAME_ID}-ue4ss-loadorder-list`,
                items: filteredOrder,
                itemRenderer: Ue4ssItemRenderer,
                apply: onApply,
                idFunc: (entry) => entry.id,
                isLocked: (item) => [true, "true", "always"].includes(item?.locked),
              }),
            ),
          ),
          React.createElement(
            "div",
            { style: { flexShrink: 0 } },
            React.createElement(Ue4ssLoadOrderInfoPanel),
          ),
        ),
      ),
    ),
  );
} //*/

//* React components for LogicMods load order page
const LogicModsSelectionContext = React.createContext({
  selectedIds: new Set(),
  setSelectedIds: () => {},
  allIds: [],
  contextMenu: null,
  setContextMenu: () => {},
});

function LogicModsItemRenderer({ className, item }) {
  const { Icon, LoadOrderIndexInput, MainContext } = require("vortex-api");
  const { useSelector, useDispatch } = require("react-redux");

  const vortexContext = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profileId = useSelector((state) => selectors.activeProfile(state)?.id);
  const loadOrder = useSelector(
    (state) => state?.persistent?.logicModsLoadOrder?.[profileId]?.loadOrder ?? [],
  );
  const mods = useSelector((state) => state?.persistent?.mods?.[GAME_ID] ?? {});
  const pictureUrl = mods[item.modId]?.attributes?.pictureUrl;

  const isModEnabled = useSelector(
    (state) => state?.persistent?.profiles?.[profileId]?.modState?.[item.modId]?.enabled ?? false,
  );

  const currentIdx = loadOrder.findIndex((e) => e.id === item.id) + 1;
  const isLocked = (entry) => [true, "true", "always"].includes(entry?.locked);
  //Core derives the index input's minimum from this and assumes locked entries sit at the top.
  //Only the LEADING locked run blocks row 1 - a lock further down must not raise the floor.
  const firstUnlocked = loadOrder.findIndex((e) => !isLocked(e));
  const leadingLockedCount = firstUnlocked === -1 ? loadOrder.length : firstUnlocked;

  const onApplyIndex = React.useCallback(
    (idx) => {
      if (currentIdx === idx || isLocked(item)) return;
      //Locked entries hold their absolute index - the typed row picks a slot among the unlocked ones
      const bound = idx - 1 + (idx > currentIdx ? 1 : 0);
      const dest = loadOrder.filter((e, i) => !isLocked(e) && e.id !== item.id && i < bound).length;
      const unlocked = loadOrder.filter((e) => !isLocked(e) && e.id !== item.id);
      unlocked.splice(dest, 0, item);
      let next = 0;
      const newLO = loadOrder.map((e) => (isLocked(e) ? e : unlocked[next++]));
      dispatch(setLogicModsLoadOrder(profileId, newLO));
      serializeLogicMods(vortexContext.api, newLO);
    },
    [dispatch, vortexContext, profileId, loadOrder, item, currentIdx],
  );

  const isEntryLocked = isLocked(item);

  const onLock = React.useCallback(() => {
    const newLO = loadOrder.map((e) => (e.id === item.id ? { ...e, locked: !isEntryLocked } : e));
    dispatch(setLogicModsLoadOrder(profileId, newLO));
    serializeLogicMods(vortexContext.api, newLO);
  }, [dispatch, vortexContext, profileId, loadOrder, item, isEntryLocked]);

  const onDisable = React.useCallback(() => {
    if (!item.modId) return;
    actions.setModsEnabled(vortexContext.api, profileId, [item.modId], false, {
      allowAutoDeploy: true,
    });
  }, [vortexContext, profileId, item.modId]);

  const { selectedIds, setSelectedIds, allIds, contextMenu, setContextMenu } =
    React.useContext(LogicModsSelectionContext);
  const isSelected = selectedIds.has(item.id);

  const onContextMenu = React.useCallback(
    (evt) => {
      evt.preventDefault();
      evt.stopPropagation();
      setContextMenu({ x: evt.clientX, y: evt.clientY, itemId: item.id });
    },
    [item.id, setContextMenu],
  );

  const onSelect = React.useCallback(
    (evt) => {
      const ctrlKey = evt.ctrlKey || evt.metaKey;
      const shiftKey = evt.shiftKey;
      setSelectedIds((prev) => {
        const next = new Set(prev);
        if (ctrlKey) {
          next.has(item.id) ? next.delete(item.id) : next.add(item.id);
        } else if (shiftKey) {
          const lastId = [...prev].at(-1);
          const start = allIds.indexOf(lastId ?? item.id);
          const end = allIds.indexOf(item.id);
          const [lo, hi] = [Math.min(start, end), Math.max(start, end)];
          for (let i = lo; i <= hi; i++) next.add(allIds[i]);
        } else {
          next.clear();
          next.add(item.id);
        }
        return next;
      });
    },
    [item.id, setSelectedIds, allIds],
  );

  useInjectStyleOnce("lo-index-focus-style", LO_INDEX_FOCUS_CSS);

  const classes = ["load-order-entry"];
  if (className) classes.push(...className.split(" ").filter(Boolean));

  return React.createElement(
    "div",
    {
      key: item.id,
      className: classes.join(" "),
      onClick: onSelect,
      onContextMenu: onContextMenu,
      style: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
        padding: "4px 12px",
        margin: 0,
        border: "1px solid rgba(255,255,255,0.15)",
        borderRadius: 4,
        minHeight: 52,
        outline: isSelected ? "2px solid #337ab7" : "none",
        outlineOffset: "-1px",
      },
    },
    React.createElement(
      "div",
      { style: { visibility: isEntryLocked ? "hidden" : "visible" } },
      React.createElement(Icon, { className: "drag-handle-icon", name: "drag-handle" }),
    ),
    React.createElement(
      "div",
      { style: { width: 24, flexShrink: 0, overflow: "hidden" } },
      React.createElement(LoadOrderIndexInput, {
        className: "load-order-index",
        api: vortexContext.api,
        item: item,
        currentPosition: currentIdx,
        lockedEntriesCount: leadingLockedCount,
        loadOrder: loadOrder,
        isLocked: isLocked,
        onApplyIndex: onApplyIndex,
      }),
    ),
    React.createElement(
      "div",
      {
        style: { cursor: "pointer", display: "flex", alignItems: "center" },
        title: isEntryLocked ? "Unlock position" : "Lock position",
        onClick: (evt) => {
          evt.stopPropagation();
          onLock();
        },
      },
      React.createElement(Icon, {
        name: isEntryLocked ? "locked" : "unlocked",
        style: { color: isEntryLocked ? "#e2c04c" : "inherit" },
      }),
    ),
    React.createElement(
      "div",
      {
        className: "load-order-thumb-slot",
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, flexShrink: 0 },
      },
      !item.modId
        ? React.createElement(
            "div",
            {
              className: "load-order-unmanaged-banner",
              title: "Not managed by Vortex",
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                textAlign: "center",
                borderRadius: 2,
                border: "1px solid #e2c04c",
                background: "rgba(226,192,76,0.12)",
                color: "#e2c04c",
                fontSize: 9,
                lineHeight: 1.1,
                padding: 2,
                pointerEvents: "none",
              },
            },
            React.createElement(Icon, {
              className: "external-caution-logo",
              name: "feedback-warning",
              style: { color: "#e2c04c" },
            }),
            React.createElement("span", null, "Not managed by Vortex"),
          )
        : pictureUrl
          ? React.createElement("img", {
              className: "load-order-thumb",
              src: pictureUrl,
              draggable: false,
              style: {
                width: LO_IMAGE_WIDTH,
                height: LO_IMAGE_HEIGHT,
                objectFit: "cover",
                borderRadius: 2,
                pointerEvents: "none",
              },
            })
          : null,
    ),
    React.createElement(
      "p",
      {
        className: "load-order-name",
        style: { flex: "1 1 0", margin: 0, whiteSpace: "normal", wordBreak: "break-word" },
      },
      item.name ?? item.id,
    ),
    item.modId && isModEnabled
      ? React.createElement(
          "button",
          {
            className: "btn btn-default btn-sm",
            style: {
              margin: "0 4px",
              flexShrink: 0,
              display: "flex",
              alignItems: "center",
              gap: 4,
            },
            onClick: (evt) => {
              evt.stopPropagation();
              onDisable();
            },
          },
          React.createElement(Icon, { name: "toggle-disabled" }),
          "Disable",
        )
      : null,
    contextMenu?.itemId === item.id
      ? React.createElement(LogicModsContextMenu, {
          x: contextMenu.x,
          y: contextMenu.y,
          item,
          loadOrder,
          profileId,
          dispatch,
          api: vortexContext.api,
          selectedIds,
          isModEnabled,
          onClose: () => setContextMenu(null),
        })
      : null,
  );
}

function LogicModsContextMenu({
  x,
  y,
  item,
  loadOrder,
  profileId,
  dispatch,
  api,
  selectedIds,
  isModEnabled,
  onClose,
}) {
  useDismissOnOutside(onClose);

  useInjectStyleOnce("ue4ss-ctx-menu-style", LO_CTX_MENU_CSS);

  const isLocked = (e) => [true, "true", "always"].includes(e?.locked);
  const isMulti = selectedIds.size >= 2 && selectedIds.has(item.id);
  const targets = isMulti ? loadOrder.filter((e) => selectedIds.has(e.id)) : [item];

  const applyToTargets = (transform) => {
    const newLO = transform(loadOrder, targets);
    dispatch(setLogicModsLoadOrder(profileId, newLO));
    serializeLogicMods(api, newLO);
    onClose();
  };

  const isEntryLocked = isLocked(item);

  const [menuPosition, clampRef] = useClampedMenuPosition(x, y);
  const menuStyle = {
    position: "fixed",
    left: menuPosition.left,
    top: menuPosition.top,
    zIndex: 9999,
    background: "#1e1e1e",
    border: "1px solid rgba(255,255,255,0.2)",
    borderRadius: 4,
    padding: "4px 0",
    minWidth: 180,
    boxShadow: "0 4px 12px rgba(0,0,0,0.6)",
  };
  const itemStyle = { padding: "6px 16px", cursor: "pointer", whiteSpace: "nowrap" };
  const sepStyle = { borderTop: "1px solid rgba(255,255,255,0.1)", margin: "4px 0" };

  const menuItem = (label, onClick) =>
    React.createElement(
      "div",
      {
        className: "ue4ss-ctx-item",
        style: itemStyle,
        onClick: (evt) => {
          evt.stopPropagation();
          onClick();
        },
      },
      label,
    );

  if (isMulti) {
    const n = targets.length;
    return React.createElement(
      "div",
      { ref: clampRef, style: menuStyle },
      menuItem(`Lock Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: true } : e)),
        ),
      ),
      menuItem(`Unlock Selected (${n})`, () =>
        applyToTargets((lo) =>
          lo.map((e) => (targets.find((t) => t.id === e.id) ? { ...e, locked: false } : e)),
        ),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Move to Top (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...selected, ...rest];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      menuItem(`Move to Bottom (${n})`, () =>
        applyToTargets((lo) => {
          //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
          const selected = lo.filter((e) => targets.find((t) => t.id === e.id) && !isLocked(e));
          const rest = lo.filter((e) => !isLocked(e) && !targets.find((t) => t.id === e.id));
          const reordered = [...rest, ...selected];
          let next = 0;
          return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
        }),
      ),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Open LogicMods Folder (${n})`, () => {
        try {
          //LOGICMODS_PATH already ends in the folder for this game
          window.api.shell.openFile(path.join(GAME_PATH, LOGICMODS_PATH));
        } catch (err) {
          api.showErrorNotification("Failed to open the file or folder", err, {
            allowReport: false,
          });
        }
        onClose();
      }),
      React.createElement("div", { style: sepStyle }),
      menuItem(`Disable Selected (${n})`, () => {
        const modIds = targets.filter((e) => e.modId !== undefined).map((e) => e.modId);
        if (modIds.length > 0) {
          actions.setModsEnabled(api, profileId, modIds, false, { allowAutoDeploy: true });
        }
        onClose();
      }),
    );
  }

  const modPageUrl = getModPageURL(api, item.modId);
  const stagingFolder = getModStagingFolder(api, item.modId);

  return React.createElement(
    "div",
    { ref: clampRef, style: menuStyle },
    menuItem(isEntryLocked ? "Unlock Position" : "Lock Position", () =>
      applyToTargets((lo) =>
        lo.map((e) => (e.id === item.id ? { ...e, locked: !isEntryLocked } : e)),
      ),
    ),
    React.createElement("div", { style: sepStyle }),
    menuItem("Move to Top", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...moved, ...rest];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    menuItem("Move to Bottom", () =>
      applyToTargets((lo) => {
        if (isLocked(item)) return lo;
        //Locked entries hold their absolute index - only the unlocked entries reorder into the slots between them
        const moved = lo.filter((e) => !isLocked(e) && e.id === item.id);
        const rest = lo.filter((e) => !isLocked(e) && e.id !== item.id);
        const reordered = [...rest, ...moved];
        let next = 0;
        return lo.map((e) => (isLocked(e) ? e : reordered[next++]));
      }),
    ),
    React.createElement("div", { style: sepStyle }),
    menuItem("Open LogicMods Folder", () => {
      try {
        //LOGICMODS_PATH already ends in the folder for this game
        window.api.shell.openFile(path.join(GAME_PATH, LOGICMODS_PATH));
      } catch (err) {
        api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
      }
      onClose();
    }),
    stagingFolder
      ? menuItem("Open Staging Folder", () => {
          try {
            window.api.shell.openFile(stagingFolder);
          } catch (err) {
            api.showErrorNotification("Failed to open the file or folder", err, {
              allowReport: false,
            });
          }
          onClose();
        })
      : null,
    modPageUrl
      ? menuItem("Open Mod Page", () => {
          try {
            window.api.shell.openUrl(modPageUrl);
          } catch (err) {
            api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
          }
          onClose();
        })
      : null,
    item.modId ? React.createElement("div", { style: sepStyle }) : null,
    item.modId
      ? menuItem(isModEnabled ? "Disable Vortex Mod" : "Enable Vortex Mod", () => {
          actions.setModsEnabled(api, profileId, [item.modId], !isModEnabled, {
            allowAutoDeploy: true,
          });
          onClose();
        })
      : null,
  );
}

function LogicModsLoadOrderInfoPanel() {
  return React.createElement(
    "div",
    {
      id: "logicmods-loadorderinfo",
      style: { padding: "12px", borderTop: "1px solid rgba(255,255,255,0.1)" },
    },
    React.createElement(
      "h2",
      { style: { marginTop: 0, display: "flex", alignItems: "center", gap: 10 } },
      React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          style: { width: 28, height: 28, fill: "currentColor", flexShrink: 0 },
        },
        React.createElement("path", { d: BLUEPRINT_ICON }),
      ),
      React.createElement(
        "span",
        null,
        React.createElement("span", { style: { fontWeight: "bold" } }, "LogicMods"),
        React.createElement(
          "span",
          { style: { fontWeight: 300, color: "rgba(255,255,255,0.65)" } },
          " Blueprint Pak Load Order",
        ),
      ),
    ),
    React.createElement(
      "ul",
      { style: { margin: 0, paddingLeft: 20, listStyleType: "disc" } },
      React.createElement(
        "li",
        null,
        "Drag and drop mods to change the order in which BPModLoaderMod loads Blueprint paks. Changes write to load_order.txt immediately.",
      ),
      React.createElement(
        "li",
        null,
        'Use the "Disable" button to disable the underlying Vortex mod. Deploy after disabling to remove the pak from the LogicMods folder.',
      ),
      React.createElement(
        "li",
        null,
        "Paks not listed in load_order.txt still load, but in random order after the listed ones.",
      ),
      React.createElement(
        "li",
        { style: { fontStyle: "italic", color: "yellow", fontWeight: "bold" } },
        "Note: This page manages LogicMods/Blueprint paks only. UE4SS script/DLL mod load order is managed on the UE4SS Load Order page.",
      ),
    ),
  );
}

function LogicModsLoadOrderPage({ api }) {
  const { useSelector, useDispatch } = require("react-redux");
  const { FormControl } = require("react-bootstrap");

  const profileId = useSelector((state) => selectors.activeProfile(state)?.id);
  const loadOrder = useSelector(
    (state) => state?.persistent?.logicModsLoadOrder?.[profileId]?.loadOrder ?? [],
  );
  const modState = useSelector((state) => state?.persistent?.profiles?.[profileId]?.modState ?? {});
  const dispatch = useDispatch();
  const [filterText, setFilterText] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState(new Set());
  const [selectedIds, setSelectedIds] = React.useState(new Set());
  const [contextMenu, setContextMenu] = React.useState(null);

  React.useEffect(() => {
    if (!profileId) return;
    if (selectors.activeGameId(api.getState()) !== GAME_ID) return;
    deserializeLogicMods(api)
      .then((lo) => dispatch(setLogicModsLoadOrder(profileId, lo)))
      .catch((err) => log("warn", `[${GAME_ID}] LogicMods load order refresh failed`, err));
    setSelectedIds(new Set());
  }, [profileId]);

  useInjectStyleOnce("lo-index-focus-style", LO_INDEX_FOCUS_CSS);

  const isFiltered = !!filterText || statusFilter.size > 0;
  const isEntryEnabled = (e) => modState?.[e.modId]?.enabled ?? false;
  const isEntryLocked = (e) => [true, "true", "always"].includes(e?.locked);

  const onApply = React.useCallback(
    (reordered) => {
      let newLO;
      if (isFiltered) {
        const filteredIds = new Set(reordered.map((e) => e.id));
        const positions = loadOrder.reduce((acc, e, i) => {
          if (filteredIds.has(e.id)) acc.push(i);
          return acc;
        }, []);
        newLO = [...loadOrder];
        positions.forEach((pos, i) => {
          newLO[pos] = reordered[i];
        });
      } else {
        newLO = reordered;
      }
      dispatch(setLogicModsLoadOrder(profileId, newLO));
      serializeLogicMods(api, newLO);
    },
    [dispatch, loadOrder, isFiltered, profileId],
  );

  const filteredOrder = loadOrder.filter(
    (e) =>
      (!filterText || (e.name ?? e.id).toLowerCase().includes(filterText.toLowerCase())) &&
      matchesStatus(e, statusFilter, isEntryEnabled, isEntryLocked),
  );

  const allIds = filteredOrder.map((e) => e.id);

  if (!loadOrder.length) {
    return React.createElement(
      MainPage,
      null,
      React.createElement(
        MainPage.Body,
        null,
        React.createElement(
          "p",
          { style: { padding: "12px", fontWeight: "bold", color: "yellow" } },
          "No LogicMods/Blueprint pak mods are installed.",
        ),
      ),
    );
  }

  return React.createElement(
    MainPage,
    null,
    React.createElement(
      MainPage.Header,
      null,
      React.createElement(
        "div",
        { style: { display: "flex", alignItems: "center", width: "100%" } },
        React.createElement(FormControl, {
          type: "search",
          placeholder: "Filter mods...",
          className: "file-based-load-order-filter",
          style: { flex: 1 },
          value: filterText,
          onChange: (evt) => setFilterText(evt.target.value),
        }),
        React.createElement(LoadOrderStatusFilter, {
          active: statusFilter,
          setActive: setStatusFilter,
          groups: ["enabled", "locked", "unmanaged"],
          count:
            statusFilter.size > 0
              ? { matched: filteredOrder.length, total: loadOrder.length }
              : null,
        }),
      ),
    ),
    React.createElement(
      MainPage.Body,
      null,
      React.createElement(
        DNDContainer,
        { style: { height: "95%" } },
        React.createElement(
          FlexLayout,
          {
            type: "column",
            className: "file-based-load-order-container",
            style: { height: "100%" },
          },
          React.createElement(
            FlexLayout.Flex,
            { className: "file-based-load-order-list", style: { overflowY: "auto", minHeight: 0 } },
            React.createElement(
              LogicModsSelectionContext.Provider,
              { value: { selectedIds, setSelectedIds, allIds, contextMenu, setContextMenu } },
              React.createElement(DraggableList, {
                itemTypeId: `${GAME_ID}-logicmods-lo-entry`,
                id: `${GAME_ID}-logicmods-loadorder-list`,
                items: filteredOrder,
                itemRenderer: LogicModsItemRenderer,
                apply: onApply,
                idFunc: (entry) => entry.id,
                isLocked: (item) => [true, "true", "always"].includes(item?.locked),
              }),
            ),
          ),
          React.createElement(
            "div",
            { style: { flexShrink: 0 } },
            React.createElement(LogicModsLoadOrderInfoPanel),
          ),
        ),
      ),
    ),
  );
} //*/

//Read-only view of UE4SS + LogicMods load order data exported with a collection (collection workshop tab)
function CollectionsDataView({ t, collection }) {
  const { useSelector } = require("react-redux");
  const { ListGroup, ListGroupItem } = require("react-bootstrap");

  const profileId = useSelector((state) => selectors.lastActiveProfileForGame(state, GAME_ID));
  const ue4ssLO = useSelector(
    (state) => state?.persistent?.ue4ssLoadOrder?.[profileId]?.loadOrder ?? [],
  );
  const logicLO = useSelector(
    (state) => state?.persistent?.logicModsLoadOrder?.[profileId]?.loadOrder ?? [],
  );

  const isInCollection = (entry) =>
    entry.modId !== undefined &&
    (collection?.rules ?? []).some((rule) => rule.reference?.id === entry.modId);
  const ue4ssFiltered = ue4ssLoadOrder ? ue4ssLO.filter(isInCollection) : [];
  const logicFiltered = logicModsLoadOrder ? logicLO.filter(isInCollection) : [];

  const renderSection = (title, entries, showEnabled) =>
    React.createElement(
      "div",
      { style: { marginBottom: 16 } },
      React.createElement("h4", null, t(title)),
      entries.length > 0
        ? React.createElement(
            ListGroup,
            null,
            entries.map((entry, idx) =>
              React.createElement(
                ListGroupItem,
                { key: entry.id },
                React.createElement(
                  "span",
                  { style: { marginRight: 8, color: "rgba(255,255,255,0.5)" } },
                  `${idx + 1}.`,
                ),
                React.createElement("span", null, entry.name ?? entry.id),
                showEnabled && entry.enabled === false
                  ? React.createElement(
                      "span",
                      {
                        style: {
                          marginLeft: 8,
                          fontStyle: "italic",
                          color: "rgba(255,255,255,0.5)",
                        },
                      },
                      t("(disabled)"),
                    )
                  : null,
              ),
            ),
          )
        : React.createElement(
            "p",
            { style: { fontStyle: "italic" } },
            t("No mods of this type from this collection are in the load order."),
          ),
    );

  return React.createElement(
    "div",
    { style: { overflow: "auto", padding: "8px" } },
    React.createElement(
      "p",
      null,
      t(
        "This is a snapshot of the UE4SS and LogicMods load order information that will be exported with this collection.",
      ),
    ),
    ue4ssLoadOrder ? renderSection("UE4SS Mods (mods.txt)", ue4ssFiltered, true) : null,
    logicModsLoadOrder ? renderSection("LogicMods/Blueprint Mods", logicFiltered, false) : null,
  );
}

//export to Vortex
module.exports = {
  default: main,
};
