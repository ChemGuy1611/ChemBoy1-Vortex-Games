# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.1.1] - 2026-01-07

- Removed "~mods" folder from the pak mod path as some mods apparently don't work from that folder.
- Disabled Load Ordering so that paks are not in subfolders.

## [0.1.0] - 2026-01-04

- Initial release
