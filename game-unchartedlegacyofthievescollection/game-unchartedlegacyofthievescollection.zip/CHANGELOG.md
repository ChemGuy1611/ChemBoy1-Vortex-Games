# Changelog

## [0.3.4] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [0.3.3] - 2026-10-16

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Added the game's Nexus Mods ID to the extension's info file.

## [0.3.2] - 2026-08-11

- Added GOG support

## [0.3.1] - 2026-08-11

- Added Epic Games Store support

## [0.3.0] - 2026-08-03

- Fixed: Readme and changelog files inside mods no longer show up as file conflicts.
- Fixed: Paths are now built safely on all systems.
- Added: Buttons to open the game's PCGamingWiki page, view the changelog, submit a bug report, and open the downloads folder.

## [0.2.0]

- Added notification for running FMM after mod deployment
- Removed an obsolete parameter that caused downloading updates from the Moddding Tools domain, including Fluffy MM, to fail with wrong URL
