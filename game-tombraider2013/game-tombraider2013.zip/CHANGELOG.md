# Changelog

## Future Changes (Not Implemented Yet)

- None Planned

## [0.5.0] - 2025-10-29

- Improved handling of Mod Manager mods.
- Fixed Xbox game version detection.

## [0.4.3] - 2025-06-01

- Fixed reference error when using button to open Downloads folder

## [0.4.2] - 2025-04-24

- Fixed TR Reboot Mod Manager mod installer to ensure mods always have a top-level folder
- Added buttons to open "Logs and Crash Dumps" and Downloads folders and to view the changelog - folder icon on Mods toolbar

## [0.4.1]

- Added an installer for mods intended for the TR Reboot Mod Manager that did not include a top-level folder above the modified files.
- Added notification to run TR Reboot Mod Manager after deployment

## [0.4.0]

- Integrated new TR2013 Modding Tools mod manager

## [0.3.0]

- Improved TexMod support for DX9 version
- Updated requiresLauncher function
