# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.0] - 2026-04-08

- Initial release
