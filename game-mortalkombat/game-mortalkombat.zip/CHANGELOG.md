# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None

## [0.2.0] - 2026-01-07

- Changed Signature Bypass method to MK12TTH mod <https://www.nexusmods.com/mortalkombat/mods/62?tab=files>.
- Added Xbox version support
- Fixed issue with Load Order sorting of legacy pak mods not working if certain other UE game extensions were installed. You will need to reinstall all legacy pak mods to be able to sort them properly. A notification will be sent reminding you to do this.
- Added notification indicating deployment is required after changing the load order.
- Technical fixes and improvements.
