# Changelog

## [1.0.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.11.5] - 2026-10-12

- Added check for if sp-common.psarc and bin.psarc files exist in the game folder (indicator of update and need to extract).
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: After mods were purged, the next deploy left modloader.ini and chunks.txt empty until the load order was changed. The load order is now written back on that deploy.

## [0.11.4] - 2026-09-06

- Fixed: Locked load order entries could be moved out of position when using "Move to Top", "Move to Bottom" or the position number box on another entry. Locked entries now keep their place.
- Fixed: The load order position number box now accepts low numbers even when a locked entry is further down the list.

## [0.11.3] - 2026-09-04

- Added: Right-click menu on the load order: enable or disable an entry, lock or unlock it, move it to the top or bottom, and open its staging folder or mod page. Works on one entry or several at once.
- Added: Lock button on each load order row, plus ctrl/shift multi-select.
- Added: Load order filter by status (enabled, disabled, locked, unlocked, unmanaged) with a matched/total count.
- Added: Load order entries for mods Vortex does not manage are now marked "Not managed by Vortex".
- Fixed: A locked load order entry no longer unlocks itself after deploying or reopening the load order page.
- Fixed: Opening the load order on a fresh install could fail with a "file doesn't exist" error for modloader.ini. Saving the order also did nothing when that file had no MountOrder line; the line is now added.

## [0.11.2] - 2026-07-29

- Fixed: The load order could disappear after deploying while a mod update was in progress, and only came back after deploying a second time.
- Added: A message now appears if you change the load order while a mod update is still finishing, so it is clear the change was not applied and needs to be made again.
- Fixed: After a mod update finished, the load order page could keep showing out-of-date information until another deployment was run.

## [0.11.1] - 2026-07-25

- Fixed: Using "Update all" to update several mods at once could move them in the load order or uncheck them.

## [0.11.0] - 2026-07-22

- Fixed: Updating a mod could uncheck it or move it in the load order, especially on profiles other than the one you were using.

## [0.10.1] - 2026-07-19

- Removed: Deprecated downloader module. All requirements are downloaded from Nexus Mods.

## [0.10.0] - 2026-06-24

- Improved: Refactored downloader.js GitHub downloader/updater for Vortex v2.0+ and more reliable operation.

## [0.9.0] - 2026-05-05

- Added: Selection dialogue when a mod archive contains multiple .psarc files
- Fixed: Crash that could occur on purge if load order file does not exist

## [0.8.0] - 2026-04-22

- Improved: Load Order rendering using React - show mod image thumbnails

## [0.7.1] - 2026-02-12

- Fixed: Crash on undefined "err" variable if file extraction process fails

## [0.7.0] - 2026-02-11

- Fixed: Several technical fixes and improvements

## [0.6.2] - 2026-01-19

- Fixed: More reliable folder deletion operations - revised deprecated fsPromises.rmdir function to fsPromises.rm
- Added: Full Epic version support

## [0.6.1] - 2025-07-14

- Slight optimization to the load order code.
- Mods will now maintain their load order position when updating. Thanks to infarctus.
- Updated bundled ndarc executable to v220.

## [0.6.0] - 2025-04-14

- Extension now writes .psarc mod file names from the "mods" folder to chunks.txt file automatically, based on the load order.
- Updated bundled ndarc executable to v190.
- Added button to open chunks.txt file - folder icon in Mods toolbar.

## [0.5.2] - 2025-04-09

- Updated bundled ndarc executable to v185.
- Removed some unused code.

## [0.5.1] - 2025-04-09

- Fixed reference error when sending an error notification if .psarc file extraction was not completed.
- Improved check for whether .psarc extraction was successful.
- Added check for extracted folders presence before sending notification to extract .psarc files.

## [0.5.0] - 2025-04-06

- Added load ordering for .psarc files in the Mod Loader's "mods" folder. Load Order is stored in the modloader.ini file.

## [0.4.1] - 2025-04-06

- Added a notification while .psarc extraction is running.
- Fixed some typos.

## [0.4.0] - 2025-04-06

- Changed .psarc extraction tool to ndarc, which will be downloaded automatically for the user.
- Added support for the new mod loader, which will be downloaded automatically for the user.
- .psarc mods will be installed to the "mods" folder for the mod loader.

## [0.3.0] - 2025-04-04

- Completed automation of .psarc extraction.
- Added functions to clean out extracted .psarc files to "reset" mods on purge.
- Corrected Config path.
- UnPSARC is now also bundled with the extension so it can run when mods are purged.

## [0.2.4] - 2025-04-04

- Fixed extraction path for bin.psarc to "bin" folder.

## [0.2.3] - 2025-04-04

- Fixed .psarc extraction so files are not extracted into a subfolder.

## [0.2.2] - 2025-04-04

- Switched .psarc extraction tool to UnPSARC (<https://github.com/rm-NoobInCoding/UnPSARC>) since it has support for .psarc files without oodle compression and runs much faster.
- Added notification with a button to run UnPSARC to extract .psarc files (sp-common.psarc and bin.psarc).
- Added button to run .psarc extraction - folder icon in Mods toolbar.

## [0.2.1] - 2025-04-04

- Corrected game ID to match Nexus domain.
- Fixed typo in RegEx for archive name matching when checking for updates to U4.PSARC.Tool.

## [0.2.0] - 2025-04-03

- Added automatic download of U4.PSARC.Tool

## [0.1.0] - 2025-04-03

- Initial release
