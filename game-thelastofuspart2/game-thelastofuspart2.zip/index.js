/*////////////////////////////////////////////////
Name: The Last of Us Part II Remastered Vortex Extension
Author: ChemBoy1
Structure: Generic Game w/ File Extraction, Mod Loader, and Load Order
Version: 0.11.2
Date: 2026-07-29
////////////////////////////////////////////////*/

//Import libraries
const { actions, fs, util, selectors, log } = require('vortex-api');
const path = require('path');
const template = require('string-template');
const fsPromises = require('fs/promises');
const React = require('react');

//Specify all information about the game
const STEAMAPP_ID = "2531310";
const EPICAPP_ID = "831cd8c0c25b4615ade419ecb4f50e42";
const GAME_ID = "thelastofuspart2";
const GAME_NAME = "The Last of Us Part II Remastered";
const GAME_NAME_SHORT = "TLOU Part II";
const EXEC = "launcher.exe";
const MOD_PATH_DEFAULT = path.join(".");
let GAME_PATH = '';
let GAME_VERSION = ''; //Game version
let STAGING_FOLDER = '';
let DOWNLOAD_FOLDER = '';
let LOAD_ORDER_ENABLED = true;
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/The_Last_of_Us_Part_II_Remastered";
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1250"; //Nexus link to this extension. Used for links

const IGNORE_CONFLICTS = [path.join('**', 'modinfo.ini'), path.join('**', 'Preview.png'), path.join('**', 'screenshot.png'), path.join('**', 'screenshot.jpg'), path.join('**', 'readme.txt'), path.join('**', 'README.txt'), path.join('**', 'ReadMe.txt'), path.join('**', 'Readme.txt')];
const IGNORE_DEPLOY = [path.join('**', 'modinfo.ini'), path.join('**', 'Preview.png'), path.join('**', 'readme.txt'), path.join('**', 'README.txt'), path.join('**', 'ReadMe.txt'), path.join('**', 'Readme.txt')];

//Info for mod types and installers
const USER_HOME = util.getVortexPath("home");
const DOCUMENTS = util.getVortexPath("documents");

const BUILD_ID = `${GAME_ID}-buildfolder`;
const BUILD_NAME = "Build Folder";
const BUILD_FOLDER = "build";
const BUILD_PATH = path.join(".");

const BIN_ID = `${GAME_ID}-binfolder`;
const BIN_NAME = "bin Folder";
const BIN_FOLDER = "bin";
const BIN_PATH = path.join(BUILD_FOLDER, "pc", "main");
const MAIN_PATH = path.join(BUILD_FOLDER, "pc", "main");
const BIN_EXT = ".bin";

const PAK_ID = `${GAME_ID}-pak`;
const PAK_NAME = "Pak (actor97)";
const PAK_EXT = ".pak";
const PAK_FOLDER = "actor97";
const PAK_PATH = path.join(BUILD_FOLDER, "pc", "main");

const MODLOADER_ID = `${GAME_ID}-modloader`;
const MODLOADER_NAME = "ND Mod Loader";
const MODLOADER_PATH = path.join(".");
const MODLOADER_FILE = "winmm.dll";
const MODLOADER_PAGE_NO = 32;
const MODLOADER_FILE_NO = 122;

const LO_FILE = "modloader.ini";
const LO_LINE_START = "MountOrder=";
const LO_ATTRIBUTE = 'psarcFiles';
const CHUNKS_FILE = "chunks.txt";
const CHUNKS_PATH = path.join(MAIN_PATH, CHUNKS_FILE);
const CHUNKS_START_LINE = 38;
const CHUNKS_DEFAULT_CONTENT = `common 0
epic 1
sp-common 2
steam 3
world-abby-ellie-fight 4
world-abby-fights-militia 5
world-abby-flashback-dad 6
world-amputation 7
world-cutting-room 8
world-ellie-flashback-museum 9
world-ellie-flashback-patrol 10
world-ellie-flashback-ultimatum 11
world-epilogue 12
world-farm 13
world-find-aquarium 14
world-find-nora 15
world-flashback-guitar 16
world-flooded-city 17
world-forward-base 18
world-game-start 19
world-guitar-freeplay 20
world-jordan-escape 21
world-medicine 22
world-patrol 23
world-patrol-chalet 24
world-patrol-departure 25
world-patrol-jackson 26
world-rescue-jesse 27
world-rogue 28
world-santa-barbara 29
world-save-lev 30
world-saving-kids 31
world-seattle-arrival 32
world-theater 33
world-theater-ambush 34
world-tracking 35
world-tracking-horde 36
world-watchtower 37
`;

// for mod update to keep them in the load order and not uncheck them
let mod_update_all_profile = false;
let updateModIds = new Map(); // Nexus mod id -> {firstSeen, targetFileId} (Map, not scalar, so batch updates don't clobber each other)
const MAX_UPDATE_WAIT_MS = 5 * 60 * 1000; // release the guard for an update that never lands (cancelled or failed install)
let updating_mod = false; // used to see if it's a mod update or not
let mod_install_name = ""; // used to display the name of the currently installed mod

const PSARC_ID = `${GAME_ID}-psarc`;
const PSARC_NAME = ".psarc (Mod Loader)";
const PSARC_PATH = path.join("mods");
const PSARC_EXT = ".psarc";

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = "Save";
const SAVE_FOLDER = path.join(DOCUMENTS, "The Last of Us Part II");
let USERID_FOLDER = "";
function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}
try {
  const SAVE_ARRAY = fs.readdirSync(SAVE_FOLDER);
  USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_FOLDER, entry));
} catch {
  USERID_FOLDER = "";
}
if (USERID_FOLDER === undefined) {
  USERID_FOLDER = "";
} //*/
const SAVE_PATH = path.join(SAVE_FOLDER, USERID_FOLDER, "savedata");
const SAVE_FILE = "USR-DATA";

const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_NAME = "Config";
const CONFIG_PATH = path.join(USER_HOME, "SOFTWARE", "Naughty Dog", "The Last of Us Part II");
const CONFIG_FILE = "screeninfo.cfg";

const PSARCTOOL_ID = `${GAME_ID}-psarctoolndarc`;
const PSARCTOOL_NAME = "ndarc Tool";
const PSARCTOOL_EXEC = "ndarc.exe";
const PSARCTOOL_EXT_PATH = 'ndarc';
const PSARCTOOL_PAGE_NO = 31;
const PSARCTOOL_FILE_NO = 107;
/*const PSARCTOOL_NAME = "UnPSARC Tool";
const PSARCTOOL_EXEC = "UnPSARC.exe";
const PSARCTOOL_EXT_PATH = 'UnPSARC'; //*/
const PSARCTOOL_PATH = path.join(BUILD_FOLDER, "pc", "main");
const SPCOMPSARC_FILE = "sp-common.psarc";
const BAK_SPCOMPSARC_FILE = "sp-common.psarc.bak";
const SPCOMPSARC_PATH = path.join(BUILD_FOLDER, "pc", "main", SPCOMPSARC_FILE);
const BINPSARC_FILE = "bin.psarc";
const BAK_BINPSARC_FILE = "bin.psarc.bak";
const BINPSARC_PATH = path.join(BUILD_FOLDER, "pc", "main", BINPSARC_FILE);
const VANILLA_FOLDERS = ["boot1", "movie1", "speech1", "tts1"];
const CLEANUP_FOLDERS = ["actor97", "animstream97", "bin", "irpack3", "pak68", "sfx1", "soundbank4", "texturedict3"];

const PSARC_FILES_ARRAY = [
  { //sp-common.psarc
    fileName: SPCOMPSARC_FILE,
    backupName: BAK_SPCOMPSARC_FILE,
    extractTo: ".",
  },
  { //bin.psarc
    fileName: BINPSARC_FILE,
    backupName : BAK_BINPSARC_FILE,
    extractTo: BIN_FOLDER,
  },
];

const LO_IMAGE_WIDTH = 96; //Width of the load order thumbnail image
const LO_IMAGE_HEIGHT = LO_IMAGE_WIDTH * 0.5625;

// FILLED IN FROM DATA ABOVE
const spec = {
  "game": {
    "id": GAME_ID,
    "name": GAME_NAME,
    "shortName": GAME_NAME_SHORT,
    "executable": EXEC,
    "logo": `${GAME_ID}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPath": MOD_PATH_DEFAULT,
    "modPathIsRelative": true,
    "requiredFiles": [
      EXEC
    ],
    "details": {
      "steamAppId": +STEAMAPP_ID,
      "epicAppId": EPICAPP_ID,
      //"ignoreDeploy": IGNORE_DEPLOY,
      "ignoreConflicts": IGNORE_CONFLICTS,
    },
    "environment": {
      "SteamAPPId": STEAMAPP_ID,
      "EpicAPPId": EPICAPP_ID,
    }
  },
  "modTypes": [
    {
      "id": PSARC_ID,
      "name": PSARC_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', PSARC_PATH)
    },
    {
      "id": BUILD_ID,
      "name": BUILD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BUILD_PATH)
    },
    {
      "id": BIN_ID,
      "name": BIN_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BIN_PATH)
    },
    {
      "id": PAK_ID,
      "name": PAK_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', PAK_PATH)
    },
    {
      "id": SAVE_ID,
      "name": SAVE_NAME,
      "priority": "high",
      "targetPath": SAVE_PATH
    },
    {
      "id": CONFIG_ID,
      "name": CONFIG_NAME,
      "priority": "high",
      "targetPath": CONFIG_PATH
    },
    {
      "id": PSARCTOOL_ID,
      "name": PSARCTOOL_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', PSARCTOOL_PATH)
    },
    {
      "id": MODLOADER_ID,
      "name": MODLOADER_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', MODLOADER_PATH)
    },
  ],
  "discovery": {
    "ids": [
      STEAMAPP_ID,
      EPICAPP_ID,
    ],
    "names": []
  }
};

//3rd party tools and launchers
const tools = [
  {
    id: PSARCTOOL_ID,
    name: PSARCTOOL_NAME,
    //logo: "psarctool.png",
    executable: () => PSARCTOOL_EXEC,
    requiredFiles: [PSARCTOOL_EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    parameters: [],
  }, //*/
  {
    id: `${GAME_ID}-customlaunch`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC,
    requiredFiles: [EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    parameters: []
  }, //*/
];

//Set mod type priorities
function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}

async function statCheckAsync(gamePath, file) {
  try {
    await fs.statAsync(path.join(gamePath, file));
    return true;
  }
  catch {
    return false;
  }
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fs.readdirAsync(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fs.statAsync(fullPath);
      if (stats.isDirectory()) { // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else { // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log('warn', `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Convert path placeholders to actual values
function pathPattern(api, game, pattern) {
  var _a;
  return template(pattern, {
    gamePath: (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0 ? void 0 : _a.path,
    documents: util.getVortexPath('documents'),
    localAppData: util.getVortexPath('localAppData'),
    appData: util.getVortexPath('appData'),
  });
}

//Set mod path
function makeGetModPath(api, gameSpec) {
  return () => gameSpec.game.modPathIsRelative !== false
    ? gameSpec.game.modPath || '.'
    : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () => util.GameStoreHelper.findByAppId(gameSpec.discovery.ids)
    .then((game) => game.gamePath);
}

async function requiresLauncher(gamePath, store) {
  if (store === 'epic') {
    return Promise.resolve({
        launcher: 'epic',
        addInfo: {
            appId: EPICAPP_ID,
        },
    });
  } //*/
  return Promise.resolve(undefined);
}

const getDiscoveryPath = (api) => {
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, GAME_ID], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  return new Promise((resolve, reject) => api.events.emit('purge-mods', true, (err) => err ? reject(err) : resolve()));
}
async function deploy(api) {
  return new Promise((resolve, reject) => api.events.emit('deploy-mods', (err) => err ? reject(err) : resolve()));
}

// AUTOMATIC INSTALLER FUNCTIONS /////////////////////////////////////////////////////////

/*
async function onCheckModVersion(api, gameId, mods, forced) {
  try {
    await testRequirementVersion(api, REQUIREMENTS[0]);
  } catch (err) {
    log('warn', `failed to test requirement version: ${err}`);
  }
}

async function checkForTool(api) {
  const mod = await REQUIREMENTS[0].findMod(api);
  return mod !== undefined;
} //*/

//Check if Mod Loader is installed
function isModLoaderInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === MODLOADER_ID);
}

//Check if PSARC Tool is installed
function isPsarcToolInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === PSARCTOOL_ID);
}

//* Function to auto-download Mod Enabler form Nexus Mods
async function downloadModLoader(api, gameSpec) {
  let isInstalled = isModLoaderInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = MODLOADER_NAME;
    const MOD_TYPE = MODLOADER_ID;
    const NOTIF_ID = `${GAME_ID}-${MOD_TYPE}-installing`;
    const PAGE_ID = MODLOADER_PAGE_NO;
    const FILE_ID = MODLOADER_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = gameSpec.game.id;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          //throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
          throw new Error(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = {
        game: GAME_DOMAIN, // always set to the game's ID so user wil not get a game selection popup. Vortex will update the metadata automatically if the mod is from another domain, such as 'site'
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions.
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Function to auto-download Mod Enabler form Nexus Mods
async function downloadPsarcTool(api, gameSpec) {
  let isInstalled = isPsarcToolInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = PSARCTOOL_NAME;
    const MOD_TYPE = PSARCTOOL_ID;
    const NOTIF_ID = `${GAME_ID}-${MOD_TYPE}-installing`;
    const PAGE_ID = PSARCTOOL_PAGE_NO;
    const FILE_ID = PSARCTOOL_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = gameSpec.game.id;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          //throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
          throw new Error(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = {
        game: GAME_DOMAIN, // always set to the game's ID so user wil not get a game selection popup. Vortex will update the metadata automatically if the mod is from another domain, such as 'site'
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions.
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for Fluffy Mod Manager files
function testModLoader(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === MODLOADER_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Fluffy Mod Manger files
function installModLoader(files) {
  const modFile = files.find(file => (path.basename(file) === MODLOADER_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MODLOADER_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for .pak or .bin files in "build" folder
function testBuildPakBin(files, gameId) {
  const isBuild = files.some(file => (path.basename(file) === BUILD_FOLDER));
  const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  const isBin = files.some(file => (path.extname(file).toLowerCase() === BIN_EXT));
  let supported = (gameId === spec.game.id) && isBuild && ( isPak || isBin );

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install .pak or .bin files in "build" folder
function installBuildPakBin(files, fileName) {
  const modFile = files.find(file => (path.basename(file) === BUILD_FOLDER));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: BUILD_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for  "bin" folder
function testBin(files, gameId) {
  const isBinFolder = files.some(file => (path.basename(file) === BIN_FOLDER));
  /*const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  const isBin = files.some(file => (path.extname(file).toLowerCase() === BIN_EXT));
  let supported = (gameId === spec.game.id) && isBinFolder && ( isPak || isBin ); //*/
  let supported = (gameId === spec.game.id) && isBinFolder;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install "bin" folder
function installBin(files, fileName) {
  const modFile = files.find(file => (path.basename(file) === BIN_FOLDER));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: BIN_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for psarc files
function testPsarc(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === PSARC_EXT));
  const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  const isBin = files.some(file => (path.extname(file).toLowerCase() === BIN_EXT));
  let supported = (gameId === spec.game.id) && isMod && !isPak && !isBin;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer Install psarc files
async function installPsarc(api, files) {
  const setModTypeInstruction = { type: 'setmodtype', value: PSARC_ID };
  const PSARC_FILES = files.filter(file => (path.extname(file).toLowerCase() === PSARC_EXT));
  const installFiles = (PSARC_FILES.length > 1)
    ? await chooseFilesToInstall(api, PSARC_FILES)
    : PSARC_FILES;
  //set a mod attribute to find the mod name in deserializeLoadOrder
  const MOD_ATTRIBUTE = {
    type: 'attribute',
    key: LO_ATTRIBUTE,
    value: installFiles.map(f => path.basename(f)),
  };

  const instructions = installFiles.map(file => ({
    type: 'copy',
    source: file,
    destination: path.basename(file),
  }));
  instructions.push(setModTypeInstruction);
  instructions.push(MOD_ATTRIBUTE);
  return Promise.resolve({ instructions });
}

async function chooseFilesToInstall(api, files) {
  const t = api.translate;
  return api.showDialog('question', t('Multiple .psarc Files Found'), {
    text: t('The mod you are installing contains {{x}} .psarc files. ', { replace: { x: files.length } })
        + `This may mean the author intended for you to choose one of several options. `
        + `Please select which files to install below:`,
    checkboxes: files.map((file) => ({
      id: file,
      text: file,
      value: false,
    })),
  }, [
    { label: 'Cancel' },
    { label: 'Install Selected' },
    { label: 'Install All_plural' },
  ]).then((result) => {
    if (result.action === 'Cancel')
      return Promise.reject(new util.UserCanceled('User cancelled.'));
    else {
      const installAll = (result.action === 'Install All' || result.action === 'Install All_plural');
      const installFiles = installAll ? files : Object.keys(result.input).filter(s => result.input[s])
        .map(file => files.find(f => f === file));
      return installFiles;
    }
  });
}

//Installer test for pak files in root folder
function testPak(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer Install pak files in root folder
function installPak(files, fileName) {
  const modFile = files.find(file => (path.extname(file).toLowerCase() === PAK_EXT));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: PAK_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(PAK_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for "build" folder (non-Fluffy)
function testBuild(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === BUILD_FOLDER));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install "build" folder (non-Fluffy)
function installBuild(files) {
  const modFile = files.find(file => (path.basename(file) === BUILD_FOLDER));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: BUILD_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for save files
function testSave(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === SAVE_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install save files
function installSave(files) {
  const modFile = files.find(file => (path.basename(file) === SAVE_FILE));
  const rootPath = path.dirname(modFile);
  let idx = modFile.indexOf(`${path.basename(rootPath)}${path.sep}`);
  const setModTypeInstruction = { type: 'setmodtype', value: SAVE_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for config files
function testConfig(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === CONFIG_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install config files
function installConfig(files) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === CONFIG_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: CONFIG_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Fluffy Mod Manager files
function testPsarcTool(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === PSARCTOOL_EXEC));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Fluffy Mod Manger files
function installPsarcTool(files) {
  const modFile = files.find(file => (path.basename(file) === PSARCTOOL_EXEC));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: PSARCTOOL_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

// LOAD ORDER FUNCTIONS ///////////////////////////////////////////////////////////////

//Reordering is ignored while a mod update is in flight: the deserializers below freeze the stored
//order and the serializers skip writing, so tell the user their change was not applied.
function notifyLoadOrderPaused(api, gameId) {
  api.sendNotification({
    id: `${gameId}-loadorder-update-paused`,
    type: 'warning',
    message: 'Load order changes are paused while a mod update finishes. Reorder again once it completes.',
    displayMS: 6000,
  });
}

async function deserializeLoadOrder(context) {
  //* on mod update for all profile it would cause the mod if it was selected to be unselected
  if (mod_update_all_profile) {
    //A mod update briefly removes and reinstalls mods, so rebuilding the order from disk right now
    //would drop their entries. Return the stored order untouched instead: positions are preserved
    //and the page keeps showing the real load order rather than a placeholder row.
    const updateState = context.api.getState();
    const updateProfileId = selectors.lastActiveProfileForGame(updateState, GAME_ID);
    return util.getSafe(updateState, ['persistent', 'loadOrder', updateProfileId], []);
  } //*/

  //Set basic information for load order paths and data
  let gameDir = getDiscoveryPath(context.api);
  if (gameDir === undefined) {
    return Promise.reject(new util.NotFound('Game not found'));
  }
  const mods = util.getSafe(context.api.store.getState(), ['persistent', 'mods', spec.game.id], {});
  let loadOrderPath = path.join(gameDir, LO_FILE);
  let loadOrderFile = await fs.readFileAsync(
    loadOrderPath,
    { encoding: "utf8", }
  );
  let loadOrderSplit = loadOrderFile.split("\n");
  let LO_LINE = loadOrderSplit.find(line => line.startsWith(LO_LINE_START)); //we are putting the list on one line. should be element [1], but doing find just in case that ever changes.
  LO_LINE = LO_LINE.replace(LO_LINE_START, '');
  let LO_MOD_ARRAY = LO_LINE.split(',');

  //Get all .psarc files from mods folder
  let modFolderPath = path.join(gameDir, PSARC_PATH);
  let modFiles = [];
  try {
    modFiles = await fs.readdirAsync(modFolderPath);
    modFiles = modFiles.filter((file) => (path.extname(file) === PSARC_EXT));
    modFiles.sort((a,b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  } catch {
    return Promise.reject(new Error('Failed to read .psarc "mods" folder'));
  }

  // Get readable mod name using attribute from mod installer
  async function getModName(file) {
    try {//find mod where atrribute (from installer) matches file in the load order
      const modMatch = Object.values(mods).find(mod => (util.getSafe(mods[mod.id]?.attributes, [LO_ATTRIBUTE], '').includes(file))); //find mod that includes the psarc file
      if (modMatch) {
        return modMatch.attributes.customFileName ?? modMatch.attributes.logicalFileName ?? modMatch.attributes.name;
      }
      return file;
    } catch {
      return file;
    }
  }

  // Get readable mod id using attribute from mod installer
  async function getModId(file) {
    try {//find mod where atrribute (from installer) matches file in the load order
      const modMatch = Object.values(mods).find(mod => (util.getSafe(mods[mod.id]?.attributes, [LO_ATTRIBUTE], '').includes(file))); //find mod that includes the psarc file
      if (modMatch) {
        return modMatch.id;
      }
      return undefined;
    } catch {
      return undefined;
    }
  }

  //Set load order
  let loadOrder = await LO_MOD_ARRAY
    .reduce(async (accumP, entry) => {
      const accum = await accumP;
      const file = entry;
      if (!modFiles.includes(file)) {
        return Promise.resolve(accum);
      }
      accum.push(
        {
          id: file,
          name: `${file.replace(PSARC_EXT, '')} (${await getModName(file)})`,
          modId: await getModId(file),
          enabled: true,
        }
      );
      return Promise.resolve(accum);
    }, Promise.resolve([]));

  //push new mod files to loadOrder
  for (let file of modFiles) {
    if (!loadOrder.find((mod) => (mod.id === file))) {
      loadOrder.push({
        id: file,
        name: `${file.replace(PSARC_EXT, '')} (${await getModName(file)})`,
        modId: await getModId(file),
        enabled: true,
      });
    }
  }

  return loadOrder;
}

//Write load order to files
async function serializeLoadOrder(context, loadOrder) {
  //* don't write if all profiles are being updated
  if (mod_update_all_profile) {
    notifyLoadOrderPaused(context.api, GAME_ID);
    return;
  } //*/

  let gameDir = getDiscoveryPath(context.api);
  if (gameDir === undefined) {
    return Promise.reject(new util.NotFound('Game not found'));
  }

  let loadOrderPath = path.join(gameDir, LO_FILE);
  let loadOrderFile = await fs.readFileAsync(
    loadOrderPath,
    { encoding: "utf8", }
  );
  let loadOrderSplit = loadOrderFile.split("\n");
  let LO_LINE = loadOrderSplit.find(line => line.startsWith(LO_LINE_START)); //we are putting the list on one line. should be element [1], but doing find just in case that ever changes.
  let index = loadOrderSplit.indexOf(LO_LINE);
  let loadOrderMapped = loadOrder
    .map((mod) => (mod.enabled ? mod.id : ``)); //this is used for chunks.txt also
  let loadOrderJoined = loadOrderMapped
    .filter((entry) => (entry !== ``))
    .join(",");
  loadOrderSplit[index] = LO_LINE_START + loadOrderJoined;

  //Write to chunks.txt file
  let chunksPath = path.join(gameDir, CHUNKS_PATH);
  let loadOrderName = loadOrderMapped
    .filter((entry) => (entry !== ``))
    .map((name) => (name.replace('.psarc', '')));
  const startLine = CHUNKS_START_LINE;
  for (let line = startLine; line < (startLine + loadOrderName.length); line++) {
    let offset = line - startLine; //offset to zero for indexing the array from the first element
    loadOrderName[offset] = `${loadOrderName[offset]} ${line}`;
  }
  let loadOrderJoinedChunks = loadOrderName.join(`\n`);
  await fs.writeFileAsync(
    chunksPath,
    CHUNKS_DEFAULT_CONTENT + loadOrderJoinedChunks,
    { encoding: "utf8" },
  );

  //write to modloader.ini file
  let loadOrderOutput = loadOrderSplit.join("\n");
  return fs.writeFileAsync(
    loadOrderPath,
    loadOrderOutput,
    { encoding: "utf8" },
  );
}

//remove load order list from modloader.ini on purge
async function clearModOrder(api) {
  let gameDir = getDiscoveryPath(api);
  if (gameDir === undefined) {
    return Promise.reject(new util.NotFound('Game not found'));
  }

  let loadOrderPath = path.join(gameDir, LO_FILE);
  try {
    await fs.statAsync(loadOrderPath);
  } catch (err) {
    return Promise.reject(err);
  }
  let loadOrderFile = await fs.readFileAsync(
    loadOrderPath,
    { encoding: "utf8", }
  );
  let loadOrderSplit = loadOrderFile.split("\n");
  let LO_LINE = loadOrderSplit.find(line => line.startsWith(LO_LINE_START)); //we are putting the list on one line. should be element [1], but doing find just in case that ever changes.
  let index = loadOrderSplit.indexOf(LO_LINE);
  loadOrderSplit[index] = LO_LINE_START; //set the line to the default "blank" text

  let loadOrderOutput = loadOrderSplit.join("\n");
  return fs.writeFileAsync(
    loadOrderPath,
    loadOrderOutput,
    { encoding: "utf8" },
  );
}

//remove load order list from chunks.txt on purge
async function clearChunksTxt(api) {
  let gameDir = getDiscoveryPath(api);
  if (gameDir === undefined) {
    return Promise.reject(new util.NotFound('Game not found'));
  }

  let chunksPath = path.join(gameDir, CHUNKS_PATH);
  return fs.writeFileAsync(
    chunksPath,
    `${CHUNKS_DEFAULT_CONTENT}`,
    { encoding: "utf8" },
  );
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

//Notify User of Setup instructions
async function setupNotify(api) {
  GAME_PATH = getDiscoveryPath(api);
  try {
    await fs.statAsync(path.join(GAME_PATH, PSARCTOOL_PATH, 'pak68'));
    log('warn', `Extracted folder found. Suppressing setup notification.`);
  }
  catch { //*/
    const NOTIF_ID = `${GAME_ID}-setup`;
    const MESSAGE = `Extract Vanilla .psarc Files with ${PSARCTOOL_NAME}`;
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      message: MESSAGE,
      allowSuppress: true,
      actions: [
        {
          title: 'Extract Game Files',
          action: (dismiss) => {
            psarcSetup(api);
            dismiss();
          },
        },
        {
          title: 'More',
          action: (dismiss) => {
            api.showDialog('question', MESSAGE, {
              text: 'For mods to work properly, you must extract the game files from the .psarc files and rename the .psarc files. This process must be done initially and after any game updates.\n'
                  + `Click the button below to run the ${PSARCTOOL_NAME} to extract the game files and rename the .psarc files.\n`
            }, [
                {
                  label: 'Extract Game Files', action: () => {
                    psarcSetup(api);
                    dismiss();
                  }
                },
                { label: 'Not Now', action: () => dismiss() },
                {
                  label: 'Never Show Again', action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  }
                },
              ]);
          },
        },
      ],
    });
  }
}

//Extract .psarc game files
async function psarcExtract(GAME_PATH, api) {
  let RUN_PATH = path.join(__dirname, PSARCTOOL_EXT_PATH, PSARCTOOL_EXEC);
  /*
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  const mods = state.persistent.mods[spec.game.id] || {};
  const modMatch = Object.values(mods).find(mod => mod.type === PSARCTOOL_ID);
  const EXEC_FOLDER = modMatch.installationPath;
  if (EXEC_FOLDER !== undefined) {
    //const RUN_PATH = path.join(GAME_PATH, PSARCTOOL_PATH, PSARCTOOL_EXEC);
    RUN_PATH = path.join(STAGING_FOLDER, EXEC_FOLDER, PSARCTOOL_EXEC);
  } //*/
  const WORK_PATH = path.join(GAME_PATH, PSARCTOOL_PATH);
  //extract sp-common.psarc
  try {
    const TARGET_FILE = path.join(WORK_PATH, SPCOMPSARC_FILE);
    const EXTRACT_PATH = WORK_PATH;
    await fs.statAsync(TARGET_FILE);
    //const ARGUMENTS = `"${TARGET_FILE}" "${EXTRACT_PATH}"`; //unPSARC arguments
    const ARGUMENTS = `-e "${TARGET_FILE}" -o "${EXTRACT_PATH}"`; //ndarc arguments
    await api.runExecutable(RUN_PATH, [ARGUMENTS], { shell: true, detached: true, suggestDeploy: false });
    log('warn', `Ran extraction for .psarc file ${SPCOMPSARC_FILE}`);
  } catch (err) {
    log('error', `Could not extract .psarc file ${SPCOMPSARC_FILE}: ${err}`);
    return false;
  }
  //extract bin.psarc
  try {
    const TARGET_FILE = path.join(WORK_PATH, BINPSARC_FILE);
    const EXTRACT_PATH = path.join(WORK_PATH, BIN_FOLDER);
    await fs.statAsync(TARGET_FILE);
    //const ARGUMENTS = `"${TARGET_FILE}" "${EXTRACT_PATH}"`; //unPSARC arguments
    const ARGUMENTS = `-e "${TARGET_FILE}" -o "${EXTRACT_PATH}"`; //ndarc arguments
    await api.runExecutable(RUN_PATH, [ARGUMENTS], { shell: true, detached: true, suggestDeploy: false });
    log('warn', `Ran extraction for .psarc file ${BINPSARC_FILE}`);
  } catch (err) {
    log('error', `Could not extract .psarc file ${BINPSARC_FILE}: ${err}`);
    return false;
  }
  //stat extracted folders to make sure they are there
  try {
    await fs.statAsync(path.join(WORK_PATH, BIN_FOLDER));
    await fs.statAsync(path.join(WORK_PATH, 'pak68'));
    return true;
  } catch { //if the folders aren't there, the user probably closed the terminal windows early
    return false;
  }
}
function extractSuccessNotify(api) {
  const NOTIF_ID = `${GAME_ID}-extractsuccess`;
  const MESSAGE = `Successfully extracted .psarc files`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'success',
    message: MESSAGE,
    allowSuppress: true,
    actions: [],
  });
}

//Setup .psarc files for modding
async function psarcSetup(api) { //run on mod purge
  const NOTIF_ID = `${GAME_ID}-psarcsetup`
  api.sendNotification({ //notification indicating process
    id: NOTIF_ID,
    message: `Extracting and Renaming .psarc Files. This will take a while. Do not close the terminal windows.`,
    type: 'activity',
    noDismiss: true,
    allowSuppress: false,
  });
  GAME_PATH = await getDiscoveryPath(api);
  const WORK_PATH = path.join(GAME_PATH, PSARCTOOL_PATH);
  //await api.emitAndAwait('purge-mods-in-path', GAME_ID, '', WORK_PATH);
  await purge(api);
  //await api.emitAndAwait('deploy-single-mod', GAME_ID, modMatch.id, false);
  let EXTRACTED = await psarcExtract(GAME_PATH, api);
  if (EXTRACTED) {
    log('warn', `Extraction of all .psarc files complete. Renaming files...`);
    //rename sp-common.psarc
    try {
      await fs.statAsync(path.join(WORK_PATH, SPCOMPSARC_FILE));
      await fs.renameAsync(path.join(WORK_PATH, SPCOMPSARC_FILE), path.join(WORK_PATH, BAK_SPCOMPSARC_FILE));
      log('warn', `Renamed .psarc file ${SPCOMPSARC_FILE} to ${BAK_SPCOMPSARC_FILE}`);
    } catch (err) {
      log('error', `Could not rename .psarc file ${SPCOMPSARC_FILE}: ${err}`);
    }
    //rename bin.psarc
    try {
      await fs.statAsync(path.join(WORK_PATH, BINPSARC_FILE));
      await fs.renameAsync(path.join(WORK_PATH, BINPSARC_FILE), path.join(WORK_PATH, BAK_BINPSARC_FILE));
      log('warn', `Renamed .psarc file ${BINPSARC_FILE} to ${BAK_BINPSARC_FILE}`);
    } catch (err) {
      log('error', `Could not rename .psarc file ${BINPSARC_FILE}: ${err}`);
    } //*/
    //finish up - success
    await deploy(api);
    api.dismissNotification(NOTIF_ID);
    extractSuccessNotify(api);
    return;
  }
  //finish up - failure
  await deploy(api);
  api.dismissNotification(NOTIF_ID);
  api.showErrorNotification(`Could not complete extraction of .psarc files. Please try again.`,
    `Could not complete extraction of .psarc files. Please try again. This error likely occured due to closing the ndarc terminal windows before extraction was complete.`,
    { allowReport: false }
  );
  return;
}

async function foldersCleanup(workingPath, folders) {
  for (let index = 0; index < folders.length; index++) {
    const folder = path.join(workingPath, folders[index]);
    try { //remove extracted .psarc folders
      await fs.statAsync(folder);
      await fsPromises.rm(folder, { recursive: true });
    } catch (err) {
      log('error', `Could not delete extracted .psarc folder "${folder}": ${err}`);
    }
  }
}
function cleanupSuccessNotify(api) {
  const NOTIF_ID = `${GAME_ID}-cleanupsuccess`;
  const MESSAGE = `Successfully restored vanilla .psarc files and deleted extracted files`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'success',
    message: MESSAGE,
    allowSuppress: true,
    actions: [],
  });
}

//Cleanup extracted .psarc game files (called on purge)
async function psarcCleanup(api) {
  const NOTIF_ID = `${GAME_ID}-psarccleanup`
  api.sendNotification({ //notification indicating process
    id: NOTIF_ID,
    message: `Cleaning up extracted .psarc Files and restoring file names. This will take a few seconds.`,
    type: 'activity',
    noDismiss: true,
    allowSuppress: false,
  });
  GAME_PATH = await getDiscoveryPath(api);
  const WORK_PATH = path.join(GAME_PATH, PSARCTOOL_PATH);
  await foldersCleanup(WORK_PATH, CLEANUP_FOLDERS);
  //restore name of sp-common.psarc
  try {
    await fs.statAsync(path.join(WORK_PATH, BAK_SPCOMPSARC_FILE));
    try { //make sure vanilla file is not in place - this usually means the game was updated
      await fs.statAsync(path.join(WORK_PATH, SPCOMPSARC_FILE));
      await fs.unlinkAsync(path.join(WORK_PATH, BAK_SPCOMPSARC_FILE));
    } catch { //vanilla file not present, safe to rename
      await fs.renameAsync(path.join(WORK_PATH, BAK_SPCOMPSARC_FILE), path.join(WORK_PATH, SPCOMPSARC_FILE));
      log('warn', `Renamed .psarc file ${BAK_SPCOMPSARC_FILE} to ${SPCOMPSARC_FILE}`);
    }
  } catch (err) {
    log('error', `Could not restore name of .psarc file ${SPCOMPSARC_FILE}: ${err}`);
  }
  //restore name of bin.psarc
  try {
    await fs.statAsync(path.join(WORK_PATH, BAK_BINPSARC_FILE));
    try { //make sure vanilla file is not in place - this usually means the game was updated
      await fs.statAsync(path.join(WORK_PATH, BINPSARC_FILE));
      await fs.unlinkAsync(path.join(WORK_PATH, BAK_BINPSARC_FILE));
    } catch {
      await fs.renameAsync(path.join(WORK_PATH, BAK_BINPSARC_FILE), path.join(WORK_PATH, BINPSARC_FILE));
      log('warn', `Renamed .psarc file ${BAK_BINPSARC_FILE} to ${BINPSARC_FILE}`);
    }
  } catch (err) {
    log('error', `Could not restore name of .psarc file ${BINPSARC_FILE}: ${err}`);
  }
  //stat vanilla files to make sure they are there
  try {
    await fs.statAsync(path.join(WORK_PATH, BINPSARC_FILE));
    await fs.statAsync(path.join(WORK_PATH, SPCOMPSARC_FILE));
    api.dismissNotification(NOTIF_ID);
    cleanupSuccessNotify(api);
    setupNotify(api);
    return;
  } catch (err) { //if the files aren't there, cleanup did not succeed
    api.dismissNotification(NOTIF_ID);
    api.showErrorNotification(`Did Not Complete .psarc Cleanup. Please try again.`,
      `Could not complete cleanup of extracted .psarc files and restoration of vanilla files. Please verify your game files to ensure vanilla .psarc files are present.\n ${err}`,
      { allowReport: false }
    );
    setupNotify(api);
    return;
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  // ASYNCHRONOUS CODE ///////////////////////////////////
  await setupNotify(api);
  await fs.ensureDirWritableAsync(CONFIG_PATH);
  await fs.ensureDirWritableAsync(SAVE_PATH);
  await fs.ensureDirWritableAsync(path.join(GAME_PATH, PAK_PATH));
  await fs.ensureDirWritableAsync(path.join(GAME_PATH, PSARC_PATH));
  await downloadModLoader(api, gameSpec);
  if (LOAD_ORDER_ENABLED) { //ensure LO file present
    const LO_FILE_PATH = path.join(GAME_PATH, LO_FILE);
    try {
      await fs.statAsync(LO_FILE_PATH);
    } catch {
      const modFolder = path.join(GAME_PATH, PSARC_PATH);
      const LO_FILE_LINES = [`[ModLoader]`, 'MountOrder=', 'ShowConsole=false', `ModFolder=${modFolder}`];
      const LO_FILE_CONTENT = LO_FILE_LINES.join('\n')
      await fs.writeFileAsync(
        LO_FILE_PATH,
        LO_FILE_CONTENT,
        { encoding: "utf8" },
      );
    }
  }
  return downloadPsarcTool(api, gameSpec);
}

//Let vortex know about the game
function applyGame(context, gameSpec) {
  //register the game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    executable: () => gameSpec.game.executable,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //register mod installers
  context.registerInstaller(MODLOADER_ID, 25, testModLoader, installModLoader);
  context.registerInstaller(PSARC_ID, 27, testPsarc, (files) => installPsarc(context.api, files));
  context.registerInstaller(`${BUILD_ID}pakbin`, 29, testBuildPakBin, installBuildPakBin);
  context.registerInstaller(BIN_ID, 31, testBin, installBin);
  context.registerInstaller(PAK_ID, 33, testPak, installPak);
  context.registerInstaller(BUILD_ID, 35, testBuild, installBuild);
  context.registerInstaller(SAVE_ID, 37, testSave, installSave);
  context.registerInstaller(CONFIG_ID, 39, testConfig, installConfig);
  context.registerInstaller(PSARCTOOL_ID, 41, testPsarcTool, installPsarcTool);

  //register actions
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Extract .psarc Files', () => {
    psarcSetup(context.api);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Cleanup Extracted .psarc Files', () => {
    psarcCleanup(context.api);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open "build\\pc\\main" Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    util.opn(path.join(GAME_PATH, BIN_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open .psarc "mods" Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, PSARC_PATH);
    util.opn(openPath).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open modloader.ini', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, LO_FILE);
    util.opn(openPath).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open chunks.txt', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, CHUNKS_PATH);
    util.opn(openPath).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Saves Folder', () => {
    const openPath = path.join(SAVE_PATH);
    util.opn(openPath).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    const openPath = path.join(CONFIG_PATH);
    util.opn(openPath).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    util.opn(path.join(__dirname, 'CHANGELOG.md')).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });

  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', () => {
    util.opn(SAVE_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
}

//Main function
function main(context) {
  applyGame(context, spec);
  if (LOAD_ORDER_ENABLED) {
    context.registerLoadOrder({
      gameId: GAME_ID,
      validate: async () => Promise.resolve(undefined), // no validation implemented yet
      deserializeLoadOrder: async () => await deserializeLoadOrder(context),
      serializeLoadOrder: async (loadOrder) => await serializeLoadOrder(context, loadOrder),
      toggleableEntries: true,
      usageInstructions: LoadOrderInstructions,
      customItemRenderer: LoadOrderItemRenderer,
    });
  }
  context.once(() => { // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    api.onAsync('did-purge', (profileId) => didPurge(api, profileId)); //*/
    api.onAsync("did-deploy", async (profileId) => {
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== LAST_ACTIVE_PROFILE) return; //only reset this game's mod update flags
      //release tracking one mod id at a time, and only once that mod's new version has
      //landed and is enabled, so a deploy that fires mid-batch can't disarm the guard for
      //mods that haven't been reinstalled yet
      //guard state as it stood before the loop below releases it - the FBLO refresh further
      //down only runs on the deploy that actually clears the guard
      const guardWasArmed = mod_update_all_profile;
      if (updateModIds.size > 0) {
        const state = api.getState();
        const profile = selectors.profileById(state, profileId);
        const mods = util.getSafe(state, ["persistent", "mods", GAME_ID], {});
        const now = Date.now();
        for (const [nexusId, { firstSeen, targetFileId }] of Array.from(updateModIds)) {
          const landed = Object.values(mods).some((mod) =>
            String(mod?.attributes?.modId ?? '') === nexusId &&
            //if the target file is unknown, fall back to "installed and enabled"
            (targetFileId === '' || String(mod?.attributes?.fileId ?? '') === targetFileId) &&
            util.getSafe(profile, ["modState", mod.id, "enabled"], false)
          );
          if (landed) {
            updateModIds.delete(nexusId);
          } else if (now - firstSeen > MAX_UPDATE_WAIT_MS) {
            log('warn', `[${GAME_ID}] Mod update tracking for Nexus mod ${nexusId} timed out without landing; releasing load order guard for it.`);
            updateModIds.delete(nexusId);
          }
        }
      }
      mod_update_all_profile = updateModIds.size > 0; //stay armed while any update is still outstanding
      //Core FBLO deserialized this order concurrently with this handler - did-deploy listeners run
      //in parallel and the core one is registered first - so it read the frozen order before the
      //guard cleared above, leaving its page stale. Re-run the deserialize it would have got and
      //push the result into state; cheaper and less disruptive than forcing a second deployment.
      if (guardWasArmed && !mod_update_all_profile) {
        try {
          const refreshedLO = await deserializeLoadOrder({ api: context.api });
          context.api.store.dispatch(actions.setFBLoadOrder(profileId, refreshedLO));
        } catch (err) {
          log('warn', `[${GAME_ID}] post-update load order refresh failed`, err);
        }
      }
      updating_mod = false; //reset updating flag on deploy
    });
    //detect mod update (to maintain LO position)
    //fileId is the version being updated TO, and is what tells the new version apart from
    //the old one on deploy - without it every mod not yet updated still looks "already installed"
    api.events.on("mod-update", (gameId, modId, fileId) => {
      if (GAME_ID == gameId) {
        updateModIds.set(String(modId), { firstSeen: Date.now(), targetFileId: String(fileId ?? '') });
      }
    });
    //detect batch mod update: the "Update all" button emits mods-update with LOCAL mod ids
    //and never emits mod-update, so resolve each one to its Nexus mod id before tracking it
    api.events.on("mods-update", (gameId, modIds) => {
      if (GAME_ID !== gameId) return;
      const mods = util.getSafe(api.getState(), ["persistent", "mods", GAME_ID], {});
      for (const modId of modIds ?? []) {
        const nexusModId = mods[modId]?.attributes?.modId;
        if (nexusModId !== undefined) {
          updateModIds.set(String(nexusModId), {
            firstSeen: Date.now(),
            targetFileId: String(mods[modId]?.attributes?.newestFileId ?? ''),
          });
        }
      }
    });
    //detect mod removal (to maintain LO position) - match on the Nexus mod id
    //recorded in state (attributes.modId), not the local modId string: the
    //local id's naming convention varies by when the mod was originally
    //downloaded (older dash-delimited vs current space-delimited), so string
    //parsing silently misses old installs.
    api.events.on("remove-mod", (gameMode, modId) => {
      const removedMod = util.getSafe(api.getState(), ["persistent", "mods", GAME_ID, modId], undefined);
      const nexusModId = removedMod?.attributes?.modId;
      if (nexusModId !== undefined && updateModIds.has(String(nexusModId))) {
        mod_update_all_profile = true;
      }
    });
    //detect mod installation (to maintain LO position). This only gates the
    //fallback-installer re-notify suppression, so a best-effort filename
    //match (covering both the old dash and current space delimiter) is fine.
    api.events.on("will-install-mod", (gameId, archiveId, modId) => {
      mod_install_name = modId.split("-")[0];
      updating_mod = GAME_ID == gameId && Array.from(updateModIds.keys()).some((id) =>
        modId.includes("-" + id + "-") || modId.includes(" " + id + " ")
      );
    }); //*/
  });
  return true;
}

//on purge
async function didPurge(api, profileId) { //run on mod purge
  const state = api.getState();
  const profile = selectors.profileById(state, profileId);
  const gameId = profile === null || profile === void 0 ? void 0 : profile.gameId;
  if (gameId !== GAME_ID) {
    return Promise.resolve();
  }
  GAME_PATH = await getDiscoveryPath(api);
  try {
    await fs.statAsync(path.join(GAME_PATH, PSARCTOOL_PATH, 'pak68'));
    await fs.statAsync(path.join(GAME_PATH, PSARCTOOL_PATH, BIN_FOLDER));
    await psarcCleanup(api);
  } catch {
    log('warn', `Skipping purge cleanup because cleanup folders not found.`);
  }
  clearModOrder(api);
  clearChunksTxt(api);
  return Promise.resolve();
}

//React load order instructions renderer
function LoadOrderInstructions() {
  return React.createElement('div', null,
    React.createElement('p', null,
      `Drag and drop the mods on the left to change the order in which they load.   `,
    ),
    React.createElement('br', null),
    React.createElement('p', null,
      `${GAME_NAME} loads mods in the order you set from top to bottom.   `,
    ),
  );
}

//* React line item renderer for load order
function LoadOrderItemRenderer(props) {
  const { className, item } = props;
  if (item?.loEntry === undefined) return null;

  const { ListGroupItem, Checkbox } = require('react-bootstrap');
  const { Icon, LoadOrderIndexInput, MainContext } = require('vortex-api');
  const { useSelector, useDispatch } = require('react-redux');

  const context = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) =>
    util.getSafe(state, ['persistent', 'loadOrder', profile?.id], []),
  );

  const { loEntry, displayCheckboxes } = item;
  const mods = useSelector((state) => util.getSafe(state, ['persistent', 'mods', GAME_ID], {}));
  const pictureUrl = mods[loEntry.modId]?.attributes?.pictureUrl;
  const currentIdx = loadOrder.findIndex((e) => e.id === loEntry.id) + 1;

  const isLocked = (entry) => [true, 'true', 'always'].includes(entry?.locked);
  const lockedCount = loadOrder.filter(isLocked).length;

  const onApplyIndex = React.useCallback((idx) => {
    if (currentIdx === idx) return;
    const newLO = loadOrder.filter((e) => e.id !== loEntry.id);
    newLO.splice(idx - 1, 0, loEntry);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
  }, [dispatch, profile, loadOrder, loEntry, currentIdx]);

  const onToggle = React.useCallback((evt) => {
    dispatch(actions.setFBLoadOrderEntry(profile.id, { ...loEntry, enabled: evt.target.checked }));
  }, [dispatch, profile, loEntry]);

  const classes = ['load-order-entry'];
  if (className) classes.push(...className.split(' '));

  return React.createElement(
    ListGroupItem,
    { key: loEntry.id, className: classes.join(' ') },
    React.createElement(Icon, { className: 'drag-handle-icon', name: 'drag-handle' }),
    React.createElement(LoadOrderIndexInput, {
      className: 'load-order-index',
      api: context.api,
      item: loEntry,
      currentPosition: currentIdx,
      lockedEntriesCount: lockedCount,
      loadOrder: loadOrder,
      isLocked: isLocked,
      onApplyIndex: onApplyIndex,
    }),
    React.createElement('div', { className: 'load-order-thumb-slot', style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, marginRight: 4, flexShrink: 0 } },
      pictureUrl ? React.createElement('img', {
        className: 'load-order-thumb',
        src: pictureUrl,
        draggable: false,
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, objectFit: 'cover', borderRadius: 2, pointerEvents: 'none' },
      }) : null,
    ),
    React.createElement('p', { className: 'load-order-name' }, loEntry.name),
    displayCheckboxes ? React.createElement(Checkbox, {
      className: 'entry-checkbox',
      checked: loEntry.enabled,
      disabled: isLocked(loEntry),
      onChange: onToggle,
    }) : null,
  );
} //*/

//export to Vortex
module.exports = {
  default: main,
};
