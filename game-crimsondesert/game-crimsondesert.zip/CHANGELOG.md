# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.2.2] - 2026-03-28

- Changed: Patch mod installer updated for new modding patterns (JSON/QT Mod Managers) - "0036+" folders
- Fixed: New name for JSON Mod Manager executable v7.5+
- Added: Separate installer for JSON mods with no data files
- Removed: CD Mod Manager tool and download button (not currently available)
- Removed: Unpacker download button (deprectated)

## [0.2.1] - 2026-03-26

- Added: Download buttons and setup scripts for tools
- Crimson Browser - will attempt to install dependencies and add game path to config file - Python 3.10+ REQUIRED

## [0.2.0] - 2026-03-25

- Added: Support for multiple new mod installers and formats, including launch tools:
- Crimson Browser (manifest.json and "files" folder)
- CD Mod Manager (.cdmod files)
- JSON Mod Manager (.json files)

## [0.1.2] - 2026-03-24

- Added: "meta" folder to Root Installer
- Added: Launch tool for Save Editor

## [0.1.1] - 2026-03-23

- Added: Root Folder installer (bin64, 0000, 0001, ..., 0035)
- Added: Installer and launch tool for Unpacker
- Added: Fallback installer to root folder with notification - includes link to ReShade installer

## [0.1.0] - 2026-03-22

- Initial Release
