/*//////////////////////////////////////////
Name: MOUSE: P.I. For Hire Vortex Extension
Structure: Unity BepinEx/MelonLoader/Custom Loader Hybrid
Author: ChemBoy1
Version: 0.1.0
Date: 2026-04-18
Notes:
- Need custom BepInEx patch due to stripped methods
- Cannot install BepInExConfigManager - causes BepInEx crash
//////////////////////////////////////////*/

//Import libraries
const { actions, fs, util, selectors, log } = require('vortex-api');
const path = require('path');
const template = require('string-template');
const fsExtra = require('fs-extra');
const { parseStringPromise } = require('xml2js');
const winapi = require('winapi-bindings');
//const fsPromises = require('fs/promises'); //.rm() for recursive folder deletion
//const turbowalk = require('turbowalk');

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const USER_HOME = util.getVortexPath("home");
const LOCALLOW = path.join(USER_HOME, 'AppData', 'LocalLow');
//const DOCUMENTS = util.getVortexPath("documents");
//const ROAMINGAPPDATA = util.getVortexPath("appData");
const LOCALAPPDATA = util.getVortexPath("localAppData");

//Specify all the information about the game
const GAME_ID = "mousepiforhire";
const STEAMAPP_ID = "2416450"; // https://steamdb.info/app/2416450/
const STEAMAPP_ID_DEMO = null;
const EPICAPP_ID = null;
const GOGAPP_ID = null;
const XBOXAPP_ID = "XXX"; // NOT on Game Pass - https://apps.microsoft.com/detail/9p7522hwd0nh
const XBOXEXECNAME = "Game";
const XBOX_PUB_ID = "XXX"; //string after "ID_"
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID]; // UPDATE THIS WITH ALL VALID IDs

const GAME_NAME = "MOUSE: P.I. For Hire";
const GAME_NAME_SHORT = "MOUSE";
const GAME_STRING = "MOUSE"; //string for exe and data folder (seem to always match)
const GAME_STRING_ALT = GAME_STRING; //CHANGE THIS IF IT DOESN'T MATCH
const EXEC = `${GAME_STRING}.exe`;
const EXEC_EGS = EXEC;
const EXEC_GOG = EXEC;
const EXEC_DEMO = EXEC;
const EXEC_XBOX = 'gamelaunchhelper.exe';
const EXEC_ALT = `${GAME_STRING_ALT}.exe`;
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Mouse%3A_P.I._For_Hire";
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1835"; //Nexus link to this extension. Used for links

//feature toggles
const allowSymlinks = true; //true if game can use symlinks without issues. Typically needs to be false if files have internal references (i.e. pak/ucas/utoc or ba2/esp)
const hasXbox = true; //toggle for Xbox version logic
let multiExe = false; //set to true if there are multiple executables (typically for Xbox/EGS)
if (GAME_STRING_ALT !== GAME_STRING) {
  multiExe = true;
} //*/
const setupNotification = false; //enable to show the user a notification with special instructions (specify below)
const fallbackInstaller = true; //enable fallback installer. Set false if you need to avoid installer collisions
const preventPluginInstall = true; //set to true if you want to prevent plugins not for the current mod loader from installing. Disable if using cross-compatibility plugins.
const loaderSwitchRestart = false; //set to true if you need to restart the extension after switching mod loaders
const enableSaveInstaller = false; //set to true if you want to enable the save installer (only recommended if saves are stored in the game's folder)
const hasCustomMods = false; //set to true if there are modTypes with folder paths dependent on which mod loader is installed
const hasCustomLoader = false; //set to true if there is a custom mod loader
const customLoaderInstaller = false; //set true if the custom loader uses an installer
const debug = false; //toggle for debug mode

const DATA_FOLDER_DEFAULT = `${GAME_STRING}_Data`;
let DATA_FOLDER = DATA_FOLDER_DEFAULT;
const ALT_VERSION = 'xbox';
const DATA_FOLDER_ALT = `${GAME_STRING_ALT}_Data`; //don't always match
const ROOT_FOLDERS = [DATA_FOLDER, DATA_FOLDER_ALT];
const VERSION_FILE = path.join('Version.info'); // LIKELY to change - usually .txt or .info file, i.e. Version.info. app.info typically does NOT contain version number
let VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
const hasVersionFile = false; //set to true if there is a Version.info file that contains the game version number
const VER_IDX = 3; //index of the version number in the Version.info file
const VER_SPLIT = ' '; //split character for the Version.info file - typically a space

const DEV_REGSTRING = "Fumi Games"; //developer name
const GAME_REGSTRING = "MOUSE"; //game name
const CONFIG_FOLDERNAME = "Save";
const SAVE_FOLDERNAME = "Save";
const hasUserIdFolder = false; //true if there is a folder in the Save path that is a user ID that must be read (i.e. Steam ID)

//Data to determine BepinEx/MelonLoader versions and URLs
const loaderChoice = false; //true if loader choice is enabled
const recommendedLoader = 'bep'; // bep/mel - If loaderChoice false, this determines downloaded loader. Otherwise shows as "(Recommended)" in selector.
const bepinexLoaderPatch = true; //should BepInEx Loader Patch be downloaded?
const BEPINEX_BUILD = 'mono'; // 'mono' or 'il2cpp' - check for "il2cpp_data" folder
const ARCH = 'x64'; //'x64' or 'x86' game architecture (64-bit or 32-bit)
const BEP_VER = '5.4.23.4'; //* Used .4 to match the patch version
const BEP_BE_VER = '755'; //set BepInEx build for BE IL2CPP URLs
const BEP_BE_COMMIT = '3fab71a'; //git commit number for BE IL2CPP builds
const BEPCFGMAN_VER = '18.4.1'; //set BepInExConfigManager version for direct URLs
const allowBepCfgMan = false; //! Causes BepInEx to crash if installed!
const allowMelPrefMan = false; //should MelonPreferencesManager be downloaded (via notification)?
const allowBepinexNexus = true; //allow Nexus Mods download of BepInEx/MelonLoader
const allowMelonNexus = true; 
const BEPINEX_PAGE_NO = 0; //7 - not using this one, using patch instead (for now)
const BEPINEX_FILE_NO = 0; //13
const BEPINEX_DOMAIN = GAME_ID;
const MELON_PAGE_NO = 0;
const MELON_FILE_NO = 0;
const MELON_DOMAIN = GAME_ID;
const useMelonNightly = false; //use Nightly build of MelonLoader?

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

let GAME_PATH = '';
let STAGING_FOLDER = '';
let DOWNLOAD_FOLDER = '';
let GAME_VERSION = '';
let bepinexInstalled = false;
let melonInstalled = false;
let customInstalled = false;
const APPMANIFEST_FILE = 'appxmanifest.xml';

//Config and save paths
const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_HIVE = 'HKEY_CURRENT_USER';
const CONFIG_KEY = `Software\\${DEV_REGSTRING}\\${GAME_REGSTRING}`;
const CONFIG_REGPATH_FULL = `${CONFIG_HIVE}\\${CONFIG_KEY}`; //*/
const CONFIG_FOLDER = path.join(LOCALLOW, DEV_REGSTRING, GAME_REGSTRING);
let USERID_FOLDER = "";
if (hasUserIdFolder) {
  try {
    const CONFIG_ARRAY = fs.readdirSync(CONFIG_FOLDER);
    USERID_FOLDER = CONFIG_ARRAY.find((entry) => isDir(CONFIG_FOLDER, entry));
  } catch(err) {
    USERID_FOLDER = "";
  }
  if (USERID_FOLDER === undefined) {
    USERID_FOLDER = "";
  } //*/
}
const CONFIG_PATH = path.join(CONFIG_FOLDER, USERID_FOLDER, CONFIG_FOLDERNAME);
const CONFIG_FILES = ['settings.json'];

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_PATH_DEFAULT = path.join(LOCALLOW, DEV_REGSTRING, GAME_REGSTRING, USERID_FOLDER, SAVE_FOLDERNAME);
const SAVE_PATH_XBOX = path.join(LOCALAPPDATA, "Packages", `${XBOXAPP_ID}_${XBOX_PUB_ID}`, "SystemAppData", "wgs"); //XBOX Version
let SAVE_PATH = SAVE_PATH_DEFAULT;
const SAVE_FILES = ['XXX.XXX'];
const SAVE_EXTS = [".XXX"];

//info for modtypes, installers, and tools
const BEPINEX_ID = `${GAME_ID}-bepinex`;
const BEPINEX_NAME = "BepInEx Injector";
const BEPINEX_DLL_FILE = "winhttp.dll";
let BEPINEX_FILE = 'BepInEx.Core.dll';
let BEP_INDICATOR_FILE = path.join('BepInEx', 'core', BEPINEX_FILE);
if (BEPINEX_BUILD === 'mono') {
  BEPINEX_FILE = 'BepInEx.dll';
  BEP_INDICATOR_FILE = path.join('BepInEx', 'core', BEPINEX_FILE);
}
const BEPINEX_FOLDER = 'BepInEx';
const BEP_STRING = 'BepInEx';
const BEP_PATCHER_STRING = 'BepInEx.Preloader.Core.Patching';

const BEP_LOADER_PATCH_ID = `${GAME_ID}-bepinex-loaderpatch`;
const BEP_LOADER_PATCH_NAME = "BepInEx Loader Patch";
const BEP_LOADER_PATCH_PATH = '.';
const BEP_LOADER_PATCH_FILE = 'doorstop_config.ini';
const BEP_LOADER_PATCH_EXCLUDE_FILE = 'winhttp.dll';
const BEP_LOADER_PATCH_PAGE_NO = 1;
const BEP_LOADER_PATCH_FILE_NO = 10;
const BEP_LOADER_PATCH_DOMAIN = GAME_ID;

let BEPINEX_ZIP = `BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.${BEP_BE_VER}+${BEP_BE_COMMIT}.zip`;
let BEPINEX_URL = `https://builds.bepinex.dev/projects/bepinex_be/${BEP_BE_VER}/BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.${BEP_BE_VER}%2B${BEP_BE_COMMIT}.zip`;
let BEPINEX_URL_ERR = `https://builds.bepinex.dev/projects/bepinex_be`;
if (BEPINEX_BUILD === 'mono') {
  BEPINEX_ZIP = `BepInEx_win_${ARCH}_${BEP_VER}.zip`;
  BEPINEX_URL = `https://github.com/BepInEx/BepInEx/releases/download/v${BEP_VER}/${BEPINEX_ZIP}`;
  BEPINEX_URL_ERR = `https://github.com/BepInEx/BepInEx/releases`;
}
const BEPINEX_ARCHIVE_NAME = 'BepInEx-Unity.IL2CPP-win-x64-6.0.0-be';

let MELON_STRING = 'IL2CPP';
if ( BEPINEX_BUILD === 'mono') {
  MELON_STRING = 'Mono';
}
const MELON_ID = `${GAME_ID}-melonloader`;
const MELON_NAME = "MelonLoader";
const MELON_ZIP = `MelonLoader.${ARCH}.zip`;
const MELON_URL = `https://github.com/LavaGang/MelonLoader/releases/latest/download/${MELON_ZIP}`;
const MELON_URL_NIGHTLY = `https://nightly.link/LavaGang/MelonLoader/workflows/build/alpha-development/MelonLoader.Windows.x64.CI.Release.zip`;
const MELON_URL_ERR = `https://github.com/LavaGang/MelonLoader/releases`;
const MELON_FILE = 'MelonLoader.dll';
const MELON_DLL_FILE = "version.dll";
const MELON_FOLDER = 'MelonLoader';
const MEL_STRING = 'MelonLoader';
const MEL_PLUGIN_STRING = 'MelonPlugin';
const MELON_INDICATOR_FILE = path.join('MelonLoader', 'net6', MELON_FILE);
const MELON_DOTNET_VER = '6';
const MELON_DOTNET_URL = `https://dotnet.microsoft.com/download/dotnet/${MELON_DOTNET_VER}.0`; //required for MelonLoader on IL2CPP games
const DOTNET_REG_HIVE = 'HKEY_LOCAL_MACHINE';
const DOTNET_REG_KEY = `SOFTWARE\\WOW6432Node\\dotnet\\Setup\\InstalledVersions\\x64\\sharedfx\\Microsoft.WindowsDesktop.App`;

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Game Folder";

const ASSEMBLY_ID = `${GAME_ID}-assemblydll`;
const ASSEMBLY_NAME = "Assembly DLL Mod";
let ASSEMBLY_PATH = '.';
let ASSEMBLY_FILES = ["GameAssembly.dll"];
if (BEPINEX_BUILD === 'mono') {
  ASSEMBLY_PATH = path.join(DATA_FOLDER, 'Managed');
  ASSEMBLY_FILES = ["Assembly-CSharp.dll", "Assembly-CSharp-firstpass.dll"];
}

const ASSETS_ID = `${GAME_ID}-assets`;
const ASSETS_NAME = "Assets/Resources File";
let ASSETS_PATH = DATA_FOLDER;
const ASSETS_EXTS = ['.assets', '.resource', '.ress'];

const PLUGIN_EXTS = ['.dll'];

const BEPINEX_MOD_ID = `${GAME_ID}-bepinexmod`;
const BEPINEX_MOD_NAME = "BepInEx Mod";
const BEPINEX_MOD_PATH = BEPINEX_FOLDER;
const BEPINEX_MOD_FOLDERS = ['plugins', 'patchers', 'config'];

const MELON_MOD_ID = `${GAME_ID}-melonmod`;
const MELON_MOD_NAME = "MelonLoader Mod";
const MELON_MOD_PATH = '.';
const MELON_MOD_FOLDERS = ['mods', 'plugins', 'userdata', 'userlibs'];

const BEPINEX_PLUGINS_ID = `${GAME_ID}-bepinex-plugins`;
const BEPINEX_PLUGINS_NAME = "BepInEx Plugins";
const BEPINEX_PLUGINS_FOLDER = 'plugins';
const BEPINEX_PLUGINS_PATH = path.join(BEPINEX_FOLDER, BEPINEX_PLUGINS_FOLDER);

const BEPINEX_PATCHERS_ID = `${GAME_ID}-bepinex-patchers`;
const BEPINEX_PATCHERS_NAME = "BepInEx Patchers";
const BEPINEX_PATCHERS_FOLDER = 'patchers';
const BEPINEX_PATCHERS_PATH = path.join(BEPINEX_FOLDER, BEPINEX_PATCHERS_FOLDER);

const BEPINEX_CONFIG_ID = `${GAME_ID}-bepinex-config`;
const BEPINEX_CONFIG_NAME = "BepInEx Config";
const BEPINEX_CONFIG_FOLDER = 'config';
const BEPINEX_CONFIG_PATH = path.join(BEPINEX_FOLDER, BEPINEX_CONFIG_FOLDER);

const MELON_MODS_ID = `${GAME_ID}-melonloader-mods`;
const MELON_MODS_NAME = "MelonLoader Mods";
const MELON_MODS_FOLDER = 'Mods';
const MELON_MODS_PATH = MELON_MODS_FOLDER;

const MELON_PLUGINS_ID = `${GAME_ID}-melonloader-plugins`;
const MELON_PLUGINS_NAME = "MelonLoader Plugins";
const MELON_PLUGINS_FOLDER = 'Plugins';
const MELON_PLUGINS_PATH = MELON_PLUGINS_FOLDER;

const MELON_CONFIG_ID = `${GAME_ID}-melonloader-config`;
const MELON_CONFIG_NAME = "MelonLoader Config";
const MELON_CONFIG_FOLDER = 'UserData';
const MELON_CONFIG_PATH = MELON_CONFIG_FOLDER;

const MELON_USERLIB_ID = `${GAME_ID}-melonloader-userlibs`;
const MELON_USERLIB_NAME = "MelonLoader UserLibs";
const MELON_USERLIB_FOLDER = 'UserLibs';
const MELON_USERLIB_PATH = MELON_USERLIB_FOLDER;

const BEPCFGMAN_ID = `${GAME_ID}-bepcfgman`;
const BEPCFGMAN_NAME = "BepInExConfigManager";
const BEPCFGMAN_PATH = BEPINEX_MOD_PATH;
const BEPCFGMAN_URL_ERR = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases`;
const BEPCFGMAN_FILE = `configurationmanager.dll`; //lowercased
let BEPCFGMAN_ARCHIVE_NAME = `BepInEx.ConfigurationManager_IL2CPP_v`;
const BEPCFGMAN_URL_MAIN = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases`;
let BEPCFGMAN_URL_DIRECT = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases/download/v${BEPCFGMAN_VER}/BepInEx.ConfigurationManager_IL2CPP_v${BEPCFGMAN_VER}.zip`;
if (BEPINEX_BUILD === 'mono') {
  BEPCFGMAN_ARCHIVE_NAME = `BepInEx.ConfigurationManager_BepInEx5_v`;
  BEPCFGMAN_URL_DIRECT = `https://github.com/BepInEx/BepInEx.ConfigurationManager/releases/download/v${BEPCFGMAN_VER}/BepInEx.ConfigurationManager_BepInEx5_v${BEPCFGMAN_VER}.zip`;
}

const MELONPREFMAN_ID = `${GAME_ID}-melonprefman`;
const MELONPREFMAN_NAME = "MelonPreferencesManager";
const MELONPREFMAN_PATH = MELON_MODS_PATH;
const MELONPREFMAN_URL = `https://github.com/Bluscream/MelonPreferencesManager/releases/latest/download/MelonPrefManager.${MELON_STRING}.dll`;
const MELONPREFMAN_URL_ERR = `https://github.com/Bluscream/MelonPreferencesManager/releases`;
const MELONPREFMAN_STRING = 'melonprefmanager';
const MELONPREFMAN_FILE = `${MELONPREFMAN_STRING}.${BEPINEX_BUILD}.dll`; //lowercased - naked dll on GitHub

const BEP_CONFIG_FILE = 'BepInEx.cfg';
const BEP_CONFIG_FILEPATH = path.join(BEPINEX_CONFIG_PATH, BEP_CONFIG_FILE);
const MEL_CONFIG_FILE = 'Loader.cfg';
const MEL_CONFIG_FILEPATH = path.join(MELON_CONFIG_PATH, MEL_CONFIG_FILE);

const BEP_LOG_FILE = 'LogOutput.log';
const BEP_LOG_FILEPATH = path.join(BEPINEX_FOLDER, BEP_LOG_FILE);
const MEL_LOG_FILE = 'Latest.log';
const MEL_LOG_FILEPATH = path.join(MELON_FOLDER, MEL_LOG_FILE);

//custom mods (that change directory based on loader)
const CUSTOM_ID = `${GAME_ID}-custommod`;
const CUSTOM_NAME = "XXX";
const CUSTOM_FOLDER = 'XXX';
const CUSTOM_PATH_BEPINEX = path.join(BEPINEX_PLUGINS_PATH, CUSTOM_FOLDER);
const CUSTOM_PATH_MELON = path.join(MELON_MODS_PATH, CUSTOM_FOLDER);
let CUSTOM_PATH = '';
/*const CUSTOM_PATH_BEPINEX = path.join(BEPINEX_PLUGINS_PATH);
const CUSTOM_PATH_MELON = path.join(MELON_MODS_PATH); //*/
const CUSTOM_STRING = '.custom.json';
const CUSTOM_EXTS = ['.json'];

const DEPLOY_FILE = `vortex.deployment.${CUSTOM_ID}.json`;
const CUSTOM_DEPLOYFILE_BEPINEX = path.join(CUSTOM_PATH_BEPINEX, DEPLOY_FILE);
const CUSTOM_DEPLOYFILE_MELON = path.join(CUSTOM_PATH_MELON, DEPLOY_FILE);

//Save Editor
const SAVEEDITOR_ID = `${GAME_ID}-saveeditor`;
const SAVEEDITOR_NAME = "Save Editor";
const SAVEEDITOR_EXEC = 'XXX.exe';

//Custom mod loader
const CUSTOMLOADER_ID = `${GAME_ID}-customloader`;
const CUSTOMLOADER_NAME = "XXX";
const CUSTOMLOADER_EXEC = 'XXX.exe';
const CUSTOMLOADER_FILE = 'XXX.dll';
const CUSTOMLOADER_MARKER_FILE = 'XXX.dll';
const CUSTOMLOADER_MARKER_PATH = path.join(DATA_FOLDER, 'Managed', CUSTOMLOADER_MARKER_FILE);
const CUSTOMLOADER_FOLDER = 'XXX';
const CUSTOMLOADER_PAGE_NO = 0;
const CUSTOMLOADER_FILE_NO = 0;
const CUSTOMLOADER_DOMAIN = GAME_ID;
const CUSTOMLOADER_FILES_ARRAY = [
  'winhttp.dll',
  CUSTOMLOADER_MARKER_PATH,
];

const CUSTOMLOADER_MOD_ID = `${GAME_ID}-customloadermod`;
const CUSTOMLOADER_MOD_NAME = "XXX Mod";
const CUSTOMLOADER_MOD_PATH = '.';
const CUSTOMLOADER_MOD_FOLDERS = ['mods'];

const CUSTOMLOADER_PLUGIN_ID = `${GAME_ID}-customloaderplugin`;
const CUSTOMLOADER_PLUGIN_NAME = "XXX Plugin";
const CUSTOMLOADER_PLUGIN_PATH = path.join('XXX');
const CUSTOMLOADER_PLUGIN_FOLDERS = ['XXX'];
const CUSTOM_PLUGIN_STRING = 'XXX'; //string to ID Custom plugin file

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const MOD_PATH_DEFAULT = ".";
let REQ_FILE = EXEC;
if (multiExe) {
  REQ_FILE = path.join(ASSEMBLY_PATH, ASSEMBLY_FILES[0]);
}
const PARAMETERS_STRING = '';
const PARAMETERS = [PARAMETERS_STRING];

const IGNORE_CONFLICTS = [path.join('**', 'manifest.json'), path.join('**', 'icon.png'), path.join('**', 'changelog*'), path.join('**', 'readme*')];
const IGNORE_DEPLOY = [path.join('**', 'manifest.json'), path.join('**', 'icon.png'), path.join('**', 'changelog*'), path.join('**', 'readme*')];
let MODTYPE_FOLDERS = [BEPINEX_PATCHERS_PATH, BEPINEX_PLUGINS_PATH, BEPINEX_CONFIG_PATH, MELON_PLUGINS_PATH, MELON_MODS_PATH, MELON_CONFIG_PATH, MELON_USERLIB_PATH];
if (hasCustomMods) {
  MODTYPE_FOLDERS.push(CUSTOM_PATH_BEPINEX, CUSTOM_PATH_MELON);
}
if (hasCustomLoader) {
  MODTYPE_FOLDERS.push(CUSTOMLOADER_PLUGIN_PATH);
}

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

//Filled in from info above
const spec = {
  "game": {
    "id": GAME_ID,
    "name": GAME_NAME,
    "shortName": GAME_NAME_SHORT,
    //"parameters": PARAMETERS,
    "logo": `${GAME_ID}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPath": MOD_PATH_DEFAULT,
    "modPathIsRelative": true,
    "requiredFiles": [
      REQ_FILE
    ],
    "compatible": {
      "dinput": false,
      "enb": false,
    },
    "details": {
      "steamAppId": +STEAMAPP_ID,
      "gogAppId": GOGAPP_ID,
      "epicAppId": EPICAPP_ID,
      "xboxAppId": XBOXAPP_ID,
      "supportsSymlinks": allowSymlinks,
      "ignoreConflicts": IGNORE_CONFLICTS,
      "ignoreDeploy": IGNORE_DEPLOY,
    },
    "environment": {
      "SteamAPPId": STEAMAPP_ID,
      "GogAPPId": GOGAPP_ID,
      "EpicAPPId": EPICAPP_ID,
      "XboxAPPId": XBOXAPP_ID
    }
  },
  "modTypes": [
    {
      "id": BEPINEX_MOD_ID,
      "name": BEPINEX_MOD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_MOD_PATH)
    },
    {
      "id": MELON_MOD_ID,
      "name": MELON_MOD_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_MOD_PATH)
    }, //*/
    {
      "id": BEPINEX_PLUGINS_ID,
      "name": BEPINEX_PLUGINS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_PLUGINS_PATH)
    },
    {
      "id": BEPINEX_PATCHERS_ID,
      "name": BEPINEX_PATCHERS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_PATCHERS_PATH)
    },
    {
      "id": BEPINEX_CONFIG_ID,
      "name": BEPINEX_CONFIG_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPINEX_CONFIG_PATH)
    },
    {
      "id": MELON_MODS_ID,
      "name": MELON_MODS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_MODS_PATH)
    },
    {
      "id": MELON_PLUGINS_ID,
      "name": MELON_PLUGINS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_PLUGINS_PATH)
    },
    {
      "id": MELON_CONFIG_ID,
      "name": MELON_CONFIG_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_CONFIG_PATH)
    },
    {
      "id": MELON_USERLIB_ID,
      "name": MELON_USERLIB_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELON_USERLIB_PATH)
    },
    {
      "id": BEPCFGMAN_ID,
      "name": BEPCFGMAN_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BEPCFGMAN_PATH)
    },
    {
      "id": MELONPREFMAN_ID,
      "name": MELONPREFMAN_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', MELONPREFMAN_PATH)
    },
    {
      "id": ROOT_ID,
      "name": ROOT_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": BEPINEX_ID,
      "name": BEPINEX_NAME,
      "priority": "low",
      "targetPath": '{gamePath}'
    },
    {
      "id": BEP_LOADER_PATCH_ID,
      "name": BEP_LOADER_PATCH_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', BEP_LOADER_PATCH_PATH)
    },
    {
      "id": MELON_ID,
      "name": MELON_NAME,
      "priority": "low",
      "targetPath": '{gamePath}'
    },
  ],
  "discovery": {
    "ids": DISCOVERY_IDS_ACTIVE,
    "names": []
  }
};

//3rd party tools and launchers
let tools = [
  {
    id: `${GAME_ID}-customlaunch`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC,
    requiredFiles: [EXEC],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS,
  }, //*/
  /*{
    id: SAVEEDITOR_ID,
    name: SAVEEDITOR_NAME,
    logo: `saveeditor.png`,
    executable: () => SAVEEDITOR_EXEC,
    requiredFiles: [SAVEEDITOR_EXEC],
    detach: true,
    relative: true,
    exclusive: false,
    //shell: true,
    //parameters: [],
  }, //*/
];

if (multiExe) {
  tools.push(
    {
      id: `${GAME_ID}-customlaunchalt`,
      name: `Custom Launch`,
      logo: `exec.png`,
      executable: () => EXEC_ALT,
      requiredFiles: [EXEC_ALT],
      detach: true,
      relative: true,
      exclusive: true,
      shell: true,
      //defaultPrimary: true,
      parameters: PARAMETERS,
    },
  );
}
if (customLoaderInstaller) {
  tools.push(
    {
      id: CUSTOMLOADER_ID,
      name: `${CUSTOMLOADER_NAME} Installer`,
      logo: `customloader.png`,
      executable: () => path.join(CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC),
      requiredFiles: [path.join(CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC)],
      detach: true,
      relative: true,
      exclusive: true,
      //shell: true,
      //parameters: [],
    },
  );
}

// BASIC FUNCTIONS //////////////////////////////////////////////////////////////

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  }
  catch (err) {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fs.statAsync(path.join(gamePath, file));
    return true;
  }
  catch (err) {
    return false;
  }
}

//Set mod type priorities
function modTypePriority(priority) {
  return {
    high: 30,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath: (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0 ? void 0 : _a.path,
      documents: util.getVortexPath('documents'),
      localAppData: util.getVortexPath('localAppData'),
      appData: util.getVortexPath('appData'),
    });
  }
  catch (err) { //this happens if the executable comes back as "undefined", usually caused by the Xbox app locking down the folder
    api.showErrorNotification('Failed to locate executable. Please launch the game at least once.', err);
  }
}

//Set the mod path for the game
function makeGetModPath(api, gameSpec) {
  return () => gameSpec.game.modPathIsRelative !== false
    ? gameSpec.game.modPath || '.'
    : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () => util.GameStoreHelper.findByAppId(gameSpec.discovery.ids)
    .then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher(gamePath, store) {
  //*
  if (store === 'steam') {
    return Promise.resolve({
      launcher: 'steam',
    });
  } //*/
  if (store === 'xbox' && (DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID))) {
    return Promise.resolve({
      launcher: 'xbox',
      addInfo: {
        appId: XBOXAPP_ID,
        parameters: [{ appExecName: XBOXEXECNAME }],
      },
    });
  } //*/
  if (store === 'epic' && (DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID))) {
    return Promise.resolve({
      launcher: 'epic',
      addInfo: {
        appId: EPICAPP_ID,
      },
    });
  } //*/
  return Promise.resolve(undefined);
}

//Get correct save folder for game version
async function getSavePath(api) {
  GAME_PATH = getDiscoveryPath(api);
  if (hasXbox && await statCheckAsync(GAME_PATH, EXEC_XBOX)) {
    SAVE_PATH = SAVE_PATH_XBOX;
    return SAVE_PATH;
  }
  else {
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return SAVE_PATH;
  };
} //*/

//Get correct executable for game version
function getExecutable(discoveryPath) {
  if (!multiExe && !hasXbox) { //return immediately if only one exe filename for all versions
    return EXEC;
  }
  if (hasXbox && statCheckSync(discoveryPath, EXEC_XBOX)) {
    GAME_VERSION = 'xbox';
    DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    }
    VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
    SAVE_PATH = SAVE_PATH_XBOX;
    return EXEC_XBOX;
  };
  if (multiExe && statCheckSync(discoveryPath, EXEC_ALT)) { // Epic/GOG/Demo
    GAME_VERSION = ALT_VERSION;
    DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    }
    VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
    return EXEC_ALT;
  };
  return EXEC;
}

//Get correct game version
async function setGameVersion(gamePath) {
  if (hasXbox && statCheckAsync(gamePath, EXEC_XBOX)) {
    GAME_VERSION = 'xbox';
    DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    }
    VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
    SAVE_PATH = SAVE_PATH_XBOX;
    return GAME_VERSION;
  };
  if (multiExe && await statCheckAsync(gamePath, EXEC_ALT)) { // Epic/GOG
    GAME_VERSION = ALT_VERSION;
    DATA_FOLDER = DATA_FOLDER_ALT;
    ASSETS_PATH = path.join(DATA_FOLDER, "Managed");
    if (BEPINEX_BUILD === 'mono') {
      ASSEMBLY_PATH = path.join(DATA_FOLDER, "Managed");
    }
    VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
    return GAME_VERSION;
  } else {
    GAME_VERSION = 'default';
    return GAME_VERSION;
  }
}

//Get correct custom mod path for installed mod loader
function getCustomFolder(api, game) {
  GAME_PATH = getDiscoveryPath(api);
  if (GAME_PATH === undefined) {
    return '.'; //fallback to root
  }
  bepinexInstalled = isBepinexInstalled(api, spec);
  melonInstalled = isMelonInstalled(api, spec);
  if (bepinexInstalled) { //remove melon deployment json file
    CUSTOM_PATH = CUSTOM_PATH_BEPINEX;
    try {
      fs.statSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_MELON));
      fsExtra.unlinkSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_MELON));
    } catch (err) {
      //log('warn', `Failed to remove ${CUSTOMCHAR_DEPLOYFILE_MELON}: ${err.message}`);
    }
  };
  if (melonInstalled) { //remove BepInEx deployment json file
    CUSTOM_PATH = CUSTOM_PATH_MELON;
    try {
      fs.statSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_BEPINEX));
      fsExtra.unlinkSync(path.join(GAME_PATH, CUSTOM_DEPLOYFILE_BEPINEX));
    } catch {
      //log('warn', `Failed to remove ${CUSTOMCHAR_DEPLOYFILE_BEPINEX}: ${err.message}`);
    }
  };
  const folderPath = path.join(GAME_PATH, CUSTOM_PATH); //set the correct mod path
  return folderPath;
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fs.readdirAsync(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fs.statAsync(fullPath);
      if (stats.isDirectory()) { // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else { // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log('warn', `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api) => { //get the game's discovered path
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, GAME_ID], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) { //useful to clear out mods prior to doing some action
  return new Promise((resolve, reject) => api.events.emit('purge-mods', true, (err) => err ? reject(err) : resolve()));
}
async function deploy(api) { //useful to deploy mods after doing some action
  return new Promise((resolve, reject) => api.events.emit('deploy-mods', (err) => err ? reject(err) : resolve()));
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Test for BepinEx files
function testBepinex(files, gameId) {
  //const isMod = files.some(file => (path.basename(file) === BEPINEX_FILE));
  const isFolder = files.some(file => (path.basename(file) === BEPINEX_FOLDER));
  const isDll = files.some(file => (path.basename(file) === BEPINEX_DLL_FILE));
  let supported = (gameId === spec.game.id) && isFolder && isDll;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install BepInEx files
function installBepinex(files) {
  const MOD_TYPE = BEPINEX_ID;
  const modFile = files.find(file => (path.basename(file) === BEPINEX_DLL_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for BepinEx files
function testBepLoaderPatch(files, gameId) {
  const isExcl = files.some(file => (path.basename(file) === BEP_LOADER_PATCH_EXCLUDE_FILE));
  const isFile = files.some(file => (path.basename(file) === BEP_LOADER_PATCH_FILE));
  let supported = (gameId === spec.game.id) && !isExcl && isFile;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install BepInEx files
function installBepLoaderPatch(files) {
  const MOD_TYPE = BEP_LOADER_PATCH_ID;
  const modFile = files.find(file => (path.basename(file) === BEP_LOADER_PATCH_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for MelonLoader files
function testMelon(files, gameId) {
  //const isMod = files.some(file => (path.basename(file) === MELON_FILE));
  const isFolder = files.some(file => (path.basename(file) === MELON_FOLDER));
  const isDll = files.some(file => (path.basename(file) === MELON_DLL_FILE));
  let supported = (gameId === spec.game.id) && isFolder && isDll;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install MelonLoader files
function installMelon(files) {
  const MOD_TYPE = MELON_ID;
  const modFile = files.find(file => (path.basename(file) === MELON_FOLDER));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Custom Mod Loader files
function testCustomLoader(files, gameId) {
  const isMod = files.some(file => (path.basename(file) === CUSTOMLOADER_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Custom Mod Loader files
function installCustomLoader(files) {
  const MOD_TYPE = CUSTOMLOADER_ID;
  const modFile = files.find(file => (path.basename(file) === CUSTOMLOADER_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

if (customLoaderInstaller) {
  //Test for Custom Mod Loader files (installer exe)
  function testCustomLoader(files, gameId) {
    const isMod = files.some(file => (path.basename(file) === CUSTOMLOADER_EXEC));
    let supported = (gameId === spec.game.id) && isMod;

    // Test for a mod installer.
    if (supported && files.find(file =>
        (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
        (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
      supported = false;
    }

    return Promise.resolve({
        supported,
        requiredFiles: [],
    });
  }
  //Install Custom Mod Loader files (installer exe)
  function installCustomLoader(files) {
    const MOD_TYPE = CUSTOMLOADER_ID;
    const modFile = files.find(file => (path.basename(file) === CUSTOMLOADER_EXEC));
    const idx = modFile.indexOf(path.basename(modFile));
    const rootPath = path.dirname(modFile);
    const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

    // Remove directories and anything that isn't in the rootPath.
    const filtered = files.filter(file => (
      (file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep))
    ));
    const instructions = filtered.map(file => {
      return {
        type: 'copy',
        source: file,
        destination: path.join(CUSTOMLOADER_FOLDER, file.substr(idx)),
      };
    });
    instructions.push(setModTypeInstruction);
    return Promise.resolve({ instructions });
  }
}

//Test for BepinExConfigManager mod files
function testBepCfgMan(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === BEPCFGMAN_FILE));
  const isFolder = files.some(file => (path.basename(file).toLowerCase() === 'plugins'));
  let supported = (gameId === spec.game.id) && isMod && isFolder;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install BepinExConfigManager mod files
function installBepCfgMan(files) {
  const MOD_TYPE = BEPCFGMAN_ID;
  const modFile = files.find(file => (path.basename(file).toLowerCase() === 'plugins'));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for MelonPreferencesManager mod files
function testMelonPrefMan(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === MELONPREFMAN_FILE));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install MelonPreferencesManager mod files
function installMelonPrefMan(files) {
  const MOD_TYPE = MELONPREFMAN_ID;
  const modFile = files.find(file => (path.basename(file).toLowerCase() === MELONPREFMAN_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Assembly mod files
function testAssembly(files, gameId) {
  const isMod = files.some(file => ASSEMBLY_FILES.includes(path.basename(file)));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Assembly mod files
function installAssembly(files) {
  const MOD_TYPE = ASSEMBLY_ID;
  const modFile = files.find(file => ASSEMBLY_FILES.includes(path.basename(file)));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) &&
    (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const isMod = files.some(file => ROOT_FOLDERS.includes(path.basename(file)));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
async function installRoot(files, workingDir) {
  const modFile = files.find(file => ROOT_FOLDERS.includes(path.basename(file)));
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`
  const idx = modFile.indexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: ROOT_ID };

  if (GAME_VERSION === ALT_VERSION) {
    try {
      await fs.statAsync(path.join(workingDir, modFile));
      if (path.basename(modFile) === DATA_FOLDER_DEFAULT) {
        await fs.renameAsync(path.join(workingDir, modFile), path.join(workingDir, rootPath, DATA_FOLDER_ALT));
      }
      const paths = await getAllFiles(workingDir);
      files = [...paths.map(p => p.replace(`${workingDir}${path.sep}`, ''))];
    } catch (err) {
      log('warn', `Failed to rename "${DATA_FOLDER_DEFAULT}" folder to "${DATA_FOLDER_ALT}" for root mod ${workingDir} (or "${DATA_FOLDER_DEFAULT}" folder is not present): ${err}`);
    }
  } //*/

  // Don't use rootPath filter since it removes files without extensions
  const filtered = files.filter(file =>
    ((!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer Test for assets files
function testAssets(files, gameId) {
  const isMod = files.some(file => ASSETS_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install assets files
function installAssets(files) {
  const modFile = files.find(file => ASSETS_EXTS.includes(path.extname(file).toLowerCase()));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: ASSETS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for Assembly mod files
function testCustom(files, gameId) {
  const isMod = files.some(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
  const isString = files.some(file => (path.basename(file).toLowerCase().includes(CUSTOM_STRING)));
  let supported = (gameId === spec.game.id) && isMod && isString;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
      supported,
      requiredFiles: [],
  });
}

//Install Assembly mod files
function installCustom(files) {
  const MOD_TYPE = CUSTOM_ID;
  const setModTypeInstruction = { type: 'setmodtype', value: MOD_TYPE };
  const modFile = files.find(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
  /*let modFile = files.find(file => (path.basename(file) === CUSTOM_FOLDER)); //check for folder and use to index if it's there.
  let folder  = '.';
  if (modFile === undefined) {
    modFile = files.find(file => (CUSTOM_EXTS.includes(path.extname(file).toLowerCase())));
    folder =  CUSTOM_FOLDER;
  } //*/
  const DATA_FILE = path.basename(modFile, '.custom.json');
  const idx = modFile.indexOf(DATA_FILE);
  const rootPath = path.dirname(modFile);
 
  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file => (
    (file.indexOf(rootPath) !== -1) 
    && (!file.endsWith(path.sep))
  ));
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file.substr(idx),
      //destination: path.join(folder, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer Test for plugin files
function testPlugin(files, gameId) {
  const isMod = files.some(file => PLUGIN_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install plugin files
async function installPlugin(api, gameSpec, files, workingDir) {
  const modFile = files.find(file => PLUGIN_EXTS.includes(path.extname(file).toLowerCase()));
  let idx = modFile.indexOf(path.basename(modFile));
  let rootPath = path.dirname(modFile);
  let setModTypeInstruction = {};
  const MOD_NAME = path.basename(workingDir).replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*/gi, '');

  // logic to parse dll files to determine if they are Custom/Melon/BepInEx plugins
  let isBepinex = false;
  let isBepinexPatcher = false;
  let isMelon = false;
  let isMelonPlugin = false;
  let isCustom = false;
  let unknown = false;
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = isCustomInstalled(api, gameSpec);
  }

  // STEP 1 - Detect plugin types by reading DLL contents //////////////////////////////////////////

  await Promise.all(files.map(async file => {
    if (PLUGIN_EXTS.includes(path.extname(file).toLowerCase())) {
      try {
        const content = await fs.readFileAsync(path.join(workingDir, file), 'utf8');
        if (hasCustomLoader && content.includes(CUSTOM_PLUGIN_STRING)) {
          isCustom = true;
        } 
        else if (content.includes(BEP_STRING)) {
          isBepinex = true;
          isBepinexPatcher = content.includes(BEP_PATCHER_STRING);
        } 
        else if (content.includes(MEL_STRING)) {
          isMelon = true;
          isMelonPlugin = content.includes(MEL_PLUGIN_STRING);
        }
        else {
          unknown = true;
        }
      } catch (err) {
        api.showErrorNotification(`Failed to read plugin file "${file}" to determine which mod loader it requires. Plugin is likely corrupted.`, err, { allowReport: false });
      }
    }
  }));

  // STEP 2 - CANCEL/WARN INSTALL CONDITIONS //////////////////////////////////////////

  if (hasCustomLoader) {
    if (isCustom && ( bepinexInstalled || melonInstalled )) {
      const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
          bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has ${CUSTOMLOADER_NAME} plugins, but you have installed BepInEx or MelonLoader.[br][/br][br][/br]`
              + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
              + `${preventPluginInstall ? `The installation will be cancelled to avoid issues.[br][/br][br][/br]` : `The mod will not be loaded unless the correct mod loader is installed.[br][/br][br][/br]`}`
              + `Check the mod's page to see if there is a ${CUSTOMLOADER_NAME} version of the mod, or change your mod loader to MelonLoader.[br][/br][br][/br]`),
          options: { order: ['bbcode'], wrap: true },
      }, [
          { label: 'Ok' }
      ]);
      if (wrongLoader.action === 'Ok') {
        if (preventPluginInstall) {
          throw new util.UserCanceled();
        } else {
          //do nothing, proceed with install
        }
      }
    }
    if ((isBepinex || isMelon) && customInstalled) {
      const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
          bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has BepInEx/MelonLoader plugins, but you have installed ${CUSTOMLOADER_NAME}.[br][/br][br][/br]`
              + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
              + `Check the mod's page to see if there is a ${CUSTOMLOADER_NAME} version of the mod, or change your mod loader to BepInEx/MelonLoader.[br][/br][br][/br]`),
          options: { order: ['bbcode'], wrap: true },
      }, [
          { label: 'Ok' }
      ]);
      if (wrongLoader.action === 'Ok') {
        if (preventPluginInstall) {
          throw new util.UserCanceled();
        } else {
          //do nothing, proceed with install
        }
      }
    }
  }
  // If both BepInEx and MelonLoader plugins are detected, cancel install
  if (isBepinex && isMelon) {
    const mixedModHandling = await api.showDialog('error', 'Mixed Mod Detected', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has both BepInEx and MelonLoader plugins in the same archive.[br][/br][br][/br]`
            + `Mixed mods are not supported by the game extension and the mod author will need to repackage their mod.[br][/br][br][/br]`
            + `You can manually extract the correct plugin from the archive and install it to Vortex.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (mixedModHandling.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }
  //if BepInEx plugin is installed while using MelonLoader, cancel install
  if (isBepinex && melonInstalled) {
    const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has BepInEx plugins, but you have installed MelonLoader.[br][/br][br][/br]`
            + `The installation will be cancelled to avoid issues.[br][/br][br][/br]`
            + `Check the mod's page to see if there is a MelonLoader version of the mod, or change your mod loader to BepInEx.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (wrongLoader.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }
  //if MelonLoader plugin is installed while using BepInEx, cancel install
  if (isMelon && bepinexInstalled) {
    const wrongLoader = await api.showDialog('error', 'Wrong Mod Loader', {
        bbcode: api.translate(`Vortex has detected that the ${MOD_NAME} archive has MelonLoader plugins, but you have installed BepInEx.[br][/br][br][/br]`
            + `The installation will be cancelled to avoid issues.[br][/br][br][/br]` 
            + `Check the mod's page to see if there is a BepInEx version of the mod, or change your mod loader to MelonLoader.[br][/br][br][/br]`),
        options: { order: ['bbcode'], wrap: true },
    }, [
        { label: 'Ok' }
    ]);
    if (wrongLoader.action === 'Ok') {
      if (preventPluginInstall) {
        throw new util.UserCanceled();
      } else {
        //do nothing, proceed with install
      }
    }
  }

  // STEP 3 - INSTALL THE PLUGINS //////////////////////////////////////////

  // Install method that attempts to index on folders, then dll files
  if (hasCustomLoader) {
    if (isCustom) {
      setModTypeInstruction = { type: 'setmodtype', value: CUSTOMLOADER_MOD_ID };
      const folder = files.find(file => CUSTOMLOADER_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
      if (folder !== undefined) {
        idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
        rootPath = path.dirname(folder);
      } else {
        setModTypeInstruction = { type: 'setmodtype', value: CUSTOMLOADER_PLUGIN_ID };
      }
    }
  }

  if (isBepinex && !isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_MOD_ID };
    const folder = files.find(file => BEPINEX_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    } else {
      setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PLUGINS_ID };
    }
  }

  if (isBepinex && isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_MOD_ID };
    const folder = files.find(file => BEPINEX_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    } else {
      setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PATCHERS_ID };
    }
  }

  if (isMelon && !isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MOD_ID };
    const folder = files.find(file => MELON_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    } else {
      setModTypeInstruction = { type: 'setmodtype', value: MELON_MODS_ID };
    }
  }

  if (isMelon && isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MOD_ID };
    const folder = files.find(file => MELON_MOD_FOLDERS.includes(path.basename(file).toLowerCase()));
    if (folder !== undefined) {
      idx = folder.indexOf(`${path.basename(folder)}${path.sep}`);
      rootPath = path.dirname(folder);
    } else {
      setModTypeInstruction = { type: 'setmodtype', value: MELON_PLUGINS_ID };
    }
  } //*/

  if (unknown) { //warn user - installs to default location (root)
    unknownDllNotify(api, workingDir);
  } //*/

  /* NORMAL INSTALL - Assign mod types
  if (isBepinex && !isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PLUGINS_ID };
  }
  if (isBepinex && isBepinexPatcher) {
    setModTypeInstruction = { type: 'setmodtype', value: BEPINEX_PATCHERS_ID };
  }
  if (isMelon && !isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_MODS_ID };
  }
  if (isMelon && isMelonPlugin) {
    setModTypeInstruction = { type: 'setmodtype', value: MELON_PLUGINS_ID };
  } //*/

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

function unknownDllNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  modName = path.basename(modName, '.installing');
  const id = modName.replace(/[^a-zA-Z0-9\s]*( )*/gi, '').slice(0, 20);
  const NOTIF_ID = `${GAME_ID}-${id}-fallback`;
  const MESSAGE = 'Unknown DLL File in mod: ' + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'info',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `The mod you just installed contains dll files that don't appear to use any know mod loader for this game.\n`
                + `Please check the mod page description to determine if the mod was installed correctly.\n`
                + `\n`
                + `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n`
                + `\n`
                + `Mod Name: ${modName}.\n`
                + `\n`             
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Contact Ext. Developer', action: () => {
                util.opn(`${EXTENSION_URL}?tab=posts`).catch(() => null);
                dismiss();
              }
            }, //*/
            //*
            { label: `Open Mod Page + Staging Folder`, action: () => {
              util.opn(path.join(STAGING_FOLDER, modName)).catch(() => null);
              const mods = util.getSafe(api.store.getState(), ['persistent', 'mods', spec.game.id], {});
              const modMatch = Object.values(mods).find(mod => mod.installationPath === modName);
              log('warn', `Found ${modMatch?.id} for ${modName}`);
              let PAGE = ``;
              if (modMatch) {
                const MOD_ID = modMatch.attributes.modId;
                if (MOD_ID !== undefined) {
                  PAGE = `${MOD_ID}?tab=description`; 
                }
              }
              const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
              util.opn(MOD_PAGE_URL).catch(err => undefined);
              dismiss();
            }}, //*/
          ]);
        },
      },
    ],
  });
}

//Fallback installer to root folder
function testFallback(files, gameId) {
  let supported = (gameId === spec.game.id);

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to root folder
function installFallback(api, files, destinationPath) {
  fallbackInstallerNotify(api, destinationPath);
  
  const filtered = files.filter(file =>
    (!file.endsWith(path.sep))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file,
    };
  });
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  modName = path.basename(modName, '.installing');
  const id = modName.replace(/[^a-zA-Z0-9\s]*( )*/gi, '').slice(0, 20);
  const NOTIF_ID = `${GAME_ID}-${id}-fallback`;
  const MESSAGE = 'Fallback installer reached for ' + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'info',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `The mod you just installed reached the fallback installer. This means Vortex could not determine where to place these mod files.\n`
                + `Please check the mod page description and review the files in the mod staging folder to determine if manual file manipulation is required.\n`
                + `\n`
                + `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n`
                + `\n`
                + `Mod Name: ${modName}.\n`
                + `\n`             
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Contact Ext. Developer', action: () => {
                util.opn(`${EXTENSION_URL}?tab=posts`).catch(() => null);
                dismiss();
              }
            }, //*/
            //*
            { label: `Open Mod Page + Staging Folder`, action: () => {
              util.opn(path.join(STAGING_FOLDER, modName)).catch(() => null);
              const mods = util.getSafe(api.store.getState(), ['persistent', 'mods', spec.game.id], {});
              const modMatch = Object.values(mods).find(mod => mod.installationPath === modName);
              log('warn', `Found ${modMatch?.id} for ${modName}`);
              let PAGE = ``;
              if (modMatch) {
                const MOD_ID = modMatch.attributes.modId;
                if (MOD_ID !== undefined) {
                  PAGE = `${MOD_ID}?tab=description`; 
                }
              }
              const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
              util.opn(MOD_PAGE_URL).catch(() => null);
              dismiss();
            }}, //*/
          ]);
        },
      },
    ],
  });
}

//Installer Test for save files
function testSave(files, gameId) {
  const isFile = files.some(file => SAVE_FILES.includes(path.basename(file).toLowerCase()));
  const isExt = files.some(file => SAVE_EXTS.includes(path.extname(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && (isFile || isExt);

  // Test for a mod installer.
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install save files
function installSave(files) {
  let modFile = files.find(file => SAVE_FILES.includes(path.basename(file).toLowerCase()));
  if (modFile === undefined) {
    modFile = files.find(file => SAVE_EXTS.includes(path.extname(file).toLowerCase()));
  }
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: ASSETS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

async function relaunchExt(api) {
  return api.showDialog('info', 'Restart Required', {
    text: '\n'
        + 'The extension requires a restart to complete the Mod Loader setup.\n'
        + '\n'
        + 'The extension will purge mods and then exit - please re-activate the game via the Games page or Dashboard page.\n'
        + '\n'
        + 'IMPORTANT: You may see an External Changes dialogue. Select "Revert change (use staging file)".\n'
        + '\n',
  }, [ { label: 'Restart Extension' } ])
  .then(async () => {
    try {
      await purge(api);
      const batched = [
        actions.setDeploymentNecessary(GAME_ID, true),
        actions.setNextProfile(undefined),
      ];
      util.batchDispatch(api.store, batched);
    } catch (err) {
      api.showErrorNotification('Failed to set up Mod Loader', err, { allowReport: false });
    }
  });
}

//Function to choose mod loader
async function chooseModLoader(api, gameSpec) {
  if (!loaderChoice) {
    if (recommendedLoader === 'bep') {
      if ((BEPINEX_PAGE_NO !== 0) && allowBepinexNexus) {
        await downloadBepinexNexus(api, gameSpec);
      } else {
        await downloadBepinex(api, gameSpec);
        if (bepinexLoaderPatch) await downloadBepLoaderPatch(api, gameSpec);
      }
    } else {
      if ((MELON_PAGE_NO !== 0) && allowMelonNexus) {
        await downloadMelonNexus(api, gameSpec);
      } else {
        await downloadMelon(api, gameSpec, true);
      }
    }
  } else {
    const CUSTOM_LABEL = `${CUSTOMLOADER_NAME} (Recommended)`;
    let BEP_LABEL = `BepInEx`;
    if (recommendedLoader === 'bep') {
      BEP_LABEL = `${BEPINEX_NAME} (Recommended)`;
    }
    let MEL_LABEL = `MelonLoader`;
    if (recommendedLoader === 'mel') {
      MEL_LABEL = `${MELON_NAME} (Recommended)`;
    }
    const t = api.translate;
    let choices = [
      { label: t(BEP_LABEL) },
      { label: t(MEL_LABEL) },
    ];
    if (hasCustomLoader) {
      choices = [
        { label: t(CUSTOM_LABEL) },
        { label: t(BEP_LABEL) },
        { label: t(MEL_LABEL) },
      ];
    }
    const replace = {
      game: gameSpec.game.name,
      bl: '[br][/br][br][/br]',
    };
    return api.showDialog('info', 'Mod Loader Selection', {
      bbcode: t('You must choose a mod loader to install mods.{{bl}}'
        + 'Only one mod loader can be installed at a time.{{bl}}'
        + 'Make your choice based on which mods you would like to install and which loader they support.{{bl}}'
        + 'You can change which mod loader you have installed by Uninstalling the current one from Vortex, which will bring up this dialog again.{{bl}}'
        + 'Which mod loader would you like to use for {{game}}?',
        { replace }
      ),
    }, choices)
    .then(async (result) => {
      if (result === undefined) {
        return;
      }
      if (hasCustomLoader && (result.action === CUSTOM_LABEL)) {
        await downloadCustom(api, gameSpec);
      }
      if (result.action === BEP_LABEL) {
        if ((BEPINEX_PAGE_NO !== 0) && allowBepinexNexus) {
          await downloadBepinexNexus(api, gameSpec);
        } else {
          await downloadBepinex(api, gameSpec);
        }
      } else if (result.action === MEL_LABEL) {
        if ((MELON_PAGE_NO !== 0) && allowMelonNexus) {
          await downloadMelonNexus(api, gameSpec);
        } else {
          await downloadMelon(api, gameSpec, true);
        }
      }
      if (hasCustomMods || loaderSwitchRestart) { //Run this if need to change a modType path based on the mod loader installed
        await deploy(api);
        relaunchExt(api);
      }
    }); //*/
  }
}

//Deconflict mod loaders
async function deconflictModLoaders(api, gameSpec) {
  const CUSTOM_LABEL = `${CUSTOMLOADER_NAME} (Recommended)`;
  const BEP_LABEL = `BepInEx`;
  const MEL_LABEL = `MelonLoader`;
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = checkCustomInstalled(api, gameSpec);
  }
  const t = api.translate;
  let choices = [
    { label: t(BEP_LABEL) },
    { label: t(MEL_LABEL) },
  ];
  if (hasCustomLoader) {
    choices = [
      { label: t(CUSTOM_LABEL) },
      { label: t(BEP_LABEL) },
      { label: t(MEL_LABEL) },
    ];
  }
  const replace = {
    game: gameSpec.game.name,
    bl: '[br][/br][br][/br]',
  };
  return api.showDialog('info', 'Mod Loader Conflict', {
    bbcode: t('You have more than one mod loader installed.{{bl}}'
      + 'This will cause the game to crash at launch. Only one mod loader can be installed at a time.{{bl}}'
      + 'You must choose which mod loader you would like to use for {{game}}.',
      { replace }
    ),
  }, choices)
  .then(async (result) => {
    if (result === undefined) {
      return;
    }
    if (hasCustomLoader && (result.action === CUSTOM_LABEL)) {
      if (melonInstalled) {
        await removeMelon(api, gameSpec);
      }
      if (bepinexInstalled) {
        await removeBepinex(api, gameSpec);
      }
    }
    if (result.action === BEP_LABEL) {
      if (melonInstalled) {
        await removeMelon(api, gameSpec);
      }
      if (hasCustomLoader && customInstalled) {
        await removeCustom(api, gameSpec);
      }
    } else if (result.action === MEL_LABEL) {
      if (bepinexInstalled) {
        await removeBepinex(api, gameSpec);
      }
      if (hasCustomLoader && customInstalled) {
        await removeCustom(api, gameSpec);
      }
    }
    if (hasCustomMods || loaderSwitchRestart) { //Run this if need to change a modType path based on the mod loader installed
      await deploy(api);
      relaunchExt(api);
    }
  });
}
async function removeBepinex(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === BEPINEX_ID);
  const modId = mods[mod].id
  log('warn', `Found BepInEx mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
  } catch (err) {
    api.showErrorNotification('Failed to remove BepInEx', err, { allowReport: false });
  }
}
async function removeMelon(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === MELON_ID);
  const modId = mods[mod].id
  log('warn', `Found MelonLoader mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
  } catch (err) {
    api.showErrorNotification('Failed to remove MelonLoader', err, { allowReport: false });
  }
}
async function removeCustom(api, gameSpec) {
  const state = api.getState();
  const mods = state.persistent.mods[gameSpec.game.id] || {};
  const mod = Object.keys(mods).find(id => mods[id]?.type === CUSTOMLOADER_ID);
  const modId = mods[mod].id
  log('warn', `Found ${CUSTOMLOADER_NAME} mod to remove for deconfliction: ${modId}`);
  try {
    await util.removeMods(api, gameSpec.game.id, [modId]);
    if (customLoaderInstaller) { //remove files from installer here if there are any
      await removeCustomFiles(api, gameSpec);
    }
  } catch (err) {
    api.showErrorNotification(`Failed to remove ${CUSTOMLOADER_NAME}`, err, { allowReport: false });
  }
}
async function removeCustomFiles(api, gameSpec) { //run on purge too
  GAME_PATH = getDiscoveryPath(api);
  let files = CUSTOMLOADER_FILES_ARRAY;
  log('warn', `Found ${CUSTOMLOADER_NAME} files to remove for deconfliction/purge: [${files.join(', ')}]`);
  await deleteFiles(GAME_PATH, files);
}
async function deleteFiles(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    try {
      await fs.unlinkAsync(path.join(gamePath, relPaths[index]));
    } catch (err) {
      log('warn', `Failed to remove ${path.join(gamePath, relPaths[index])}: ${err}`);
    }
  }
}

async function resolveGameVersion(gamePath) {
  GAME_VERSION = await setGameVersion(gamePath);
  VERSION_FILE_PATH = path.join(DATA_FOLDER, VERSION_FILE);
  let version = '0.0.0';
  if (hasVersionFile) { //use text file - Not many games have a Version.info file with the version in it
    const versionFilePath = path.join(gamePath, VERSION_FILE_PATH);
    try {
      const data = await fs.readFileAsync(versionFilePath, { encoding: 'utf8' });
      const segments = data.split(VER_SPLIT); //space is usually the split for Version.info files
      return (segments[VER_IDX]) 
        ? Promise.resolve(segments[VER_IDX])
        : Promise.reject(new util.DataInvalid('Failed to resolve version'));
    } catch (err) {
      log('error', `Could not read ${VERSION_FILE} file to get game version: ${err}`);
      return Promise.resolve(version);
    }
  } //*/
  if (GAME_VERSION === 'xbox') { // use appxmanifest.xml for Xbox version
    try {
      const appManifest = await fs.readFileAsync(path.join(gamePath, APPMANIFEST_FILE), 'utf8');
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log('error', `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  } 
  else { // use exe - only returns Unity version
    try {
      const exeVersion = require('exe-version');
      const EXEC = getExecutable(gamePath); //need to read to account for multiple exe
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC)); //getFileVersion may need to be used in some cases
      return Promise.resolve(version); 
    } catch (err) {
      log('error', `Could not read ${EXEC} file to get game version: ${err}`);
      return Promise.resolve(version);
    }
  } //*/
} //*/

//Notify User to ask if they want to download BepInExConfigManager
async function downloadBepCfgManNotify(api) {
  let isInstalled = isBepCfgManInstalled(api, spec);
  if (!isInstalled) {
    const NOTIF_ID = `${GAME_ID}-bepcfgman`;
    const MOD_NAME = BEPCFGMAN_NAME;
    const MESSAGE = `Would you like to download ${MOD_NAME}?`;
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      message: MESSAGE,
      allowSuppress: true,
      actions: [
        {
          title: 'Download BepCfgMan',
          action: (dismiss) => {
            downloadBepCfgMan(api, spec);
            dismiss();
          },
        },
        {
          title: 'More',
          action: (dismiss) => {
            api.showDialog('question', MESSAGE, {
              text: `${MOD_NAME} is a mod that allows you to configure BepInEx mods with and in-game GUI.\n`
                  + `Click the button below to download and install ${MOD_NAME}.\n`
                  + `Once installed, the default key to show the configuration menu is F1.\n`
            }, [
                {
                  label: `Download ${MOD_NAME}`, action: () => {
                    downloadBepCfgMan(api, spec);
                    dismiss();
                  }
                },
                { label: 'Not Now', action: () => dismiss() },
                {
                  label: 'Never Show Again', action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  }
                },
              ]);
          },
        },
      ],
    });  
  }
}

//Notify User to ask if they want to download MelonPreferencesManager
async function downloadMelonPrefManNotify(api) {
  let isInstalled = isMelonPrefManInstalled(api, spec);
  if (!isInstalled) {
    const NOTIF_ID = `${GAME_ID}-melonprefman`;
    const MOD_NAME = MELONPREFMAN_NAME;
    const MESSAGE = `Would you like to download ${MOD_NAME}?`;
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      message: MESSAGE,
      allowSuppress: true,
      actions: [
        {
          title: 'Download MelPrefMan',
          action: (dismiss) => {
            downloadMelonPrefMan(api, spec);
            dismiss();
          },
        },
        {
          title: 'More',
          action: (dismiss) => {
            api.showDialog('question', MESSAGE, {
              text: `${MOD_NAME} is a mod that allows you to configure MelonLoader mods with and in-game GUI.\n`
                  + `Click the button below to download and install ${MOD_NAME}.\n`
                  + `Once installed, the default key to show the configuration menu is F5.\n`
                  + '\n'
                  + `Note that due to the way the file is packaged on GitHub, the .dll will be copied directly to the Mods folder, not installed as a mod in Vortex.\n`
            }, [
                {
                  label: `Download ${MOD_NAME}`, action: () => {
                    downloadMelonPrefMan(api, spec);
                    dismiss();
                  }
                },
                { label: 'Not Now', action: () => dismiss() },
                {
                  label: 'Never Show Again', action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  }
                },
              ]);
          },
        },
      ],
    });  
  }
}

function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup-notify`;
  const MESSAGE = 'Special Setup Instructions';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `TEXT HERE.\n`
                + `\n`
                + `TEXT HERE.\n`
                + `\n`
          }, [
            { label: 'Acknowledge', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

async function modFoldersEnsureWritable(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    await fs.ensureDirWritableAsync(path.join(gamePath, relPaths[index]));
  }
}

function dotNetMelonNotify(api) {
  const NOTIF_ID = `${GAME_ID}-dotnetmelon-notify`;
  const MESSAGE = `.NET ${MELON_DOTNET_VER} Required`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Download .NET ${MELON_DOTNET_VER}`,
        action: (dismiss) => {
          util.opn(MELON_DOTNET_URL).catch(() => null);
          dismiss();
        }
      },
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `MelonLoader requires .NET ${MELON_DOTNET_VER} to be installed on your system for IL2CPP build Unity games, like this game.\n`
                + `\n`
                + `Please install .NET ${MELON_DOTNET_VER} so that MelonLoader can function. Your game may crash at launch if the correct version of .NET is not installed.\n`
                + `\n`
          }, [
            { label: `Download .NET ${MELON_DOTNET_VER}`, action: () => {
              util.opn(MELON_DOTNET_URL).catch(() => null);
              dismiss();
            }},
            { label: 'Not Now', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

async function checkDotNetMelon(api) {
  const version = MELON_DOTNET_VER;
  let values = undefined;
  try {
    const buffer = winapi.WithRegOpen( //array of objects with values.type and values.key
      DOTNET_REG_HIVE,
      DOTNET_REG_KEY,
      (hkey) => { //have to enum in the callback - https://github.com/Nexus-Mods/node-winapi-bindings/blob/master/index.d.ts
        values = winapi.RegEnumValues(hkey); //array of objects with values.type and values.key
      }
    );
    if (!values) {
      dotNetMelonNotify(api); //assume not installed if key not found
    }
    values = values.map(value => value.key); //map array to only keys
    const found = values.some(value => value.startsWith(version)); //find entry starting with correct version number
    if (found) {
      //log('warn', `Found .NET ${version} installation`);
    } else {
      dotNetMelonNotify(api); //assume not installed if key not found
    }
  } catch (err) { //*/
    log('warn', `Failed to read .NET registry key: ${err}`);
    dotNetMelonNotify(api)
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  //SYNC CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  bepinexInstalled = isBepinexInstalled(api, gameSpec);
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = isCustomInstalled(api, spec);
  }
  if (setupNotification) {
    setupNotify(api);
  }
  // ASYNC CODE ///////////////////////////////////
  if (multiExe || hasXbox) {
    GAME_VERSION = await setGameVersion(GAME_PATH);
  }
  MODTYPE_FOLDERS.push(ASSEMBLY_PATH);
  MODTYPE_FOLDERS.push(ASSETS_PATH);
  await modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
  if (!bepinexInstalled && !melonInstalled && !customInstalled) {
    await chooseModLoader(api, spec); //dialog to choose mod loader
  }
  if ( (bepinexInstalled && melonInstalled) || (bepinexInstalled && customInstalled) || (melonInstalled && customInstalled)) {
    await deconflictModLoaders(api, spec); //deconflict if multiple mod loaders are installed
  } //*/
  bepinexInstalled = isBepinexInstalled(api, gameSpec); //check installs again after install/deconflict
  melonInstalled = isMelonInstalled(api, gameSpec);
  if (hasCustomLoader) {
    customInstalled = isCustomInstalled(api, gameSpec);
  }
  if (bepinexInstalled && allowBepCfgMan) {
    downloadBepCfgManNotify(api, gameSpec); //notification to download BepInExConfigManager
  } //*/
  if (melonInstalled && allowMelPrefMan) {
    downloadMelonPrefManNotify(api, gameSpec); //notification to download MelonPreferencesManager
  } //*/
  if (melonInstalled && BEPINEX_BUILD === 'il2cpp') {
    checkDotNetMelon(api); //check for .NET 6 installation
  } //*/
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  const game = { //register game
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersion,
    supportedTools: tools,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //register mod types explicitly
  if (hasCustomMods) {
    context.registerModType(CUSTOM_ID, 58, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => getCustomFolder(context.api, game),
      () => Promise.resolve(false), 
      { name: CUSTOM_NAME }
    ); //*/
    //add more if needed
  }
  if (hasCustomLoader) {
    context.registerModType(CUSTOMLOADER_MOD_ID, 25, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}', CUSTOMLOADER_MOD_PATH)),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_PLUGIN_NAME }
    ); //*/
    context.registerModType(CUSTOMLOADER_PLUGIN_ID, 27, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}', CUSTOMLOADER_PLUGIN_PATH)),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_MOD_NAME }
    ); //*/
    context.registerModType(CUSTOMLOADER_ID, 60, 
      (gameId) => {
        var _a;
        return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
      }, 
      (game) => pathPattern(context.api, game, path.join('{gamePath}')),
      () => Promise.resolve(false), 
      { name: CUSTOMLOADER_NAME }
    ); //*/
  }

  //register mod types explicitly (due to potentially dynamic DATA_FOLDER)
  context.registerModType(ASSEMBLY_ID, 60, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, 
    (game) => pathPattern(context.api, game, path.join('{gamePath}', ASSEMBLY_PATH)), 
    () => Promise.resolve(false), 
    { name: ASSEMBLY_NAME }
  );
  context.registerModType(ASSETS_ID, 62, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, 
    (game) => pathPattern(context.api, game, path.join('{gamePath}', ASSETS_PATH)), 
    () => Promise.resolve(false), 
    { name: ASSETS_NAME }
  );

  //register mod installers
  if (hasCustomLoader) {
    context.registerInstaller(CUSTOMLOADER_ID, 25, testCustomLoader, installCustomLoader);
  }
  context.registerInstaller(BEPINEX_ID, 26, testBepinex, installBepinex);
  context.registerInstaller(BEP_LOADER_PATCH_ID, 27, testBepLoaderPatch, installBepLoaderPatch);
  context.registerInstaller(MELON_ID, 28, testMelon, installMelon);
  context.registerInstaller(ROOT_ID, 29, testRoot, installRoot);
  context.registerInstaller(BEPCFGMAN_ID, 30, testBepCfgMan, installBepCfgMan);
  context.registerInstaller(MELONPREFMAN_ID, 31, testMelonPrefMan, installMelonPrefMan);
  context.registerInstaller(ASSEMBLY_ID, 32, testAssembly, installAssembly);
  //32 - if there are other known dll files that are not loader plugins, add installers for them here
  context.registerInstaller(`${GAME_ID}-plugin`, 33, testPlugin, (files, workingDir) => installPlugin(context.api, gameSpec, files, workingDir));
  context.registerInstaller(ASSETS_ID, 37, testAssets, installAssets);
  if (hasCustomMods) {
    context.registerInstaller(CUSTOM_ID, 39, testCustom, installCustom);
  }
  if (enableSaveInstaller) {
    context.registerInstaller(SAVE_ID, 47, testSave, installSave); //best to only enable if saves are stored in the game's folder
  }
  if (fallbackInstaller) {
    context.registerInstaller(`${GAME_ID}-fallback`, 49, testFallback, (files, destinationPath) => installFallback(context.api, files, destinationPath));
  }
  
  //register actions
  /*if (BEPINEX_BUILD === 'il2cpp') {
    context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download Latest BepInEx BE (Browse)', () => {
      downloadBepinexManual(context.api, spec, false);
      }, () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
    });
  }
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download BepInExConfigManager', () => {
    downloadBepCfgManManual(context.api, spec, false);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download Latest MelonLoader', () => {
    downloadMelon(context.api, spec, false);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  if (allowMelPrefMan) {
    context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download MelonPreferencesManager', () => {
      downloadMelonPrefMan(context.api, spec, false);
      }, () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
    });
  } //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Data Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, DATA_FOLDER);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', async () => {
    //SAVE_PATH = await getSavePath(context.api);
    util.opn(SAVE_PATH).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    util.opn(CONFIG_PATH).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open BepInEx Config', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, BEP_CONFIG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open BepInEx Log', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, BEP_LOG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open MelonLoader Config', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, MEL_CONFIG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open MelonLoader Log', () => {
    GAME_PATH = getDiscoveryPath(context.api);
    const openPath = path.join(GAME_PATH, MEL_LOG_FILEPATH);
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    const openPath = path.join(__dirname, 'CHANGELOG.md');
    util.opn(openPath).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
}

//main function
function main(context) {
  applyGame(context, spec);
  context.once(() => { // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    context.api.onAsync('did-deploy', async (profileId, deployment) => { 
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== LAST_ACTIVE_PROFILE) return;
      bepinexInstalled = isBepinexInstalled(api, spec);
      melonInstalled = isMelonInstalled(api, spec);
      if (hasCustomLoader) {
        customInstalled = isCustomInstalled(api, spec);
      }
      if (!bepinexInstalled && !melonInstalled && !customInstalled) {
        await chooseModLoader(api, spec); //dialog to choose mod loader
      }
      if ( (bepinexInstalled && melonInstalled) || (bepinexInstalled && customInstalled) || (melonInstalled && customInstalled)) {
        await deconflictModLoaders(api, spec); //deconflict if multiple mod loaders are installed
      } //*/
      /*
      bepinexInstalled = isBepinexInstalled(api, spec); //check installs again after install/deconflict
      melonInstalled = isMelonInstalled(api, spec);
      if (hasCustomLoader) {
        customInstalled = isCustomInstalled(api, spec);
      } //*/
      /*if (bepinexInstalled && allowBepCfgMan) {
        downloadBepCfgManNotify(api, spec); //download BepInExConfigManager
      } //*/
      /*if (melonInstalled && allowMelPrefMan) {
        downloadMelonPrefManNotify(api, spec); //download MelonPreferencesManager
      } //*/
      if (hasCustomLoader && customLoaderInstaller && customInstalled) {
        checkCustomInstalled(api, spec); //check if user has run installer and notify if not
      }
      if (isMelonInstalled(api, spec) && BEPINEX_BUILD === 'il2cpp') {
        checkDotNetMelon(api); //check for .NET 6 installation
      } //*/
      return Promise.resolve();
    });
    context.api.onAsync('did-purge', async (profileId) => { 
      const LAST_ACTIVE_PROFILE = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
      if (profileId !== LAST_ACTIVE_PROFILE) return;
      if (hasCustomLoader) {
        bepinexInstalled = isBepinexInstalled(api, spec);
        melonInstalled = isMelonInstalled(api, spec);
        customInstalled = checkCustomInstalled(api, spec); //file check
        if (customInstalled && customLoaderInstaller) {
          await removeCustomFiles(api, spec); //delete installed files to clean folder
        }
        //*
        customInstalled = isCustomInstalled(api, spec);
        if (!bepinexInstalled && !melonInstalled && !customInstalled) {
          await chooseModLoader(api, spec); //dialog to choose mod loader
        } //*/
      }
      return Promise.resolve();
    });
  });
  return true;
}

// Test if BepInEx is installed
function isBepinexInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === BEPINEX_ID);
}

// Test if MelonLoader is installed
function isMelonInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === MELON_ID);
}

// Test if Custom Mod Loader is installed
function isCustomInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  const idTest = Object.keys(mods).some(id => mods[id]?.type === CUSTOMLOADER_ID);
  if (!customLoaderInstaller) {
    return idTest;
  }
  GAME_PATH = getDiscoveryPath(api);
  let fileTest = false;
  try {
    fs.statSync(path.join(GAME_PATH, CUSTOMLOADER_MARKER_PATH));
    fileTest = true;
  } catch (err) {
    fileTest = false;
  }
  return (idTest || fileTest);
}

// Test if Custom Mod Loader installer was run (marker file exists)
function checkCustomInstalled(api, spec) {
  GAME_PATH = getDiscoveryPath(api);
  let fileTest = false;
  try {
    fs.statSync(path.join(GAME_PATH, CUSTOMLOADER_MARKER_PATH));
    fileTest = true;
  } catch (err) {
    customInstallerNotify(api);
    fileTest = false;
  }
  return fileTest;
}
//Notify user to run Custom Mod Loader Installer if marker file not found
function customInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-custominstaller`;
  const MOD_NAME = CUSTOMLOADER_NAME;
  const MESSAGE = `Run ${MOD_NAME} Installer`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: `Run ${MOD_NAME}`,
        action: (dismiss) => {
          runCustom(api);
          dismiss();
        },
      },
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `You must run the ${MOD_NAME} installer to install necessary files to the game folder.\n`
                + `\n`
                + `IMPORTANT: Use the default installation options for compatibility with Vortex.\n`
                + `\n`
                + `Use the included tool to launch ${MOD_NAME} installer (button on this notification or in "Dashboard" tab).\n`
          }, [
            {
              label: `Run ${MOD_NAME}`, action: () => {
                runCustom(api);
                dismiss();
              }
            },
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}
function runCustom(api) {
  const TOOL_ID = CUSTOMLOADER_ID;
  const TOOL_NAME = `${CUSTOMLOADER_NAME} Installer`;
  const state = api.store.getState();
  const tool = util.getSafe(state, ['settings', 'gameMode', 'discovered', GAME_ID, 'tools', TOOL_ID], undefined);
  try {
    const TOOL_PATH = tool.path;
    if (TOOL_PATH !== undefined) {
      return api.runExecutable(TOOL_PATH, [], { suggestDeploy: false })
        .catch(err => api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err,
          { allowReport: ['EPERM', 'EACCESS', 'ENOENT'].indexOf(err.code) !== -1 })
        );
    }
    else {
      return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, `Path to ${TOOL_NAME} executable could not be found. Ensure ${TOOL_NAME} is installed through Vortex.`);
    }
  } catch (err) {
    return api.showErrorNotification(`Failed to run ${TOOL_NAME}`, err, { allowReport: ['EPERM', 'EACCESS', 'ENOENT'].indexOf(err.code) !== -1 });
  }
}

//Test if BepInExConfigManager is installed
function isBepCfgManInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === BEPCFGMAN_ID);
}

//Test if MelonPreferences Manager is installed - file read
function isMelonPrefManInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  let test =  Object.keys(mods).some(id => mods[id]?.type === MELONPREFMAN_ID);
  if (test === false) {
    try {
      GAME_PATH = getDiscoveryPath(api);
      fs.statSync(path.join(GAME_PATH, MELON_MODS_PATH, MELONPREFMAN_FILE));
      test = true;
    } catch (err) {
      test = false;
    }
  }
  return test;
}

// Download BepInEx from URL
async function downloadBepinex(api, gameSpec, check = true) {
  let isInstalled = isBepinexInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = BEPINEX_NAME;
    const MOD_TYPE = BEPINEX_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    const URL = BEPINEX_URL;
    const URL_ERR = BEPINEX_URL_ERR;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
}

//* Function to auto-download BepInEx from a Nexus Mods page
async function downloadBepinexNexus(api, gameSpec, check = true) {
  let isInstalled = isBepinexInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = BEPINEX_NAME;
    const MOD_TYPE = BEPINEX_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = BEPINEX_PAGE_NO;
    const FILE_ID = BEPINEX_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = BEPINEX_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch (err) { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// Test if BepInEx Loader Patch is installed
function isBepLoaderPatchInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === BEP_LOADER_PATCH_ID);
}

//* Function to auto-download BepInEx Loader Patch from a Nexus Mods page
async function downloadBepLoaderPatch(api, gameSpec, check = true) {
  let isInstalled = isBepLoaderPatchInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = BEP_LOADER_PATCH_NAME;
    const MOD_TYPE = BEP_LOADER_PATCH_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = BEP_LOADER_PATCH_PAGE_NO;
    const FILE_ID = BEP_LOADER_PATCH_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = BEP_LOADER_PATCH_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch (err) { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Download BepInEx BE from page (user browse for download)
async function downloadBepinexManual(api, gameSpec, check = true) {
  let isInstalled = isBepinexInstalled(api, gameSpec);
  const URL = BEPINEX_URL_ERR;
  const MOD_NAME = 'BepInEx BE';
  const MOD_TYPE = BEPINEX_ID;
  const ARCHIVE_NAME = BEPINEX_ARCHIVE_NAME;
  const instructions = api.translate(`Click on Continue below to open the browser. - `
    + `Navigate to the latest version of "${BEPINEX_ARCHIVE_NAME}" on the next page and `
    + `click on the appropriate file to download and install the mod.`
  );

  if (!isInstalled || !check) {
    return new Promise((resolve, reject) => { //Browse and download the mod
      return api.emitAndAwait('browse-for-download', URL, instructions)
      .then((result) => { //result is an array with the URL to the downloaded file as the only element
        if (!result || !result.length) { //user clicks outside the window without downloading
          return reject(new util.UserCanceled());
        }
        if (!result[0].includes(ARCHIVE_NAME)) { //if user downloads the wrong file
          return reject(new util.UserCanceled('Selected wrong download'));
        } //*/
        return Promise.resolve(result);
      })
      .catch((error) => {
        return reject(error);
      })
      .then((result) => {
        const dlInfo = {game: gameSpec.game.id, name: MOD_NAME};
        api.events.emit('start-download', result, {}, undefined,
          async (error, id) => { //callback function to check for errors and pass id to and call 'start-install-download' event
            if (error !== null && (error.name !== 'AlreadyDownloaded')) {
              return reject(error);
            }
            api.events.emit('start-install-download', id, { allowAutoEnable: true }, async (error) => { //callback function to complete the installation
              if (error !== null) {
                return reject(error);
              }
              const profileId = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
              const batched = [
                actions.setModsEnabled(api, profileId, result, true, {
                  allowAutoDeploy: true,
                  installed: true,
                }),
                actions.setModType(GAME_ID, result[0], MOD_TYPE), // Set the mod type
              ];
              util.batchDispatch(api.store, batched); // Will dispatch both actions.
              return resolve();
            });
          }, 
          'never',
          { allowInstall: false },
        );
      });
    })
    .catch(err => {
      if (err instanceof util.UserCanceled) {
        api.showErrorNotification(`User cancelled download/install of ${MOD_NAME}. Please try again.`, err, { allowReport: false });
        //util.opn(URL).catch(() => null);
        return Promise.resolve();
      } else if (err instanceof util.ProcessCanceled) {
        api.showErrorNotification(`Failed to download/install ${MOD_NAME}. Please try again or download manually.`, err, { allowReport: false });
        util.opn(URL).catch(() => null);
        return Promise.reject(err);
      } else {
        return Promise.reject(err);
      }
    });
  }
} //*/

// Download MelonLoader latest from GitHub
async function downloadMelon(api, gameSpec, check = true) {
  let isInstalled = isMelonInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = MELON_NAME;
    const MOD_TYPE = MELON_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    let URL = MELON_URL;
    if (useMelonNightly) {
      URL = MELON_URL_NIGHTLY;
    }
    const URL_ERR = MELON_URL_ERR;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
}

//* Function to auto-download MelonLoader from a Nexus Mods page
async function downloadMelonNexus(api, gameSpec, check = true) {
  let isInstalled = isMelonInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = MELON_NAME;
    const MOD_TYPE = MELON_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = MELON_PAGE_NO;
    const FILE_ID = MELON_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = MELON_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch (err) { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Function to auto-download Custom Mod Loader from Nexus Mods
async function downloadCustom(api, gameSpec, check = true) {
  let isInstalled = isCustomInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = CUSTOMLOADER_NAME;
    const MOD_TYPE = CUSTOMLOADER_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = CUSTOMLOADER_PAGE_NO;
    const FILE_ID = CUSTOMLOADER_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = CUSTOMLOADER_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1)
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch (err) { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
      if (customLoaderInstaller) { //run Custom Mod Loader installer if required
        /*
        try {
          GAME_PATH = getDiscoveryPath(api);
          const executable = path.join(GAME_PATH, CUSTOMLOADER_FOLDER, CUSTOMLOADER_EXEC);
          api.runExecutable(executable, [], { suggestDeploy: false });
        } catch (err) {
          api.showErrorNotification(`Failed to run ${MOD_NAME} installer. You must run it manually.`, err, { allowReport: false });
        } //*/
      }
    }
  }
} //*/

// Download BepInExConfigManager from GitHub
async function downloadBepCfgMan(api, gameSpec, check = true) {
  let isInstalled = isBepCfgManInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = BEPCFGMAN_NAME;
    const MOD_TYPE = BEPCFGMAN_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    const URL = BEPCFGMAN_URL_DIRECT;
    const URL_ERR = BEPCFGMAN_URL_MAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //const dlInfo = {};
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) {
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

//* Download BepInEx CfgMan from GitHub (user browse for download)
async function downloadBepCfgManManual(api, gameSpec, check = true) {
  let isInstalled = isBepCfgManInstalled(api, gameSpec);
  const URL = BEPCFGMAN_URL_MAIN;
  const MOD_NAME = BEPCFGMAN_NAME;
  const MOD_TYPE = BEPCFGMAN_ID;
  const ARCHIVE_NAME = BEPCFGMAN_ARCHIVE_NAME;
  const instructions = api.translate(`Click on Continue below to open the browser. - `
    + `Navigate to the latest experimental version of ${MOD_NAME} on the GitHub releases page and `
    + `click on the appropriate file to download and install the mod.`
  );

  if (!isInstalled || !check) {
    return new Promise((resolve, reject) => { //Browse and download the mod
      return api.emitAndAwait('browse-for-download', URL, instructions)
      .then((result) => { //result is an array with the URL to the downloaded file as the only element
        if (!result || !result.length) { //user clicks outside the window without downloading
          return reject(new util.UserCanceled());
        }
        if (!result[0].includes(ARCHIVE_NAME)) { //if user downloads the wrong file
          return reject(new util.UserCanceled('Selected wrong download'));
        } //*/
        return Promise.resolve(result);
      })
      .catch((error) => {
        return reject(error);
      })
      .then((result) => {
        const dlInfo = {game: gameSpec.game.id, name: MOD_NAME};
        api.events.emit('start-download', result, {}, undefined,
          async (error, id) => { //callback function to check for errors and pass id to and call 'start-install-download' event
            if (error !== null && (error.name !== 'AlreadyDownloaded')) {
              return reject(error);
            }
            api.events.emit('start-install-download', id, { allowAutoEnable: true }, async (error) => { //callback function to complete the installation
              if (error !== null) {
                return reject(error);
              }
              const profileId = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
              const batched = [
                actions.setModsEnabled(api, profileId, result, true, {
                  allowAutoDeploy: true,
                  installed: true,
                }),
                actions.setModType(GAME_ID, result[0], MOD_TYPE), // Set the mod type
              ];
              util.batchDispatch(api.store, batched); // Will dispatch both actions.
              return resolve();
            });
          }, 
          'never',
          { allowInstall: false },
        );
      });
    })
    .catch(err => {
      if (err instanceof util.UserCanceled) {
        api.showErrorNotification(`User cancelled download/install of ${MOD_NAME}. Please try again.`, err, { allowReport: false });
        //util.opn(URL).catch(() => null);
        return Promise.resolve();
      } else if (err instanceof util.ProcessCanceled) {
        api.showErrorNotification(`Failed to download/install ${MOD_NAME}. Please try again or download manually.`, err, { allowReport: false });
        util.opn(URL).catch(() => null);
        return Promise.reject(err);
      } else {
        return Promise.reject(err);
      }
    });
  }
} //*/

// Download MelonPreferences Manager from GitHub
async function downloadMelonPrefMan(api, gameSpec, check = true) {
  GAME_PATH = getDiscoveryPath(api);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(api.getState(), gameSpec.game.id);
  let isInstalled = isMelonPrefManInstalled(api, gameSpec);
  if (!isInstalled || !check) {
    const MOD_NAME = MELONPREFMAN_NAME;
    const MOD_TYPE = MELONPREFMAN_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const GAME_DOMAIN = gameSpec.game.id;
    const URL = MELONPREFMAN_URL;
    const URL_ERR = MELONPREFMAN_URL_ERR;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    //try {
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      //*Use promise to copy file to Mods folder directly (since it is a naked exe on GitHub and cannot be installed as a mod archive)
      return new Promise((resolve, reject) => {
        api.events.emit('start-download', [URL], {}, undefined,
          async (error, dlid) => { //callback function to check for errors and copy the dll to the Mods folder
            if (error !== null && (error.name !== 'AlreadyDownloaded')) {
              return reject(error);
            }
            try { //find file in Downloads and copy to Mods folder
              api.sendNotification({ //notification of copy process
                id: `${NOTIF_ID}-copy`,
                message: `Copying ${MOD_NAME} to MelonLoader Mods folder`,
                type: 'activity',
                noDismiss: true,
                allowSuppress: false,
              });
              let files = await fs.readdirAsync(DOWNLOAD_FOLDER);
              files = files.filter(file => (path.basename(file).toLowerCase().includes(MELONPREFMAN_STRING)))
                .sort((a,b) => a.toLowerCase().localeCompare(b.toLowerCase()))
                .reverse();
              const copyFile = files[0];
              if (copyFile === undefined) {
                throw new util.UserCanceled(`No ${MOD_NAME} download file found`);
              }
              await fs.statAsync(path.join(DOWNLOAD_FOLDER, copyFile));
              const source = path.join(DOWNLOAD_FOLDER, copyFile);
              const destination = path.join(GAME_PATH, MELON_MODS_PATH, MELONPREFMAN_FILE);
              await fs.copyAsync(source, destination, { overwrite: true });
              api.dismissNotification(NOTIF_ID);
              api.dismissNotification(`${NOTIF_ID}-copy`);
              api.sendNotification({ //notification copy success
                id: `${NOTIF_ID}-success`,
                message: `Successfully copied ${MOD_NAME} executable to Mods folder`,
                type: 'success',
                noDismiss: false,
                allowSuppress: true,
              });
            } catch (err) { //Show the user the download page if the download and copy process fails
              api.showErrorNotification(`Failed to download and copy ${MOD_NAME}`, err, { allowReport: false });
              util.opn(URL_ERR).catch(() => null);
              return reject(err);
            }
            finally {
              api.dismissNotification(NOTIF_ID);
              api.dismissNotification(`${NOTIF_ID}-copy`);
              return resolve();
            }
          },
          'never',
          { allowInstall: false },
        );
      });
    /*} catch (err) { //Show the user the download page if the download and copy process fails
      api.showErrorNotification(`Failed to download and copy ${MOD_NAME}`, err, { allowReport: false });
      util.opn(URL_ERR).catch(() => null);
      api.dismissNotification(NOTIF_ID);
      api.dismissNotification(`${NOTIF_ID}-copy`);
    } //*/
  }
} //*/

//export to Vortex
module.exports = {
  default: main,
};
