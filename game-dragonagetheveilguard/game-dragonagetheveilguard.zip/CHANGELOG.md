# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.2.2] - 2025-05-28

- Fixed profile test when checking for new versions of UnPSARC

## [0.2.1] - 2025-05-19

- Switched Frosty Mod Manager download to J-Lyt GitHub repository (more updated).

## [0.2.0] - 2025-04-11

- Implemented automatic download and update of Frosty Mod Manager Alpha.
- Added notification to run Frosty Mod Manager after deployment.
- Added buttons to open Config, Save, Frosty mods, and Vortex Downloads folders and the Changelog - folder icon in Mods toolbar.