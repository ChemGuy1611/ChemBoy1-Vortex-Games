# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- Config and save installers (partition check)

## [0.2.4] - 2025-10-23

- Fixed new version check for Frosty Mod Manage (for real this time!).

## [0.2.3] - 2025-06-17

- Fixed new version check for Frosty Mod Manager.

## [0.2.2] - 2025-05-28

- Fixed profile test when checking for new versions of Frosty Mod Manager

## [0.2.1] - 2025-05-19

- Switched Frosty Mod Manager download to J-Lyt GitHub repository (more updated).

## [0.2.0] - 2025-04-11

- Implemented automatic download and update of Frosty Mod Manager Alpha.
- Added notification to run Frosty Mod Manager after deployment.
- Added buttons to open Config, Save, Frosty mods, and Vortex Downloads folders and the Changelog - folder icon in Mods toolbar.
