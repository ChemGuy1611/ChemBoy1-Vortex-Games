# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2025-09-18

- js plugins will now be written to plugins.js file automatically at mod installation. NOTE - when the game updates, you will need to update the plugins.js file again, either by manually editing it or reinstalling all js plugin mods.

## [0.1.0] - 2025-09-18

- Inital Release
