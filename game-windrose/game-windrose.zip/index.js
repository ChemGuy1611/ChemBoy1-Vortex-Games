/*////////////////////////////////////////////////
Name: Windrose Vortex Extension
Structure: Unreal Engine Game
Author: ChemBoy1
Version: 0.3.0
Date: 2026-04-24
Notes:
- User selects where to install pak mods (SP or MP)
- Dedicated Server registered as a separate game
////////////////////////////////////////////////*/

//Import libraries
const { actions, fs, util, selectors, log } = require('vortex-api');
const path = require('path');
const template = require('string-template');
const { parseStringPromise } = require('xml2js');
const React = require('react');
//const fsPromises = require('fs/promises'); //.rm() for recursive folder deletion

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
// -------------------------------------
//#region Edit Zone
// -------------------------------------

//const USER_HOME = util.getVortexPath('home'); //only uncomment the ones needed
//const DOCUMENTS = util.getVortexPath('documents');
//const ROAMINGAPPDATA = util.getVortexPath('appData');
const LOCALAPPDATA = util.getVortexPath('localAppData');

//Specify all information about the game
const GAME_ID = "windrose"; //same as Nexus domain
const STEAMAPP_ID = "3041230"; //from steamdb.info
const STEAMAPP_ID_DEMO = "4291770"; //VERIFY if the EPIC_CODE_NAME and EXEC_DEMO match Steam full game
const EPICAPP_ID = "d08157fbe22d45fcba452680857ac58d"; //https://egdata.app/offers/2cef0862649140d1b000e0fcdd76f4c8/builds
const EPICAPP_ID_DEMO = "a8fc3e1cd0504d549ed1bbfa11b5e5ff"; //https://egdata.app/offers/4b0484bbe3334ef099180022019612ea/builds
const GOGAPP_ID = null; // from gogdb.org
const XBOXAPP_ID = null; //from appxmanifest.xml
const XBOXEXECNAME = "AppUEGameShipping"; //from appxmanifest.xml
const XBOX_PUB_ID = "XXX"; //get from Save folder. '8wekyb3d8bbwe' if published by Microsoft
const DISCOVERY_IDS_ACTIVE = [STEAMAPP_ID, EPICAPP_ID, STEAMAPP_ID_DEMO, EPICAPP_ID_DEMO]; // UPDATE THIS WITH ALL VALID IDs

const GAME_NAME = "Windrose";
const GAME_NAME_SHORT = GAME_NAME; //Try for 8-10 characters
const EPIC_CODE_NAME = "R5"; //Folder in root
const EXEC = `Windrose.exe`; //This is true ~80% of the time. Change if different
const EXEC_EPIC = EXEC; //change these 3 if different
const EXEC_GOG = EXEC;
const EXEC_DEMO = EXEC;
const PARAMETERS_STRING = ''; //launch arguments to pass when launching the game
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Windrose";
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/1752"; //Nexus link to this extension. Used for links

//feature toggles
const hasXbox = false; //toggle for Xbox version logic.
let multiExe = false; //toggle for multiple executables (Epic/GOG/Demo don't match Steam)
if ( (EXEC !== EXEC_EPIC) || (EXEC !== EXEC_GOG) || (EXEC !== EXEC_DEMO) ) {
  multiExe = true;
} //*/
const setupNotification = false; //enable to show the user a notification with special instructions (specify below)
const hasModKit = false; //toggle for UE ModKit mod support
const hasServer = true; //toggle for server pak mod logic
const preferHardlinks = true; //set true to perform partition checks when IO-STORE=false for Config/Save modtypes so that hardlinks available to more users
const autoDownloadUe4ss = false; //toggle for auto downloading UE4SS
const SIGBYPASS_REQUIRED = false; //set true if there are .sig files in the Paks folder
const IO_STORE = true; //true if the Paks folder contains .ucas and .utoc files
const hasUserIdFolder = false; //true if there is a folder in the Save path that is a user ID that must be read (i.e. Steam ID)

//UE specific
const ENGINE_VERSION = '5.6.1.0'; //Unreal Engine version - info only atm. usually '4.27.2.0' or '5.X.X.0'
const ROOT_FOLDERS = [EPIC_CODE_NAME, 'Engine']; //addressable folders in root
const ROOTSUB_FOLDERS = ['Content', 'Binaries', 'Mods']; //subfolders of EPIC_CODE_NAME. Don't use "Plugins" here since it can conflict with plugin loader/asi mods
const SAVE_EXT = ".sav";
const SAVE_COMPAT_VERSIONS = ['steam', 'epic', 'gog']; //game versions with installable save mods (never Xbox)
let PAKMOD_PATH = path.join(EPIC_CODE_NAME, 'Content', 'Paks', '~mods'); //usually works. Some games don't work from "~mods".
const PAKMOD_LOADORDER = true; //set to false if you don't want loadOrder. If must be in "Paks" root, disable loadOrder.
const FBLO = true; //set to false to use legacy load order page
const LO_IMAGE_WIDTH = 96; //Width of the load order thumbnail image
const SPECIAL_LO_INSTRUCTIONS = 'The Load Order is for Client (SP) Paks only!'; //Show special load order instructions
const PAKMOD_EXTRA_EXTS = []; //extra extensions to include with paks (usually for custom modding frameworks, i.e .toml, .json)
const UE4SS_PAGE_NO = 43; //set these if there is a customized UE4SS Nexus page
const UE4SS_FILE_NO = 248;
const UE4SS_DOMAIN = GAME_ID; //either GAME_ID or 'site'
const UE4SS_MOD_PATH = path.join('ue4ss', 'Mods'); //this should probably never change (unless UE4SS team changes it again lol)

//config, save, shipping exe
const DATA_FOLDER = EPIC_CODE_NAME; //almost always matches.
const CONFIG_FOLDERNAME = 'Windows'; //UE 4 games are often 'WindowsNoEditor'
const CONFIG_LOC = 'Local AppData'; //string for notification text.
const SAVE_LOC = CONFIG_LOC; //string for notification text. Config and Save mods are almost always in the same place
const CONFIGMOD_LOCATION = LOCALAPPDATA; //almost always matches. Some are in game folder or Documents.
const SAVEMOD_LOCATION = CONFIGMOD_LOCATION;

//shipping exe
const SHIPEXE_STRING_DEFAULT = '';
const SHIPEXE_STRING_EGS = '';
const SHIPEXE_STRING_GOG = '';
const SHIPEXE_STRING_XBOX = '';
const SHIPEXE_STRING_DEMO = '';
const SHIPEXE_PROJECTNAME = EPIC_CODE_NAME; //almost always matches.

//Save Editor (only used if one is available)
const SAVE_EDITOR_ID = `${GAME_ID}-saveeditor`;
const SAVE_EDITOR_NAME = "Save Editor";
const SAVE_EDITOR_EXEC = "XXX.exe";

//#endregion
// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const LO_IMAGE_HEIGHT = LO_IMAGE_WIDTH * 0.5625;
//const ENGINE_VERSION_NO = +ENGINE_VERSION;
let configSaveMatch = (CONFIGMOD_LOCATION === SAVEMOD_LOCATION); //true if the config and save mods are in the same folder
const XBOX_SAVE_STRING = XBOX_PUB_ID;
const CONFIG_PATH_DEFAULT = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, "Saved", "Config", CONFIG_FOLDERNAME);
const CONFIG_PATH_XBOX = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, "Saved", "Config", "WinGDK"); //XBOX Version
const SAVE_PATH_DEFAULT = path.join(SAVEMOD_LOCATION, DATA_FOLDER, "Saved", "SaveGames");
const SAVE_PATH_XBOX = path.join(LOCALAPPDATA, "Packages", `${XBOXAPP_ID}_${XBOX_SAVE_STRING}`, "SystemAppData", "wgs"); //XBOX Version

//Settings related to the IO Store UE feature
if (!PAKMOD_LOADORDER) PAKMOD_PATH = path.join(EPIC_CODE_NAME, 'Content', 'Paks'); //if loadOrder is disabled, Paks must be in root
let PAKMOD_EXTS = ['.pak'].concat(PAKMOD_EXTRA_EXTS);
let PAK_FILE_MIN = PAKMOD_EXTS.length;
let SYM_LINKS = true;
if (IO_STORE) { //Set file number for pak installer file selection (needs to be 3 if IO Store is used to accomodate .ucas and .utoc files)
  SYM_LINKS = false;
  PAKMOD_EXTS = ['.pak', '.ucas', '.utoc'].concat(PAKMOD_EXTRA_EXTS);
  PAK_FILE_MIN = PAKMOD_EXTS.length;
}

//global variables to set later
let GAME_PATH = ''; //game installation path
let CHECK_CONFIG = false; //boolean to check if game, staging folder, and config and save folders are on the same drive
let CHECK_SAVE = false; //secondary same as above (if save and config are in different locations)
let STAGING_FOLDER = ''; //Vortex staging folder path
let DOWNLOAD_FOLDER = ''; //Vortex download folder path
let GAME_VERSION = '';
let USERID_FOLDER = "";
let STORE_FOLDER = '';

//other constants
const APPMANIFEST_FILE = 'appxmanifest.xml';
const EXEC_XBOX = 'gamelaunchhelper.exe';
const EXEC_FOLDER_DEFAULT = "Win64"; //almost never changes
const EXEC_FOLDER_XBOX = "WinGDK"; //almost never changes

//Unreal Engine Game Data
const UNREALDATA = {
  modsPath: PAKMOD_PATH,
  fileExt: PAKMOD_EXTS,
  loadOrder: PAKMOD_LOADORDER,
}
const UE5_SORTABLE_ID = `${GAME_ID}-uesortablepak`; //this should not be changed to be maintain consistency with other UE5 games
const UE5_SORTABLE_NAME = 'UE Sortable Pak Mod';

//Information for modtypes, installers, tools, and actions
const BINARIES_ID = `${GAME_ID}-binaries`;
const BINARIES_NAME = "Binaries (Engine Injector)";
let BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
let SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEFAULT}-Shipping.exe`);

const GOG_FILE = path.join('Plugins', 'OnlineSubsystemGOG', 'GalaxySDK', 'Galaxy64.dll');
const STEAM_FILE = path.join('Engine', 'Binaries', 'ThirdParty', 'Steamworks', 'Steamv153', 'Win64', 'steam_api64.dll');
const EPIC_FILE = path.join(EPIC_CODE_NAME, 'Binaries', 'Win64', SHIPPING_EXE);
const XBOX_FILE = EXEC_XBOX;

const PAK_ALT_ID = `${GAME_ID}-pakalt`;
let PAK_ALT_NAME = 'Paks (no "~mods")';
let PAK_ALT_PATH = path.join(EPIC_CODE_NAME, 'Content', 'Paks');
if (UNREALDATA.loadOrder === false) {
  PAK_ALT_PATH = path.join(EPIC_CODE_NAME, 'Content', 'Paks', '~mods');
  PAK_ALT_NAME = 'Paks (with "~mods")';
}
const PAK_PATH = UNREALDATA.modsPath;
const PAK_EXT = '.pak';

const ROOT_ID = `${GAME_ID}-root`;
const ROOT_NAME = "Root Game Folder";
const ROOT_FOLDER = EPIC_CODE_NAME;

const ROOTSUB_ID = `${GAME_ID}-rootsubfolders`;
const ROOTSUB_NAME = "Root Sub-Folders";
const ROOTSUB_PATH = EPIC_CODE_NAME;

const CONFIG_ID = `${GAME_ID}-config`;
const CONFIG_NAME = `Config (${CONFIG_LOC})`;
let CONFIG_PATH = CONFIG_PATH_DEFAULT;
const CONFIG_FILES = ["engine.ini", "scalability.ini", "input.ini", "game.ini", "gameusersettings.ini"];
const CONFIG_EXT = ".ini";

const SAVE_ID = `${GAME_ID}-save`;
const SAVE_NAME = `Saves (${SAVE_LOC})`;
const SAVE_FOLDER = SAVE_PATH_DEFAULT;
if (hasUserIdFolder) {
  try {
    const SAVE_ARRAY = fs.readdirSync(SAVE_FOLDER);
    USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(SAVE_FOLDER, entry));
  } catch(err) {
    USERID_FOLDER = "";
  }
  if (USERID_FOLDER === undefined) {
    USERID_FOLDER = "";
  } //*/
}
let SAVE_PATH = path.join(SAVE_FOLDER, USERID_FOLDER);

const SCRIPTS_ID = `${GAME_ID}-scripts`;
const SCRIPTS_NAME = "UE4SS Script Mod";
const SCRIPTS_EXT = ".lua";
const SCRIPTS_FOLDER = "Scripts";
let SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);

const DLL_ID = `${GAME_ID}-ue4ssdll`;
const DLL_NAME = "UE4SS DLL Mod";
const DLL_EXT = ".dll";
const DLL_FOLDER = "dlls";
let DLL_PATH = SCRIPTS_PATH;

const LOGICMODS_ID = `${GAME_ID}-logicmods`;
const LOGICMODS_NAME = "UE4SS LogicMods (Blueprint)";
const UE4SSCOMBO_ID = `${GAME_ID}-ue4sscombo`;
const UE4SSCOMBO_NAME = "UE4SS Script-LogicMod Combo";
const LOGICMODS_PATH = path.join(EPIC_CODE_NAME, 'Content', 'Paks');
const LOGICMODS_FOLDER = "LogicMods";
const LOGICMODS_EXT = ".pak";

const UE4SS_ID = `${GAME_ID}-ue4ss`;
const UE4SS_NAME = "UE4SS";
const UE4SS_FILE = "dwmapi.dll";
const UE4SS_DLFILE_STRING = "ue4ss_v";
const UE4SS_URL = "https://github.com/UE4SS-RE/RE-UE4SS/releases";
const UE4SS_SETTINGS_FILE = 'UE4SS-settings.ini';
const UE4SS_SETTINGS_FILEPATH = path.join('ue4ss', UE4SS_SETTINGS_FILE); //relative to Binaries folder
const UE4SS_MODSJSON_FILE = 'mods.json';
const UE4SS_MODSTXT_FILE = 'mods.txt';
const UE4SS_MODSJSON_FILEPATH = path.join(UE4SS_MOD_PATH, UE4SS_MODSJSON_FILE); //relative to Binaries folder
const UE4SS_MODSTXT_FILEPATH = path.join(UE4SS_MOD_PATH, UE4SS_MODSTXT_FILE);

//Signature Bypass (only used if game requires)
const SIGBYPASS_ID = `${GAME_ID}-sigbypass`;
const SIGBYPASS_NAME = "Sig Bypass";
const SIGBYPASS_DLL = "dsound.dll";
const SIGBYPASS_LUA = "UniversalSigBypasser.asi";
const SIGBYPASS_PAGE_NO = 1416;
const SIGBYPASS_FILE_NO = 5719;
const SIGBYPASS_DOMAIN = 'site';

//ModKit (only used if game supports)
const MODKITMOD_ID = `${GAME_ID}-modkitmod`;
const MODKITMOD_NAME = "ModKit mod";
const MODKITMOD_FILE = 'mod.json';
const MODKITMOD_EXT = '.uplugin';
const MODKITMOD_PATH = path.join(EPIC_CODE_NAME, 'Mods');

//server (MP) mods
const SERVERPAKS_ID = `${GAME_ID}-serverpaks`;
const SERVERPAKS_NAME = "Server Pak Mod";
const SERVERPAKS_PATH_BASE = path.join(EPIC_CODE_NAME, 'Builds', 'WindowsServer', EPIC_CODE_NAME, 'Content', 'Paks');
const SERVERPAKS_PATH = path.join(SERVERPAKS_PATH_BASE, '~mods');

const MODKIT_ID = `${GAME_ID}-modkit`;
const MODKIT_NAME = "ModKit";
const MODKITAPP_ID = "XXX";
const MODKIT_EXEC_NAME = "ModKit.exe";
const MODKIT_FOLDER = path.join('XXX', 'Binaries', 'Win64');
const MODKIT_EXEC_PATH = path.join(MODKIT_FOLDER, MODKIT_EXEC_NAME);

// -- START EDIT ZONE -- ///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

const LO_FILE_NAME = 'loadOrder.json';
const MOD_PATH_DEFAULT = PAK_PATH;
const REQ_FILE = EPIC_CODE_NAME;
const PARAMETERS = [PARAMETERS_STRING];

const IGNORE_CONFLICTS = [path.join('**', 'changelog*'), path.join('**', 'readme*')];
const IGNORE_DEPLOY = [path.join('**', 'changelog*'), path.join('**', 'readme*')];
let MODTYPE_FOLDERS = [path.join(LOGICMODS_PATH, LOGICMODS_FOLDER), PAK_PATH, PAK_ALT_PATH, SERVERPAKS_PATH];

// -- END EDIT ZONE -- /////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

//Filled in from data above
const spec = {
  "game": {
    "id": GAME_ID,
    "name": GAME_NAME,
    "shortName": GAME_NAME_SHORT,
    //"parameters": PARAMETERS, //must uncomment manually since we don't want to send empty string parameter
    "logo": `${GAME_ID}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPath": MOD_PATH_DEFAULT,
    "modPathIsRelative": true,
    "requiredFiles": [
      REQ_FILE
    ],
    "compatible": {
      "dinput": false,
      "enb": false,
    },
    "details": {
      //"steamAppId": +STEAMAPP_ID_DEMO,
      "steamAppId": +STEAMAPP_ID,
      "gogAppId": GOGAPP_ID,
      //"epicAppId": EPICAPP_ID_DEMO,
      "epicAppId": EPICAPP_ID,
      "xboxAppId": XBOXAPP_ID,
      "supportsSymlinks": SYM_LINKS,
      "ignoreConflicts": IGNORE_CONFLICTS,
      "ignoreDeploy": IGNORE_DEPLOY,
    },
    "environment": {
      //"SteamAPPId": STEAMAPP_ID_DEMO,
      "SteamAPPId": STEAMAPP_ID,
      "GogAPPId": GOGAPP_ID,
      //"EpicAPPId": EPICAPP_ID_DEMO,
      "EpicAPPId": EPICAPP_ID,
      "XboxAPPId": XBOXAPP_ID,
    },
  },
  "modTypes": [
    {
      "id": SERVERPAKS_ID,
      "name": SERVERPAKS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', SERVERPAKS_PATH)
    },
    {
      "id": UE4SSCOMBO_ID,
      "name": UE4SSCOMBO_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": LOGICMODS_ID,
      "name": LOGICMODS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', LOGICMODS_PATH)
    },
    {
      "id": PAK_ALT_ID,
      "name": PAK_ALT_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', PAK_ALT_PATH)
    },
    {
      "id": ROOT_ID,
      "name": ROOT_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": ROOTSUB_ID,
      "name": ROOTSUB_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', ROOTSUB_PATH)
    },
    {
      "id": BINARIES_ID,
      "name": BINARIES_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BINARIES_PATH)
    },
    {
      "id": UE4SS_ID,
      "name": UE4SS_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', BINARIES_PATH)
    },
    {
      "id": SCRIPTS_ID,
      "name": SCRIPTS_ID,
      "priority": "low",
      "targetPath": path.join('{gamePath}', SCRIPTS_PATH)
    },
    {
      "id": DLL_ID,
      "name": DLL_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', DLL_PATH)
    },
  ],
  "discovery": {
    "ids": DISCOVERY_IDS_ACTIVE,
    "names": []
  }
};

if (hasModKit) {
  spec.modTypes.push({
    "id": MODKITMOD_ID,
    "name": MODKITMOD_NAME,
    "priority": "high",
    "targetPath": path.join('{gamePath}', MODKITMOD_PATH)
  });
}

//for Dedicated Server
const GAME_ID_SERVER = "windrose-server";
const GAME_NAME_SERVER = "Windrose Dedicated Server";
const GAME_NAME_SHORT_SERVER = "Windrose Server"; //Try for 8-10 characters
const STEAMAPP_ID_SERVER = "4129620"; //https://steamdb.info/app/4129620/
const EPICAPP_ID_SERVER = "XXX"; //from egdata.app
const DISCOVERY_IDS_ACTIVE_SERVER = [STEAMAPP_ID]; // UPDATE THIS WITH ALL VALID IDs
const EXEC_SERVER = "WindroseServer.exe";
const UE5_SORTABLE_ID_SERVER = `${GAME_ID_SERVER}-uesortablepak`; //this should not be changed to be maintain consistency with other UE5 games
let GAME_PATH_SERVER = ''; //game installation path
let STAGING_FOLDER_SERVER = ''; //Vortex staging folder path
let DOWNLOAD_FOLDER_SERVER = ''; //Vortex download folder path
let GAME_VERSION_SERVER = '';
const SHIPPING_EXE_SERVER = path.join(BINARIES_PATH, `WindroseServer-Win64-Shipping.exe`);

const specServer = {
  "game": {
    "id": GAME_ID_SERVER,
    "name": GAME_NAME_SERVER,
    "shortName": GAME_NAME_SHORT_SERVER,
    //"parameters": PARAMETERS, //must uncomment manually since we don't want to send empty string parameter
    "logo": `${GAME_ID_SERVER}.jpg`,
    "mergeMods": true,
    "requiresCleanup": true,
    "modPathIsRelative": true,
    "requiredFiles": [
      REQ_FILE
    ],
    "compatible": {
      "dinput": false,
      "enb": false,
      "nexusPageId": GAME_ID,
      "compatibleDownloads": [GAME_ID],
    },
    "details": {
      "steamAppId": +STEAMAPP_ID_SERVER,
      "epicAppId": EPICAPP_ID_SERVER,
      "supportsSymlinks": false,
      "ignoreConflicts": IGNORE_CONFLICTS,
      "ignoreDeploy": IGNORE_DEPLOY,
    },
    "environment": {
      "SteamAPPId": STEAMAPP_ID_SERVER,
      "EpicAPPId": EPICAPP_ID_SERVER,
    },
  },
  "modTypes": [
    {
      "id": UE4SSCOMBO_ID,
      "name": UE4SSCOMBO_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": LOGICMODS_ID,
      "name": LOGICMODS_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', LOGICMODS_PATH)
    },
    {
      "id": PAK_ALT_ID,
      "name": PAK_ALT_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', PAK_ALT_PATH)
    },
    {
      "id": ROOT_ID,
      "name": ROOT_NAME,
      "priority": "high",
      "targetPath": "{gamePath}"
    },
    {
      "id": ROOTSUB_ID,
      "name": ROOTSUB_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', ROOTSUB_PATH)
    },
    {
      "id": BINARIES_ID,
      "name": BINARIES_NAME,
      "priority": "high",
      "targetPath": path.join('{gamePath}', BINARIES_PATH)
    },
    {
      "id": UE4SS_ID,
      "name": UE4SS_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', BINARIES_PATH)
    },
    {
      "id": SCRIPTS_ID,
      "name": SCRIPTS_ID,
      "priority": "low",
      "targetPath": path.join('{gamePath}', SCRIPTS_PATH)
    },
    {
      "id": DLL_ID,
      "name": DLL_NAME,
      "priority": "low",
      "targetPath": path.join('{gamePath}', DLL_PATH)
    },
  ],
  "discovery": {
    "ids": DISCOVERY_IDS_ACTIVE_SERVER,
    "names": []
  }
};

if (hasModKit) {
  specServer.modTypes.push({
    "id": MODKITMOD_ID,
    "name": MODKITMOD_NAME,
    "priority": "high",
    "targetPath": path.join('{gamePath}', MODKITMOD_PATH)
  });
}

// BASIC EXTENSION FUNCTIONS ///////////////////////////////////////////////////

function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  }
  catch (err) {
    return false;
  }
}
async function statCheckAsync(gamePath, file) {
  try {
    await fs.statAsync(path.join(gamePath, file));
    return true;
  }
  catch (err) {
    return false;
  }
}

//Set mod type priority
function modTypePriority(priority) {
  return {
    high: 30,
    low: 75,
  }[priority];
}

//Replace folder path string placeholders with actual folder paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath: (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0 ? void 0 : _a.path,
      documents: util.getVortexPath('documents'),
      localAppData: util.getVortexPath('localAppData'),
      appData: util.getVortexPath('appData'),
    });
  }
  catch (err) { //this happens if the executable comes back as "undefined", usually caused by another app locking down the folder
    api.showErrorNotification('Failed to locate executable. Please launch the game at least once.', err);
  }
}

//Set mod path
function makeGetModPath(api, gameSpec) {
  return () => gameSpec.game.modPathIsRelative !== false
    ? gameSpec.game.modPath || '.'
    : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () => util.GameStoreHelper.findByAppId(gameSpec.discovery.ids)
    .then((game) => game.gamePath);
}

async function requiresLauncher(gamePath, store) {
  if (store === 'xbox' && DISCOVERY_IDS_ACTIVE.includes(XBOXAPP_ID)) {
    return Promise.resolve({
      launcher: 'xbox',
      addInfo: {
        appId: XBOXAPP_ID,
        parameters: [{ appExecName: XBOXEXECNAME }],
      },
    });
  } //*/
  //*
  if (store === 'epic' && DISCOVERY_IDS_ACTIVE.includes(EPICAPP_ID)) {
    return Promise.resolve({
        launcher: 'epic',
        addInfo: {
            appId: EPICAPP_ID,
        },
    });
  } //*/
  //*
  if (store === 'steam') {
    return Promise.resolve({
        launcher: 'steam',
    });
  } //*/
  return Promise.resolve(undefined);
}

async function requiresLauncherServer(gamePath, store) {
  //*
  if (store === 'epic' && DISCOVERY_IDS_ACTIVE_SERVER.includes(EPICAPP_ID_SERVER)) {
    return Promise.resolve({
        launcher: 'epic',
        addInfo: {
            appId: EPICAPP_ID_SERVER,
        },
    });
  } //*/
  //*
  if (store === 'steam') {
    return Promise.resolve({
        launcher: 'steam',
    });
  } //*/
  return Promise.resolve(undefined);
}

function getUserIdFolder(savePath) {
  try {
    const SAVE_ARRAY = fs.readdirSync(savePath);
    USERID_FOLDER = SAVE_ARRAY.find((entry) => isDir(savePath, entry));
  } catch(err) {
    USERID_FOLDER = "";
  }
  if (USERID_FOLDER === undefined) {
    USERID_FOLDER = "";
  }
  return SAVE_PATH = path.join(savePath, USERID_FOLDER);
}

//Get correct executable for game version
function getExecutable(discoveryPath) {
  if (!hasXbox && !multiExe) {
    return EXEC;
  }
  if (hasXbox) {
    if (statCheckSync(discoveryPath, EXEC_XBOX)) {
      GAME_VERSION = 'xbox';
      BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_XBOX);
      SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_XBOX}${SHIPEXE_STRING_XBOX}-Shipping.exe`);
      SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
      DLL_PATH = SCRIPTS_PATH;
      CONFIG_PATH = CONFIG_PATH_XBOX;
      //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
      SAVE_PATH = getUserIdFolder(SAVE_PATH_XBOX);
      return EXEC_XBOX;
    }
  }
  if (statCheckSync(discoveryPath, EXEC)) {
    GAME_VERSION = 'steam';
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEFAULT}-Shipping.exe`);
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_DEMO)) {
    GAME_VERSION = 'demo';
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_DEMO}-Shipping.exe`);
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_DEMO;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_EPIC)) {
    GAME_VERSION = 'epic';
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_EGS}-Shipping.exe`);
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_EPIC;
  } //*/
  if (statCheckSync(discoveryPath, EXEC_GOG)) {
    GAME_VERSION = 'gog';
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
    SHIPPING_EXE = path.join(BINARIES_PATH, `${SHIPEXE_PROJECTNAME}-${EXEC_FOLDER_DEFAULT}${SHIPEXE_STRING_GOG}-Shipping.exe`);
    SCRIPTS_PATH = path.join(BINARIES_PATH, UE4SS_MOD_PATH);
    DLL_PATH = SCRIPTS_PATH;
    CONFIG_PATH = CONFIG_PATH_DEFAULT;
    //CONFIG_PATH = setConfigPath(GAME_VERSION); //if there's an intermediate store folder in the path
    //SAVE_PATH = setSavePath;
    SAVE_PATH = SAVE_PATH_DEFAULT;
    return EXEC_GOG;
  } //*/
  GAME_VERSION = 'default';
  return EXEC;
}

//Get correct shipping executable for game version
function getShippingExe(gamePath) {
  if (hasXbox) {
    if (statCheckSync(gamePath, EXEC_XBOX)) {
      SHIPPING_EXE = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_XBOX, `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_XBOX}-${EXEC_FOLDER_XBOX}-Shipping.exe`);
      return SHIPPING_EXE; 
    }
  }
  if (statCheckSync(gamePath, EXEC)) {
    SHIPPING_EXE = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT, `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_DEFAULT}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`);
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_EPIC)) {
    SHIPPING_EXE = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT, `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_EGS}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`);
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_GOG)) {
    SHIPPING_EXE = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT, `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_GOG}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`);
    return SHIPPING_EXE;
  }
  if (statCheckSync(gamePath, EXEC_DEMO)) {
    SHIPPING_EXE = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT, `${SHIPEXE_PROJECTNAME}${SHIPEXE_STRING_DEMO}-${EXEC_FOLDER_DEFAULT}-Shipping.exe`);
    return SHIPPING_EXE;
  }
}

//Get correct shipping executable folder for game version (for tool pathing)
function getBinariesFolder(discoveryPath) {
  if (!hasXbox) {
    return BINARIES_PATH;
  }
  if (statCheckSync(discoveryPath, EXEC_FOLDER_XBOX)) {
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_XBOX);
    return BINARIES_PATH;
  }
  if (statCheckSync(discoveryPath, EXEC_FOLDER_DEFAULT)) {
    BINARIES_PATH = path.join(EPIC_CODE_NAME, 'Binaries', EXEC_FOLDER_DEFAULT);
    return BINARIES_PATH;
  }
}

//Get correct game version - async
async function setGameVersionAsync(gamePath) {
  if (hasXbox) {
    if (await statCheckAsync(gamePath, EXEC_XBOX)) {
      GAME_VERSION = 'xbox';
      return GAME_VERSION;
    }
  }
  if (await statCheckAsync(gamePath, EXEC)) {
    GAME_VERSION = 'steam';
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_EPIC)) {
    GAME_VERSION = 'epic';
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_GOG)) {
    GAME_VERSION = 'gog';
    return GAME_VERSION;
  }
  if (await statCheckAsync(gamePath, EXEC_DEMO)) {
    GAME_VERSION = 'demo';
    return GAME_VERSION;
  } //*/
}

//Get correct game version - synchronous
function setGameVersionSync(gamePath) {
  if (hasXbox) {
    if (statCheckSync(gamePath, EXEC_XBOX)) {
      GAME_VERSION = 'xbox';
      return GAME_VERSION;
    }
  }
  if (statCheckSync(gamePath, EXEC)) {
    GAME_VERSION = 'steam';
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_EPIC)) {
    GAME_VERSION = 'epic';
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_GOG)) {
    GAME_VERSION = 'gog';
    return GAME_VERSION;
  }
  if (statCheckSync(gamePath, EXEC_DEMO)) {
    GAME_VERSION = 'demo';
    return GAME_VERSION;
  } //*/
}

//Get correct config path for game version
async function setConfigPath(version) {
  const DATA_PATH = path.join(CONFIGMOD_LOCATION, DATA_FOLDER);
  try {
    const ARRAY = await fs.readdirAsync(DATA_PATH);
    STORE_FOLDER = ARRAY.find(entry => isDir(DATA_PATH, entry));
  } catch(err) {
    STORE_FOLDER = '';
  }
  if (STORE_FOLDER === undefined) {
    STORE_FOLDER = '';
  } 
  CONFIG_PATH = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, STORE_FOLDER, "Saved", "Config", CONFIG_FOLDERNAME);
  if (version === 'xbox') {
    CONFIG_PATH = path.join(CONFIGMOD_LOCATION, DATA_FOLDER, STORE_FOLDER, "Saved", "Config", 'WinGDK');
  }
  return CONFIG_PATH;
}

//Get correct save path for game version
async function setSavePath() {
  const DATA_PATH = path.join(SAVEMOD_LOCATION, DATA_FOLDER);
  try {
    const ARRAY = await fs.readdirAsync(DATA_PATH);
    STORE_FOLDER = ARRAY.find(entry => isDir(DATA_PATH, entry));
  } catch(err) {
    STORE_FOLDER = '';
  }
  if (STORE_FOLDER === undefined) {
    STORE_FOLDER = '';
  }
  SAVE_PATH = path.join(SAVEMOD_LOCATION, DATA_FOLDER, STORE_FOLDER, "Saved", "SaveGames");
  SAVE_PATH = getUserIdFolder(SAVE_PATH);
  return SAVE_PATH;
} //*/

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fs.readdirAsync(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fs.statAsync(fullPath);
      if (stats.isDirectory()) { // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else { // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log('warn', `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api, id) => { //get the game's discovered path
  const state = api.getState();
  const discovery = util.getSafe(state, [`settings`, `gameMode`, `discovered`, id], {});
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  return new Promise((resolve, reject) => api.events.emit('purge-mods', true, (err) => err ? reject(err) : resolve()));
}
async function deploy(api) {
  return new Promise((resolve, reject) => api.events.emit('deploy-mods', (err) => err ? reject(err) : resolve()));
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for modkit mod files
function testModKitMod(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === MODKITMOD_EXT));
  const isJson = files.some(file => (path.basename(file).toLowerCase() === MODKITMOD_FILE));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && ( isMod && isJson );

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install modkit mod files
function installModKitMod(files, fileName) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === MODKITMOD_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: MODKITMOD_ID };
  let MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, '');
  if (rootPath !== '.') {
    MOD_NAME = path.basename(rootPath);
    MOD_FOLDER = MOD_NAME;
  }
  try { //read mod.json file to get folder name (game will crash if this doesn't match)
    const JSON_OBJECT = JSON.parse(fs.readFileSync(path.join(fileName, rootPath, MODKITMOD_FILE)));
    const JSON_MOD_NAME = JSON_OBJECT["modPluginName"];
    MOD_FOLDER = JSON_MOD_NAME;
  } catch (err) { //mod.json could not be read.
    log('error', `Could not read mod.json file for mod ${MOD_NAME}.`);
  }

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for UE4SS combo (pak and lua/dll) mod files
function testUe4ssCombo(files, gameId) {
  //const isMod = files.some(file => (path.extname(file).toLowerCase() === SCRIPTS_EXT));
  const isBinaries = files.some(file => (path.basename(file).toLowerCase() === 'binaries')); //added to catch mods packaged with paks and dll/asi, but no lua scripts.
  //const isPak = files.some(file => (path.extname(file).toLowerCase() === LOGICMODS_EXT));
  const isContent = files.some(file => (path.basename(file).toLowerCase() === 'content'));
  //const isFolder = files.some(file => (path.basename(file).toLowerCase() === ROOT_FOLDER.toLowerCase()));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && isContent && isBinaries;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS combo (pak and lua/dll) mod files
async function installUe4ssCombo(files, workingDir) {
  //const modFile = files.find(file => (path.basename(file).toLowerCase() === ROOT_FOLDER.toLowerCase()));
  const modFile = files.find(file => (path.basename(file).toLowerCase() === 'binaries'));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: UE4SSCOMBO_ID };

  if (GAME_VERSION === 'xbox') {
    try {
      /*await fs.statAsync(path.join(workingDir, modFile, 'Binaries', 'Win64'));
      await fs.renameAsync(path.join(workingDir, modFile, 'Binaries', 'Win64'), path.join(workingDir, modFile, 'Binaries', 'WinGDK')); //*/
      await fs.statAsync(path.join(workingDir, modFile, 'Win64'));
      await fs.renameAsync(path.join(workingDir, modFile, 'Win64'), path.join(workingDir, modFile, 'WinGDK')); //*/
      const paths = await getAllFiles(workingDir);
      files = [...paths.map(p => p.replace(`${workingDir}${path.sep}`, ''))];
    } catch (err) {
      log('warn', `Failed to rename "Win64" folder to "WinGDK" for UE4SS combo mod ${workingDir} (or "Win64" folder is not present): ${err}`);
    }
  }

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );

  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      //destination: path.join(file.substr(idx)),
      destination: path.join(EPIC_CODE_NAME, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for save files
function testLogic(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === LOGICMODS_FOLDER.toLowerCase()));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install save files
function installLogic(files) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === LOGICMODS_FOLDER.toLowerCase()));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: LOGICMODS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) &&
      (!file.endsWith(path.sep))
    )
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for UE4SS files
function testUe4ss(files, gameId) {
  const isMod = files.some(file => (path.basename(file).toLowerCase() === UE4SS_FILE));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install UE4SS files
function installUe4ss(files) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === UE4SS_FILE));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: UE4SS_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for UE4SS Script files
function testScripts(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === SCRIPTS_EXT));
  const isFolder = files.some(file => (path.basename(file).toLowerCase() === SCRIPTS_FOLDER.toLowerCase()));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && isMod && isFolder;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS Script files
function installScripts(files, fileName) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === SCRIPTS_FOLDER.toLowerCase()));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: SCRIPTS_ID };
  const MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = path.basename(rootPath);
  if (MOD_FOLDER === '.') {
    MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, '');
  }
  
  const ENABLEDTXT_FILE = 'enabled.txt'
  const ENABLEDTXT_PATH = path.join(fileName, rootPath, ENABLEDTXT_FILE);
  try {
    fs.statSync(ENABLEDTXT_PATH);
  } catch (err) {
    try {
      fs.writeFileSync(
        ENABLEDTXT_PATH,
        ``,
        { encoding: "utf8" },
      );
      files.push(path.join(rootPath, ENABLEDTXT_FILE));
      log('info', `Successfully created enabled.txt for UE4SS Script Mod: ${MOD_NAME}`);
    } catch (err) {
      log('error', `Could not create enabled.txt for UE4SS Script Mod: ${MOD_NAME}`);
    }
  }

  //Filter files and set instructions
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for UE4SS DLL files
function testDll(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === DLL_EXT));
  const isFolder = files.some(file => (path.basename(file).toLowerCase() === DLL_FOLDER.toLowerCase()));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && isMod && isFolder;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install UE4SS DLL files
function installDll(files, fileName) {
  const modFile = files.find(file => (path.basename(file).toLowerCase() === DLL_FOLDER.toLowerCase()));
  const idx = modFile.indexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: DLL_ID };
  const MOD_NAME = path.basename(fileName);
  let MOD_FOLDER = path.basename(rootPath);
  if (MOD_FOLDER === '.') {
    MOD_FOLDER = MOD_NAME.replace(/(\.installing)*(\.zip)*(\.rar)*(\.7z)*( )*/gi, '');
  }
  
  const ENABLEDTXT_FILE = 'enabled.txt'
  const ENABLEDTXT_PATH = path.join(fileName, rootPath, ENABLEDTXT_FILE);
  try {
    fs.statSync(ENABLEDTXT_PATH);
  } catch (err) {
    try {
      fs.writeFileSync(
        ENABLEDTXT_PATH,
        ``,
        { encoding: "utf8" },
      );
      files.push(path.join(rootPath, ENABLEDTXT_FILE));
      log('info', `Successfully created enabled.txt for UE4SS DLL Mod: ${MOD_NAME}`);
    } catch (err) {
      log('error', `Could not create enabled.txt for UE4SS DLL Mod: ${MOD_NAME}`);
    }
  }

  //Filter files and set instructions
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(MOD_FOLDER, file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root folder files
function testRoot(files, gameId) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map(str => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map(str => str.toLowerCase());
  const isMod = files.some(file => ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()));
  const isSub = files.some(file => ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && ( isMod || isSub );

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installRoot(files) {
  const ROOT_FOLDERS_LOWER = ROOT_FOLDERS.map(str => str.toLowerCase());
  const ROOTSUB_FOLDERS_LOWER = ROOTSUB_FOLDERS.map(str => str.toLowerCase());
  let modFile = files.find(file => ROOT_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()));
  let setModTypeInstruction = { type: 'setmodtype', value: ROOT_ID };
  if (modFile === undefined) {
    modFile = files.find(file => ROOTSUB_FOLDERS_LOWER.includes(path.basename(file).toLowerCase()));
    setModTypeInstruction = { type: 'setmodtype', value: ROOTSUB_ID };
  }
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`
  const idx = modFile.indexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Test for config files
function testConfig(files, gameId) {
  const isConfig = files.some(file => CONFIG_FILES.includes(path.basename(file).toLowerCase()));
  let supported = (gameId === spec.game.id) && isConfig;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install config files
function installConfig(api, files) {
  const modFile = files.find(file => (path.extname(file).toLowerCase() === CONFIG_EXT));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: CONFIG_ID };

  //Filter files and set instructions
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  GAME_PATH = getDiscoveryPath(api, GAME_ID);
  const IS_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
  if (IS_CONFIG === false) {
    //api.showErrorNotification(`Could not install mod as Config`, `You tried installing a Config mod, but the game, staging folder, and ${CONFIG_LOC} folder are not all on the same drive. Please move the game and/or staging folder to the same drive as the ${CONFIG_LOC} folder (typically C Drive) to install these types of mods with Vortex.`, { allowReport: false });
    configInstallerNotify(api);
  }
  return Promise.resolve({ instructions });
}

//Notification for config installer
function configInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-configinstaller`;
  const MESSAGE = 'Could not install mod as Config';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'error',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `You tried installing a Config file mod, but the game, staging folder, and ${CONFIG_LOC} folder are not all on the same drive.\n`
                + `Please move the game and/or staging folder to the same drive as the ${CONFIG_LOC} folder (typically C Drive) to install these types of mods with Vortex.\n`
                + `\n`
                + `Config Path: ${CONFIG_PATH}\n`
                + `\n`             
                + `If you want to use this mod installer, you must move the game and staging folder to the same partition as the ${CONFIG_LOC} folder (typically C Drive).\n`
                + `\n`
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Open Config Folder', action: () => {
                util.opn(CONFIG_PATH).catch(() => null);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

function saveErrorNotify(api) {
  const NOTIF_ID = `${GAME_ID}-saveinsterrxbox`;
  const MESSAGE = `Save files are not supported by the Xbox version of ${GAME_NAME}`;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'error',
    message: MESSAGE,
    allowSuppress: true,
    actions: [],
  });
}

//Test for save files
function testSave(files, gameId) {
  const isMod = files.some(file => (path.extname(file).toLowerCase() === SAVE_EXT));
  let supported = (gameId === spec.game.id) && isMod;

  // Test for a mod installer
  if (supported && files.find(file =>
      (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
      (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Install save files
function installSave(api, files) {
  const modFile = files.find(file => (path.extname(file).toLowerCase() === SAVE_EXT));
  const idx = modFile.indexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const setModTypeInstruction = { type: 'setmodtype', value: SAVE_ID };

  GAME_PATH = getDiscoveryPath(api, GAME_ID);
  GAME_VERSION = setGameVersionSync(GAME_PATH);
  const TEST = SAVE_COMPAT_VERSIONS.includes(GAME_VERSION);
  if (!TEST) {
    throw new Error(`Save files are not supported by the Xbox version of ${GAME_NAME}`);
    //saveErrorNotify(api);
  }
  
  //Filter files and set instructions
  const filtered = files.filter(file =>
    ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep)))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  GAME_PATH = getDiscoveryPath(api, GAME_ID);
  const IS_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
  if (IS_SAVE === false) {
    //api.showErrorNotification(`Could not install mod as Save`, `You tried installing a Save mod, but the game, staging folder, and ${SAVE_LOC} folder are not all on the same drive. Please move the game and/or staging folder to the same drive as the ${SAVE_LOC} folder (typically C Drive) to install these types of mods with Vortex.`, { allowReport: false });
    saveInstallerNotify(api);
  } 
  return Promise.resolve({ instructions });
}

//Notification for config installer
function saveInstallerNotify(api) {
  const NOTIF_ID = `${GAME_ID}-saveinstaller`;
  const MESSAGE = 'Could not install mod as Save';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'error',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `You tried installing a Save file mod, but the game, staging folder, and ${SAVE_LOC} folder are not all on the same drive.\n`
                + `Please move the game and/or staging folder to the same drive as the ${SAVE_LOC} folder (typically C Drive) to install these types of mods with Vortex.\n`
                + `\n`
                + `Save Path: ${SAVE_PATH}\n`
                + `\n`             
                + `If you want to use this mod installer, you must move the game and staging folder to the same partition as the ${SAVE_LOC} folder (typically C Drive).\n`
                + `\n`
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Open Save Folder', action: () => {
                util.opn(SAVE_PATH).catch(() => null);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

//Test Fallback installer to Binaries folder
function testBinaries(files, gameId) {
  const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  let supported = (gameId === spec.game.id || gameId === specServer.game.id) && !isPak;

  // Test for a mod installer.
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Fallback installer to Binaries folder
function installBinaries(api, files, fileName) {
  fallbackInstallerNotify(api, fileName);
  const setModTypeInstruction = { type: 'setmodtype', value: BINARIES_ID };
  
  const filtered = files.filter(file =>
    (!file.endsWith(path.sep))
  );
  const instructions = filtered.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: file,
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

function fallbackInstallerNotify(api, modName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, spec.game.id);
  modName = path.basename(modName, '.installing');
  const id = modName.replace(/[^a-zA-Z0-9\s]*( )*/gi, '').slice(0, 20);
  const NOTIF_ID = `${GAME_ID}-${id}-fallback`;
  const MESSAGE = 'Fallback installer reached for ' + modName;
  api.sendNotification({
    id: NOTIF_ID,
    type: 'info',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `The mod you just installed reached the fallback installer to the Binaries folder. This means Vortex could not determine where to place these mod files.\n`
                + `Please check the mod page description and review the files in the mod staging folder to determine whether the mod was installed correctly.\n`
                + `It may be necessary to perform manual file manipulation for the mod, or to manually change the Mod Type.\n`
                + `It is also possible that the mod was installed correctly. For example a non-UE4SS dll mod, like Optiscaler, is installed correctly to the Binaries folder.\n`
                + `\n`
                + `If you think that Vortex should be capable to install this mod to a specific folder, please contact the extension developer for support at the link below.\n`
                + `\n`
                + `Mod Name: ${modName}.\n`
                + `\n`
          }, [
            { label: 'Continue', action: () => dismiss() },
            {
              label: 'Contact Ext. Developer', action: () => {
                util.opn(`${EXTENSION_URL}?tab=posts`).catch(() => null);
                dismiss();
              }
            }, //*/
            {
              label: 'Open Staging Folder', action: () => {
                util.opn(path.join(STAGING_FOLDER, modName)).catch(() => null);
                dismiss();
              }
            }, //*/
            //*
            { label: `Open Nexus Mods Page`, action: () => {
              const mods = util.getSafe(api.store.getState(), ['persistent', 'mods', spec.game.id], {});
              const modMatch = Object.values(mods).find(mod => mod.installationPath === modName);
              log('warn', `Found ${modMatch?.id} for ${modName}`);
              let PAGE = ``;
              if (modMatch) {
                const MOD_ID = modMatch.attributes.modId;
                if (MOD_ID !== undefined) {
                  PAGE = `${MOD_ID}?tab=description`; 
                }
              }
              const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
              util.opn(MOD_PAGE_URL).catch(err => undefined);
              //dismiss();
            }}, //*/
          ]);
        },
      },
    ],
  });
}

// AUTOMATIC MOD DOWNLOADERS ///////////////////////////////////////////////////

//Check if UE4SS is installed
function isUe4ssInstalled(api, spec) {
  const state = api.getState();
  const mods = state.persistent.mods[spec.game.id] || {};
  return Object.keys(mods).some(id => mods[id]?.type === UE4SS_ID);
}

//* Download UE4SS from GitHub page (user browse for download)
async function downloadUe4ss(api, gameSpec) {
  let isInstalled = isUe4ssInstalled(api, gameSpec);
  const URL = UE4SS_URL;
  const MOD_NAME = UE4SS_NAME;
  const MOD_TYPE = UE4SS_ID;
  const ARCHIVE_NAME = UE4SS_DLFILE_STRING;
  const instructions = api.translate(`Click on Continue below to open the browser. - `
    + `Navigate to the latest experimental version of ${MOD_NAME} on the GitHub releases page and `
    + `click on the appropriate file to download and install the mod.`
  );

  if (!isInstalled) {
    return new Promise((resolve, reject) => { //Browse and download the mod
      return api.emitAndAwait('browse-for-download', URL, instructions)
      .then((result) => { //result is an array with the URL to the downloaded file as the only element
        if (!result || !result.length) { //user clicks outside the window without downloading
          return reject(new util.UserCanceled());
        }
        if (!result[0].toLowerCase().includes(ARCHIVE_NAME)) { //if user downloads the wrong file
          return reject(new util.UserCanceled('Selected wrong download'));
        } //*/
        return Promise.resolve(result);
      })
      .catch((error) => {
        return reject(error);
      })
      .then((result) => {
        const dlInfo = {game: gameSpec.game.id, name: MOD_NAME};
        api.events.emit('start-download', result, {}, undefined,
          async (error, id) => { //callback function to check for errors and pass id to and call 'start-install-download' event
            if (error !== null && (error.name !== 'AlreadyDownloaded')) {
              return reject(error);
            }
            api.events.emit('start-install-download', id, { allowAutoEnable: true }, async (error) => { //callback function to complete the installation
              if (error !== null) {
                return reject(error);
              }
              const profileId = selectors.lastActiveProfileForGame(api.getState(), GAME_ID);
              const batched = [
                actions.setModsEnabled(api, profileId, result, true, {
                  allowAutoDeploy: true,
                  installed: true,
                }),
                actions.setModType(GAME_ID, result[0], MOD_TYPE), // Set the mod type
              ];
              util.batchDispatch(api.store, batched); // Will dispatch both actions.
              return resolve();
            });
          }, 
          'never',
          { allowInstall: false },
        );
      });
    })
    .catch(err => {
      if (err instanceof util.UserCanceled) {
        api.showErrorNotification(`User cancelled download/install of ${MOD_NAME}. Please try again.`, err, { allowReport: false });
        //util.opn(URL).catch(() => null);
        return Promise.resolve();
      } else if (err instanceof util.ProcessCanceled) {
        api.showErrorNotification(`Failed to download/install ${MOD_NAME}. Please try again or download manually.`, err, { allowReport: false });
        util.opn(URL).catch(() => null);
        return Promise.reject(err);
      } else {
        return Promise.reject(err);
      }
    });
  }
} //*/

//* Function to auto-download UE4SS from Nexus Mods
async function downloadUe4ssNexus(api, gameSpec) {
  let isInstalled = isUe4ssInstalled(api, gameSpec);
  if (!isInstalled) {
    const MOD_NAME = UE4SS_NAME;
    const MOD_TYPE = UE4SS_ID;
    const NOTIF_ID = `${MOD_TYPE}-installing`;
    const PAGE_ID = UE4SS_PAGE_NO;
    const FILE_ID = UE4SS_FILE_NO;  //If using a specific file id because "input" below gives an error
    const GAME_DOMAIN = UE4SS_DOMAIN;
    api.sendNotification({ //notification indicating install process
      id: NOTIF_ID,
      message: `Installing ${MOD_NAME}`,
      type: 'activity',
      noDismiss: true,
      allowSuppress: false,
    });
    if (api.ext?.ensureLoggedIn !== undefined) { //make sure user is logged into Nexus Mods account in Vortex
      await api.ext.ensureLoggedIn();
    }
    try {
      let FILE = null;
      let URL = null;
      try { //get the mod files information from Nexus
        const modFiles = await api.ext.nexusGetModFiles(GAME_DOMAIN, PAGE_ID);
        const fileTime = (input) => Number.parseInt(input.uploaded_time, 10);
        const file = modFiles
          .filter(file => file.category_id === 1 && !file.file_name.includes('ZDEV')) //filter out dev builds
          .sort((lhs, rhs) => fileTime(lhs) - fileTime(rhs))
          .reverse()[0];
        if (file === undefined) {
          throw new util.ProcessCanceled(`No ${MOD_NAME} main file found`);
        }
        FILE = file.file_id;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      } catch (err) { // use defined file ID if input is undefined above
        FILE = FILE_ID;
        URL = `nxm://${GAME_DOMAIN}/mods/${PAGE_ID}/files/${FILE}`;
      }
      const dlInfo = { //Download the mod
        game: GAME_DOMAIN,
        name: MOD_NAME,
      };
      const dlId = await util.toPromise(cb =>
        api.events.emit('start-download', [URL], dlInfo, undefined, cb, undefined, { allowInstall: false }));
      const modId = await util.toPromise(cb =>
        api.events.emit('start-install-download', dlId, { allowAutoEnable: false }, cb));
      const profileId = selectors.lastActiveProfileForGame(api.getState(), gameSpec.game.id);
      const batched = [
        actions.setModsEnabled(api, profileId, [modId], true, {
          allowAutoDeploy: true,
          installed: true,
        }),
        actions.setModType(gameSpec.game.id, modId, MOD_TYPE), // Set the mod type
      ];
      util.batchDispatch(api.store, batched); // Will dispatch both actions
    } catch (err) { //Show the user the download page if the download, install process fails
      const errPage = `https://www.nexusmods.com/${GAME_DOMAIN}/mods/${PAGE_ID}/files/?tab=files`;
      api.showErrorNotification(`Failed to download/install ${MOD_NAME}`, err);
      util.opn(errPage).catch(() => null);
    } finally {
      api.dismissNotification(NOTIF_ID);
    }
  }
} //*/

// UNREAL FUNCTIONS ///////////////////////////////////////////////////////////////

//* FBLO Functions
function generateProps(context, profileId) {
  const api = context.api;
  const state = api.getState();
  const profile = (profileId !== undefined)
    ? selectors.profileById(state, profileId)
    : selectors.activeProfile(state);
  if (profile?.gameId !== GAME_ID) {
      return undefined;
  }

  const discovery = util.getSafe(state, ['settings', 'gameMode', 'discovered', GAME_ID], undefined);
  if (discovery?.path === undefined) {
    return undefined;
  }

  const mods = util.getSafe(state, ['persistent', 'mods', GAME_ID], {});
  return { api, state, profile, mods, discovery };
}

async function ensureLOFile(context, profileId, props) {
  if (props === undefined) {
    props = generateProps(context, profileId);
  }
  if (props === undefined) {
    return Promise.reject(new util.ProcessCanceled('failed to generate game props'));
  }
  const targetPath = path.join(props.discovery.path, props.profile.id + '_' + LO_FILE_NAME);
  try {
    await fs.ensureFileAsync(targetPath);
    return targetPath;
  } catch (err) {
    return Promise.reject(err);
  }
}

async function deserializeLoadOrder(context) {
  const props = generateProps(context, undefined);
  if (props?.profile?.gameId !== GAME_ID) {
    return Promise.reject(new util.ProcessCanceled('invalid props'));
  }

  // The deserialization function should be used to filter and insert wanted data into Vortex's
  //  loadOrder application state, once that's done, Vortex will trigger a serialization event
  //  which will ensure that the data is written to the LO file.
  const currentModsState = util.getSafe(props.profile, ['modState'], {});

  // we only want to insert enabled mods.
  const enabledModIds = Object.keys(currentModsState)
      .filter(modId => util.getSafe(currentModsState, [modId, 'enabled'], false));
  const mods = util.getSafe(props.state,
      ['persistent', 'mods', GAME_ID], {});
  const loFilePath = await ensureLOFile(context, props.profile.gameId, props);
  const fileData = await fs.readFileAsync(loFilePath, { encoding: 'utf8' });
  let data = [];
  if (fileData.length > 0) {
    data = JSON.parse(fileData);
  }
  try {
    /*try {
      data = JSON.parse(fileData);
      //data = fileData.split('\n');
    } catch (err) {
      await new Promise((resolve, reject) => {
        props.api.showDialog('error', 'Corrupt load order file', {
          bbcode: props.api.translate('The load order file is in a corrupt state. You can try to fix it yourself '
              + 'or Vortex can regenerate the file for you, but that may result in loss of data ' +
              '(Will only affect load order items you added manually, if any).')
          },
          [
            { label: 'Cancel', action: () => reject(err) },
            {
              label: 'Regenerate File', action: () => {
                data = [];
                return resolve();
              }
            }
          ]
        )
      })
    } //*/

    // User may have disabled/removed a mod - we need to filter out any existing entries from the data we parsed.
    let filteredData = data.filter(entry => enabledModIds.includes(entry.id));
    //let filteredData = data.filter(entry => enabledModIds.includes(entry));
    // Check if the user added any new mods
    const diff = enabledModIds.filter((id) => 
      (mods[id]?.type === UE5_SORTABLE_ID)
      && !filteredData.some((loEntry) => (loEntry.id === id))
      //&& !filteredData.some((entry) => (entry === id))
    );
    // Add any newly added mods to the bottom of the loadOrder.
    diff.forEach(id => {
      filteredData.push({
        id: id,
        modId: id,
        enabled: true,
        name: mods[id] !== undefined
          ? util.renderModName(mods[id])
          : id,
        //name: id
      });
    });
    return Promise.resolve(filteredData);
  } catch (err) {
    return Promise.reject(err);
  }
}

async function serializeLoadOrder(context, loadOrder) {
  const props = generateProps(context, undefined);
  if (props === undefined) {
    return Promise.reject(new util.ProcessCanceled('invalid props'));
  }
  // Make sure the LO file is created and ready to be written to.
  const loFilePath = await ensureLOFile(context, props.profile.id, props);
  //loadOrder = loadOrder.map(mod => mod.id);
  // Write the prefixed LO to file
  await fs.writeFileAsync(loFilePath, JSON.stringify(loadOrder, null, 4), { encoding: 'utf8' });
  //await fs.writeFileAsync(loFilePath, loadOrder.join('\n'), { encoding: 'utf8' });
  // something has changed so we need to tell vortex that a deployment will be necessary
  requestDeployment(context.api, spec);
  return Promise.resolve();
}
//*/

//UNREAL - Pre-sort function - legacy load order page
async function preSort(api, items, direction) {
  const mods = util.getSafe(api.store.getState(), ['persistent', 'mods', spec.game.id], {});
  const fileExt = UNREALDATA.fileExt;

  const loadOrder = items.map(mod => {
    const modInfo = mods[mod.id];
    let name = modInfo ? modInfo.attributes.customFileName ?? modInfo.attributes.logicalFileName ?? modInfo.attributes.name : mod.name;
    const paks = util.getSafe(modInfo.attributes, ['unrealModFiles'], []);
    if (paks.length > 1) name = name + ` (${paks.length} ${fileExt} files)`;

    return {
      id: mod.id,
      name,
      imgUrl: util.getSafe(modInfo, ['attributes', 'pictureUrl'], path.join(__dirname, spec.game.logo))
    }
  });

  return (direction === 'descending') ? Promise.resolve(loadOrder.reverse()) : Promise.resolve(loadOrder);
}

//Make prefix based on loadOrder index
function makePrefix(input) {
  let res = '';
  let rest = input;
  while (rest > 0) {
    res = String.fromCharCode(65 + (rest % 25)) + res;
    rest = Math.floor(rest / 25);
  }
  return util.pad(res, 'A', 3);
}

//Find the loadOrder index and convert to prefix
function loadOrderPrefix(api, mod) {
  const state = api.getState();
  const profile = selectors.lastActiveProfileForGame(state, GAME_ID);
  const loadOrder = util.getSafe(state, ['persistent', 'loadOrder', profile], {});
  let pos;
  if (FBLO) {
    pos = loadOrder.findIndex((entry) => entry.id === mod.id); //for FBLO
  } else {
    const loKeys = Object.keys(loadOrder);
    pos = loKeys.indexOf(mod.id); //for legacy load order page
  }
  //
  if (pos === -1) {
    return 'ZZZZ-';
  }
  return makePrefix(pos) + '-';
}

//Test for pak mods
function testPak(files, gameId) {
  const supportedGame = gameId === spec.game.id;
  const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  let supported = supportedGame && isPak;
  
  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }
  
  return Promise.resolve({
    supported,
    requiredFiles: []
  });
};

//install pak mods
async function installPak(api, files) {
  const fileExt = UNREALDATA.fileExt;
  const modFiles = files.filter(file => fileExt.includes(path.extname(file).toLowerCase()));
  let modType = UE5_SORTABLE_ID;
  const selection = await chooseInstallDestination(api, modFiles);
  if (selection === UE5_SORTABLE_ID || selection === SERVERPAKS_ID) {
    modType = selection;
  }
  if (selection === 'both') {
    modType = ROOT_ID;
  }
  const installFiles = (modFiles.length > PAK_FILE_MIN)
    ? await chooseFilesToInstall(api, modFiles, fileExt)
    : modFiles;
  const unrealModFiles = {
    type: 'attribute',
    key: 'unrealModFiles',
    value: installFiles.map(f => path.basename(f))
  };
  const modTypeInstruction = {
    type: 'setmodtype',
    value: modType,
  };
  let instructions = installFiles.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.basename(file)
    };
  });
  let serverInstructions = [];
  if (selection === 'both') {
    instructions = installFiles.map(file => {
      return {
        type: 'copy',
        source: file,
        destination: path.join(PAK_PATH, path.basename(file))
      };
    });
    serverInstructions = installFiles.map(file => {
      return {
        type: 'copy',
        source: file,
        destination: path.join(SERVERPAKS_PATH, path.basename(file))
      };
    });
  }
  instructions.push(serverInstructions);
  instructions.push(modTypeInstruction);
  instructions.push(unrealModFiles);
  return Promise.resolve({ instructions });
}

const CLIENT_LABEL = 'Client (SP)';
const SERVER_LABEL = 'Server (MP)';

//file selection dialog for pak mods
async function chooseInstallDestination(api, files) {
  const t = api.translate;
  return api.showDialog('question', t('Choose Destination for Pak Mod Files'), {
    text: t('Choose the destination for the pak files.\n' 
          +`\n`
          +`${CLIENT_LABEL}: Single-Player (Client) Pak Mods\n`
          +`    Destination: ${PAK_PATH}\n`
          +`\n`
          +`${SERVER_LABEL}: Multiplayer (Server) Pak Mods\n`
          +`    Destination: ${SERVERPAKS_PATH}\n`
          +`\n`
          ),
    }, [
      { label: 'Cancel' }, //don't use this since we feed directly to modType
      { label: CLIENT_LABEL },
      { label: SERVER_LABEL },
      //{ label: 'BOTH SP & MP' },
  ]).then((result) => {
    if (result.action === 'Cancel') {
      return Promise.reject(new util.UserCanceled());
    }
    if (result.action === CLIENT_LABEL) {
      return UE5_SORTABLE_ID;
    } else if (result.action === SERVER_LABEL) {
      return SERVERPAKS_ID;
    } else {
      return 'both';
    }
  });
}

//file selection dialog for pak mods
async function chooseFilesToInstall(api, files, fileExt) {
  const t = api.translate;
  return api.showDialog('question', t('Multiple {{PAK}} files', { replace: { PAK: fileExt } }), {
    text: t('The mod you are installing contains {{x}} {{ext}} files.', { replace: { x: files.length, ext: fileExt } }) +
        `This can be because the author intended for you to chose one of several options. Please select which files to install below:`,
    checkboxes: files.map((pak) => {
      return {
          id: pak,
          text: pak,
          value: false
      };
    })
    }, [
      { label: 'Cancel' },
      { label: 'Install Selected' },
      { label: 'Install All_plural' }
  ]).then((result) => {
      if (result.action === 'Cancel')
          return Promise.reject(new util.UserCanceled('User cancelled.'));
      else {
          const installAll = (result.action === 'Install All' || result.action === 'Install All_plural');
          const installPAKS = installAll ? files : Object.keys(result.input).filter(s => result.input[s])
            .map(file => files.find(f => f === file));
          return installPAKS;
      }
  });
}

//Test for pak mods - DEDICATED SERVER
function testPakServer(files, gameId) {
  const supportedGame = gameId === specServer.game.id;
  const isPak = files.some(file => (path.extname(file).toLowerCase() === PAK_EXT));
  let supported = supportedGame && isPak;
  
  // Test for a mod installer
  if (supported && files.find(file =>
    (path.basename(file).toLowerCase() === 'moduleconfig.xml') &&
    (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
    supported = false;
  }
  
  return Promise.resolve({
    supported,
    requiredFiles: []
  });
};

//install pak mods - DEDICATED SERVER
async function installPakServer(api, files) {
  const fileExt = UNREALDATA.fileExt;
  const modFiles = files.filter(file => fileExt.includes(path.extname(file).toLowerCase()));
  const installFiles = (modFiles.length > PAK_FILE_MIN)
    ? await chooseFilesToInstall(api, modFiles, fileExt)
    : modFiles;
  const unrealModFiles = {
    type: 'attribute',
    key: 'unrealModFiles',
    value: installFiles.map(f => path.basename(f))
  };
  const modTypeInstruction = {
    type: 'setmodtype',
    value: UE5_SORTABLE_ID_SERVER,
  };
  let instructions = installFiles.map(file => {
    return {
      type: 'copy',
      source: file,
      destination: path.basename(file)
    };
  });
  instructions.push(modTypeInstruction);
  instructions.push(unrealModFiles);
  return Promise.resolve({ instructions });
}

//* FBLO Functions - DEDICATED SERVER
function generatePropsServer(context, profileId) {
  const api = context.api;
  const state = api.getState();
  const profile = (profileId !== undefined)
    ? selectors.profileById(state, profileId)
    : selectors.activeProfile(state);
  if (profile?.gameId !== GAME_ID_SERVER) {
      return undefined;
  }

  const discovery = util.getSafe(state, ['settings', 'gameMode', 'discovered', GAME_ID_SERVER], undefined);
  if (discovery?.path === undefined) {
    return undefined;
  }

  const mods = util.getSafe(state, ['persistent', 'mods', GAME_ID_SERVER], {});
  return { api, state, profile, mods, discovery };
}

async function ensureLOFileServer(context, profileId, props) {
  if (props === undefined) {
    props = generatePropsServer(context, profileId);
  }
  if (props === undefined) {
    return Promise.reject(new util.ProcessCanceled('failed to generate game props'));
  }
  const targetPath = path.join(props.discovery.path, props.profile.id + '_' + LO_FILE_NAME);
  try {
    await fs.ensureFileAsync(targetPath);
    return targetPath;
  } catch (err) {
    return Promise.reject(err);
  }
}

async function deserializeLoadOrderServer(context) {
  const props = generatePropsServer(context, undefined);
  if (props?.profile?.gameId !== GAME_ID_SERVER) {
    return Promise.reject(new util.ProcessCanceled('invalid props'));
  }
  const currentModsState = util.getSafe(props.profile, ['modState'], {});
  const enabledModIds = Object.keys(currentModsState)
      .filter(modId => util.getSafe(currentModsState, [modId, 'enabled'], false));
  const mods = util.getSafe(props.state,
      ['persistent', 'mods', GAME_ID_SERVER], {});
  const loFilePath = await ensureLOFileServer(context, props.profile.gameId, props);
  const fileData = await fs.readFileAsync(loFilePath, { encoding: 'utf8' });
  let data = [];
  if (fileData.length > 0) {
    data = JSON.parse(fileData);
  }
  try {
    let filteredData = data.filter(entry => enabledModIds.includes(entry.id));
    const diff = enabledModIds.filter((id) => 
      (mods[id]?.type === UE5_SORTABLE_ID_SERVER)
      && !filteredData.some((loEntry) => (loEntry.id === id))
    );
    // Add any newly added mods to the bottom of the loadOrder.
    diff.forEach(id => {
      filteredData.push({
        id: id,
        modId: id,
        enabled: true,
        name: mods[id] !== undefined
          ? util.renderModName(mods[id])
          : id,
        //name: id
      });
    });
    return Promise.resolve(filteredData);
  } catch (err) {
    return Promise.reject(err);
  }
}

async function serializeLoadOrderServer(context, loadOrder) {
  const props = generatePropsServer(context, undefined);
  if (props === undefined) {
    return Promise.reject(new util.ProcessCanceled('invalid props'));
  }
  const loFilePath = await ensureLOFileServer(context, props.profile.id, props);
  await fs.writeFileAsync(loFilePath, JSON.stringify(loadOrder, null, 4), { encoding: 'utf8' });
  requestDeployment(context.api, specServer);
  return Promise.resolve();
}
//*/

//Find the loadOrder index and convert to prefix - DEDICATED SERVER
function loadOrderPrefixServer(api, mod) {
  const state = api.getState();
  const profile = selectors.lastActiveProfileForGame(state, GAME_ID_SERVER);
  const loadOrder = util.getSafe(state, ['persistent', 'loadOrder', profile], {});
  let pos;
  if (FBLO) {
    pos = loadOrder.findIndex((entry) => entry.id === mod.id); //for FBLO
  } else {
    const loKeys = Object.keys(loadOrder);
    pos = loKeys.indexOf(mod.id); //for legacy load order page
  }
  //
  if (pos === -1) {
    return 'ZZZZ-';
  }
  return makePrefix(pos) + '-';
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

// Function to check if staging folder and game path are on same drive partition to enable modtypes + installers
function checkPartitions(folder, discoveryPath) {
  if (!preferHardlinks && !IO_STORE) { //only do early return if hardlinks have no benefits and aren't required
    return true;
  }
  try {
    // Define paths
    const path1 = discoveryPath;
    const path2 = STAGING_FOLDER;
    const path3 = folder;
    // Ensure all folders exist
    fs.ensureDirSync(path1);
    fs.ensureDirSync(path2);
    fs.ensureDirSync(path3); 
    // Get the stats for all folders
    const stats1 = fs.statSync(path1);
    const stats2 = fs.statSync(path2);
    const stats3 = fs.statSync(path3);
    // Read device IDs and check if they are all the same
    const a = stats1.dev;
    const b = stats2.dev;
    const c = stats3.dev;
    const TEST = ((a === b) && (b === c));
    return TEST;
  } catch (err) {
    //log('error', `Error checking folder partitions: ${err}`);
    return false;
  }
}

//Notification if Config/Save folders are not on the same partition as the game and staging folder
function partitionCheckNotify(api, CHECK_CONFIG, CHECK_SAVE) {
  const NOTIF_ID = `${GAME_ID}-partioncheck`;
  const MESSAGE = 'Some Mods Installers are Not Available';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `Because ${GAME_NAME} includes the IO-Store Unreal Engine feature (or because hardlinks are preferred), Vortex must use hardlinks to install mods for the game.\n`
                + `As such, the game, staging folder, and user folder (typically on C Drive) must all be on the same drive partition to install certain mods with Vortex.\n`
                + `Vortex detected that one or more of the mod types listed below are not available because the game, staging folder, and mod type folder(s) are not all on the same drive partition.\n`
                + `\n`
                + `Here are your results for the partition checks to enable these mod types:\n`
                + `  - Config: ${CHECK_CONFIG ? `ENABLED: ${CONFIG_LOC} folder is on the same partition as the game and the Vortex staging folder, so the Config modtype is available` : `DISABLED: ${CONFIG_LOC} folder is NOT on the same partition as the game and the Vortex staging folder, so the Config modtype is NOT available`}\n`
                + `  - Save: ${CHECK_SAVE ? `ENABLED: ${SAVE_LOC} folder is on the same partition as the game and the Vortex staging folder, so the Save modtype is available` : `DISABLED: ${SAVE_LOC} folder is NOT on the same partition as the game and the Vortex staging folder, so the Save modtype is NOT available`}\n`
                + `\n`
                + `Game Path: ${GAME_PATH}\n`
                + `Staging Path: ${STAGING_FOLDER}\n`
                + `Config Path: ${CONFIG_PATH}\n`
                + `Save Path (installer for Steam/Epic/GOG versions only): ${SAVE_PATH}\n`
                + `\n`
                + `If you want to use the disabled mod types, you must move the game and staging folder to the same partition as the folders shown above.\n`
                + `\n`
          }, [
            { label: 'Acknowledge', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

function setupNotify(api) {
  const NOTIF_ID = `${GAME_ID}-setup-notify`;
  const MESSAGE = 'Special Setup Instructions';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `TEXT HERE.\n`
                + `\n`
                + `TEXT HERE.\n`
                + `\n`
          }, [
            { label: 'Acknowledge', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

//Setup function - DEDICATED SERVER
function setupNotifyServer(api) {
  const NOTIF_ID = `${GAME_ID_SERVER}-setup-notify`;
  const MESSAGE = 'Notes for Dedicated Server';
  api.sendNotification({
    id: NOTIF_ID,
    type: 'warning',
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: 'More',
        action: (dismiss) => {
          api.showDialog('question', MESSAGE, {
            text: `\n`
                + `Please note that if you are managing the Windrose game on the same Vortex install as the Dedicated Server, you need to use Manual Download and drag-and-drop mod zips into Vortex to install them here.\n`
                + `\n`
                + `If you use the Mod Manager Download button, Vortex will "hijack" the install and send it to the Windrose game instead of the Dedicated Server.\n`
                + `\n`
          }, [
            { label: 'Acknowledge', action: () => dismiss() },
            {
              label: 'Never Show Again', action: () => {
                api.suppressNotification(NOTIF_ID);
                dismiss();
              }
            },
          ]);
        },
      },
    ],
  });
}

async function resolveGameVersion(gamePath, exePath) {
  GAME_VERSION = await setGameVersionAsync(gamePath);
  //SHIPPING_EXE = getShippingExe(gamePath);
  const READ_FILE = path.join(gamePath, SHIPPING_EXE);
  let version = '0.0.0';
  if (GAME_VERSION === 'xbox') { // use appxmanifest.xml for Xbox version
    try { //try to parse appxmanifest.xml
      const appManifest = await fs.readFileAsync(path.join(gamePath, APPMANIFEST_FILE), 'utf8');
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log('error', `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  else { //use shipping exe (note that this only returns the UE engine version right now)
    try {
      const exeVersion = require('exe-version');
      version = await exeVersion.getProductVersion(READ_FILE);
      //log('warn', `Resolved game version for ${GAME_ID} to: ${version}`);
      return Promise.resolve(version); 
    } catch (err) {
      log('error', `Could not read ${READ_FILE} file to get game version: ${err}`);
      return Promise.resolve(version);
    }
  }
}

async function modFoldersEnsureWritable(gamePath, relPaths) {
  for (let index = 0; index < relPaths.length; index++) {
    await fs.ensureDirWritableAsync(path.join(gamePath, relPaths[index]));
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, gameSpec.game.id);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, gameSpec.game.id);
  CHECK_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
  if (configSaveMatch) {
    CHECK_SAVE = CHECK_CONFIG;
  } else {
    CHECK_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
  }
  if (!CHECK_CONFIG || !CHECK_SAVE) {
    partitionCheckNotify(api, CHECK_CONFIG, CHECK_SAVE);
  }
  if (setupNotification) {
    setupNotify(api);
  }
  // ASYNC CODE ///////////////////////////////////
  GAME_VERSION = await setGameVersionAsync(GAME_PATH);
  if (CHECK_CONFIG) { //if game, staging folder, and config and save folders are on the same drive
    await fs.ensureDirWritableAsync(CONFIG_PATH);
    if (SAVE_COMPAT_VERSIONS.includes(GAME_VERSION)) {
      if (configSaveMatch) {
        await fs.ensureDirWritableAsync(SAVE_PATH);
      }
    }
  } //*/
  if (!configSaveMatch) {
    if (CHECK_SAVE) { //if game, staging folder, and config and save folders are on the same drive
      await fs.ensureDirWritableAsync(SAVE_PATH);
    }
  }
  if (autoDownloadUe4ss) {
    if (UE4SS_PAGE_NO !== 0) {
      await downloadUe4ssNexus(api, gameSpec);
    } else {
      await downloadUe4ss(api, gameSpec);
    }
  } //*/
  MODTYPE_FOLDERS.push(SCRIPTS_PATH);
  return modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
}

//Setup function
async function setupServer(discovery, api, gameSpec) {
  // SYNCHRONOUS CODE ////////////////////////////////////
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, gameSpec.game.id);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, gameSpec.game.id);
  setupNotifyServer(api);
  // ASYNC CODE ///////////////////////////////////
  if (autoDownloadUe4ss) {
    if (UE4SS_PAGE_NO !== 0) {
      await downloadUe4ssNexus(api, gameSpec);
    } else {
      await downloadUe4ss(api, gameSpec);
    }
  } //*/
  MODTYPE_FOLDERS.push(SCRIPTS_PATH);
  return modFoldersEnsureWritable(GAME_PATH, MODTYPE_FOLDERS);
}

//* Get ModKit install path with GameStoreHelper
async function getModKitPath() {
  let game = undefined;
  try {
    game = await util.GameStoreHelper.findByAppId(MODKITAPP_ID, 'epic');
  } catch (err) {
    log('warn', `ModKit path not found`);
    return undefined;
  }
  if (game === undefined) {
    log('warn', `ModKit path not found`);
    return undefined;
  }
  let instPath = game.gamePath;
  log('warn', `ModKit path found at ${instPath}`);
  instPath = path.join(instPath, MODKIT_FOLDER);
  return instPath;
} //*/

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register the game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    getGameVersion: resolveGameVersion,
    supportedTools: [
      {
        id: `${GAME_ID}-customlaunch`,
        name: `Custom Launch`,
        logo: `exec.png`,
        executable: () => EXEC,
        requiredFiles: [EXEC],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        //parameters: [],
      }, //*/
      /*{
        id: `${GAME_ID}-customlaunchxbox`,
        name: `Custom Launch`,
        logo: `exec.png`,
        executable: () => EXEC_XBOX,
        requiredFiles: [EXEC_XBOX],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        //parameters: [],
      }, //*/
      /*{
        id: SAVE_EDITOR_ID,
        name: SAVE_EDITOR_NAME,
        logo: `saveeditor.png`,
        queryPath: getBinariesFolder,
        executable: () => SAVE_EDITOR_EXEC,
        requiredFiles: [SAVE_EDITOR_EXEC],
        detach: true,
        relative: true,
        exclusive: true,
        //shell: true,
        //parameters: [],
      }, //*/
      /*
      {
        id: MODKIT_ID,
        name: MODKIT_NAME,
        logo: `modkit.png`,
        queryPath: async () => await getModKitPath(),
        //queryPath: () => getModKitPathReg(),
        executable: () => MODKIT_EXEC_NAME,
        requiredFiles: [MODKIT_EXEC_NAME],
        detach: true,
        relative: false,
        exclusive: false,
        //parameters: [],
      }, //*/
    ],
  };
  context.registerGame(game);

  //register mod types recursively (types that are always the same)
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //Pak modType
  context.registerModType(UE5_SORTABLE_ID, 25, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    },
    (game) => pathPattern(context.api, game, path.join('{gamePath}', UNREALDATA.modsPath)), 
    () => Promise.resolve(false), 
    { name: UE5_SORTABLE_NAME,
      mergeMods: (mod) => {
        if (UNREALDATA.loadOrder === true) {
          return loadOrderPrefix(context.api, mod) + mod.id
        } else { //If load order is disabled, don't use sorting folders
          return '';
        }
      } //*/
    }
  );

  //* register modtypes with partition checks
  context.registerModType(CONFIG_ID, 62, 
    (gameId) => {
      GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
      if (GAME_PATH !== undefined) {
        CHECK_CONFIG = checkPartitions(CONFIGMOD_LOCATION, GAME_PATH);
      }
      return ((gameId === GAME_ID) && (CHECK_CONFIG === true));
    },
    (game) => pathPattern(context.api, game, CONFIG_PATH), 
    () => Promise.resolve(false), 
    { name: CONFIG_NAME }
  ); //*/
  context.registerModType(SAVE_ID, 64, 
    (gameId) => {
      GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
      GAME_VERSION = setGameVersionSync(GAME_PATH);
      if (GAME_PATH !== undefined) {
        if (configSaveMatch) {
          CHECK_CONFIG = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
        }
        if (!configSaveMatch) {
          CHECK_SAVE = checkPartitions(SAVEMOD_LOCATION, GAME_PATH);
        }
      }
      if (configSaveMatch) {
        return ((gameId === GAME_ID) && (CHECK_CONFIG === true) && SAVE_COMPAT_VERSIONS.includes(GAME_VERSION));
      }
      if (!configSaveMatch) {
        return ((gameId === GAME_ID) && (CHECK_SAVE === true) && SAVE_COMPAT_VERSIONS.includes(GAME_VERSION));
      }
    },
    (game) => pathPattern(context.api, game, SAVE_PATH), 
    () => Promise.resolve(false), 
    { name: SAVE_NAME }
  ); //*/
  
  //register mod installers
  if (hasModKit === true) {
    context.registerInstaller(MODKITMOD_ID, 25, testModKitMod, installModKitMod);
  }
  context.registerInstaller(UE4SSCOMBO_ID, 26, testUe4ssCombo, installUe4ssCombo);
  context.registerInstaller(LOGICMODS_ID, 27, testLogic, installLogic);
  context.registerInstaller(UE5_SORTABLE_ID, 30, testPak, (files) => installPak(context.api, files)); //Pak installer
  context.registerInstaller(UE4SS_ID, 31, testUe4ss, installUe4ss);
  context.registerInstaller(SCRIPTS_ID, 35, testScripts, installScripts);
  context.registerInstaller(DLL_ID, 37, testDll, installDll);
  context.registerInstaller(ROOT_ID, 39, testRoot, installRoot);
  context.registerInstaller(CONFIG_ID, 41, testConfig, (files) => installConfig(context.api, files));
  context.registerInstaller(SAVE_ID, 43, testSave, (files) => installSave(context.api, files));
  context.registerInstaller(BINARIES_ID, 49, testBinaries, (files, fileName) => installBinaries(context.api, files, fileName));

  //register actions
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Client Paks Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, PAK_ALT_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Server Paks Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, SERVERPAKS_PATH_BASE)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Binaries Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, BINARIES_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS Mods Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn( path.join(GAME_PATH, SCRIPTS_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open LogicMods Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, LOGICMODS_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', async () => {
    //CONFIG_PATH = await setConfigPath(GAME_VERSION);
    util.opn(CONFIG_PATH).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Saves Folder', async () => {
    //SAVE_PATH = await setSavePath();
    util.opn(SAVE_PATH).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download UE4SS', () => {
    if (UE4SS_PAGE_NO !== 0) { //download from Nexus if the page exists
      downloadUe4ssNexus(context.api, gameSpec);
    } else {
      downloadUe4ss(context.api, gameSpec, false);
    }
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS Settings INI', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, BINARIES_PATH, UE4SS_SETTINGS_FILEPATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS mods.json', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID);
    util.opn(path.join(GAME_PATH, BINARIES_PATH, UE4SS_MODSJSON_FILEPATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    util.opn(path.join(__dirname, 'CHANGELOG.md')).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
}

//Let Vortex know about the game - SERVER
function applyGameServer(context, gameSpec) {
  //register the game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: () => EXEC_SERVER,
    queryModPath: () => MOD_PATH_DEFAULT,
    setup: async (discovery) => await setupServer(discovery, context.api, gameSpec),
    requiresLauncher: requiresLauncherServer,
    supportedTools: [
      {
        id: `${GAME_ID_SERVER}-customlaunch`,
        name: `Custom Launch`,
        logo: `exec.png`,
        executable: () => EXEC_SERVER,
        requiredFiles: [EXEC_SERVER],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        //parameters: [],
      }, //*/
    ],
  };
  context.registerGame(game);

  //register mod types recursively (types that are always the same)
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(type.id, modTypePriority(type.priority) + idx, (gameId) => {
      var _a;
      return (gameId === gameSpec.game.id)
        && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    }, (game) => pathPattern(context.api, game, type.targetPath), () => Promise.resolve(false), { name: type.name });
  });

  //Pak modType
  context.registerModType(UE5_SORTABLE_ID_SERVER, 25, 
    (gameId) => {
      var _a;
      return (gameId === GAME_ID_SERVER) && !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null || _a === void 0 ? void 0 : _a.path);
    },
    (game) => pathPattern(context.api, game, path.join('{gamePath}', UNREALDATA.modsPath)), 
    () => Promise.resolve(false), 
    { name: UE5_SORTABLE_NAME,
      mergeMods: (mod) => {
        if (UNREALDATA.loadOrder === true) {
          return loadOrderPrefixServer(context.api, mod) + mod.id
        } else { //If load order is disabled, don't use sorting folders
          return '';
        }
      } //*/
    }
  );

  //register mod installers
  context.registerInstaller(UE5_SORTABLE_ID_SERVER, 29, testPakServer, (files) => installPakServer(context.api, files)); //Pak installer - DEDICATED SERVER
  //all other installers are identical to client

  //register actions
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Paks Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, PAKMOD_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Binaries Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, BINARIES_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS Mods Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, SCRIPTS_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open LogicMods Folder', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, LOGICMODS_PATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Download UE4SS', () => {
    if (UE4SS_PAGE_NO !== 0) { //download from Nexus if the page exists
      downloadUe4ssNexus(context.api, gameSpec);
    } else {
      downloadUe4ss(context.api, gameSpec, false);
    }
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS Settings INI', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, BINARIES_PATH, UE4SS_SETTINGS_FILEPATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open UE4SS mods.json', () => {
    GAME_PATH = getDiscoveryPath(context.api, GAME_ID_SERVER);
    util.opn(path.join(GAME_PATH, BINARIES_PATH, UE4SS_MODSJSON_FILEPATH)).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open PCGamingWiki Page', () => {
    util.opn(PCGAMINGWIKI_URL).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'View Changelog', () => {
    util.opn(path.join(__dirname, 'CHANGELOG.md')).catch(() => null);
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Submit Bug Report', () => {
    util.opn(`${EXTENSION_URL}?tab=bugs`).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Downloads Folder', () => {
    util.opn(DOWNLOAD_FOLDER).catch(() => null);
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID_SERVER;
  });
}

//Main function
function main(context) {
  applyGame(context, spec);
  applyGameServer(context, specServer);
  if (UNREALDATA.loadOrder === true) { //UNREAL - mod load order
    if (FBLO) {
      context.registerLoadOrder({
        gameId: spec.game.id,
        validate: async () => Promise.resolve(undefined), // no validation implemented yet
        deserializeLoadOrder: async () => await deserializeLoadOrder(context),
        serializeLoadOrder: async (loadOrder) => await serializeLoadOrder(context, loadOrder),
        toggleableEntries: false,
        usageInstructions: LoadOrderInstructions,
        customItemRenderer: LoadOrderItemRenderer,
      }); //*/
      //for Dedicated Server
      context.registerLoadOrder({
        gameId: specServer.game.id,
        validate: async () => Promise.resolve(undefined), // no validation implemented yet
        deserializeLoadOrder: async () => await deserializeLoadOrderServer(context),
        serializeLoadOrder: async (loadOrder) => await serializeLoadOrderServer(context, loadOrder),
        toggleableEntries: false,
        usageInstructions: LoadOrderInstructions,
        customItemRenderer: LoadOrderItemRenderer,
      }); //*/
    } else { //legacy Load Order
      let previousLO;
      context.registerLoadOrderPage({
        gameId: spec.game.id,
        gameArtURL: path.join(__dirname, spec.game.logo),
        preSort: (items, direction) => preSort(context.api, items, direction),
        filter: mods => mods.filter(mod => mod.type === UE5_SORTABLE_ID),
        displayCheckboxes: false,
        callback: (loadOrder) => {
          if (previousLO === undefined) previousLO = loadOrder;
          if (loadOrder === previousLO) return;
          requestDeployment(context.api, spec);
          previousLO = loadOrder;
        },
        createInfoPanel: () =>
          context.api.translate(`Drag and drop the mods on the left to change the order in which they load.\n` 
            + `${spec.game.name} loads mods in alphanumerical order, so Vortex prefixes the folder names with "AAA, AAB, AAC, ..." to ensure they load in the order you set here.\n`
            + 'The number in the left column represents the overwrite order. The changes from mods with higher numbers will take priority over other mods which make similar edits.\n'
            + '\n'
            + 'YOU MUST DEPLOY MODS AFTER CHANGING THE ORDER TO APPLY CHANGES.'
          ),
      }); //*/
    }
  }
  context.once(() => { // put code here that should be run (once) when Vortex starts up
    const api = context.api;
    api.onAsync('did-deploy', (profileId) => didDeploy(api, profileId)); //*/
    //api.onAsync('did-purge', (profileId) => didPurge(api, profileId)); //*/
  });
  return true;
}

const requestDeployment = (api, spec) => {
  api.store.dispatch(actions.setDeploymentNecessary(spec.game.id, true));
  api.sendNotification({
    id: `${spec.game.id}-loadorderdeploy-notif`,
    type: 'warning',
    message: 'Deployment Required to Apply Load Order Changes',
    allowSuppress: true,
    actions: [
      {
        title: 'Deploy',
        action: (dismiss) => {
          deploy(api);
          dismiss();
        }
      }
    ],
  });
};

async function didDeploy(api, profileId) { //run on mod deploy
  const state = api.getState();
  const profile = selectors.profileById(state, profileId);
  const gameId = profile === null || profile === void 0 ? void 0 : profile.gameId;
  if (gameId !== GAME_ID) {
    return Promise.resolve();
  }
  api.dismissNotification(`${GAME_ID}-loadorderdeploy-notif`);
  return Promise.resolve();
}

async function didPurge(api, profileId) { //run on mod purge
  const state = api.getState();
  const profile = selectors.profileById(state, profileId);
  const gameId = profile === null || profile === void 0 ? void 0 : profile.gameId;
  if (gameId !== GAME_ID) {
    return Promise.resolve();
  }
  
  return Promise.resolve();
}

//React load order instructions renderer
function LoadOrderInstructions() {
  return React.createElement('div', null,
    React.createElement('p', null,
      'Drag and drop the mods on the left to change the order in which they load. ',
    ),
    React.createElement('br', null),
    React.createElement('p', null,
      `${GAME_NAME_SHORT} loads mods in alphanumerical order, so Vortex prefixes the folder `,
      'names with "AAA, AAB, AAC, ..." to ensure they load in the order you set here. ',
      'The number in the left column represents the overwrite order. Changes from ',
      'mods with higher numbers take priority over mods that make similar edits.'
    ),
    React.createElement('br', null),
    React.createElement('p', { style: { fontWeight: 'bold' } },
      'YOU MUST DEPLOY MODS AFTER CHANGING THE ORDER TO APPLY CHANGES! ',
      '- This is required to rename the folders for the correct order.'
    ),
    React.createElement('br', null),
    React.createElement('p', { style: { color: 'yellow', fontWeight: 'bold' } },
      SPECIAL_LO_INSTRUCTIONS
    )
  );
}

//* React line item renderer for load order
function LoadOrderItemRenderer(props) {
  const { className, item } = props;
  if (item?.loEntry === undefined) return null;

  const { ListGroupItem, Checkbox } = require('react-bootstrap');
  const { Icon, LoadOrderIndexInput, MainContext } = require('vortex-api');
  const { useSelector, useDispatch } = require('react-redux');

  const context = React.useContext(MainContext);
  const dispatch = useDispatch();

  const profile = useSelector((state) => selectors.activeProfile(state));
  const loadOrder = useSelector((state) =>
    util.getSafe(state, ['persistent', 'loadOrder', profile?.id], []),
  );

  const { loEntry, displayCheckboxes } = item;
  const mods = useSelector((state) => util.getSafe(state, ['persistent', 'mods', GAME_ID], {}));
  const pictureUrl = mods[loEntry.modId]?.attributes?.pictureUrl;
  const currentIdx = loadOrder.findIndex((e) => e.id === loEntry.id) + 1;

  const isLocked = (entry) => [true, 'true', 'always'].includes(entry?.locked);
  const lockedCount = loadOrder.filter(isLocked).length;

  const onApplyIndex = React.useCallback((idx) => {
    if (currentIdx === idx) return;
    const newLO = loadOrder.filter((e) => e.id !== loEntry.id);
    newLO.splice(idx - 1, 0, loEntry);
    dispatch(actions.setFBLoadOrder(profile.id, newLO));
  }, [dispatch, profile, loadOrder, loEntry, currentIdx]);

  const onToggle = React.useCallback((evt) => {
    dispatch(actions.setFBLoadOrderEntry(profile.id, { ...loEntry, enabled: evt.target.checked }));
  }, [dispatch, profile, loEntry]);

  const classes = ['load-order-entry'];
  if (className) classes.push(...className.split(' '));

  return React.createElement(
    ListGroupItem,
    { key: loEntry.id, className: classes.join(' ') },
    React.createElement(Icon, { className: 'drag-handle-icon', name: 'drag-handle' }),
    React.createElement(LoadOrderIndexInput, {
      className: 'load-order-index',
      api: context.api,
      item: loEntry,
      currentPosition: currentIdx,
      lockedEntriesCount: lockedCount,
      loadOrder: loadOrder,
      isLocked: isLocked,
      onApplyIndex: onApplyIndex,
    }),
    React.createElement('div', { className: 'load-order-thumb-slot', style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, marginRight: 4, flexShrink: 0 } },
      pictureUrl ? React.createElement('img', {
        className: 'load-order-thumb',
        src: pictureUrl,
        draggable: false,
        style: { width: LO_IMAGE_WIDTH, height: LO_IMAGE_HEIGHT, objectFit: 'cover', borderRadius: 2, pointerEvents: 'none' },
      }) : null,
    ),
    React.createElement('p', { className: 'load-order-name' }, loEntry.name),
    displayCheckboxes ? React.createElement(Checkbox, {
      className: 'entry-checkbox',
      checked: loEntry.enabled,
      disabled: isLocked(loEntry),
      onChange: onToggle,
    }) : null,
  );
} //*/

//export to Vortex
module.exports = {
  default: main,
};
