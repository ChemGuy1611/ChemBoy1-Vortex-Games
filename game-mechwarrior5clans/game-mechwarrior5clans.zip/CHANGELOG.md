# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.2.0] - 2025-07-14

- Added installer for new Modding Editor mods in the "Mods" folder. All legacy installers are still available.