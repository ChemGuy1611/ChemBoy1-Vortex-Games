# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.3.1] - 2026-08-12

- Fixed: The Epic Games Store version is now found automatically during game discovery

## [0.3.0] - 2026-05-07

- Fixed: Issue with Load Order sorting not working if certain other UE game extensions were installed. You will need to reinstall all pak mods to be able to sort them properly. A notification will be sent reminding you to do this.
- Added: Notification indicating deployment is required after changing the load order.
- Fixed: Missing FOMOD installer check for pak mods.
- Fixed: path strings
- Added: Buttons to open PCGamingWiki page, view changelog, and submit bug reports
- Fixed: Xbox game version detection
- Improved: Made UE4SS Scripts, UE4SS DLL, LogicMods, and Root Folder mod installers case-insensitive to folder names

## [0.2.0] - 2025-07-14

- Added installer for new Modding Editor mods in the "Mods" folder. All legacy installers are still available.
