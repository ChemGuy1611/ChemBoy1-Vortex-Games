# Changelog

## Planned Improvements (Not Yet Released)

- UE4SS support
- Remove UEMI dependency

## [0.5.1] - 2026-08-11

- Added Epic Games Store support
- Steam version now launches through Steam

## [0.5.0] - 2026-05-07

- Fixed: Multiple technical issues

## [0.4.0] - 2025-06-17

- Many technical fixes to improve the extension.
- Added installers for save and config mods on both Xbox and Steam versions. Fixed paths for Steam version.
- Added buttons for opening useful folders and files (folder icon in Mods toolbar).
