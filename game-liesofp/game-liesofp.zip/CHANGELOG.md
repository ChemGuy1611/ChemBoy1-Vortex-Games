# Changelog

Future Changes (NOT IMPLEMENTED YET):

- None

## [0.4.0] - 2025-06-17

- Many technical fixes to improve the extension.
- Added installers for save and config mods on both Xbox and Steam versions.
- Added buttons for opening useful folders and files (folder icon in Mods toolbar).
