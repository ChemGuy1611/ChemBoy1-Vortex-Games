# Changelog

## Planned Improvements (Not Yet Released)

- Add???: Support for installing MelonLoader plugins. Need the compatibility loader for MelonLoader mods to work (<https://github.com/BepInEx/BepInEx.MelonLoader.Loader>) - there are very few MelonLoader mods.

## [0.3.3] - 2026-09-18

- Fixed: Updating a skin mod could install it into a new folder instead of replacing the previous version.

## [0.3.2] - 2026-09-13

- Updated: BepInExConfigManager now automatically checks for and installs the latest version instead of staying pinned to 18.4.1, and shows its proper name in the mod list
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.3.1] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.3.0] - 2026-03-29

- Added: Support for .png skin mod packs that install to the "Hollow Knight Silksong_Data\Mods\Customizer" folder.
- Added: Root installer ("Hollow Knight Silksong_Data" folder)
- Added: Fallback installer with notification if Vortex could not determine how to install the mod.
- Updated: BepInEx to latest 5.4.23.5 - fixes log writer errors
- Updated: BepInExConfigManager to latest 18.4.1 and added download button

## [0.2.0] - 2026-02-07

- Fixed: Path strings
- Fixed: Xbox game version detection

## [0.1.3] - 2025-09-08

- Added "CHANGELOG.md" filename to ignoreConflicts list.

## [0.1.2] - 2025-09-06

- Added ignoreConflicts list for common files (icon.png, manifest.json, readme.txt).
- BepInExConfigManager now installed automatically from GitHub.
- Added button to open BepInEx.cfg (folder icon on Mods page toolbar).
- Added executable icon for custom launch tool.

## [0.1.1] - 2025-09-04

- Added Assembly-CSharp.dll mod installer.
- Added buttons to open the Data and save folders (folder icon on Mods page toolbar).

## [0.1.0] - 2025-09-04

- Initial release
