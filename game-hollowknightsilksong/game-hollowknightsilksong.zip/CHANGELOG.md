# Changelog

## Future Improvements (Not Yet Released)

- None

## [0.1.2] - 2025-09-06

- Added ignoreConflicts list for common files (icon.png, manifest.json, readme.txt).
- BepInExConfigManager now installed automatically from GitHub.

## [0.1.1] - 2025-09-04

- Added Assembly-CSharp.dll mod installer.
- Added buttons to open the Data and save folders (folder icon on Mods page toolbar).

## [0.1.0] - 2025-09-04

- Initial release
