# Changelog

## Planned Improvements (Not Yet Released)

- Add???: Support for installing MelonLoader plugins. Need the compatibility loader for MelonLoader mods to work (<https://github.com/BepInEx/BepInEx.MelonLoader.Loader>) - there are very few MelonLoader mods.

## [1.0.0] - 2026-10-01

- Changed: BepInEx is now installed and managed by this extension instead of Vortex's built-in BepInEx support. Your installed BepInEx and mods are carried over automatically - no action needed.
- BepInEx now checks for updates and notifies you when a newer version is available. It is no longer held at 5.4.23.5, but it is never updated without you choosing to.
- Plugins that don't already ship their own folder are now installed into one of their own, so two mods with a same-named file no longer overwrite each other.
- New installs: BepInExConfigManager is now offered through a notification instead of being installed automatically.
- Added: "Download Latest MelonLoader" button. Only one mod loader can be installed at a time - if both are present, you'll be asked to choose which one to keep.
- Thunderstore package files (manifest.json, icon.png) from newly installed mods are no longer copied into the shared mod loader folder, where they collided between mods.

## [0.4.1] - 2026-09-28

- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Game version now shows the real game build instead of the Unity engine version.

## [0.4.0] - 2026-09-20

- Added: "Browse Thunderstore" page, which opens the Hollow Knight: Silksong Thunderstore site inside Vortex. Downloads started from it are installed, enabled, and named automatically, and any mods they depend on can be installed with them.
- Added: Update notifications for mods installed from the Thunderstore page.

## [0.3.3] - 2026-09-18

- Fixed: Updating a skin mod could install it into a new folder instead of replacing the previous version.

## [0.3.2] - 2026-09-13

- Updated: BepInExConfigManager now automatically checks for and installs the latest version instead of staying pinned to 18.4.1, and shows its proper name in the mod list
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.

## [0.3.1] - 2026-09-12

- Fixed: Mod files with no file extension, such as Unity asset bundles, were skipped during installation

## [0.3.0] - 2026-03-29

- Added: Support for .png skin mod packs that install to the "Hollow Knight Silksong_Data\Mods\Customizer" folder.
- Added: Root installer ("Hollow Knight Silksong_Data" folder)
- Added: Fallback installer with notification if Vortex could not determine how to install the mod.
- Updated: BepInEx to latest 5.4.23.5 - fixes log writer errors
- Updated: BepInExConfigManager to latest 18.4.1 and added download button

## [0.2.0] - 2026-02-07

- Fixed: Path strings
- Fixed: Xbox game version detection

## [0.1.3] - 2025-09-08

- Added "CHANGELOG.md" filename to ignoreConflicts list.

## [0.1.2] - 2025-09-06

- Added ignoreConflicts list for common files (icon.png, manifest.json, readme.txt).
- BepInExConfigManager now installed automatically from GitHub.
- Added button to open BepInEx.cfg (folder icon on Mods page toolbar).
- Added executable icon for custom launch tool.

## [0.1.1] - 2025-09-04

- Added Assembly-CSharp.dll mod installer.
- Added buttons to open the Data and save folders (folder icon on Mods page toolbar).

## [0.1.0] - 2025-09-04

- Initial release
