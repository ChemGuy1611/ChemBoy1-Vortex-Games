# Changelog

## Planned Improvements (Not Yet Released)

- None

## [1.0.0] - 2026-08-24

- Initial release
