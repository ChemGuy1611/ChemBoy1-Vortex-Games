# Changelog

## [1.2.4] - 2026-11-23

- Fixed: Mod files whose names only begin with README, CHANGELOG, or LICENSE (for example, License_Plates.dds) are no longer skipped during deployment.
- Added: README and CHANGELOG files spelled with a hyphen, underscore, or space (for example, READ_ME.txt or Change Log.md) are now excluded from mod conflict detection and deployment.
- Changed: Updated the extension's info.json to the latest Vortex format.

## [1.2.3] - 2026-11-04

- Changed: Browse pages no longer open ads and other pop-ups in your web browser. A blocked page shows a notification with an "Open" button instead.

## [1.2.2] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.2.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.2.0] - 2026-10-12

- Added a fallback installer: when no other installer matches a mod, Vortex now shows a notice and installs the files to the game folder.
- Fixed: Mods packaged inside an outer folder whose name ends with a game folder's name (for example "MyData" for "Data") now install into the right place instead of a doubled folder.
- Vortex now checks that the game's mod folders are writable when the game is set up.
- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.1] - 2026-09-08

- Fixed: A required mod loader or tool is no longer mistaken for an unrelated Nexus mod that shares the same file, which could show the wrong mod details or offer a bogus update for it
- Fixed: Downloads fetched for a required mod loader or tool now show "Website" as their source instead of being left blank

## [1.1.0] - 2026-08-25

- Added: A page to browse mods on fcmodding.com.

## [1.0.0] - 2026-08-14

- The FC3 Mod Installer is now kept up to date. Vortex checks for new builds and installs them, and a "Download Latest FC3 Mod Installer" button has been added to the Mods toolbar.
- If you already have the Mod Installer installed, you will see one update notification the first time this runs, even if your build is current. Taking the update clears it.

## [0.2.4] - 2026-08-11

- Added Epic Games Store support

## [0.2.3] - 2025-10-24

- Fixed potential error when write checking Config folder and setting path to Saves folder.

## [0.2.2] - 2025-10-14

- Fixed button to open Saves folder.

## [0.2.1] - 2025-10-04

- Corrected an issue with the loose .a3 file installer.
- Added tool to launch Save Manager.
- Added button to open Save folder.

## [0.2.0] - 2025-10-03

- Corrected Mod Installer installer putting files in the wrong place.
- Several technical fixes and improvements.
- Added tool to launch game with custom command line parameters (set by user).
- Added buttons to open multiple folders and site (folder icon on Mods page toolbar).
