# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2025-10-03

- Corrected Mod Installer installer putting files in the wrong place.
- Several technical fixes and improvements.
- Added tool to launch game with custom command line parameters (set by user).
- Added buttons to open multiple folders and site (folder icon on Mods page toolbar).
