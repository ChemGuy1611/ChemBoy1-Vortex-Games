# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.2.3] - 2025-10-24

- Fixed potential error when write checking Config folder and setting path to Saves folder.

## [0.2.2] - 2025-10-14

- Fixed button to open Saves folder.

## [0.2.1] - 2025-10-04

- Corrected an issue with the loose .a3 file installer.
- Added tool to launch Save Manager.
- Added button to open Save folder.

## [0.2.0] - 2025-10-03

- Corrected Mod Installer installer putting files in the wrong place.
- Several technical fixes and improvements.
- Added tool to launch game with custom command line parameters (set by user).
- Added buttons to open multiple folders and site (folder icon on Mods page toolbar).
