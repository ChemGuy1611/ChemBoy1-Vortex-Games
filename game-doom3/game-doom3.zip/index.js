/*//////////////////////////////////////////
Name: DOOM 3 and DOOM 3: BFG Edition Vortex Extension
Structure: Basic multi-game with multiple exes
Author: ChemBoy1
Version: 1.1.2
Date: 2026-11-23
/////////////////////////////////////////*/
/*
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣠⣤⣤⣤⡴⣦⡴⣖⠶⣴⠶⡶⣖⡶⣶⢶⣲⡾⠿⢿⡷⣾⢿⣷⣦⢾⣷⣾⣶⣤⣀⣰⣤⣀⡀⠀⠀⢀⣴⣿⡿⡿⣿⣿⣦⣄⠀⠀⣠⣴⣿⡿⢿⡿⣷⣦⡄⠀⠀⢀⣀⣤⣦⣀⣤⣶⣶⣷⣦⣴⡿⢿⡷⣿⠿⡿⣿⣷⢶⣦⢴⡲⣦⢶⡶⢶⡲⣖⡶⣦⣤⣤⣤⣤⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⠶⣟⣻⣙⡏⡽⣬⢳⠴⣣⣔⡳⣤⣒⣖⡳⣰⠣⠖⠤⠶⠤⢦⣥⣭⣭⣐⣘⣘⣋⠐⠘⠛⠒⠚⠲⢮⠽⣍⣛⣻⣿⣿⣶⣿⡿⡷⣿⣽⣳⠿⣽⣿⣿⣾⣿⣯⣷⣟⡿⣟⡷⣿⣿⣶⣿⣿⣟⣫⣙⠯⡶⠞⠒⠒⠛⠃⠘⣋⣓⣀⣣⣬⣭⣬⠴⠤⠦⠵⠰⡔⣒⢦⣓⣔⣲⣒⢦⡱⢎⡵⣫⢵⣋⣏⣻⠟⣶⢦⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣠⣤⣶⣿⣿⣯⣷⣾⣿⣾⣷⣿⣽⣿⣽⣿⣿⣿⣾⣽⣯⣿⣭⣿⣽⣻⣟⣻⡟⣷⢶⡶⢶⣥⣮⣍⣛⣉⢛⠛⠓⠒⠶⢦⣄⣀⠠⢈⠻⡰⣹⣽⠭⠗⠛⠑⠨⠘⠉⣿⢃⡙⠋⡘⡷⠌⠆⠑⠚⠛⠷⢭⣧⣯⢎⣻⠍⢀⣀⣀⣴⠶⠒⠚⠛⣋⣉⣛⣩⣴⣴⡶⣶⢶⣞⡿⣛⣟⣟⣯⣿⣽⣯⣷⣿⣿⣿⣿⣿⣽⣿⣿⣾⣷⣿⣷⣾⣷⣯⣿⣿⣷⣶⣤⡀⠀⠀
⢶⠿⠟⠛⠛⠛⠛⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠛⠛⠛⠛⠛⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣯⣿⣞⣽⣻⡽⣿⢿⠿⣶⣶⣦⣤⡈⠙⣠⢊⢝⢎⠞⠀⠀⠀⠀⢀⢀⣁⠘⠙⠣⠜⠋⠇⣈⣀⡀⠀⠀⠀⢀⠱⡑⡀⡐⢞⢛⣉⣤⣤⣶⣶⠾⣿⢿⣏⣿⣛⣮⣷⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⠿⠛⠛⠛⠛⠛⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠛⠛⠛⠻⠿⠿⢶
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠿⣿⣿⣿⣿⣿⣾⣿⣟⣹⣷⣯⣿⢫⡿⣰⢃⢚⠌⡔⠂⠀⣠⣔⡟⠃⠂⠠⠀⠀⠂⠀⠀⠐⠚⢻⠢⣄⠀⠀⢂⠱⡈⡘⢆⢣⡼⣿⣽⣾⣏⣻⣽⣾⣿⣿⣿⣿⣿⠿⠛⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠛⢿⡿⣿⣿⣿⣿⣿⣿⣾⣷⢫⢊⠒⡀⣴⣞⡃⠉⠀⡴⣠⠂⡜⠀⠀⢣⠐⢄⢀⠀⠉⠉⢳⣖⢤⠀⡑⡜⣾⣧⣿⣿⣿⣿⣿⣿⢿⡿⠛⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⣿⣿⣿⣿⣿⠛⢱⠃⡅⣿⡟⢪⠂⢢⡞⣴⠃⡞⠁⠀⠀⠀⢳⠈⣦⠑⡄⠀⠋⡞⣧⠐⠈⡎⠙⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣷⣷⣃⢞⣼⣿⣷⣣⡴⢋⡼⠃⡼⡁⠀⠀⠀⠀⠈⣦⠈⢧⡘⢢⡐⢤⣿⣧⡒⢜⣞⣮⣿⣿⣿⣿⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣟⡿⣯⠶⢛⡥⡽⣖⡟⠺⣿⠇⢸⡃⠌⢢⠀⠀⡀⠂⢈⡇⠘⢿⡦⢿⣳⠮⠨⣿⡶⣿⢿⣻⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣯⡿⡽⣿⢄⡷⢖⠛⠃⠦⣍⠢⣀⠙⢦⡆⣸⢣⢘⣤⠞⣤⣰⢏⡵⠝⠛⡒⠾⡄⢷⢻⡿⣽⣿⢿⣏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣾⣏⢷⡱⡝⢿⣾⣿⣷⣯⣆⠈⢿⡦⠙⠤⠑⣿⢸⠛⠡⡅⢩⡾⠿⣀⣸⣷⣿⣿⣿⢛⡿⣹⢿⣾⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢘⣿⣿⣿⣾⡷⣿⣿⡿⣯⠉⢻⣿⡀⡄⣿⣦⣠⣄⣿⣾⣇⣤⣀⣿⢇⡄⣾⡿⠋⣹⡿⣿⣿⡿⣧⣿⣿⣝⣏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣟⢿⣼⣄⠘⢷⣤⡿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡿⣧⣴⠛⢀⣽⣿⢿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⢮⣛⠿⣿⠛⠛⣷⣯⣟⡴⡣⠝⣿⣟⡛⣿⡗⠭⣳⣜⣿⣷⡝⢟⢻⡿⢟⣣⢾⣿⣿⣿⣻⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⠻⣟⣋⢁⣷⣸⡟⣧⢿⣿⡔⠩⢼⡗⢐⡿⠌⠱⣼⣿⢷⠏⣷⣸⣆⣉⣛⡷⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⠛⣿⡿⣼⣯⡳⣞⡽⡇⣎⣏⣿⡱⠀⠈⢁⡆⠃⠀⣲⣼⣏⣏⡆⣿⣽⡴⣫⣧⡾⣿⡏⠛⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⡿⣿⣿⣿⣾⣿⣑⡏⢆⣿⣿⣆⡀⢺⣿⠀⣸⣾⣿⣇⠎⣗⣳⣿⣾⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⢿⣿⣿⡷⣾⣿⣶⣿⣿⣿⠥⠀⣺⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣀⠘⣿⡿⣇⣿⣿⣷⣿⣿⡏⢀⢸⣿⢿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣟⢿⣿⣿⣿⣿⣿⣿⢻⡾⡦⣙⡶⡇⣿⢻⣌⡻⢞⣡⣻⣾⢹⣿⣿⣿⣿⣿⣿⢿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⢿⣿⣜⢻⡻⣿⡿⣿⣿⣿⣿⣧⣛⣤⠿⠻⡜⠻⣧⡜⣸⣿⣿⣿⣿⠿⣿⡿⡣⢘⣿⣧⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣆⠙⣻⠃⣿⣿⣝⣆⢻⠉⡿⠚⠳⡟⠛⢺⡏⣽⢃⣏⣿⣿⡇⢿⡀⢁⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⢳⣤⠙⣿⣯⣻⢾⣇⣇⡄⠀⡃⣠⢸⣧⡿⢾⣻⣿⠟⢠⣾⠃⢻⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⢸⡘⣿⣶⣟⣽⠿⣾⣦⣫⡉⠉⡏⠉⣹⣡⣶⡿⢿⣜⣶⣿⠟⣸⠘⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣼⣿⣿⣿⣿⢿⣿⣿⣿⣻⡟⢿⡿⢟⣟⣿⣽⢿⣿⢿⣿⣿⣿⣯⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⢿⣿⣄⠛⣿⣞⣝⠻⠿⠻⢟⠻⠟⢛⣽⣾⠟⢁⣽⣿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠿⣷⣮⣹⣿⣶⡶⣦⣤⡶⢶⣿⣿⣩⣾⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//*/

//Import libraries
const fs = require("fs");
const fsp = fs.promises;
const { actions, fs: vfs, util, selectors, log } = require("vortex-api");
const path = require("path");
const template = require("string-template");
const {
  download,
  findModByFile,
  findDownloadIdByFile,
  resolveVersionByPattern,
  testRequirementVersion,
} = require("./downloader");
const { parseStringPromise } = require("xml2js");
const { registerModDbBrowser, onceModDbBrowser } = require("./moddb_browser");
//Embedded GameBanana browser page (needs base_browser.js beside it)
const { registerGameBananaBrowser, onceGameBananaBrowser } = require("./gamebanana_browser");

//feature toggles
const moddbBrowser = true; //register the "Browse ModDB" page (moddb.com)
const gamebananaBrowser = true; //register the "Browse GameBanana" page - browse and install the game's GameBanana mods inside Vortex

//Specify all information about the game
const GAME_ID = "doom3";
const GAME_ID_BFG = "doom3bfgedition";
const STEAMAPP_ID = "9050";
const STEAMAPP_ID_BFG = "208200";
const STEAMDB_URL_BFG = `https://steamdb.info/app/${STEAMAPP_ID_BFG}/`;
const GOGAPP_ID = "1492054092";
const GOGAPP_ID_BFG = "1135892318";
const XBOXAPP_ID_BFG = "BethesdaSoftworks.Doom32004"; //the xbox release is the BFG Edition only, so the classic spec carries no xbox ID
const XBOXEXECNAME_BFG = "Game";
const EPICAPP_ID_BFG = "83e46676e06541d9a22d96ee852ad912"; //Epic lists one "DOOM 3" offer, which is the BFG Edition re-release
//!audit-skip: store-id - EPICAPP_ID: the classic game is not on Epic, its only DOOM 3 offer is the BFG Edition (EPICAPP_ID_BFG)
const GAME_NAME = "DOOM 3";
const GAME_NAME_BFG = "DOOM 3: BFG Edition";
const GAME_NAME_SHORT_BFG = "DOOM 3 BFG";

let GAME_PATH = "";
let GAME_PATH_BFG = null;
let STAGING_FOLDER = "";
let STAGING_FOLDER_BFG = "";
let DOWNLOAD_FOLDER = "";
let DOWNLOAD_FOLDER_BFG = "";
const APPMANIFEST_FILE = "appxmanifest.xml";

const gameFinderQuery = {
  steam: [{ id: STEAMAPP_ID, prefer: 0 }],
  gog: [{ id: GOGAPP_ID }],
};

// Information for setting executable and variables based on game store version
const EXEC_CLASSIC = "Doom3.exe";
const EXEC_BFG = "Doom3BFG.exe";
const EXEC_XBOX = "gamelaunchhelper.exe";
let GAME_VERSION = "";
const CLASSIC = "classic";
const BFG = "bfg";
const XBOX = "xbox";

// Information for installers, modtypes, and tools
//const USER_HOME = util.getVortexPath("home");
//const LOCALAPPDATA = util.getVortexPath("localAppData");
//const DOCUMENTS =  util.getVortexPath("documents");

const BASE_ID = `${GAME_ID}-base`;
const BASE_ID_BFG = `${GAME_ID_BFG}-base`;
const BASE_NAME = '"base" Data';
const BASE_PATH = "base";

const D3XP_ID = `${GAME_ID}-d3xp`;
const D3XP_NAME = "d3xp (RoE) Folder";
const D3XP_PATH = "d3xp";

const D3LE_ID = `${GAME_ID}-d3le`;
const D3LE_NAME = "d3le (Lost Mission) Folder";
const D3LE_PATH = "d3le";

const ROOT_ID = `${GAME_ID}-binaries`;
const ROOT_ID_BFG = `${GAME_ID_BFG}-root`;
const ROOT_NAME = "Binaries / Root Folder";
const ROOT_FILE = "base";

//Files used to trigger root installer
const WOMD_FILE = "womd_readme.txt"; //Weapon of Mars Destruction mod readme file
const D3HDP_FILE = "d3hdpack"; //Doom 3 HD Pack mod folder
const PHOBOS_FILE = "tfphobos"; //Phobos mod folder
const ARL_FILE = "arl"; //ARL mod folder
const REDUX_FILE = "redux 20th anniversary edition rc1"; //Redux mod folder
const REDUX_DHEWM3_FILE = "installation"; //Redux-Dhewm3 patch mod folder

const ROOT_FILES = [
  BASE_PATH,
  D3XP_PATH,
  D3LE_PATH,
  PHOBOS_FILE,
  WOMD_FILE,
  D3HDP_FILE,
  ARL_FILE,
  REDUX_FILE,
  REDUX_DHEWM3_FILE,
]; //<-- Add file/folder names here to get mods to root folder
const MANUAL_INTERVENTION_FILES = [WOMD_FILE, D3HDP_FILE, ARL_FILE, REDUX_FILE, REDUX_DHEWM3_FILE]; //<-- These require the user to do manual file manipulation - trigger notification when installing
const ROOT_FOLDERS_BFG = ["base"];

//.pk4 mods packaged inside a folder. A folder that comes with anything besides .pk4 files and docs
//is a standalone mod the game lists in its Mods menu, so it stays a folder beside "base". Otherwise
//the folder is only packaging, and its files belong in "base".
const PK4_FOLDER_ID = `${GAME_ID}-pk4folder`;
const PK4_EXTS = [".pk4"];
const MOD_FOLDER_FILES = ["description.txt"]; //the file the game's Mods menu reads a mod's name from
const DOC_EXTS = [
  ".txt",
  ".md",
  ".rtf",
  ".pdf",
  ".doc",
  ".docx",
  ".nfo",
  ".htm",
  ".html",
  ".url",
  ".jpg",
  ".jpeg",
  ".png",
  ".gif",
  ".bmp",
  ".tga",
];

const DHEWM3_ID = `${GAME_ID}-dhewm3`;
const DHEWM3_NAME = "Dhewm3";
const DHEWM3_EXEC = "dhewm3.exe";
const DHEWM3_ARC_NAME = "dhewm3-1.5.4_win32.zip";
const DHEWM3_URL_MAIN = `https://api.github.com/repos/dhewm/dhewm3`;
const DHEWM3_FILE = DHEWM3_EXEC; // <-- CASE SENSITIVE! Must match name exactly or downloader will download the file again.
const REQUIREMENTS = [
  {
    //Dhewm3
    archiveFileName: DHEWM3_ARC_NAME,
    modType: DHEWM3_ID,
    assemblyFileName: DHEWM3_FILE,
    userFacingName: DHEWM3_NAME,
    githubUrl: DHEWM3_URL_MAIN,
    findMod: (api) => findModByFile(api, DHEWM3_ID, DHEWM3_FILE),
    findDownloadId: (api) => findDownloadIdByFile(api, DHEWM3_ARC_NAME),
    fileArchivePattern: new RegExp(/^dhewm3-(\d+\.\d+\.\d+)_win32/, "i"),
    resolveVersion: (api) => resolveVersionByPattern(api, REQUIREMENTS[0]),
  },
];

const MOD_PATH_DEFAULT = BASE_PATH;
const MOD_PATH_DEFAULT_BFG = ".";
const REQ_FILE = ROOT_FILE;
const PARAMETERS_STRING = "+disconnect +set com_allowconsole 1 +set com_skipintro 1";
const PARAMETERS = [PARAMETERS_STRING];
const PARAMETERS_STRING_BFG = "+set com_allowconsole 1 +set com_skipintrovideos 1";
const PARAMETERS_STRING_BFG2 = "+set fs_resourceLoadPriority 0";
const PARAMETERS_BFG = [PARAMETERS_STRING_BFG, PARAMETERS_STRING_BFG2];
const IGNORE_DEPLOY = [
  path.join("**", "readme.txt"),
  path.join("**", "README.txt"),
  path.join("**", "ReadMe.txt"),
  path.join("**", "Readme.txt"),
  path.join("**", "license!(*.*)"),
  path.join("**", "license*.{txt,md,rtf,pdf,html,htm}"),
];
const IGNORE_CONFLICTS = [
  path.join("**", "readme.txt"),
  path.join("**", "README.txt"),
  path.join("**", "ReadMe.txt"),
  path.join("**", "Readme.txt"),
  path.join("**", "license!(*.*)"),
  path.join("**", "license*.{txt,md,rtf,pdf,html,htm}"),
];

// Filled in from data above
const EXTENSION_URL = "https://www.nexusmods.com/site/mods/686"; //Nexus link to this extension. Used for links
const PCGAMINGWIKI_URL = "https://www.pcgamingwiki.com/wiki/Doom_3";
const STEAMDB_URL = `https://steamdb.info/app/${STEAMAPP_ID}/`;
const GB_GAME_ID = "27"; //GameBanana game id - https://gamebanana.com/games/27
const GB_URL = `https://gamebanana.com/games/${GB_GAME_ID}`;

//Embedded ModDB browser page - the user browses the live moddb.com section for this game and
//installs from it. Vortex's download manager cannot fetch from this host, so the page fetches
//the file itself. No requirements: nothing on this game's ModDB page is a managed mod loader.
//moddb.com serves the classic Doom 3 page ('doom-iii'); its mod list is classic-only, so the
//page registers against the classic spec and not DOOM 3: BFG Edition.
const MODDB_BROWSER_CONFIG = {
  moddbPath: "games/doom-iii",
  pageId: `${GAME_ID}-moddb-browse`,
  pageTitle: "Browse ModDB",
};

//Embedded GameBanana browser page - the user browses the live site and installs from it.
//GameBanana mods are ordinary archives, so they land through the same installers as any other.
//Its Doom 3 section is for the classic game, so like the ModDB page it registers against the
//classic spec and not DOOM 3: BFG Edition.
const GB_BROWSER_CONFIG = {
  gbGameId: GB_GAME_ID,
  pageId: `${GAME_ID}-gamebanana-browse`,
  pageTitle: "Browse GameBanana",
  priority: 41, //directly below the ModDB page, so the sidebar order stays stable
};

const spec = {
  game: {
    id: GAME_ID,
    name: GAME_NAME,
    logo: `${GAME_ID}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    parameters: PARAMETERS,
    modPath: MOD_PATH_DEFAULT,
    modPathIsRelative: true,
    requiredFiles: [REQ_FILE],
    details: {
      steamAppId: +STEAMAPP_ID,
      gogAppId: GOGAPP_ID,
      ignoreDeploy: IGNORE_DEPLOY,
      ignoreConflicts: IGNORE_CONFLICTS,
    },
    environment: {
      SteamAPPId: STEAMAPP_ID,
      GogAPPId: GOGAPP_ID,
    },
  },
  modTypes: [
    {
      id: ROOT_ID,
      name: ROOT_NAME,
      priority: "high",
      targetPath: "{gamePath}",
    },
    {
      id: BASE_ID,
      name: BASE_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", BASE_PATH),
    },
    {
      id: D3XP_ID,
      name: D3XP_NAME,
      priority: "high",
      targetPath: `{gamePath}//${D3XP_PATH}`,
    },
    {
      id: D3LE_ID,
      name: D3LE_NAME,
      priority: "high",
      targetPath: `{gamePath}//${D3LE_PATH}`,
    },
    {
      id: DHEWM3_ID,
      name: DHEWM3_NAME,
      priority: "low",
      targetPath: `{gamePath}`,
    },
  ],
};

const specBfg = {
  game: {
    id: GAME_ID_BFG,
    name: GAME_NAME_BFG,
    shortName: GAME_NAME_SHORT_BFG,
    logo: `${GAME_ID_BFG}.jpg`,
    mergeMods: true,
    requiresCleanup: true,
    parameters: PARAMETERS_BFG,
    modPath: MOD_PATH_DEFAULT_BFG,
    modPathIsRelative: true,
    requiredFiles: [REQ_FILE],
    details: {
      steamAppId: +STEAMAPP_ID_BFG,
      gogAppId: GOGAPP_ID_BFG,
      epicAppId: EPICAPP_ID_BFG,
      xboxAppId: XBOXAPP_ID_BFG,
      nexusPageId: GAME_ID,
      compatibleDownloads: [GAME_ID],
      ignoreDeploy: IGNORE_DEPLOY,
      ignoreConflicts: IGNORE_CONFLICTS,
    },
    environment: {
      SteamAPPId: STEAMAPP_ID_BFG,
      GogAPPId: GOGAPP_ID_BFG,
      EpicAPPId: EPICAPP_ID_BFG,
      XboxAPPId: XBOXAPP_ID_BFG,
    },
  },
  modTypes: [
    {
      id: ROOT_ID_BFG,
      name: "Binaries / Root Folder",
      priority: "high",
      targetPath: "{gamePath}",
    },
    {
      id: BASE_ID_BFG,
      name: BASE_NAME,
      priority: "high",
      targetPath: path.join("{gamePath}", BASE_PATH),
    },
  ],
  discovery: {
    ids: [STEAMAPP_ID_BFG, GOGAPP_ID_BFG, EPICAPP_ID_BFG, XBOXAPP_ID_BFG],
    names: [],
  },
};

//3rd party tools and launchers
const toolsBfg = [
  {
    id: `${GAME_ID_BFG}-customlaunch`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC_BFG,
    requiredFiles: [EXEC_BFG],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    //defaultPrimary: true,
    parameters: PARAMETERS_BFG,
  }, //*/
  {
    id: `${GAME_ID_BFG}-customlaunchxbox`,
    name: `Custom Launch`,
    logo: `exec.png`,
    executable: () => EXEC_XBOX,
    requiredFiles: [EXEC_XBOX],
    detach: true,
    relative: true,
    exclusive: true,
    shell: true,
    defaultPrimary: true,
    parameters: PARAMETERS_BFG,
  }, //*/
];

// BASIC FUNCTIONS ///////////////////////////////////////////////////////////////

//Set mod type priorities
function isDir(folder, file) {
  const stats = fs.statSync(path.join(folder, file));
  return stats.isDirectory();
}

function statCheckSync(gamePath, file) {
  try {
    fs.statSync(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function statCheckAsync(gamePath, file) {
  try {
    await fsp.stat(path.join(gamePath, file));
    return true;
  } catch {
    return false;
  }
}

async function getAllFiles(dirPath) {
  let results = [];
  try {
    const entries = await fsp.readdir(dirPath);
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry);
      const stats = await fsp.stat(fullPath);
      if (stats.isDirectory()) {
        // Recursively get files from subdirectories
        const subDirFiles = await getAllFiles(fullPath);
        results = results.concat(subDirFiles);
      } else {
        // Add file to results
        results.push(fullPath);
      }
    }
  } catch (err) {
    log("warn", `Error reading directory ${dirPath}: ${err.message}`);
  }
  return results;
}

const getDiscoveryPath = (api) => {
  //get the game's discovered path
  const state = api.getState();
  const discovery = state?.settings?.gameMode?.discovered?.[GAME_ID] ?? {};
  return discovery === null || discovery === void 0 ? void 0 : discovery.path;
};

async function purge(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("purge-mods", true, (err) => (err ? reject(err) : resolve())),
  );
}

async function deploy(api) {
  return new Promise((resolve, reject) =>
    api.events.emit("deploy-mods", (err) => (err ? reject(err) : resolve())),
  );
}

function modTypePriority(priority) {
  return {
    high: 25,
    low: 75,
  }[priority];
}

//Convert string placeholders to actual paths
function pathPattern(api, game, pattern) {
  try {
    var _a;
    return template(pattern, {
      gamePath:
        (_a = api.getState().settings.gameMode.discovered[game.id]) === null || _a === void 0
          ? void 0
          : _a.path,
      documents: util.getVortexPath("documents"),
      localAppData: util.getVortexPath("localAppData"),
      appData: util.getVortexPath("appData"),
    });
  } catch (err) {
    api.showErrorNotification(
      "Failed to locate executable. Please launch the game at least once.",
      err,
    );
  }
}

//Get the executable
function getExecutable(discoveryPath) {
  const isCorrectExec = (exec) => {
    try {
      fs.statSync(path.join(discoveryPath, exec));
      return true;
    } catch {
      return false;
    }
  };
  if (isCorrectExec(EXEC_XBOX)) {
    GAME_VERSION = XBOX;
    return EXEC_XBOX;
  }
  if (isCorrectExec(EXEC_CLASSIC)) {
    GAME_VERSION = CLASSIC;
    return EXEC_CLASSIC;
  }
  if (isCorrectExec(EXEC_BFG)) {
    GAME_VERSION = BFG;
    return EXEC_BFG;
  }
  return EXEC_CLASSIC;
}

//Get the executable - BFG Edition
function getExecutableBfg(discoveryPath) {
  const isCorrectExec = (exec) => {
    try {
      fs.statSync(path.join(discoveryPath, exec));
      return true;
    } catch {
      return false;
    }
  };
  if (isCorrectExec(EXEC_XBOX)) {
    GAME_VERSION = XBOX;
    return EXEC_XBOX;
  }
  if (isCorrectExec(EXEC_BFG)) {
    GAME_VERSION = BFG;
    return EXEC_BFG;
  }
  return EXEC_BFG;
}

//Get the  store version
async function getStoreVersion(discoveryPath) {
  const isCorrectExec = (exec) => {
    try {
      fs.statSync(path.join(discoveryPath, exec));
      return true;
    } catch {
      return false;
    }
  };
  if (isCorrectExec(EXEC_XBOX)) {
    return XBOX;
  }
  if (isCorrectExec(EXEC_CLASSIC)) {
    return CLASSIC;
  }
  if (isCorrectExec(EXEC_BFG)) {
    return BFG;
  }
  return CLASSIC;
}

//Get the  store version - BFG Edition
async function getStoreVersionBfg(discoveryPath) {
  const isCorrectExec = (exec) => {
    try {
      fs.statSync(path.join(discoveryPath, exec));
      return true;
    } catch {
      return false;
    }
  };
  if (isCorrectExec(EXEC_XBOX)) {
    return XBOX;
  }
  if (isCorrectExec(EXEC_BFG)) {
    return BFG;
  }
  return BFG;
}

//Set mod path
function makeGetModPath(api, gameSpec) {
  return () =>
    gameSpec.game.modPathIsRelative !== false
      ? gameSpec.game.modPath || "."
      : pathPattern(api, gameSpec.game, gameSpec.game.modPath);
}

//Find game installation directory
function makeFindGame(api, gameSpec) {
  return () =>
    util.GameStoreHelper.findByAppId(gameSpec.discovery.ids).then((game) => game.gamePath);
}

//Set launcher requirements
async function requiresLauncher(gamePath, store) {
  if (store === "steam") {
    return Promise.resolve({
      launcher: "steam",
    });
  } //*/
  return Promise.resolve(undefined);
}

//Set launcher requirements - BFG Edition
async function requiresLauncherBfg(gamePath, store) {
  if (store === "xbox") {
    return Promise.resolve({
      launcher: "xbox",
      addInfo: {
        appId: XBOXAPP_ID_BFG,
        parameters: [{ appExecName: XBOXEXECNAME_BFG }],
      },
    });
  } //*/
  if (store === "steam") {
    return Promise.resolve({
      launcher: "steam",
    });
  } //*/
  if (store === "epic") {
    return Promise.resolve({
      launcher: "epic",
      addInfo: {
        appId: EPICAPP_ID_BFG,
      },
    });
  } //*/
  return Promise.resolve(undefined);
}

// AUTOMATIC MOD DOWNLOADERS ///////////////////////////////////////////////////

//Check if Dhewm3 is installed
function isDhewm3Installed(api) {
  const state = api.getState();
  const mods = state.persistent.mods[GAME_ID] || {};
  return Object.keys(mods).some((id) => mods[id]?.type === DHEWM3_ID);
}

async function onCheckModVersion(api, gameId, mods, forced) {
  if (GAME_VERSION !== CLASSIC) {
    return;
  }
  try {
    await testRequirementVersion(api, REQUIREMENTS[0]);
  } catch (err) {
    log("warn", "failed to test requirement version", err);
  }
}

async function checkForDhewm3(api) {
  const mod = await REQUIREMENTS[0].findMod(api);
  return mod !== undefined;
}

// MOD INSTALLER FUNCTIONS ///////////////////////////////////////////////////

//Installer test for Dhewm3
function testDhewm3(files, gameId) {
  const isMod = files.some((file) => path.basename(file).toLowerCase() === DHEWM3_EXEC);
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Dhewm3
function installDhewm3(files) {
  const modFile = files.find((file) => path.basename(file).toLowerCase() === DHEWM3_EXEC);
  const idx = modFile.lastIndexOf(path.basename(modFile));
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: DHEWM3_ID };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for Root files
function testRoot(files, gameId) {
  const isMod = files.some((file) => ROOT_FILES.includes(path.basename(file).toLowerCase()));
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root files
function installRoot(api, files, fileName) {
  const modFile = files.find((file) => ROOT_FILES.includes(path.basename(file).toLowerCase()));
  const idx = modFile.lastIndexOf(`${path.basename(modFile)}${path.sep}`);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: ROOT_ID };

  if (MANUAL_INTERVENTION_FILES.includes(path.basename(modFile).toLowerCase())) {
    manualManipulationNotify(api, fileName);
  }

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

//Installer test for .pk4 files packaged inside a folder. A .pk4 at the archive root is left to the
//default install, which already puts it in "base".
function testPk4Folder(files, gameId) {
  const pk4Files = files.filter((file) => PK4_EXTS.includes(path.extname(file).toLowerCase()));
  const isMod = pk4Files.length > 0 && pk4Files.every((file) => path.dirname(file) !== ".");
  let supported = gameId === spec.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install for .pk4 files packaged inside a folder
function installPk4Folder(files) {
  const fileList = files.filter((file) => !file.endsWith(path.sep));
  const modFile = fileList
    .filter((file) => PK4_EXTS.includes(path.extname(file).toLowerCase()))
    .sort((a, b) => a.split(path.sep).length - b.split(path.sep).length)[0];
  const modFolder = path.dirname(modFile);
  const isStandalone = fileList.some((file) => {
    const ext = path.extname(file).toLowerCase();
    return (
      MOD_FOLDER_FILES.includes(path.basename(file).toLowerCase()) ||
      (!PK4_EXTS.includes(ext) && !DOC_EXTS.includes(ext))
    );
  });

  //A standalone mod keeps its folder, along with anything packaged beside it (launcher scripts).
  const parentFolder = path.dirname(modFolder);
  const parentPrefix = parentFolder === "." ? "" : parentFolder + path.sep;
  const rootPrefix = isStandalone ? parentPrefix : modFolder + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: isStandalone ? ROOT_ID : BASE_ID };

  const filtered = fileList.filter((file) => file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: file.slice(rootPrefix.length),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

function manualManipulationNotify(api, fileName) {
  const state = api.getState();
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  const MOD_NAME = path
    .basename(fileName)
    .replace(/\.installing$/i, "")
    .replace(/\.(zip|rar|7z)$/i, "");
  const NOTIF_ID = `${GAME_ID}-manualmanipulation-${MOD_NAME}`;
  const MESSAGE = "Manual File/Folder Manipulation Required";
  api.sendNotification({
    id: NOTIF_ID,
    type: "warning",
    message: MESSAGE,
    allowSuppress: true,
    actions: [
      {
        title: "More",
        action: (dismiss) => {
          api.showDialog(
            "question",
            MESSAGE,
            {
              text:
                `You've just installed a mod with a folder structure that requires manual file/folder manipulation to install properly.\n` +
                `\n` +
                `Mod: ${MOD_NAME}.\n` +
                `\n` +
                `Use the button below to open the Staging Folder and manually manipulate files and/or folders, based on the mod's instructions.\n` +
                `\n` +
                `Check the mod page description or a readme file for installation instructions. You can use the "Open Mod Page" button below (only for mods with a Nexus page). This notification will remain active after opening the mod page.\n` +
                `\n`,
            },
            [
              {
                label: `Open Mod Page`,
                action: () => {
                  const mods = api.store.getState()?.persistent?.mods?.[spec.game.id] ?? {};
                  const modMatch = Object.values(mods).find(
                    (mod) => mod.installationPath === MOD_NAME,
                  );
                  //log('warn', `Found ${modMatch?.id} for ${MOD_NAME}`);
                  let PAGE = ``;
                  if (modMatch) {
                    const MOD_ID = modMatch.attributes.modId;
                    PAGE = `${MOD_ID}?tab=description`;
                  }
                  const MOD_PAGE_URL = `https://www.nexusmods.com/${GAME_ID}/mods/${PAGE}`;
                  try {
                    window.api.shell.openUrl(MOD_PAGE_URL);
                  } catch (err) {
                    api.showErrorNotification("Failed to open the URL", err, {
                      allowReport: false,
                    });
                  }
                  //dismiss();
                },
              }, //*/
              {
                label: `Open Staging Folder`,
                action: () => {
                  try {
                    window.api.shell.openFile(path.join(STAGING_FOLDER, MOD_NAME));
                  } catch (err) {
                    api.showErrorNotification("Failed to open the file or folder", err, {
                      allowReport: false,
                    });
                  }
                  dismiss();
                },
              }, //*/
              { label: "Dismiss", action: () => dismiss() },
              {
                label: "Never Show Again",
                action: () => {
                  api.suppressNotification(NOTIF_ID);
                  dismiss();
                },
              },
            ],
          );
        },
      },
    ],
  });
}

// MOD INSTALLER FUNCTIONS - BFG EDITION ///////////////////////////////////////////////////

//Installer test for Root folder files
function testRootBfg(files, gameId) {
  const isMod = files.some((file) => ROOT_FOLDERS_BFG.includes(path.basename(file)));
  let supported = gameId === specBfg.game.id && isMod;

  // Test for a mod installer.
  if (
    supported &&
    files.find(
      (file) =>
        path.basename(file).toLowerCase() === "moduleconfig.xml" &&
        path.basename(path.dirname(file)).toLowerCase() === "fomod",
    )
  ) {
    supported = false;
  }

  return Promise.resolve({
    supported,
    requiredFiles: [],
  });
}

//Installer install Root folder files
function installRootBfg(files) {
  const modFile = files.find((file) => ROOT_FOLDERS_BFG.includes(path.basename(file)));
  const ROOT_IDX = `${path.basename(modFile)}${path.sep}`;
  const idx = modFile.lastIndexOf(ROOT_IDX);
  const rootPath = path.dirname(modFile);
  const rootPrefix = rootPath === "." ? "" : rootPath + path.sep;
  const setModTypeInstruction = { type: "setmodtype", value: ROOT_ID_BFG };

  // Remove directories and anything that isn't in the rootPath.
  const filtered = files.filter((file) => !file.endsWith(path.sep) && file.startsWith(rootPrefix));
  const instructions = filtered.map((file) => {
    return {
      type: "copy",
      source: file,
      destination: path.join(file.substr(idx)),
    };
  });
  instructions.push(setModTypeInstruction);
  return Promise.resolve({ instructions });
}

// MAIN FUNCTIONS ///////////////////////////////////////////////////////////////

//Notify User of Setup instructions
function setupNotify(api) {
  if (GAME_VERSION === XBOX) {
    const NOTIF_ID = `${GAME_ID}-xbox-notification`;
    api.sendNotification({
      id: "xbox-notification-doom3",
      type: "warning",
      message: "Xbox Version Detected",
      allowSuppress: true,
      actions: [
        {
          title: "More",
          action: (dismiss) => {
            api.showDialog(
              "question",
              "Xbox Version Detected",
              {
                text:
                  'Vortex detected that you are using the Xbox version of Doom 3. This version of Doom 3 is the 64-bit "BFG Edition".\n' +
                  "Please ensure the mods you install are intended for the BFG version of Doom 3. Mods intended for the Classic version will not work.\n" +
                  "\n",
              },
              [
                { label: "Acknowledge", action: () => dismiss() },
                {
                  label: "Never Show Again",
                  action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  },
                },
              ],
            );
          },
        },
      ],
    });
  }
  if (GAME_VERSION === BFG) {
    const NOTIF_ID = `${GAME_ID}-bfg-notification`;
    api.sendNotification({
      id: "bfg-notification-doom3",
      type: "warning",
      message: "BFG Version Detected",
      allowSuppress: true,
      actions: [
        {
          title: "More",
          action: (dismiss) => {
            api.showDialog(
              "question",
              "BFG Version Detected",
              {
                text:
                  'Vortex detected that you are using the 64-bit "BFG Edition" version of Doom 3.\n' +
                  "Please ensure the mods you install are intended for the BFG version of Doom 3. Mods intended for the Classic version will not work.\n" +
                  "\n",
              },
              [
                { label: "Acknowledge", action: () => dismiss() },
                {
                  label: "Never Show Again",
                  action: () => {
                    api.suppressNotification(NOTIF_ID);
                    dismiss();
                  },
                },
              ],
            );
          },
        },
      ],
    });
  }
}

async function resolveGameVersion(gamePath) {
  GAME_VERSION = await getStoreVersion(gamePath);
  let version = "0.0.0";
  if (GAME_VERSION === XBOX) {
    try {
      //try to parse appxmanifest.xml
      const appManifest = await fsp.readFile(path.join(gamePath, APPMANIFEST_FILE), "utf8");
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  if (GAME_VERSION === CLASSIC) {
    // use exe
    try {
      const exeVersion = require("exe-version");
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC_CLASSIC));
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read ${EXEC_CLASSIC} file to get Steam game version: ${err}`);
      return Promise.resolve(version);
    }
  }
  if (GAME_VERSION === BFG) {
    // use exe
    try {
      const exeVersion = require("exe-version");
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC_BFG));
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read ${EXEC_BFG} file to get Steam game version: ${err}`);
      return Promise.resolve(version);
    }
  }
}

async function resolveGameVersionBfg(gamePath) {
  GAME_VERSION = await getStoreVersion(gamePath);
  let version = "0.0.0";
  if (GAME_VERSION === XBOX) {
    try {
      //try to parse appxmanifest.xml
      const appManifest = await fsp.readFile(path.join(gamePath, APPMANIFEST_FILE), "utf8");
      const parsed = await parseStringPromise(appManifest);
      version = parsed?.Package?.Identity?.[0]?.$?.Version;
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read appmanifest.xml file to get Xbox game version: ${err}`);
      return Promise.resolve(version);
    }
  } else {
    // use exe
    try {
      const exeVersion = require("exe-version");
      version = exeVersion.getProductVersion(path.join(gamePath, EXEC_BFG));
      return Promise.resolve(version);
    } catch (err) {
      log("error", `Could not read ${EXEC_BFG} file to get Steam game version: ${err}`);
      return Promise.resolve(version);
    }
  }
}

//Setup function
async function setup(discovery, api, gameSpec) {
  const state = api.getState();
  GAME_PATH = discovery.path;
  STAGING_FOLDER = selectors.installPathForGame(state, GAME_ID);
  DOWNLOAD_FOLDER = selectors.downloadPathForGame(state, GAME_ID);
  GAME_VERSION = getStoreVersion(GAME_PATH);
  await vfs.ensureDirWritableAsync(path.join(GAME_PATH, gameSpec.game.modPath));
  await vfs.ensureDirWritableAsync(path.join(GAME_PATH, D3XP_PATH));
  await vfs.ensureDirWritableAsync(path.join(GAME_PATH, D3LE_PATH));
  if (GAME_VERSION === CLASSIC) {
    const Dhewm3Installed = await checkForDhewm3(api);
    return Dhewm3Installed ? Promise.resolve() : download(api, REQUIREMENTS);
  }
  setupNotify(api);
  return;
}

//Setup function
async function setupBfg(discovery, api, gameSpec) {
  const state = api.getState();
  GAME_PATH_BFG = discovery.path;
  STAGING_FOLDER_BFG = selectors.installPathForGame(state, GAME_ID_BFG);
  DOWNLOAD_FOLDER_BFG = selectors.downloadPathForGame(state, GAME_ID_BFG);
  GAME_VERSION = getStoreVersion(GAME_PATH);
  return vfs.ensureDirWritableAsync(path.join(discovery.path, BASE_PATH));
}

//Let Vortex know about the game
function applyGame(context, gameSpec) {
  //register game
  const game = {
    ...gameSpec.game,
    queryArgs: gameFinderQuery,
    executable: getExecutable,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncher,
    setup: async (discovery) => await setup(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersion,
    supportedTools: [
      {
        id: "Dhewm3Launch",
        name: "Launch Dhewm3",
        logo: "dhewm3.png",
        executable: () => DHEWM3_EXEC,
        requiredFiles: [DHEWM3_EXEC],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        defaultPrimary: true,
        parameters: PARAMETERS,
      },
      {
        id: `${GAME_ID}-customlaunch`,
        name: `Custom Launch`,
        logo: `exec.png`,
        executable: () => EXEC_CLASSIC,
        requiredFiles: [EXEC_CLASSIC],
        detach: true,
        relative: true,
        exclusive: true,
        shell: true,
        //defaultPrimary: true,
        parameters: PARAMETERS,
      }, //*/
    ],
  };
  context.registerGame(game);

  //register the embedded moddb.com browser page
  if (moddbBrowser) {
    registerModDbBrowser(context, gameSpec, MODDB_BROWSER_CONFIG);
  }

  //register the embedded GameBanana browser page
  if (gamebananaBrowser) {
    registerGameBananaBrowser(context, gameSpec, GB_BROWSER_CONFIG);
  }

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //register mod installers
  context.registerInstaller(DHEWM3_ID, 25, testDhewm3, installDhewm3);
  context.registerInstaller(ROOT_ID, 27, testRoot, (files, fileName) =>
    installRoot(context.api, files, fileName),
  );
  context.registerInstaller(PK4_FOLDER_ID, 29, testPk4Folder, installPk4Folder);

  //register actions
  /*
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
    const openPath = CONFIG_PATH;
    try {
      window.api.shell.openFile(openPath);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  });
  context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Saves Folder', () => {
    const openPath = SAVE_PATH;
    try {
      window.api.shell.openFile(openPath);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
  }, () => {
    const state = context.api.getState();
    const gameId = selectors.activeGameId(state);
    return gameId === GAME_ID;
  }); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      const openPath = path.join(__dirname, "CHANGELOG.md");
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      const openPath = DOWNLOAD_FOLDER;
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );

  //register actions
  /*context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Save Folder', () => {
    try {
      window.api.shell.openFile(SAVE_PATH);
    } catch (err) {
      context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
    }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
  }); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Nexus Mods Page",
    () => {
      try {
        window.api.shell.openUrl(`https://www.nexusmods.com/${GAME_ID}/mods`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  if (gamebananaBrowser) {
    context.registerAction(
      "mod-icons",
      300,
      "open-ext",
      {},
      "Open GameBanana Page",
      () => {
        try {
          window.api.shell.openUrl(GB_URL);
        } catch (err) {
          context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
        }
      },
      () => {
        const state = context.api.getState();
        const gameId = selectors.activeGameId(state);
        return gameId === GAME_ID;
      },
    );
  }
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open SteamDB Page",
    () => {
      try {
        window.api.shell.openUrl(STEAMDB_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Submit Bug Report",
    () => {
      try {
        window.api.shell.openUrl(`${EXTENSION_URL}?tab=bugs`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID;
    },
  );
}

function applyGameBfg(context, gameSpec) {
  //register game
  const game = {
    ...gameSpec.game,
    queryPath: makeFindGame(context.api, gameSpec),
    executable: getExecutableBfg,
    queryModPath: makeGetModPath(context.api, gameSpec),
    requiresLauncher: requiresLauncherBfg,
    setup: async (discovery) => await setupBfg(discovery, context.api, gameSpec),
    getGameVersion: resolveGameVersionBfg,
    supportedTools: toolsBfg,
  };
  context.registerGame(game);

  //register mod types
  (gameSpec.modTypes || []).forEach((type, idx) => {
    context.registerModType(
      type.id,
      modTypePriority(type.priority) + idx,
      (gameId) => {
        var _a;
        return (
          gameId === gameSpec.game.id &&
          !!((_a = context.api.getState().settings.gameMode.discovered[gameId]) === null ||
          _a === void 0
            ? void 0
            : _a.path)
        );
      },
      (game) => pathPattern(context.api, game, type.targetPath),
      () => Promise.resolve(false),
      { name: type.name },
    );
  });

  //register mod installers
  //!audit-skip: installer-priority - shares 25 with the classic game's dhewm3 installer, but the two testSupported functions gate on different game specs (specBfg vs spec) so they can never both match; a priority could not break a tie that never happens
  context.registerInstaller(ROOT_ID_BFG, 25, testRootBfg, installRootBfg);

  //register actions
  /*
    context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Config Folder', () => {
      try {
        window.api.shell.openFile(CONFIG_PATH_BFG);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
      }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    });
    context.registerAction('mod-icons', 300, 'open-ext', {}, 'Open Saves Folder', () => {
      try {
        window.api.shell.openFile(SAVE_PATH_BFG);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, { allowReport: false });
      }
    }, () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    }); //*/
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open PCGamingWiki Page",
    () => {
      try {
        window.api.shell.openUrl(PCGAMINGWIKI_URL);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Nexus Mods Page",
    () => {
      try {
        window.api.shell.openUrl(`https://www.nexusmods.com/${GAME_ID}/mods`);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open SteamDB Page",
    () => {
      try {
        window.api.shell.openUrl(STEAMDB_URL_BFG);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the URL", err, { allowReport: false });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "View Changelog",
    () => {
      const openPath = path.join(__dirname, "CHANGELOG.md");
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    },
  );
  context.registerAction(
    "mod-icons",
    300,
    "open-ext",
    {},
    "Open Downloads Folder",
    () => {
      const openPath = DOWNLOAD_FOLDER_BFG;
      try {
        window.api.shell.openFile(openPath);
      } catch (err) {
        context.api.showErrorNotification("Failed to open the file or folder", err, {
          allowReport: false,
        });
      }
    },
    () => {
      const state = context.api.getState();
      const gameId = selectors.activeGameId(state);
      return gameId === GAME_ID_BFG;
    },
  );
}

//Main function
function main(context) {
  applyGame(context, spec);
  applyGameBfg(context, specBfg);
  context.once(() => {
    //run (once) when Vortex starts up
    const api = context.api;
    api.onAsync("check-mods-version", (gameId, mods, forced) => {
      if (gameId !== GAME_ID) return;
      return onCheckModVersion(api, gameId, mods, forced);
    }); //*/
    if (moddbBrowser) {
      //installs downloads started from the browse page, and update-checks the mods installed through it
      onceModDbBrowser(api, spec, MODDB_BROWSER_CONFIG);
    }
    if (gamebananaBrowser) {
      //claims downloads started from the browse page, and update-checks the mods installed through it
      onceGameBananaBrowser(api, spec, GB_BROWSER_CONFIG);
    }
  });
  return true;
}

//export to Vortex
module.exports = {
  default: main,
};
