# Changelog

## [1.2.1] - 2026-11-06

- Fixed: A UE4SS installed manually (outside Vortex) is now detected, so the UE4SS and LogicMods load orders and the UE4SS settings update work with it.

## [1.2.0] - 2026-11-05

- Changed: LogicMods (Blueprint) mods now always install directly into the LogicMods folder. Installed mods convert automatically when you next manage the game. Deploy when prompted.
- Added: A notification when a pak mod looks like a Blueprint mod, with a button to set it as a LogicMods mod.

## [1.1.5] - 2026-11-01

- Changed: Internal cleanup of how file paths are handled. No change to how mods install.

## [1.1.4] - 2026-10-25

- Added the Nexus mod ID to the extension info.

## [1.1.3] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.1.2] - 2026-10-12

- Fixed: Mods packaged inside an outer folder whose name ends with the name of an expected folder (for example "MyContent" for "Content") now install into the right place instead of keeping part of the outer folder's name.
- Fixed: Blueprint (LogicMods) mods with an upper-case ".PAK" extension now get the correct name on the LogicMods load order.
- Fixed: The "Open LogicMods Folder" button now opens the LogicMods folder instead of the Paks folder.

## [1.1.1] - 2026-09-26

- Game version now shows the real game build instead of the Unreal engine version.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.

## [1.1.0] - 2026-09-20

- Dropped the Unreal Engine Mod Installer (UEMI) dependency - pak mod installation is now self-contained, and existing pak mods migrate automatically on update
- Added support for a FOMOD-packaged pak mod to correctly appear on the Load Order page

## [1.0.0] - 2026-09-18

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- Migrated the pak load order page to Vortex's newer file-based system, adding a lock button, multi-select, and a right-click context menu.
- Added dedicated UE4SS Load Order and LogicMods Load Order pages, so script/DLL and LogicMods pak mods can now be reordered directly instead of relying on install order alone.
- Added an auto-downloader for UE4SS.

## [0.4.1] - 2026-07-20

- Added: Set engine version in UE4SS-settings.ini file if UE4SS is installed.

## [0.4.0] - 2026-01-31

- Added: Full UE4SS and dependent mod support
- Added: Buttons to open multiple files and folders
- Fixed: path strings
