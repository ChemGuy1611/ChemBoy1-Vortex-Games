# Changelog

## FUTURE CHANGES (NOT YET IMPLEMENTED)

- None Planned

## [0.4.0] - 2026-01-31

- Added: Full UE4SS and dependent mod support
- Added: Buttons to open multiple files and folders
- Fixed: path strings
