# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.2] - 2025-12-03

- Fixed undefined argument in path.join error when installing extension (oops).

## [0.1.1] - 2025-12-02

- Small improvement to DXHR Patcher installer to remove unnecessary files from staging folder.

## [0.1.0] - 2025-09-29

- Inital Release
