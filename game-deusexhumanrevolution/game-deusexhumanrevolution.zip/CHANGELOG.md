# Changelog

## Planned Improvements (Not Yet Released)

- None Planned

## [0.1.1] - 2025-12-02

- Small improvement to DXHR Patcher installer to remove unnecessary files from staging folder.

## [0.1.0] - 2025-09-29

- Inital Release
