# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.1.8] - 2025-09-19

- Added Epic Games ID and full support.
