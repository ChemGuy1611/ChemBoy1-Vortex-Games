# Changelog

## [1.0.1] - 2026-10-16

- Added the game's Nexus Mods ID to the extension's info file.

## [1.0.0] - 2026-10-12

- Fixed: Mod files with no file extension were skipped during installation
- Added an "Open SteamDB Page" button next to the PCGamingWiki one.
- The various "Open X Folder"/"Open X Page" buttons now show an error message if the folder or page can't be opened, instead of failing silently.
- Fixed: Mods packaged inside an outer folder whose name contains the name of the mod's own folder or file (for example "MyData" for "Data") now install into the right place.

## [0.2.0] - 2025-10-02

- Enhanced psarc mod installer to handle mods with psarc files in multile folders or with variants of the same psarc file name.
- Added custom launch tool.
- Added buttons to open Config & Save folders, changelog, and Vortex downloads folder (folder icon in Mods toolbar).

## [0.1.8] - 2025-09-19

- Added Epic Games ID and full support.
- General technical improvements.
