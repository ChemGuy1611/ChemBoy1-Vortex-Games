# Changelog

## Future Improvements (Not Yet Released)

- None Planned

## [0.2.0] - 2025-10-02

- Enhanced psarc mod installer to handle mods with psarc files in multile folders or with variants of the same psarc file name.
- Added custom launch tool.
- Added buttons to open Config & Save folders, changelog, and Vortex downloads folder  (folder icon in Mods toolbar).

## [0.1.8] - 2025-09-19

- Added Epic Games ID and full support.
- General technical improvements.
