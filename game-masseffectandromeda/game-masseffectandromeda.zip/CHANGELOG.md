# Changelog

## Future Changes (NOT IMPLEMENTED YET)

- None Planned

## [0.3.0] - 2026-02-18

- Fixed: Path strings
- Added: Buttons to open several files/folders/URLs

## [0.2.1] - 2025-04-10

- Fixed typo in display name of Frosty Mod Manager tool.
- Corrected capitalization of Frosty Mods folder to match the default.
- Added colon to game title to be technically correct.
- Added buttons to open config folder - folder icon in Mods toolbar.

## [0.2.0] - 2025-04-09

- Added notification to run Frosty Mod Manager after deployment.
- Added missing folder write check for Frosty mods.
- Added buttons to open Frosty mods folder, Vortex Downloads folder, and the Changelog - folder icon in Mods toolbar.
- Other technical fixes.
